<?php
// =============================================================================
// ChrisMES - index.php (Dashboard)
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/includes/functions.php';
require_login();

$page_title = 'Dashboard';
$user = current_user();
$org_id = user_org_id();
$org_clause = $org_id ? 'AND wo.org_id = ?' : '';
$params = $org_id ? [$org_id] : [];

// KPIs
$kpi_open = db_row("SELECT COUNT(*) AS cnt FROM work_orders wo WHERE wo.status IN ('Open','In Progress') $org_clause", $params);
$kpi_holds = db_row("SELECT COUNT(*) AS cnt FROM work_orders wo WHERE wo.status IN ('Hard Hold','Soft Hold') $org_clause", $params);
$kpi_nc = db_row("SELECT COUNT(*) AS cnt FROM nonconformances nc WHERE nc.status = 'Open'" . ($org_id ? ' AND nc.org_id = ?' : ''), $params);
$kpi_clocked = db_row("SELECT COUNT(DISTINCT cl.user_id) AS cnt FROM clock_events cl JOIN work_order_serials ws ON ws.id = cl.wo_serial_id JOIN work_orders wo ON wo.id = ws.wo_id WHERE cl.clock_off IS NULL $org_clause", $params);

// Skills expiring in 30 days (for Training Managers)
$skills_expiring = [];
if (has_role('QUALITY_TRAINING_MANAGER', 'IT_ADMIN')) {
    $skills_expiring = db_rows(
        "SELECT u.known_as, s.name AS skill_name, ts.expiry_date
         FROM user_skills ts
         JOIN users u ON u.id = ts.user_id
         JOIN skills s ON s.id = ts.skill_id
         WHERE ts.status = 'Approved'
           AND ts.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
         ORDER BY ts.expiry_date ASC
         LIMIT 10"
    );
}

// Recent work orders
$recent_wos = db_rows(
    "SELECT wo.wo_number, wo.status, p.part_number, p.description, wo.created_at
     FROM work_orders wo
     JOIN parts p ON p.id = wo.part_id
     WHERE 1=1 $org_clause
     ORDER BY wo.created_at DESC LIMIT 8",
    $params
);

include __DIR__ . '/includes/header.php';
?>

<div class="row g-4 mb-4">
    <!-- KPI cards -->
    <div class="col-6 col-md-3">
        <div class="card card-kpi h-100">
            <div class="card-body">
                <div class="kpi-value text-primary"><?= (int)($kpi_open['cnt'] ?? 0) ?></div>
                <div class="kpi-label">Active Work Orders</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card card-kpi h-100">
            <div class="card-body">
                <div class="kpi-value text-danger"><?= (int)($kpi_holds['cnt'] ?? 0) ?></div>
                <div class="kpi-label">Work Orders on Hold</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card card-kpi h-100">
            <div class="card-body">
                <div class="kpi-value text-warning"><?= (int)($kpi_nc['cnt'] ?? 0) ?></div>
                <div class="kpi-label">Open Non-Conformances</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card card-kpi h-100">
            <div class="card-body">
                <div class="kpi-value text-success"><?= (int)($kpi_clocked['cnt'] ?? 0) ?></div>
                <div class="kpi-label">Operators Clocked On</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Recent WOs -->
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="fw-semibold"><i class="bi bi-card-list me-2"></i>Recent Work Orders</span>
                <a href="/chrismes/workorders/index.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light">
                        <tr><th>WO Number</th><th>Part</th><th>Description</th><th>Status</th><th>Created</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recent_wos as $wo): ?>
                    <tr>
                        <td><a href="/chrismes/workorders/view.php?id=<?= h($wo['wo_number']) ?>" class="fw-semibold"><?= h($wo['wo_number']) ?></a></td>
                        <td><?= h($wo['part_number']) ?></td>
                        <td><?= h($wo['description']) ?></td>
                        <td><span class="badge <?= wo_status_badge($wo['status']) ?>"><?= h($wo['status']) ?></span></td>
                        <td><?= date('d M y', strtotime($wo['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($recent_wos)): ?>
                    <tr><td colspan="5" class="text-muted text-center py-3">No work orders yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Quick links + Skills expiry -->
    <div class="col-lg-5">
        <div class="card mb-4">
            <div class="card-header fw-semibold"><i class="bi bi-lightning-charge me-2"></i>Quick Actions</div>
            <div class="card-body d-grid gap-2">
                <a href="/chrismes/operator/index.php" class="btn btn-outline-primary">
                    <i class="bi bi-play-circle me-2"></i>Operator Screen
                </a>
                <a href="/chrismes/supervisor/index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-display me-2"></i>Supervisor View
                </a>
                <?php if (has_role('IT_ADMIN','SUPERVISOR')): ?>
                <a href="/chrismes/workorders/create.php" class="btn btn-outline-success">
                    <i class="bi bi-plus-circle me-2"></i>New Work Order
                </a>
                <?php endif; ?>
                <a href="/chrismes/quality/nonconformances.php" class="btn btn-outline-warning">
                    <i class="bi bi-exclamation-triangle me-2"></i>Non-Conformances
                </a>
            </div>
        </div>

        <?php if ($skills_expiring): ?>
        <div class="card border-warning">
            <div class="card-header fw-semibold text-warning">
                <i class="bi bi-clock-history me-2"></i>Skills Expiring Soon
            </div>
            <ul class="list-group list-group-flush small">
            <?php foreach ($skills_expiring as $sk): ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span><?= h($sk['known_as']) ?> — <?= h($sk['skill_name']) ?></span>
                    <span class="text-danger fw-semibold"><?= date('d M y', strtotime($sk['expiry_date'])) ?></span>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php
function wo_status_badge(string $status): string {
    return match($status) {
        'Open'       => 'bg-primary',
        'In Progress'=> 'bg-warning text-dark',
        'Hard Hold'  => 'bg-danger',
        'Soft Hold'  => 'bg-warning text-dark',
        'Complete'   => 'bg-success',
        'Cancelled'  => 'bg-secondary',
        default      => 'bg-secondary',
    };
}
include __DIR__ . '/includes/footer.php';
?>
