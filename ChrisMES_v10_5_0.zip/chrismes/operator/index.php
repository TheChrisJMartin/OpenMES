<?php
// =============================================================================
// ChrisMES - operator/index.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Operator Screen';

$user    = current_user();
$user_id = $user['id'];
$org_id  = user_org_id();

// ── Handle actions ────────────────────────────────────────────────────────────
$action = $_POST['action'] ?? '';

if ($action === 'clock_on') {
    $wo_serial_ids = array_filter(array_map('intval', explode(',', $_POST['serial_ids'] ?? '')));
    if ($wo_serial_ids) {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            foreach ($wo_serial_ids as $ws_id) {
                $ws = db_row('SELECT ws.*,wo.routing_id,wo.id AS wo_id FROM work_order_serials ws JOIN work_orders wo ON wo.id=ws.wo_id WHERE ws.id=? FOR UPDATE',[$ws_id]);
                if (!$ws || $ws['status'] !== 'Available') continue;

                // Skill gate check
                $op = db_row('SELECT * FROM routing_operations WHERE id=?',[$ws['current_op_id']]);
                if ($op && $op['skill_id']) {
                    $skill_ok = db_row("SELECT id FROM user_skills WHERE user_id=? AND skill_id=? AND status='Approved' AND (expiry_date IS NULL OR expiry_date >= CURDATE())",[$user_id,$op['skill_id']]);
                    if (!$skill_ok) {
                        flash_set('danger','Skill gate: you lack the required approved skill for this operation.');
                        $pdo->rollBack(); header('Location: /chrismes/operator/index.php'); exit;
                    }
                }

                // Close any hanging clock-on for this serial
                db_exec("UPDATE clock_events SET clock_off=NOW() WHERE wo_serial_id=? AND clock_off IS NULL",[$ws_id]);

                db_exec('INSERT INTO clock_events (wo_id,wo_serial_id,routing_op_id,user_id,clock_on) VALUES (?,?,?,?,NOW())',
                    [$ws['wo_id'],$ws_id,$ws['current_op_id'],$user_id]);
                db_exec("UPDATE work_order_serials SET status='In Progress' WHERE id=?",[$ws_id]);
                db_exec("UPDATE work_orders SET status='In Progress' WHERE id=? AND status='Open'",[$ws['wo_id']]);
            }
            $pdo->commit();
            flash_set('success','Clocked on successfully.');
        } catch (Exception $e) {
            $pdo->rollBack();
            flash_set('danger','Clock-on failed: '.$e->getMessage());
        }
    }
    header('Location: /chrismes/operator/index.php?wo='.$_POST['wo_number']); exit;
}

if ($action === 'clock_off') {
    $wo_serial_ids = array_filter(array_map('intval', explode(',', $_POST['serial_ids'] ?? '')));
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($wo_serial_ids as $ws_id) {
            db_exec("UPDATE clock_events SET clock_off=NOW() WHERE wo_serial_id=? AND user_id=? AND clock_off IS NULL",[$ws_id,$user_id]);
            db_exec("UPDATE work_order_serials SET status='Available' WHERE id=? AND status='In Progress'",[$ws_id]);
        }
        $pdo->commit();
        flash_set('success','Clocked off.');
    } catch (Exception $e) {
        $pdo->rollBack();
        flash_set('danger','Clock-off failed: '.$e->getMessage());
    }
    header('Location: /chrismes/operator/index.php?wo='.$_POST['wo_number']); exit;
}

if ($action === 'complete_op') {
    $wo_serial_ids = array_filter(array_map('intval', explode(',', $_POST['serial_ids'] ?? '')));
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($wo_serial_ids as $ws_id) {
            $ws = db_row('SELECT ws.*,wo.routing_id,wo.id AS wo_id FROM work_order_serials ws JOIN work_orders wo ON wo.id=ws.wo_id WHERE ws.id=? FOR UPDATE',[$ws_id]);
            if (!$ws) continue;

            // Clock off first
            db_exec("UPDATE clock_events SET clock_off=NOW() WHERE wo_serial_id=? AND user_id=? AND clock_off IS NULL",[$ws_id,$user_id]);

            // Find next op
            $current_op = db_row('SELECT * FROM routing_operations WHERE id=?',[$ws['current_op_id']]);
            $next_op = db_row('SELECT * FROM routing_operations WHERE routing_id=? AND op_number > ? ORDER BY op_number ASC LIMIT 1',
                [$ws['routing_id'], $current_op['op_number']]);

            if ($next_op) {
                db_exec('UPDATE work_order_serials SET current_op_id=?,status=? WHERE id=?',[$next_op['id'],'Available',$ws_id]);
            } else {
                // No more ops — serial complete
                db_exec("UPDATE work_order_serials SET status='Complete' WHERE id=?",[$ws_id]);
                // Check if all serials complete
                $remaining = db_row('SELECT COUNT(*) AS cnt FROM work_order_serials WHERE wo_id=? AND status!=?',[$ws['wo_id'],'Complete']);
                if ((int)$remaining['cnt'] === 0) {
                    db_exec("UPDATE work_orders SET status='Complete',completed_at=NOW() WHERE id=?",[$ws['wo_id']]);
                    audit_log('work_order',$ws['wo_id'],'COMPLETE','All serials complete');
                }
            }
            audit_log('work_order_serial',$ws_id,'COMPLETE_OP',"Op {$current_op['op_number']} completed by {$user['username']}");
        }
        $pdo->commit();
        flash_set('success','Operation completed. Serials advanced.');
    } catch (Exception $e) {
        $pdo->rollBack();
        flash_set('danger','Complete failed: '.$e->getMessage());
    }
    header('Location: /chrismes/operator/index.php?wo='.$_POST['wo_number']); exit;
}

if ($action === 'save_quality') {
    $ws_id    = (int)$_POST['ws_id'];
    $wo_id    = (int)$_POST['wo_id'];
    $results  = $_POST['qv'] ?? [];
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($results as $qv_id => $value) {
            $qv = db_row('SELECT * FROM quality_variables WHERE id=?',[(int)$qv_id]);
            if (!$qv) continue;
            $val = (float)$value;
            $in_spec = 1;
            if ($qv['lower_limit'] !== null && $val < (float)$qv['lower_limit']) $in_spec = 0;
            if ($qv['upper_limit'] !== null && $val > (float)$qv['upper_limit']) $in_spec = 0;
            // Upsert
            db_exec('INSERT INTO quality_results (wo_id,wo_serial_id,quality_var_id,value,in_spec,recorded_by,recorded_at)
                     VALUES (?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE value=?,in_spec=?,recorded_by=?,recorded_at=NOW()',
                [$wo_id,$ws_id,(int)$qv_id,$val,$in_spec,$user_id,$val,$in_spec,$user_id]);
        }
        $pdo->commit();
        flash_set('success','Quality results saved.');
    } catch (Exception $e) {
        $pdo->rollBack();
        flash_set('danger','Failed to save: '.$e->getMessage());
    }
    header('Location: /chrismes/operator/index.php?wo='.$_POST['wo_number']); exit;
}

// ── Load WO ───────────────────────────────────────────────────────────────────
$wo_number = $_GET['wo'] ?? $_POST['wo_number'] ?? '';
$wo = null;
$serials = [];
$my_clocked = [];

if ($wo_number) {
    $wo = db_row('SELECT wo.*,p.part_number,p.description,p.serial_controlled,o.code AS org_code
                  FROM work_orders wo JOIN parts p ON p.id=wo.part_id JOIN orgs o ON o.id=wo.org_id
                  WHERE wo.wo_number=?', [$wo_number]);
    if ($wo) {
        // Org wall
        if ($org_id && $wo['org_id'] != $org_id) { $wo = null; }
        if ($wo) {
            $serials = db_rows(
                'SELECT ws.*,ro.op_number,ro.op_name,ro.op_type,ro.behaviour,ro.doc_rev_id,dr.filename,dr.revision_number,doc.description AS doc_desc,
                        ce.id AS event_id,ce.user_id AS clocked_user,UNIX_TIMESTAMP(ce.clock_on) AS clock_on_ts
                 FROM work_order_serials ws
                 JOIN routing_operations ro ON ro.id=ws.current_op_id
                 LEFT JOIN document_revisions dr ON dr.id=ro.doc_rev_id
                 LEFT JOIN documents doc ON doc.id=dr.doc_id
                 LEFT JOIN clock_events ce ON ce.wo_serial_id=ws.id AND ce.clock_off IS NULL
                 WHERE ws.wo_id=? ORDER BY ws.serial_number',
                [$wo['id']]
            );
            $my_clocked = array_filter($serials, fn($s) => $s['clocked_user'] == $user_id);
        }
    }
}

// ── WO search list ────────────────────────────────────────────────────────────
$open_wos = db_rows(
    "SELECT wo.wo_number,p.part_number,wo.status,wo.quantity
     FROM work_orders wo JOIN parts p ON p.id=wo.part_id
     WHERE wo.status IN ('Open','In Progress') " . ($org_id ? 'AND wo.org_id=?' : '') . "
     ORDER BY wo.priority ASC, wo.created_at DESC LIMIT 50",
    $org_id ? [$org_id] : []
);

include __DIR__ . '/../includes/header.php';
?>

<div class="row g-4">
    <!-- ── WO selector ── -->
    <div class="col-lg-3">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-search me-2"></i>Select Work Order</div>
            <div class="card-body p-2">
                <form method="get" class="mb-2 d-flex gap-2">
                    <input type="text" name="wo" class="form-control form-control-sm" placeholder="WO Number…" value="<?= h($wo_number) ?>">
                    <button class="btn btn-sm btn-primary">Go</button>
                </form>
            </div>
            <div class="list-group list-group-flush small" style="max-height:450px;overflow-y:auto">
            <?php foreach ($open_wos as $ow): ?>
                <a href="?wo=<?= urlencode($ow['wo_number']) ?>"
                   class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= $ow['wo_number']===$wo_number?'active':'' ?>">
                    <span class="fw-semibold"><?= h($ow['wo_number']) ?></span>
                    <span class="badge <?= $ow['status']==='In Progress'?'bg-warning text-dark':'bg-primary' ?>"><?= h($ow['status']) ?></span>
                </a>
            <?php endforeach; ?>
            <?php if (empty($open_wos)): ?><div class="p-3 text-muted">No open WOs.</div><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ── Main panel ── -->
    <div class="col-lg-9">
        <?php if (!$wo): ?>
        <div class="card">
            <div class="card-body text-center py-5 text-muted">
                <i class="bi bi-play-circle fs-1 d-block mb-3"></i>
                Select a work order from the list, or enter a WO number.
            </div>
        </div>
        <?php else: ?>

        <!-- WO Header -->
        <div class="card mb-3">
            <div class="card-body d-flex align-items-center gap-4">
                <div>
                    <h5 class="mb-1"><?= h($wo['wo_number']) ?> <span class="badge <?= in_array($wo['status'],['Complete','Cancelled'])?'bg-success':'bg-primary' ?>"><?= h($wo['status']) ?></span></h5>
                    <div class="text-muted small"><?= h($wo['part_number']) ?> — <?= h($wo['description']) ?></div>
                </div>
                <div class="ms-auto text-end small">
                    <div><strong>Qty:</strong> <?= h($wo['quantity']) ?></div>
                    <div><strong>Type:</strong> <?= $wo['serial_controlled'] ? 'Serialised' : 'Lot' ?></div>
                </div>
                <?php if ($my_clocked): ?>
                <div id="live-clock-wrap" class="text-end">
                    <div class="text-muted small">Active</div>
                    <div id="live-clock" class="fs-4 fw-bold text-success font-monospace"
                         data-start="<?= min(array_column(iterator_to_array((function() use ($my_clocked) { foreach ($my_clocked as $s) yield $s; })()),'clock_on_ts')) ?>">00:00:00</div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Serial chips -->
        <div class="card mb-3">
            <div class="card-header d-flex align-items-center gap-3 flex-wrap">
                <span class="fw-semibold"><i class="bi bi-grid-3x3-gap me-2"></i>Serials / Lots</span>
                <button class="btn btn-sm btn-outline-success" onclick="selectAllSerials('available')">Select Available</button>
                <button class="btn btn-sm btn-outline-primary" onclick="selectAllSerials('mine')">Select Mine</button>
                <button class="btn btn-sm btn-outline-secondary" onclick="clearSerialSelection()">Clear</button>
                <span class="ms-auto small text-muted"><span id="selected_count">0</span> selected</span>
            </div>
            <div class="card-body">
                <div class="serial-grid" id="serialGrid">
                <?php foreach ($serials as $s):
                    $chip_class = 'serial-available';
                    if ($s['status'] === 'In Progress') {
                        $chip_class = ($s['clocked_user'] == $user_id) ? 'serial-mine' : 'serial-in-use';
                    }
                    if ($s['behaviour'] === 'Non-Clocking') $chip_class = 'serial-non-clock';
                    if ($s['status'] === 'Complete') $chip_class = 'serial-complete';
                    if ($s['status'] === 'Hold') $chip_class = 'serial-hold';
                    if ($s['status'] === 'Scrapped') $chip_class = 'serial-scrapped';
                    $clickable = in_array($chip_class,['serial-available','serial-mine']);
                ?>
                <span class="serial-chip <?= $chip_class ?>"
                      data-serial="<?= h($s['serial_number']) ?>"
                      data-ws-id="<?= $s['id'] ?>"
                      data-op="<?= h($s['op_name']) ?>"
                      data-op-type="<?= h($s['op_type']) ?>"
                      data-doc="<?= $s['doc_rev_id'] ? '/chrismes/uploads/documents/'.h($s['filename']) : '' ?>"
                      title="<?= h($s['serial_number']) ?> | Op: <?= h($s['op_name']) ?> | <?= h($s['status']) ?>">
                    <?= h($s['serial_number']) ?>
                </span>
                <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Action buttons -->
        <?php $has_sel_non_nc = true; ?>
        <div class="row g-3 mb-3">
            <div class="col-auto">
                <form method="post">
                    <input type="hidden" name="action" value="clock_on">
                    <input type="hidden" name="wo_number" value="<?= h($wo_number) ?>">
                    <input type="hidden" name="serial_ids" id="selected_serials_clockon" value="">
                    <button type="submit" class="btn btn-success serial-action-btn" disabled
                            onclick="syncIds('selected_serials_clockon')">
                        <i class="bi bi-play-fill me-1"></i>Clock On
                    </button>
                </form>
            </div>
            <div class="col-auto">
                <form method="post">
                    <input type="hidden" name="action" value="clock_off">
                    <input type="hidden" name="wo_number" value="<?= h($wo_number) ?>">
                    <input type="hidden" name="serial_ids" id="selected_serials_clockoff" value="">
                    <button type="submit" class="btn btn-warning serial-action-btn" disabled
                            onclick="syncIds('selected_serials_clockoff')">
                        <i class="bi bi-stop-fill me-1"></i>Clock Off
                    </button>
                </form>
            </div>
            <div class="col-auto">
                <form method="post">
                    <input type="hidden" name="action" value="complete_op">
                    <input type="hidden" name="wo_number" value="<?= h($wo_number) ?>">
                    <input type="hidden" name="serial_ids" id="selected_serials_complete" value="">
                    <button type="submit" class="btn btn-primary serial-action-btn" disabled
                            data-confirm="Mark selected operations complete and advance to next op?"
                            onclick="syncIds('selected_serials_complete')">
                        <i class="bi bi-check-circle me-1"></i>Complete Op
                    </button>
                </form>
            </div>
            <?php if ($my_clocked): ?>
            <div class="col-auto ms-auto">
                <a href="/chrismes/quality/nonconformances.php?wo=<?= urlencode($wo_number) ?>&new=1"
                   class="btn btn-outline-danger">
                    <i class="bi bi-exclamation-triangle me-1"></i>Raise NC
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Document viewer -->
        <?php
        $first_doc = null;
        foreach ($serials as $s) { if ($s['doc_rev_id']) { $first_doc = $s; break; } }
        if ($first_doc): ?>
        <div class="card mb-3">
            <div class="card-header fw-semibold d-flex align-items-center gap-3">
                <i class="bi bi-file-earmark-pdf me-1"></i>Work Instruction
                <span class="small text-muted"><?= h($first_doc['doc_desc']) ?> Rev <?= format_revision((int)$first_doc['revision_number']) ?></span>
            </div>
            <div id="pdf-viewer-container">
                <iframe src="/chrismes/uploads/documents/<?= h($first_doc['filename']) ?>"></iframe>
            </div>
        </div>
        <?php endif; ?>

        <!-- Quality data entry for inspection ops in my clocked serials -->
        <?php foreach ($my_clocked as $mcs):
            if (!in_array($mcs['op_type'],['Inspection','Final Test','Final Inspection'])) continue;
            $qvars = db_rows('SELECT qv.*,u.code AS uom_code FROM quality_variables qv JOIN units_of_measure u ON u.id=qv.uom_id WHERE qv.op_id=?',[$mcs['current_op_id']]);
            if (!$qvars) continue;
            $prev_results = db_rows('SELECT * FROM quality_results WHERE wo_serial_id=? AND wo_id=?',[$mcs['id'],$wo['id']]);
            $prev_map = array_column($prev_results,'value','quality_var_id');
        ?>
        <div class="card mb-3">
            <div class="card-header fw-semibold">
                <i class="bi bi-clipboard-data me-2"></i>Quality Data — <?= h($mcs['serial_number']) ?> — Op <?= str_pad((int)$mcs['op_number'],3,'0',STR_PAD_LEFT) ?> <?= h($mcs['op_name']) ?>
            </div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="action" value="save_quality">
                    <input type="hidden" name="wo_number" value="<?= h($wo_number) ?>">
                    <input type="hidden" name="ws_id" value="<?= $mcs['id'] ?>">
                    <input type="hidden" name="wo_id" value="<?= $wo['id'] ?>">
                    <?php foreach ($qvars as $qv):
                        $prev_val = $prev_map[$qv['id']] ?? '';
                    ?>
                    <div class="quality-measurement-row mb-3">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <strong><?= h($qv['name']) ?></strong>
                            <span class="badge bg-secondary"><?= h($qv['code']) ?></span>
                            <span class="text-muted small"><?= h($qv['uom_code']) ?></span>
                            <?php if ($qv['lower_limit'] !== null && $qv['upper_limit'] !== null): ?>
                            <span class="text-muted small">Spec: <?= h($qv['lower_limit']) ?> – <?= h($qv['upper_limit']) ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ($qv['lower_limit'] !== null && $qv['upper_limit'] !== null): ?>
                        <div class="spec-bar mb-2" id="spec-bar-<?= $qv['id'] ?>">
                            <div class="spec-range" style="left:0%;width:100%"></div>
                            <div class="spec-pointer<?= ($prev_val !== '' && (float)$prev_val >= (float)$qv['lower_limit'] && (float)$prev_val <= (float)$qv['upper_limit']) ? ' in-spec' : '' ?>"
                                 style="left:<?= $prev_val !== '' ? min(100,max(0,((float)$prev_val-(float)$qv['lower_limit'])/((float)$qv['upper_limit']-(float)$qv['lower_limit'])*100)) : 50 ?>%"></div>
                        </div>
                        <?php endif; ?>
                        <input type="number" step="any"
                               name="qv[<?= $qv['id'] ?>]"
                               class="form-control quality-input"
                               data-var-id="<?= $qv['id'] ?>"
                               data-low="<?= h($qv['lower_limit'] ?? '') ?>"
                               data-high="<?= h($qv['upper_limit'] ?? '') ?>"
                               value="<?= h($prev_val) ?>"
                               placeholder="Enter measurement…">
                    </div>
                    <?php endforeach; ?>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Save Results</button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>

        <?php endif; ?>
    </div>
</div>

<script>
// Map chip data-ws-id to an input field so form can pick up correct IDs
function syncIds(fieldId) {
    const selected = [...document.querySelectorAll('.serial-chip.selected')].map(el => el.dataset.wsId);
    document.getElementById(fieldId).value = selected.join(',');
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
