<?php
// =============================================================================
// ChrisMES - api/toggle_dark_mode.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
require_login();
$u = current_user();
$new_val = $u['dark_mode'] ? 0 : 1;
db_exec('UPDATE users SET dark_mode=? WHERE id=?',[$new_val,$u['id']]);
$_SESSION['user']['dark_mode'] = (bool)$new_val;
echo json_encode(['dark_mode' => $new_val]);
