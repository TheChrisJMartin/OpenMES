<?php
// =============================================================================
// ChrisMES - api/integration_inbound.php
// Version: 10.5.0
// ERP integration endpoint. Accepts JSON POST with Bearer token auth.
// =============================================================================
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error'=>'Method not allowed']); exit;
}

// Bearer token auth — set INTEGRATION_TOKEN in config or env
$token = getenv('INTEGRATION_TOKEN') ?: (defined('INTEGRATION_TOKEN') ? INTEGRATION_TOKEN : null);
if ($token) {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!str_starts_with($auth,'Bearer ') || substr($auth,7) !== $token) {
        http_response_code(401); echo json_encode(['error'=>'Unauthorised']); exit;
    }
}

$raw     = file_get_contents('php://input');
$payload = json_decode($raw, true);
$tx_num  = $payload['transaction_number'] ?? ('AUTO-'.uniqid());
$msg_type= $payload['message_type'] ?? 'UNKNOWN';
$org_id  = (int)($payload['org_id'] ?? 0);

// Log the inbound message
db_exec('INSERT INTO integration_inbound (transaction_number,org_id,message_type,payload,status,received_at)
         VALUES (?,?,?,?,?,NOW())',[$tx_num,$org_id,$msg_type,$raw,'Received']);
$log_id = (int)db_last_id();

try {
    $result = process_inbound($msg_type, $payload, $org_id);
    db_exec("UPDATE integration_inbound SET status='Processed' WHERE id=?",[$log_id]);
    echo json_encode(['status'=>'ok','transaction_number'=>$tx_num,'detail'=>$result]);
} catch (Exception $e) {
    db_exec("UPDATE integration_inbound SET status='Error',error_message=? WHERE id=?",[$e->getMessage(),$log_id]);
    http_response_code(422);
    echo json_encode(['status'=>'error','transaction_number'=>$tx_num,'error'=>$e->getMessage()]);
}

function process_inbound(string $type, array $payload, int $org_id): string {
    require_once __DIR__ . '/../includes/functions.php';
    switch ($type) {
        case 'WO_CREATE':
            if (ALLOW_WO_CREATION) throw new RuntimeException('WO creation is in MES mode — ERP push is disabled.');
            $pn = strtoupper($payload['part_number'] ?? '');
            $part = db_row('SELECT * FROM parts WHERE part_number=? AND org_id=?',[$pn,$org_id]);
            if (!$part) throw new RuntimeException("Part {$pn} not found.");
            $routing = db_row("SELECT r.* FROM routings r WHERE r.part_id=? AND r.status='Approved' ORDER BY r.revision DESC LIMIT 1",[$part['id']]);
            if (!$routing) throw new RuntimeException("No approved routing for {$pn}.");
            $wo_num = generate_wo_number($payload['org_code'] ?? '');
            db_exec('INSERT INTO work_orders (org_id,part_id,routing_id,wo_number,status,quantity,serial_controlled,priority,planned_start,planned_finish,notes,created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())',
                [$org_id,$part['id'],$routing['id'],$wo_num,'Open',(int)$payload['quantity'],$part['serial_controlled'],
                 (int)($payload['priority']??50),$payload['planned_start']??null,$payload['planned_finish']??null,$payload['notes']??null]);
            return "WO {$wo_num} created.";

        case 'PART_SYNC':
            if (!PARTS_LOCKED) throw new RuntimeException('Parts not in ERP-lock mode. Enable PARTS_LOCKED in config.');
            $pn   = strtoupper($payload['part_number'] ?? '');
            $desc = $payload['description'] ?? '';
            $uom  = db_row('SELECT id FROM units_of_measure WHERE code=?',[$payload['uom'] ?? 'EA']);
            if (!$uom) throw new RuntimeException("UoM {$payload['uom']} not found.");
            $existing = db_row('SELECT id FROM parts WHERE part_number=? AND org_id=?',[$pn,$org_id]);
            if ($existing) {
                db_exec('UPDATE parts SET description=?,uom_id=?,revision=?,item_version=item_version+1,updated_at=NOW() WHERE id=?',
                    [$desc,$uom['id'],$payload['revision']??'A',$existing['id']]);
                return "Part {$pn} updated.";
            } else {
                db_exec('INSERT INTO parts (org_id,part_number,revision,description,uom_id,serial_controlled,make_buy,item_version,created_at) VALUES (?,?,?,?,?,?,?,1,NOW())',
                    [$org_id,$pn,$payload['revision']??'A',$desc,$uom['id'],(int)($payload['serial_controlled']??0),$payload['make_buy']??'Make']);
                return "Part {$pn} created.";
            }

        default:
            throw new RuntimeException("Unknown message type: {$type}");
    }
}
