<?php
// =============================================================================
// ChrisMES - supervisor/index.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Supervisor View';

$org_id = user_org_id();
$params = $org_id ? [$org_id] : [];
$org_w  = $org_id ? 'AND wo.org_id=?' : '';

// Active clock events
$clocked = db_rows(
    "SELECT ce.id,ce.clock_on,u.known_as,u.id AS uid,
            ws.serial_number,ro.op_number,ro.op_name,ro.op_type,
            wo.wo_number,p.part_number,p.description,o.code AS org_code
     FROM clock_events ce
     JOIN users u ON u.id=ce.user_id
     JOIN work_order_serials ws ON ws.id=ce.wo_serial_id
     JOIN routing_operations ro ON ro.id=ce.routing_op_id
     JOIN work_orders wo ON wo.id=ce.wo_id
     JOIN parts p ON p.id=wo.part_id
     JOIN orgs o ON o.id=wo.org_id
     WHERE ce.clock_off IS NULL $org_w
     ORDER BY ce.clock_on ASC",
    $params
);

// Work orders status summary
$wo_summary = db_rows(
    "SELECT wo.status,COUNT(*) AS cnt FROM work_orders wo WHERE wo.status NOT IN ('Complete','Cancelled') $org_w GROUP BY wo.status",
    $params
);
$wo_by_status = array_column($wo_summary,'cnt','status');

// NCs open
$nc_count = db_row("SELECT COUNT(*) AS cnt FROM nonconformances nc WHERE nc.status='Open'" . ($org_id?' AND nc.org_id=?':''), $params);

// Open NCs
$open_ncs = db_rows(
    "SELECT nc.nc_number,nc.description,nc.raised_at,wo.wo_number,o.code AS org_code
     FROM nonconformances nc LEFT JOIN work_orders wo ON wo.id=nc.wo_id JOIN orgs o ON o.id=nc.org_id
     WHERE nc.status='Open' $org_w ORDER BY nc.raised_at DESC LIMIT 10",
    $params
);

include __DIR__ . '/../includes/header.php';
?>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card card-kpi"><div class="card-body"><div class="kpi-value text-success"><?= count($clocked) ?></div><div class="kpi-label">Operators Active</div></div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card card-kpi"><div class="card-body"><div class="kpi-value text-primary"><?= (int)($wo_by_status['Open'] ?? 0) + (int)($wo_by_status['In Progress'] ?? 0) ?></div><div class="kpi-label">Active WOs</div></div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card card-kpi"><div class="card-body"><div class="kpi-value text-danger"><?= (int)($wo_by_status['Hard Hold'] ?? 0) + (int)($wo_by_status['Soft Hold'] ?? 0) ?></div><div class="kpi-label">On Hold</div></div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card card-kpi"><div class="card-body"><div class="kpi-value text-warning"><?= (int)$nc_count['cnt'] ?></div><div class="kpi-label">Open NCs</div></div></div>
    </div>
</div>

<div class="row g-4">
    <!-- Active operators -->
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-person-fill-check me-2"></i>Active Operators</div>
            <?php if ($clocked): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small align-middle">
                    <thead class="table-light"><tr><th>Operator</th><th>WO</th><th>Serial</th><th>Op</th><th>Clocked On</th><th>Duration</th></tr></thead>
                    <tbody>
                    <?php foreach ($clocked as $cl):
                        $dur = time() - strtotime($cl['clock_on']);
                    ?>
                    <tr>
                        <td><strong><?= h($cl['known_as']) ?></strong></td>
                        <td><code><?= h($cl['wo_number']) ?></code></td>
                        <td><code><?= h($cl['serial_number']) ?></code></td>
                        <td><?= str_pad((int)$cl['op_number'],3,'0',STR_PAD_LEFT) ?> <?= h($cl['op_name']) ?>
                            <span class="badge bg-info text-dark small"><?= h($cl['op_type']) ?></span></td>
                        <td><?= date('H:i', strtotime($cl['clock_on'])) ?></td>
                        <td class="fw-semibold font-monospace text-success"><?= fmt_duration($dur) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="card-body text-muted text-center py-4">
                <i class="bi bi-person-slash fs-2 d-block mb-2"></i>No operators currently clocked on.
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Open NCs -->
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header fw-semibold text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Open NCs</div>
            <?php if ($open_ncs): ?>
            <ul class="list-group list-group-flush small">
            <?php foreach ($open_ncs as $nc): ?>
                <li class="list-group-item">
                    <div class="d-flex justify-content-between">
                        <code class="text-danger"><?= h($nc['nc_number']) ?></code>
                        <small class="text-muted"><?= date('d M y', strtotime($nc['raised_at'])) ?></small>
                    </div>
                    <div class="text-truncate"><?= h($nc['description']) ?></div>
                    <?php if ($nc['wo_number']): ?><small class="text-muted">WO: <?= h($nc['wo_number']) ?></small><?php endif; ?>
                </li>
            <?php endforeach; ?>
            </ul>
            <div class="card-footer"><a href="/chrismes/quality/nonconformances.php?status=Open" class="btn btn-sm btn-outline-danger">View All Open NCs</a></div>
            <?php else: ?>
            <div class="card-body text-success text-center"><i class="bi bi-check-circle fs-2 d-block mb-2"></i>No open NCs.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Auto-refresh every 60s
setTimeout(() => location.reload(), 60000);
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
