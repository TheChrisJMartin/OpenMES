<?php
// =============================================================================
// ChrisMES - logout.php
// Version: 10.5.0
// =============================================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

session_start();

if ($u = current_user()) {
    require_once __DIR__ . '/db.php';
    security_log('LOGOUT', 'Low', "User {$u['username']} logged out", $u['id']);
}

session_destroy();
header('Location: /chrismes/login.php');
exit;
