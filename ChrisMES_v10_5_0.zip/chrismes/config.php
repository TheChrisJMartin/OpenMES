<?php
// =============================================================================
// ChrisMES - config.php
// Version: 10.5.0
// Central configuration file. Edit settings here before going live.
// =============================================================================

// ---------------------------------------------------------------------------
// System Identity
// ---------------------------------------------------------------------------
define('SITE_NAME',        'ChrisMES');
define('SITE_VERSION',     '10.5.0');
define('SITE_URL',         'https://chris-martin.co.uk/chrismes');
define('SITE_TIMEZONE',    'Europe/London');   // Observes GMT/BST automatically

// ---------------------------------------------------------------------------
// Database Connection
// ---------------------------------------------------------------------------
define('DB_HOST',     'localhost');
define('DB_NAME',     'chrismes');
define('DB_USER',     'chrismes_user');
define('DB_PASS',     'changeme');
define('DB_CHARSET',  'utf8mb4');

// ---------------------------------------------------------------------------
// Test / Development Mode
// ---------------------------------------------------------------------------
// TEST_MODE = true  → test accounts may log in using their username as password.
// SET THIS TO false BEFORE GOING LIVE.
define('TEST_MODE', true);

// ---------------------------------------------------------------------------
// Work Order Controls
// ---------------------------------------------------------------------------
// Set false when ERP is mastering work orders via integration.
define('ALLOW_WO_CREATION', true);

// Maximum items per work order
define('MAX_SERIALS_PER_WO',   100);
define('MAX_LOT_QTY_PER_WO', 1000);

// ---------------------------------------------------------------------------
// Item Master Controls
// ---------------------------------------------------------------------------
// Set true when ERP integration is mastering parts — prevents manual edits.
define('PARTS_LOCKED', false);

// ---------------------------------------------------------------------------
// Organisation / Department / Resource Controls
// ---------------------------------------------------------------------------
define('ORGS_LOCKED',        false);
define('DEPTS_LOCKED',       false);
define('RESOURCES_LOCKED',   false);

// ---------------------------------------------------------------------------
// Document & Routing Approval
// ---------------------------------------------------------------------------
// AUTO_APPROVE = true  → IT Admin can approve without a second user.
// Set false to enforce two-person approval in production.
define('AUTO_APPROVE', true);

// ---------------------------------------------------------------------------
// Session & Security
// ---------------------------------------------------------------------------
define('SESSION_LIFETIME',   3600);   // seconds (1 hour)
define('BCRYPT_COST',           12);

// ---------------------------------------------------------------------------
// Apply Timezone
// ---------------------------------------------------------------------------
date_default_timezone_set(SITE_TIMEZONE);
