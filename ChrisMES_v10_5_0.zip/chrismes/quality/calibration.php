<?php
// =============================================================================
// ChrisMES - quality/calibration.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
require_role('IT_ADMIN','QUALITY_ENGINEER');
$page_title = 'Calibration Register';
$action  = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $org_id_in  = user_org_id() ?? (int)$_POST['org_id'];
    $code       = strtoupper(trim($_POST['code'] ?? ''));
    $name       = trim($_POST['name'] ?? '');
    $location   = trim($_POST['location'] ?? '');
    $interval_d = (int)($_POST['interval_days'] ?? 365);
    $last_cal   = $_POST['last_cal_date'] ?? '';
    $next_cal   = $_POST['next_cal_date'] ?? '';
    $errors     = [];
    if (!$code) $errors[] = 'Code required.';
    if (!$name) $errors[] = 'Name required.';

    if (!$errors) {
        if ($id) {
            db_exec('UPDATE calibration_items SET code=?,name=?,location=?,interval_days=?,last_cal_date=?,next_cal_date=?,updated_at=NOW() WHERE id=?',
                [$code,$name,$location?:null,$interval_d,$last_cal?:null,$next_cal?:null,$id]);
            audit_log('calibration',$id,'UPDATE',"Updated by ".current_user()['username']);
        } else {
            db_exec('INSERT INTO calibration_items (org_id,code,name,location,interval_days,last_cal_date,next_cal_date,created_at) VALUES (?,?,?,?,?,?,?,NOW())',
                [$org_id_in,$code,$name,$location?:null,$interval_d,$last_cal?:null,$next_cal?:null]);
            audit_log('calibration',(int)db_last_id(),'CREATE',"Created by ".current_user()['username']);
        }
        flash_set('success','Calibration record saved.');
        header('Location: /chrismes/quality/calibration.php'); exit;
    }
    $action = $id ? 'edit' : 'create'; $edit_id = $id;
}

$edit_item = null;
if (($action==='edit') && $edit_id) $edit_item = db_row('SELECT * FROM calibration_items WHERE id=?',[$edit_id]);

$today = date('Y-m-d');
$soon  = date('Y-m-d', strtotime('+30 days'));
$org_id = user_org_id();
$items = db_rows('SELECT ci.*,o.code AS org_code FROM calibration_items ci JOIN orgs o ON o.id=ci.org_id' .
    ($org_id?' WHERE ci.org_id=?':'') . ' ORDER BY ci.next_cal_date ASC', $org_id?[$org_id]:[]);
$orgs = db_rows('SELECT id,code FROM orgs WHERE is_active=1 ORDER BY code');

include __DIR__ . '/../includes/header.php';
?>

<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="mb-0 text-muted">Track calibration due dates for measuring equipment.</p>
    <a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Item</a>
</div>

<?php
$expired = array_filter($items, fn($i) => $i['next_cal_date'] && $i['next_cal_date'] < $today);
$due_soon = array_filter($items, fn($i) => $i['next_cal_date'] && $i['next_cal_date'] >= $today && $i['next_cal_date'] <= $soon);
if ($expired): ?>
<div class="alert alert-danger small"><i class="bi bi-exclamation-octagon me-2"></i><strong><?= count($expired) ?></strong> calibration(s) overdue. Remove from service immediately.</div>
<?php endif; if ($due_soon): ?>
<div class="alert alert-warning small"><i class="bi bi-clock me-2"></i><strong><?= count($due_soon) ?></strong> calibration(s) due within 30 days.</div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light"><tr><th>Org</th><th>Code</th><th>Name</th><th>Location</th><th>Last Cal</th><th>Next Cal</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($items as $ci):
                $status_class = 'cal-none';
                $status_label = 'No Date';
                if ($ci['next_cal_date']) {
                    if ($ci['next_cal_date'] < $today) { $status_class='cal-expired'; $status_label='OVERDUE'; }
                    elseif ($ci['next_cal_date'] <= $soon) { $status_class='cal-soon'; $status_label='Due Soon'; }
                    else { $status_class='cal-indate'; $status_label='In Date'; }
                }
            ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($ci['org_code']) ?></span></td>
                <td><code><?= h($ci['code']) ?></code></td>
                <td><?= h($ci['name']) ?></td>
                <td><?= h($ci['location'] ?? '—') ?></td>
                <td><?= $ci['last_cal_date'] ? date('d M y',strtotime($ci['last_cal_date'])) : '—' ?></td>
                <td><?= $ci['next_cal_date'] ? date('d M y',strtotime($ci['next_cal_date'])) : '—' ?></td>
                <td><span class="fw-semibold <?= $status_class ?>"><?= $status_label ?></span></td>
                <td><a href="?action=edit&id=<?= $ci['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($items)): ?><tr><td colspan="8" class="text-center text-muted py-3">No calibration items.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card" style="max-width:580px">
    <div class="card-header fw-semibold"><?= $edit_item ? 'Edit: '.h($edit_item['code']) : 'Add Calibration Item' ?></div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_item['id'] ?? 0) ?>">
            <?php if (!user_org_id()): ?>
            <div class="mb-3">
                <label class="form-label">Organisation</label>
                <select name="org_id" class="form-select">
                    <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>" <?= ($edit_item['org_id']??'')==$o['id']?'selected':'' ?>><?= h($o['code']) ?></option><?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="row g-3">
                <div class="col-md-4"><label class="form-label">Code <span class="text-danger">*</span></label><input type="text" name="code" class="form-control text-uppercase" value="<?= h($edit_item['code'] ?? '') ?>" required></div>
                <div class="col-md-8"><label class="form-label">Name <span class="text-danger">*</span></label><input type="text" name="name" class="form-control" value="<?= h($edit_item['name'] ?? '') ?>" required></div>
                <div class="col-md-6"><label class="form-label">Location</label><input type="text" name="location" class="form-control" value="<?= h($edit_item['location'] ?? '') ?>"></div>
                <div class="col-md-6"><label class="form-label">Interval (days)</label><input type="number" name="interval_days" class="form-control" value="<?= h($edit_item['interval_days'] ?? 365) ?>" min="1"></div>
                <div class="col-md-6"><label class="form-label">Last Calibration Date</label><input type="date" name="last_cal_date" class="form-control" value="<?= h($edit_item['last_cal_date'] ?? '') ?>"></div>
                <div class="col-md-6"><label class="form-label">Next Calibration Date</label><input type="date" name="next_cal_date" class="form-control" value="<?= h($edit_item['next_cal_date'] ?? '') ?>"></div>
            </div>
            <div class="mt-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="/chrismes/quality/calibration.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
