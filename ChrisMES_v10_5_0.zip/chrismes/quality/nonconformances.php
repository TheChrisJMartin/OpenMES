<?php
// =============================================================================
// ChrisMES - quality/nonconformances.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Non-Conformances';

$org_id  = user_org_id();
$action  = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

// ── Raise NC ──────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'raise') {
    $wo_number   = strtoupper(trim($_POST['wo_number'] ?? ''));
    $serial_num  = strtoupper(trim($_POST['serial_number'] ?? ''));
    $description = trim($_POST['description'] ?? '');
    $part_id     = (int)$_POST['part_id'];
    $raised_org  = $org_id ?? (int)$_POST['org_id'];
    $errors = [];
    if (!$description) $errors[] = 'Description is required.';

    $wo = $wo_number ? db_row('SELECT * FROM work_orders WHERE wo_number=?',[$wo_number]) : null;

    if (!$errors) {
        $nc_number = generate_nc_number();
        db_exec('INSERT INTO nonconformances (nc_number,org_id,wo_id,part_id,serial_number,description,status,raised_by,raised_at)
                 VALUES (?,?,?,?,?,?,?,?,NOW())',
            [$nc_number,$raised_org,$wo['id']??null,$part_id?:null,$serial_num?:null,$description,'Open',$_SESSION['user']['id']]);
        $nc_id = (int)db_last_id();
        audit_log('nonconformance',$nc_id,'RAISE',"NC {$nc_number} raised");
        flash_set('success',"NC <strong>{$nc_number}</strong> raised.");
        header('Location: /chrismes/quality/nonconformances.php?action=view&id='.$nc_id); exit;
    }
    $action = 'raise';
}

// ── Update disposition ────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update') {
    $nc_id       = (int)$_POST['nc_id'];
    $disposition = $_POST['disposition'] ?? '';
    $resolution  = trim($_POST['resolution'] ?? '');
    $status      = $_POST['status'] ?? '';
    $valid_disp  = ['Scrap','Rework','Use As Is','Return to Vendor','Pending'];
    $valid_stat  = ['Open','Under Review','Closed'];
    if (!in_array($disposition,$valid_disp) && $disposition !== '') $disposition = '';
    if (!in_array($status,$valid_stat)) { flash_set('danger','Invalid status.'); header('Location: /chrismes/quality/nonconformances.php'); exit; }

    db_exec('UPDATE nonconformances SET disposition=?,resolution=?,status=?,updated_at=NOW() WHERE id=?',
        [$disposition?:null,$resolution?:null,$status,$nc_id]);
    audit_log('nonconformance',$nc_id,'UPDATE',"Disposition={$disposition}, Status={$status}");
    flash_set('success','NC updated.');
    header('Location: /chrismes/quality/nonconformances.php?action=view&id='.$nc_id); exit;
}

// ── View ──────────────────────────────────────────────────────────────────────
$view_nc = null;
if ($action === 'view' && $edit_id) {
    $view_nc = db_row('SELECT nc.*,wo.wo_number,p.part_number,p.description AS part_desc,o.code AS org_code,
                       u.known_as AS raised_by_name
                       FROM nonconformances nc
                       LEFT JOIN work_orders wo ON wo.id=nc.wo_id
                       LEFT JOIN parts p ON p.id=nc.part_id
                       JOIN orgs o ON o.id=nc.org_id
                       LEFT JOIN users u ON u.id=nc.raised_by
                       WHERE nc.id=?',[$edit_id]);
}

// ── List ──────────────────────────────────────────────────────────────────────
$filter_status = $_GET['status'] ?? '';
$list_params   = [];
$where = 'WHERE 1=1 ';
if ($org_id) { $where .= 'AND nc.org_id=? '; $list_params[] = $org_id; }
if ($filter_status) { $where .= 'AND nc.status=? '; $list_params[] = $filter_status; }

$ncs = db_rows("SELECT nc.*,wo.wo_number,p.part_number,o.code AS org_code,u.known_as AS raised_by_name
                FROM nonconformances nc
                LEFT JOIN work_orders wo ON wo.id=nc.wo_id
                LEFT JOIN parts p ON p.id=nc.part_id
                JOIN orgs o ON o.id=nc.org_id
                LEFT JOIN users u ON u.id=nc.raised_by
                $where ORDER BY nc.raised_at DESC LIMIT 200", $list_params);

$orgs  = db_rows('SELECT id,code FROM orgs WHERE is_active=1 ORDER BY code');
$parts = db_rows('SELECT id,part_number,description FROM parts' . ($org_id?' WHERE org_id=?':'') . ' ORDER BY part_number', $org_id?[$org_id]:[]);

include __DIR__ . '/../includes/header.php';
?>

<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <form class="d-flex gap-2" method="get">
        <select name="status" class="form-select form-select-sm">
            <option value="">All Statuses</option>
            <?php foreach(['Open','Under Review','Closed'] as $s): ?>
            <option <?= $s===$filter_status?'selected':'' ?>><?= $s ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-sm btn-outline-secondary">Filter</button>
    </form>
    <a href="?action=raise" class="btn btn-danger"><i class="bi bi-exclamation-triangle me-1"></i>Raise NC</a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr><th>NC Number</th><th>Org</th><th>WO</th><th>Part</th><th>Serial</th><th>Description</th><th>Status</th><th>Raised By</th><th>Date</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($ncs as $nc): ?>
            <tr>
                <td><code class="fw-bold"><?= h($nc['nc_number']) ?></code></td>
                <td><span class="badge bg-secondary"><?= h($nc['org_code']) ?></span></td>
                <td><?= $nc['wo_number'] ? h($nc['wo_number']) : '—' ?></td>
                <td><?= $nc['part_number'] ? h($nc['part_number']) : '—' ?></td>
                <td><?= $nc['serial_number'] ? h($nc['serial_number']) : '—' ?></td>
                <td class="text-truncate" style="max-width:200px"><?= h($nc['description']) ?></td>
                <td><span class="badge <?= $nc['status']==='Open'?'bg-danger':($nc['status']==='Under Review'?'bg-warning text-dark':'bg-success') ?>"><?= h($nc['status']) ?></span></td>
                <td><?= h($nc['raised_by_name'] ?? '—') ?></td>
                <td><?= date('d M y', strtotime($nc['raised_at'])) ?></td>
                <td><a href="?action=view&id=<?= $nc['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($ncs)): ?><tr><td colspan="10" class="text-center text-muted py-3">No NCs found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($action === 'raise'): ?>
<div class="card" style="max-width:640px">
    <div class="card-header fw-semibold text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Raise Non-Conformance</div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" action="?action=raise">
            <?php if (!$org_id): ?>
            <div class="mb-3">
                <label class="form-label">Organisation <span class="text-danger">*</span></label>
                <select name="org_id" class="form-select" required>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>"><?= h($o['code']) ?></option><?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="mb-3">
                <label class="form-label">Work Order Number (optional)</label>
                <input type="text" name="wo_number" class="form-control text-uppercase" value="<?= h($_GET['wo'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Serial / Lot Number (optional)</label>
                <input type="text" name="serial_number" class="form-control text-uppercase">
            </div>
            <div class="mb-3">
                <label class="form-label">Part (optional)</label>
                <select name="part_id" class="form-select">
                    <option value="">— None —</option>
                    <?php foreach ($parts as $p): ?><option value="<?= $p['id'] ?>"><?= h($p['part_number']) ?> — <?= h($p['description']) ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Description / Problem <span class="text-danger">*</span></label>
                <textarea name="description" class="form-control" rows="4" required placeholder="Describe the non-conformance in detail…"></textarea>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-danger">Raise NC</button>
                <a href="/chrismes/quality/nonconformances.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php elseif ($action === 'view' && $view_nc): ?>
<div class="mb-3"><a href="/chrismes/quality/nonconformances.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a></div>
<div class="row g-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header fw-semibold d-flex justify-content-between">
                <span><code class="text-danger"><?= h($view_nc['nc_number']) ?></code></span>
                <span class="badge <?= $view_nc['status']==='Open'?'bg-danger':($view_nc['status']==='Under Review'?'bg-warning text-dark':'bg-success') ?>"><?= h($view_nc['status']) ?></span>
            </div>
            <div class="card-body small">
                <dl class="row mb-0">
                    <dt class="col-5">Org</dt><dd class="col-7"><?= h($view_nc['org_code']) ?></dd>
                    <dt class="col-5">WO</dt><dd class="col-7"><?= $view_nc['wo_number'] ? h($view_nc['wo_number']) : '—' ?></dd>
                    <dt class="col-5">Part</dt><dd class="col-7"><?= $view_nc['part_number'] ? h($view_nc['part_number']) : '—' ?></dd>
                    <dt class="col-5">Serial</dt><dd class="col-7"><?= $view_nc['serial_number'] ? h($view_nc['serial_number']) : '—' ?></dd>
                    <dt class="col-5">Raised By</dt><dd class="col-7"><?= h($view_nc['raised_by_name']) ?></dd>
                    <dt class="col-5">Raised</dt><dd class="col-7"><?= date('d M Y H:i', strtotime($view_nc['raised_at'])) ?></dd>
                    <dt class="col-5">Disposition</dt><dd class="col-7"><?= $view_nc['disposition'] ? h($view_nc['disposition']) : '—' ?></dd>
                </dl>
                <hr>
                <p class="mb-0"><strong>Description:</strong><br><?= nl2br(h($view_nc['description'])) ?></p>
                <?php if ($view_nc['resolution']): ?><hr><p class="mb-0"><strong>Resolution:</strong><br><?= nl2br(h($view_nc['resolution'])) ?></p><?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <?php if (has_role('IT_ADMIN','QUALITY_ENGINEER','SUPERVISOR','MFG_ENGINEER_SUP')): ?>
        <div class="card">
            <div class="card-header fw-semibold">Update NC</div>
            <div class="card-body">
                <form method="post" action="?action=update">
                    <input type="hidden" name="nc_id" value="<?= $view_nc['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <?php foreach (['Open','Under Review','Closed'] as $s): ?>
                            <option <?= $view_nc['status']===$s?'selected':'' ?>><?= $s ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Disposition</label>
                        <select name="disposition" class="form-select">
                            <option value="">— Pending —</option>
                            <?php foreach (['Scrap','Rework','Use As Is','Return to Vendor'] as $d): ?>
                            <option <?= $view_nc['disposition']===$d?'selected':'' ?>><?= $d ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Resolution Notes</label>
                        <textarea name="resolution" class="form-control" rows="4"><?= h($view_nc['resolution'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Update NC</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
