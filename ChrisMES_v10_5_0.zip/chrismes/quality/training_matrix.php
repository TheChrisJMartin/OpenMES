<?php
// =============================================================================
// ChrisMES - quality/training_matrix.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
require_role('IT_ADMIN','QUALITY_TRAINING_MANAGER');
$page_title = 'Training Matrix';

$org_id = user_org_id();

// ── Assign skill ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_skill'])) {
    $user_id_target = (int)$_POST['target_user_id'];
    $skill_id       = (int)$_POST['skill_id'];
    $trained_date   = $_POST['trained_date'] ?? date('Y-m-d');
    $expiry         = $_POST['expiry_date'] ?: null;
    $errors = [];
    if (!$user_id_target) $errors[] = 'User required.';
    if (!$skill_id) $errors[] = 'Skill required.';
    if (!$errors) {
        $exists = db_row('SELECT id FROM user_skills WHERE user_id=? AND skill_id=?',[$user_id_target,$skill_id]);
        if ($exists) {
            db_exec("UPDATE user_skills SET trained_date=?,expiry_date=?,status='Pending',assigned_by=?,assigned_at=NOW() WHERE user_id=? AND skill_id=?",
                [$trained_date,$expiry,current_user()['id'],$user_id_target,$skill_id]);
        } else {
            db_exec("INSERT INTO user_skills (user_id,skill_id,trained_date,expiry_date,status,assigned_by,assigned_at) VALUES (?,?,?,?,'Pending',?,NOW())",
                [$user_id_target,$skill_id,$trained_date,$expiry,current_user()['id']]);
        }
        flash_set('success','Skill assigned — pending approval.');
    } else {
        foreach ($errors as $e) flash_set('danger',$e);
    }
    header('Location: /chrismes/quality/training_matrix.php'); exit;
}

// ── Approve / Revoke ──────────────────────────────────────────────────────────
if (isset($_GET['approve'])) {
    $us_id = (int)$_GET['approve'];
    $us = db_row('SELECT * FROM user_skills WHERE id=?',[$us_id]);
    if ($us && !AUTO_APPROVE && $us['assigned_by'] == current_user()['id']) {
        flash_set('danger','Cannot approve your own assignment (AUTO_APPROVE is disabled).');
    } else {
        db_exec("UPDATE user_skills SET status='Approved',approved_by=?,approved_at=NOW() WHERE id=?",
            [current_user()['id'],$us_id]);
        flash_set('success','Skill approved.');
    }
    header('Location: /chrismes/quality/training_matrix.php'); exit;
}
if (isset($_GET['revoke'])) {
    db_exec("UPDATE user_skills SET status='Revoked' WHERE id=?",[(int)$_GET['revoke']]);
    flash_set('success','Skill revoked.');
    header('Location: /chrismes/quality/training_matrix.php'); exit;
}

// ── Data ──────────────────────────────────────────────────────────────────────
$users = db_rows('SELECT u.id,u.known_as,u.surname,u.firstname,o.code AS org_code FROM users u LEFT JOIN orgs o ON o.id=u.org_id WHERE u.is_active=1' . ($org_id?' AND u.org_id=?':'') . ' ORDER BY u.surname,u.firstname', $org_id?[$org_id]:[]);
$skills = db_rows('SELECT s.*,o.code AS org_code FROM skills s JOIN orgs o ON o.id=s.org_id' . ($org_id?' WHERE s.org_id=?':'') . ' ORDER BY s.code', $org_id?[$org_id]:[]);

$matrix = db_rows(
    'SELECT us.*,u.known_as,u.surname,s.code AS skill_code,s.name AS skill_name,
            ab.known_as AS assigned_by_name, ap.known_as AS approved_by_name
     FROM user_skills us
     JOIN users u ON u.id=us.user_id
     JOIN skills s ON s.id=us.skill_id
     LEFT JOIN users ab ON ab.id=us.assigned_by
     LEFT JOIN users ap ON ap.id=us.approved_by
     ' . ($org_id ? 'WHERE u.org_id=?' : '') . '
     ORDER BY u.surname,u.firstname,s.code',
    $org_id?[$org_id]:[]
);

$today = date('Y-m-d');
include __DIR__ . '/../includes/header.php';
?>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-person-check me-2"></i>User Skills</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small align-middle">
                    <thead class="table-light">
                        <tr><th>Operator</th><th>Skill</th><th>Trained</th><th>Expiry</th><th>Status</th><th>Approved By</th><th></th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($matrix as $us):
                        $expired = $us['expiry_date'] && $us['expiry_date'] < $today;
                        $due_soon = $us['expiry_date'] && $us['expiry_date'] >= $today && $us['expiry_date'] <= date('Y-m-d',strtotime('+30 days'));
                    ?>
                    <tr class="<?= $expired?'table-danger':($due_soon?'table-warning':'') ?>">
                        <td><?= h($us['known_as']) ?></td>
                        <td><span class="badge bg-info text-dark"><?= h($us['skill_code']) ?></span> <?= h($us['skill_name']) ?></td>
                        <td><?= $us['trained_date'] ? date('d M y',strtotime($us['trained_date'])) : '—' ?></td>
                        <td><?= $us['expiry_date'] ? date('d M y',strtotime($us['expiry_date'])) : 'None' ?></td>
                        <td><span class="badge <?= $us['status']==='Approved'?'bg-success':($us['status']==='Pending'?'bg-warning text-dark':'bg-secondary') ?>"><?= h($us['status']) ?></span></td>
                        <td><?= h($us['approved_by_name'] ?? '—') ?></td>
                        <td>
                            <?php if ($us['status'] === 'Pending'): ?>
                            <a href="?approve=<?= $us['id'] ?>" class="btn btn-sm btn-success" data-confirm="Approve this skill?"><i class="bi bi-check"></i></a>
                            <?php endif; ?>
                            <?php if ($us['status'] === 'Approved'): ?>
                            <a href="?revoke=<?= $us['id'] ?>" class="btn btn-sm btn-outline-danger" data-confirm="Revoke this skill?"><i class="bi bi-x"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($matrix)): ?><tr><td colspan="7" class="text-center text-muted py-3">No skills assigned.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header fw-semibold">Assign Skill</div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="assign_skill" value="1">
                    <div class="mb-3">
                        <label class="form-label">Operator <span class="text-danger">*</span></label>
                        <select name="target_user_id" class="form-select form-select-sm" required>
                            <option value="">— Select —</option>
                            <?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>"><?= h($u['known_as']) ?> (<?= h($u['org_code'] ?? 'All') ?>)</option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Skill <span class="text-danger">*</span></label>
                        <select name="skill_id" class="form-select form-select-sm" required>
                            <option value="">— Select —</option>
                            <?php foreach ($skills as $sk): ?><option value="<?= $sk['id'] ?>"><?= h($sk['code']) ?> — <?= h($sk['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Trained Date</label>
                        <input type="date" name="trained_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Expiry Date <small class="text-muted">(blank = no expiry)</small></label>
                        <input type="date" name="expiry_date" class="form-control form-control-sm">
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm">Assign Skill</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
