<?php
// =============================================================================
// ChrisMES - quality/skills.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
require_role('IT_ADMIN','QUALITY_TRAINING_MANAGER');
$page_title = 'Skills Library';
$action = $_GET['action'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id      = (int)($_POST['id'] ?? 0);
    $org_id  = user_org_id() ?? (int)$_POST['org_id'];
    $code    = strtoupper(trim($_POST['code'] ?? ''));
    $name    = trim($_POST['name'] ?? '');
    $desc    = trim($_POST['description'] ?? '');
    $expiry  = (int)($_POST['validity_days'] ?? 0);
    $errors  = [];
    if (!$code) $errors[] = 'Code required.';
    if (!$name) $errors[] = 'Name required.';

    if (!$errors) {
        if ($id) {
            db_exec('UPDATE skills SET code=?,name=?,description=?,validity_days=?,updated_at=NOW() WHERE id=?',[$code,$name,$desc?:null,$expiry?:null,$id]);
        } else {
            db_exec('INSERT INTO skills (org_id,code,name,description,validity_days,created_at) VALUES (?,?,?,?,?,NOW())',[$org_id,$code,$name,$desc?:null,$expiry?:null]);
        }
        flash_set('success','Skill saved.');
        header('Location: /chrismes/quality/skills.php'); exit;
    }
    $action = $id ? 'edit' : 'create';
}

if (isset($_GET['delete'])) {
    db_exec('DELETE FROM skills WHERE id=?',[(int)$_GET['delete']]);
    flash_set('success','Skill deleted.');
    header('Location: /chrismes/quality/skills.php'); exit;
}

$edit_skill = null;
if ($action === 'edit' && isset($_GET['id'])) $edit_skill = db_row('SELECT * FROM skills WHERE id=?',[(int)$_GET['id']]);

$org_id = user_org_id();
$skills = db_rows('SELECT s.*,o.code AS org_code FROM skills s JOIN orgs o ON o.id=s.org_id' . ($org_id?' WHERE s.org_id=?':'') . ' ORDER BY s.code', $org_id?[$org_id]:[]);
$orgs   = db_rows('SELECT id,code FROM orgs WHERE is_active=1 ORDER BY code');

include __DIR__ . '/../includes/header.php';
?>
<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="mb-0 text-muted">Skills that can be gate-locked onto routing operations.</p>
    <a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Skill</a>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light"><tr><th>Org</th><th>Code</th><th>Name</th><th>Description</th><th>Validity (days)</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($skills as $sk): ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($sk['org_code']) ?></span></td>
                <td><code><?= h($sk['code']) ?></code></td>
                <td><?= h($sk['name']) ?></td>
                <td class="text-muted small"><?= h($sk['description'] ?? '—') ?></td>
                <td><?= $sk['validity_days'] ? h($sk['validity_days']).' days' : 'No expiry' ?></td>
                <td>
                    <a href="?action=edit&id=<?= $sk['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                    <a href="?delete=<?= $sk['id'] ?>" class="btn btn-sm btn-outline-danger" data-confirm="Delete skill <?= h($sk['code']) ?>?"><i class="bi bi-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($skills)): ?><tr><td colspan="6" class="text-center text-muted py-3">No skills defined.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card" style="max-width:560px">
    <div class="card-header fw-semibold"><?= $edit_skill ? 'Edit Skill: '.h($edit_skill['code']) : 'Add Skill' ?></div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_skill['id'] ?? 0) ?>">
            <?php if (!user_org_id()): ?>
            <div class="mb-3">
                <label class="form-label">Organisation</label>
                <select name="org_id" class="form-select">
                    <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>" <?= ($edit_skill['org_id']??'')==$o['id']?'selected':'' ?>><?= h($o['code']) ?></option><?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="row g-3">
                <div class="col-md-4"><label class="form-label">Code <span class="text-danger">*</span></label><input type="text" name="code" class="form-control text-uppercase" value="<?= h($edit_skill['code'] ?? '') ?>" required></div>
                <div class="col-md-8"><label class="form-label">Name <span class="text-danger">*</span></label><input type="text" name="name" class="form-control" value="<?= h($edit_skill['name'] ?? '') ?>" required></div>
                <div class="col-12"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"><?= h($edit_skill['description'] ?? '') ?></textarea></div>
                <div class="col-md-6">
                    <label class="form-label">Validity (days) <small class="text-muted">0 = no expiry</small></label>
                    <input type="number" name="validity_days" class="form-control" value="<?= h($edit_skill['validity_days'] ?? 0) ?>" min="0">
                </div>
            </div>
            <div class="mt-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="/chrismes/quality/skills.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
