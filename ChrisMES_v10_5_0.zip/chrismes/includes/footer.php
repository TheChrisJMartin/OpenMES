<?php
// =============================================================================
// ChrisMES - includes/footer.php
// Version: 10.5.0
// =============================================================================
?>
        </div><!-- /.content-area -->
    </div><!-- /#main-content -->
</div><!-- /#wrapper -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/chrismes/assets/js/app.js"></script>
<script>
// Dark mode toggle
document.getElementById('darkModeToggle')?.addEventListener('click', function () {
    fetch('/chrismes/api/toggle_dark_mode.php', { method: 'POST' })
        .then(() => location.reload());
});
// Sidebar toggle
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('wrapper').classList.toggle('sidebar-collapsed');
});
</script>

<footer class="text-center text-muted small py-2 border-top">
    <?= SITE_NAME ?> v<?= SITE_VERSION ?> &mdash; <a href="<?= SITE_URL ?>" class="text-muted"><?= SITE_URL ?></a>
</footer>
</body>
</html>
