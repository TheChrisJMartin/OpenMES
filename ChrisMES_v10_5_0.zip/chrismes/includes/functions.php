<?php
// =============================================================================
// ChrisMES - includes/functions.php
// Version: 10.5.0
// Shared utility functions used across the application.
// =============================================================================

require_once __DIR__ . '/../db.php';

// ---------------------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------------------

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!isset($_SESSION['user'])) {
        header('Location: /chrismes/login.php');
        exit;
    }
}

function has_role(string ...$roles): bool {
    $user = current_user();
    if (!$user) return false;
    return in_array($user['persona'], $roles, true);
}

function require_role(string ...$roles): void {
    require_login();
    if (!has_role(...$roles)) {
        http_response_code(403);
        include __DIR__ . '/../includes/header.php';
        echo '<div class="alert alert-danger">Access denied. Insufficient permissions.</div>';
        include __DIR__ . '/../includes/footer.php';
        exit;
    }
}

function is_it_admin(): bool {
    return has_role('IT_ADMIN');
}

// ---------------------------------------------------------------------------
// Organisation scoping
// ---------------------------------------------------------------------------

/**
 * Returns the org_id the current user may see.
 * IT_ADMIN returns null (sees all). Others get their own org.
 */
function user_org_id(): ?int {
    $user = current_user();
    if (!$user) return null;
    if ($user['persona'] === 'IT_ADMIN') return null;
    return (int)$user['org_id'];
}

function org_where(string $alias = 'o'): string {
    $org = user_org_id();
    return $org ? " AND {$alias}.org_id = {$org} " : '';
}

// ---------------------------------------------------------------------------
// Work order number generation
// ---------------------------------------------------------------------------

function generate_wo_number(string $org_code): string {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $row = db_row(
            'SELECT COUNT(*) AS cnt FROM work_orders WHERE org_id = (SELECT id FROM orgs WHERE code = ?)',
            [$org_code]
        );
        $next = (int)$row['cnt'] + 1;
        $pdo->commit();
        return strtoupper($org_code) . str_pad($next, 7, '0', STR_PAD_LEFT);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ---------------------------------------------------------------------------
// NC number generation
// ---------------------------------------------------------------------------

function generate_nc_number(): string {
    $row = db_row('SELECT MAX(CAST(SUBSTRING_INDEX(nc_number, \'/\', 1) AS UNSIGNED)) AS mx FROM nonconformances');
    $next = (int)($row['mx'] ?? 0) + 1;
    return 'NC' . str_pad($next, 7, '0', STR_PAD_LEFT);
}

// ---------------------------------------------------------------------------
// Serial number allocation
// ---------------------------------------------------------------------------

function allocate_serials(int $register_id, int $qty): array {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $reg = db_row('SELECT * FROM serial_registers WHERE id = ? FOR UPDATE', [$register_id]);
        if (!$reg) throw new RuntimeException('Serial register not found.');

        $current = (int)$reg['current_seq'];
        $end     = (int)$reg['end_seq'];
        if ($current + $qty - 1 > $end) {
            throw new RuntimeException('Serial register exhausted. Not enough serials remaining.');
        }

        $serials = [];
        for ($i = 0; $i < $qty; $i++) {
            $seq = $current + $i;
            $padded = str_pad($seq, (int)$reg['pad_length'], '0', STR_PAD_LEFT);
            $serials[] = $reg['prefix'] . $padded . ($reg['suffix'] ?? '');
        }

        db_exec('UPDATE serial_registers SET current_seq = ? WHERE id = ?',
            [$current + $qty, $register_id]);

        $pdo->commit();
        return $serials;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ---------------------------------------------------------------------------
// Audit log
// ---------------------------------------------------------------------------

function audit_log(string $entity_type, int $entity_id, string $action, string $detail = '', ?int $user_id = null): void {
    $uid = $user_id ?? (current_user()['id'] ?? null);
    db_exec(
        'INSERT INTO audit_log (entity_type, entity_id, action, detail, user_id, created_at)
         VALUES (?, ?, ?, ?, ?, NOW())',
        [$entity_type, $entity_id, $action, $detail, $uid]
    );
}

function security_log(string $event, string $severity, string $detail, ?int $user_id = null): void {
    $ip  = $_SERVER['REMOTE_ADDR'] ?? '';
    $uid = $user_id ?? (current_user()['id'] ?? null);
    db_exec(
        'INSERT INTO security_log (event, severity, detail, user_id, ip_address, created_at)
         VALUES (?, ?, ?, ?, ?, NOW())',
        [$event, $severity, $detail, $uid, $ip]
    );
}

// ---------------------------------------------------------------------------
// Integration outbound queue
// ---------------------------------------------------------------------------

function queue_outbound(string $msg_type, int $org_id, string $payload): void {
    db_exec(
        'INSERT INTO integration_outbound (transaction_number, org_id, message_type, payload, placed_at)
         VALUES (UUID(), ?, ?, ?, NOW())',
        [$org_id, $msg_type, $payload]
    );
}

// ---------------------------------------------------------------------------
// Document revision helpers
// ---------------------------------------------------------------------------

function format_revision(int $n): string {
    return str_pad($n, 6, '0', STR_PAD_LEFT);
}

// ---------------------------------------------------------------------------
// Flash messages
// ---------------------------------------------------------------------------

function flash_set(string $type, string $msg): void {
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function flash_get(): array {
    $msgs = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $msgs;
}

// ---------------------------------------------------------------------------
// Sanitise output
// ---------------------------------------------------------------------------

function h(mixed $val): string {
    return htmlspecialchars((string)$val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ---------------------------------------------------------------------------
// Pagination
// ---------------------------------------------------------------------------

function paginate(int $total, int $per_page, int $current_page): array {
    $pages = (int)ceil($total / $per_page);
    return [
        'total'        => $total,
        'per_page'     => $per_page,
        'current_page' => $current_page,
        'pages'        => max(1, $pages),
        'offset'       => ($current_page - 1) * $per_page,
    ];
}

// ---------------------------------------------------------------------------
// Time formatting
// ---------------------------------------------------------------------------

function fmt_duration(int $seconds): string {
    $h = intdiv($seconds, 3600);
    $m = intdiv($seconds % 3600, 60);
    $s = $seconds % 60;
    if ($h > 0) return sprintf('%dh %02dm', $h, $m);
    if ($m > 0) return sprintf('%dm %02ds', $m, $s);
    return sprintf('%ds', $s);
}
