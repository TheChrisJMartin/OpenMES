<?php
// =============================================================================
// ChrisMES - includes/header.php
// Version: 10.5.0
// =============================================================================
require_once __DIR__ . '/../includes/functions.php';

$user      = current_user();
$dark_mode = $user['dark_mode'] ?? false;
$persona   = $user['persona'] ?? '';
$page_title = $page_title ?? SITE_NAME;

$flash_msgs = flash_get();

// Broadcast message
$broadcast = db_row("SELECT * FROM broadcast_messages WHERE is_active = 1 LIMIT 1");
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="<?= $dark_mode ? 'dark' : 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($page_title) ?> — <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="/chrismes/assets/css/style.css" rel="stylesheet">
</head>
<body>

<?php if ($broadcast): ?>
<div class="alert alert-<?= h($broadcast['colour']) ?> alert-dismissible mb-0 rounded-0 text-center fw-semibold" role="alert">
    <i class="bi bi-megaphone-fill me-2"></i><?= h($broadcast['message']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="d-flex" id="wrapper">

    <!-- ===================== SIDEBAR ===================== -->
    <nav id="sidebar" class="sidebar d-flex flex-column flex-shrink-0 p-3">
        <a href="/chrismes/index.php" class="d-flex align-items-center mb-3 text-decoration-none sidebar-brand">
            <i class="bi bi-cpu-fill me-2 fs-4"></i>
            <span class="fs-5 fw-bold"><?= SITE_NAME ?></span>
        </a>
        <hr>

        <ul class="nav nav-pills flex-column mb-auto">

            <!-- Dashboard -->
            <li class="nav-item">
                <a href="/chrismes/index.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' && dirname($_SERVER['PHP_SELF']) === '/chrismes' ? 'active' : '' ?>">
                    <i class="bi bi-speedometer2 me-2"></i>Dashboard
                </a>
            </li>

            <!-- Operator Screen -->
            <li class="nav-item">
                <a href="/chrismes/operator/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/operator/') ? 'active' : '' ?>">
                    <i class="bi bi-play-circle me-2"></i>Operator Screen
                </a>
            </li>

            <!-- Work Orders -->
            <?php if (has_role('IT_ADMIN','SUPERVISOR','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
            <li class="nav-item">
                <a href="/chrismes/workorders/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/workorders/') ? 'active' : '' ?>">
                    <i class="bi bi-card-list me-2"></i>Work Orders
                </a>
            </li>
            <?php endif; ?>

            <!-- Routings -->
            <?php if (has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
            <li class="nav-item">
                <a href="/chrismes/routings/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/routings/') ? 'active' : '' ?>">
                    <i class="bi bi-diagram-3 me-2"></i>Routings
                </a>
            </li>
            <?php endif; ?>

            <!-- Documents -->
            <?php if (has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','SUPERVISOR')): ?>
            <li class="nav-item">
                <a href="/chrismes/documents/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/documents/') ? 'active' : '' ?>">
                    <i class="bi bi-file-earmark-pdf me-2"></i>Documents
                </a>
            </li>
            <?php endif; ?>

            <!-- Items -->
            <?php if (has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','SUPERVISOR')): ?>
            <li class="nav-item">
                <a href="/chrismes/items/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/items/') ? 'active' : '' ?>">
                    <i class="bi bi-box-seam me-2"></i>Items
                </a>
            </li>
            <?php endif; ?>

            <!-- Quality -->
            <li class="nav-item">
                <span class="nav-link text-muted small text-uppercase fw-semibold mt-2">Quality</span>
            </li>
            <li class="nav-item">
                <a href="/chrismes/quality/nonconformances.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/quality/nonconformances') ? 'active' : '' ?>">
                    <i class="bi bi-exclamation-triangle me-2"></i>Non-Conformances
                </a>
            </li>
            <?php if (has_role('IT_ADMIN','QUALITY_ENGINEER')): ?>
            <li class="nav-item">
                <a href="/chrismes/quality/calibration.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/quality/calibration') ? 'active' : '' ?>">
                    <i class="bi bi-tools me-2"></i>Calibration
                </a>
            </li>
            <?php endif; ?>
            <?php if (has_role('IT_ADMIN','QUALITY_TRAINING_MANAGER')): ?>
            <li class="nav-item">
                <a href="/chrismes/quality/skills.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/quality/skills') ? 'active' : '' ?>">
                    <i class="bi bi-award me-2"></i>Skills Library
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/quality/training_matrix.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/quality/training_matrix') ? 'active' : '' ?>">
                    <i class="bi bi-person-check me-2"></i>Training Matrix
                </a>
            </li>
            <?php endif; ?>

            <!-- Supervisor / Analytics -->
            <li class="nav-item">
                <span class="nav-link text-muted small text-uppercase fw-semibold mt-2">Reporting</span>
            </li>
            <li class="nav-item">
                <a href="/chrismes/supervisor/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/supervisor/') ? 'active' : '' ?>">
                    <i class="bi bi-display me-2"></i>Supervisor View
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/analytics/index.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/analytics/') ? 'active' : '' ?>">
                    <i class="bi bi-bar-chart-line me-2"></i>Analytics
                </a>
            </li>

            <!-- Administration -->
            <?php if (has_role('IT_ADMIN')): ?>
            <li class="nav-item">
                <span class="nav-link text-muted small text-uppercase fw-semibold mt-2">Administration</span>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/orgs.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/orgs') ? 'active' : '' ?>">
                    <i class="bi bi-building me-2"></i>Organisations
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/departments.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/departments') ? 'active' : '' ?>">
                    <i class="bi bi-diagram-2 me-2"></i>Departments
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/resources.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/resources') ? 'active' : '' ?>">
                    <i class="bi bi-pc-display me-2"></i>Resources
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/users.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/users') ? 'active' : '' ?>">
                    <i class="bi bi-people me-2"></i>Users
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/uom.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/uom') ? 'active' : '' ?>">
                    <i class="bi bi-rulers me-2"></i>Units of Measure
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/inventory_locations.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/inventory_locations') ? 'active' : '' ?>">
                    <i class="bi bi-geo-alt me-2"></i>Inventory Locations
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/serial_registers.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/serial_registers') ? 'active' : '' ?>">
                    <i class="bi bi-hash me-2"></i>Serial Registers
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/integration_log.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/integration_log') ? 'active' : '' ?>">
                    <i class="bi bi-arrow-left-right me-2"></i>Integration Log
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/security_log.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/security_log') ? 'active' : '' ?>">
                    <i class="bi bi-shield-lock me-2"></i>Security Log
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/broadcast.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/broadcast') ? 'active' : '' ?>">
                    <i class="bi bi-megaphone me-2"></i>Broadcast Message
                </a>
            </li>
            <li class="nav-item">
                <a href="/chrismes/admin/roadmap.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], '/admin/roadmap') ? 'active' : '' ?>">
                    <i class="bi bi-map me-2"></i>Roadmap
                </a>
            </li>
            <?php endif; ?>

        </ul>

        <hr>
        <div class="d-flex align-items-center">
            <div class="flex-grow-1 small">
                <strong><?= h($user['known_as'] ?? 'Guest') ?></strong><br>
                <span class="text-muted"><?= h($user['persona'] ?? '') ?></span>
            </div>
            <a href="/chrismes/logout.php" class="btn btn-sm btn-outline-secondary ms-2" title="Log out">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </nav>
    <!-- =================== END SIDEBAR =================== -->

    <!-- ==================== MAIN AREA ==================== -->
    <div id="main-content" class="flex-grow-1">

        <!-- Top bar -->
        <div class="topbar d-flex align-items-center px-4 py-2">
            <button class="btn btn-sm btn-outline-secondary me-3" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <span class="fw-semibold"><?= h($page_title) ?></span>
            <div class="ms-auto d-flex align-items-center gap-3">
                <span class="small text-muted"><?= h($user['known_as'] ?? '') ?> &bull; <?= h($user['org_code'] ?? 'All Orgs') ?></span>
                <button class="btn btn-sm btn-outline-secondary" id="darkModeToggle" title="Toggle dark mode">
                    <i class="bi bi-<?= $dark_mode ? 'sun' : 'moon' ?>"></i>
                </button>
                <span class="badge bg-secondary"><?= SITE_VERSION ?></span>
            </div>
        </div>

        <div class="content-area p-4">

            <?php foreach ($flash_msgs as $fm): ?>
            <div class="alert alert-<?= h($fm['type']) ?> alert-dismissible" role="alert">
                <?= h($fm['msg']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endforeach; ?>
