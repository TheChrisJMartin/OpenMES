/* =============================================================================
   ChrisMES - assets/js/app.js
   Version: 10.5.0
   ============================================================================= */

'use strict';

// ── Auto-dismiss alerts after 6 s ──────────────────────────────────────────
document.querySelectorAll('.alert.alert-success, .alert.alert-info').forEach(el => {
    setTimeout(() => {
        const bsAlert = bootstrap.Alert.getOrCreateInstance(el);
        bsAlert && bsAlert.close();
    }, 6000);
});

// ── Serial chip selection ───────────────────────────────────────────────────
function initSerialGrid() {
    document.querySelectorAll('.serial-chip.serial-available, .serial-chip.serial-mine').forEach(chip => {
        chip.addEventListener('click', function () {
            this.classList.toggle('selected');
            updateSerialInput();
        });
    });
}

function updateSerialInput() {
    const selected = [...document.querySelectorAll('.serial-chip.selected')]
        .map(el => el.dataset.serial);
    const inp = document.getElementById('selected_serials');
    if (inp) inp.value = selected.join(',');

    const countEl = document.getElementById('selected_count');
    if (countEl) countEl.textContent = selected.length;

    const actionBtns = document.querySelectorAll('.serial-action-btn');
    actionBtns.forEach(btn => btn.disabled = selected.length === 0);
}

function selectAllSerials(type) {
    document.querySelectorAll(`.serial-chip.serial-${type}`).forEach(chip => {
        chip.classList.add('selected');
    });
    updateSerialInput();
}

function clearSerialSelection() {
    document.querySelectorAll('.serial-chip.selected').forEach(chip => {
        chip.classList.remove('selected');
    });
    updateSerialInput();
}

document.addEventListener('DOMContentLoaded', initSerialGrid);

// ── Quality spec indicator ──────────────────────────────────────────────────
function updateSpecPointer(inputEl) {
    const val = parseFloat(inputEl.value);
    const low  = parseFloat(inputEl.dataset.low  || '');
    const high = parseFloat(inputEl.dataset.high || '');
    const bar  = document.getElementById('spec-bar-' + inputEl.dataset.varId);
    if (!bar || isNaN(val)) return;

    const pointer = bar.querySelector('.spec-pointer');
    if (!pointer) return;

    if (!isNaN(low) && !isNaN(high) && high > low) {
        const pct = Math.max(0, Math.min(100, (val - low) / (high - low) * 100));
        pointer.style.left = pct + '%';
        const inSpec = val >= low && val <= high;
        pointer.classList.toggle('in-spec', inSpec);
        inputEl.classList.toggle('is-invalid', !inSpec);
        inputEl.classList.toggle('is-valid', inSpec);
    }
}

document.querySelectorAll('.quality-input').forEach(inp => {
    inp.addEventListener('input', () => updateSpecPointer(inp));
});

// ── Confirm dialogs ─────────────────────────────────────────────────────────
document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', function (e) {
        if (!confirm(this.dataset.confirm)) e.preventDefault();
    });
});

// ── Efficiency bar colouring ────────────────────────────────────────────────
document.querySelectorAll('.efficiency-bar .fill').forEach(bar => {
    const pct = parseFloat(bar.style.width);
    bar.classList.remove('good', 'warn', 'over');
    if (pct <= 100) bar.classList.add('good');
    else if (pct <= 120) bar.classList.add('warn');
    else bar.classList.add('over');
});

// ── Clock counter ───────────────────────────────────────────────────────────
const clockEl = document.getElementById('live-clock');
if (clockEl) {
    const start = parseInt(clockEl.dataset.start, 10) * 1000;
    setInterval(() => {
        const elapsed = Math.floor((Date.now() - start) / 1000);
        const h = String(Math.floor(elapsed / 3600)).padStart(2, '0');
        const m = String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0');
        const s = String(elapsed % 60).padStart(2, '0');
        clockEl.textContent = `${h}:${m}:${s}`;
    }, 1000);
}
