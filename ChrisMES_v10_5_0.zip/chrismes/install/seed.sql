-- =============================================================================
-- ChrisMES v10.5.0 - install/seed.sql
-- Default seed data. Run AFTER schema.sql.
-- =============================================================================

USE `chrismes`;

-- ── System Units of Measure ───────────────────────────────────────────────────
INSERT INTO `units_of_measure` (`code`,`name`,`is_system`,`created_at`) VALUES
  ('EA',  'Each',         1, NOW()),
  ('SET', 'Set',          1, NOW()),
  ('KIT', 'Kit',          1, NOW()),
  ('LT',  'Litre',        1, NOW()),
  ('ML',  'Millilitre',   1, NOW()),
  ('KG',  'Kilogram',     1, NOW()),
  ('G',   'Gram',         1, NOW()),
  ('M',   'Metre',        1, NOW()),
  ('MM',  'Millimetre',   1, NOW()),
  ('HR',  'Hour',         1, NOW()),
  ('MIN', 'Minute',       1, NOW()),
  ('DEG', 'Degrees',      1, NOW()),
  ('NM',  'Newton Metre', 1, NOW()),
  ('PSI', 'PSI',          1, NOW()),
  ('BAR', 'Bar',          1, NOW()),
  ('PCT', 'Percent',      1, NOW());

-- ── Demo Organisation ─────────────────────────────────────────────────────────
INSERT INTO `orgs` (`code`,`name`,`org_type`,`is_active`,`created_at`) VALUES
  ('DEMO','Demo Organisation','OE',1,NOW());

-- ── IT Admin User (test account; change password in production) ───────────────
-- Password hash for 'admin' using bcrypt cost 12.
-- In TEST_MODE, the test account password is the username ('admin').
INSERT INTO `users` (`username`,`surname`,`firstname`,`known_as`,`persona`,`org_id`,
                     `password_hash`,`is_active`,`is_direct`,`is_test_account`,`dark_mode`,`created_at`)
VALUES (
  'ADMIN', 'Admin', 'System', 'IT Admin', 'IT_ADMIN', NULL,
  '$2y$12$eImiTXuWVxfM37uY4JANjQ==',  -- placeholder; set via admin/users.php in UI
  1, 0, 1, 0, NOW()
);

-- ── Demo Department & Resource ────────────────────────────────────────────────
INSERT INTO `departments` (`org_id`,`code`,`name`,`is_active`,`created_at`)
  SELECT id,'PROD','Production',1,NOW() FROM `orgs` WHERE code='DEMO';

INSERT INTO `resources` (`dept_id`,`code`,`name`,`is_active`,`created_at`)
  SELECT d.id,'WS-01','Workstation 1',1,NOW() FROM `departments` d
  JOIN `orgs` o ON o.id=d.org_id WHERE o.code='DEMO' AND d.code='PROD';

-- ── Demo Serial Register ──────────────────────────────────────────────────────
INSERT INTO `serial_registers` (`org_id`,`code`,`prefix`,`suffix`,`pad_length`,`start_seq`,`end_seq`,`current_seq`,`created_at`)
  SELECT id,'DEMO-A','A','',5,1,99999,1,NOW() FROM `orgs` WHERE code='DEMO';

-- ── Demo Inventory Location ───────────────────────────────────────────────────
INSERT INTO `inventory_locations` (`org_id`,`code`,`name`,`is_active`,`created_at`)
  SELECT id,'STORES','Main Stores',1,NOW() FROM `orgs` WHERE code='DEMO';
