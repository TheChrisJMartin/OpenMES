# ChrisMES v10.5.0 — Installation Guide

## Requirements
- PHP 8.1+ with PDO, PDO_MySQL, fileinfo extensions
- MySQL 8.0+ (or MariaDB 10.6+)
- Web server (Apache / Nginx) with mod_rewrite / try_files

## Steps

### 1. Create Database
```sql
CREATE DATABASE chrismes CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'chrismes_user'@'localhost' IDENTIFIED BY 'changeme';
GRANT ALL PRIVILEGES ON chrismes.* TO 'chrismes_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Run Schema
```bash
mysql -u root -p chrismes < install/schema.sql
mysql -u root -p chrismes < install/seed.sql
```

### 3. Configure
Edit `config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'chrismes');
define('DB_USER', 'chrismes_user');
define('DB_PASS', 'your_password');
define('TEST_MODE', false);    // Set false in production
define('SITE_URL', 'https://your-domain.com/chrismes');
```

### 4. Set Password for Admin
In TEST_MODE, log in with username `ADMIN` and password `ADMIN`.
Then go to Admin → Users, edit ADMIN, and set a real password.
Disable `TEST_MODE` when done.

### 5. Upload Directory
Create and make writable:
```bash
mkdir -p uploads/documents
chmod 755 uploads/documents
```

### 6. Web Server

**Apache** (add to VirtualHost or .htaccess):
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]
```

**Nginx**:
```nginx
location /chrismes {
    try_files $uri $uri/ /chrismes/index.php?$query_string;
}
```

## Key Configuration Flags (config.php)

| Flag | Default | Description |
|------|---------|-------------|
| `TEST_MODE` | `true` | Test accounts use username as password |
| `ALLOW_WO_CREATION` | `true` | Set false when ERP masters WOs |
| `PARTS_LOCKED` | `false` | Set true when ERP masters parts |
| `ORGS_LOCKED` | `false` | Prevent manual org changes |
| `DEPTS_LOCKED` | `false` | Prevent manual dept changes |
| `RESOURCES_LOCKED` | `false` | Prevent manual resource changes |
| `AUTO_APPROVE` | `true` | Set false to enforce two-person approval |
| `BCRYPT_COST` | `12` | Password hashing cost (10–14 recommended) |

## User Roles

| Persona | Access |
|---------|--------|
| `IT_ADMIN` | Full system access, all orgs |
| `SUPERVISOR` | WOs, operator view, floor view |
| `OPERATOR` | Operator screen, clock on/off |
| `TESTER` | Operator screen (test ops) |
| `INSPECTOR` | Operator screen (inspection ops) |
| `FINAL_TESTER` | Operator screen (final test ops) |
| `MFG_ENGINEER` | Routings, documents, items |
| `MFG_ENGINEER_SUP` | As MFG_ENGINEER + approvals |
| `ENGINEER` | Read-only engineering access |
| `QUALITY_ENGINEER` | NCs, calibration |
| `QUALITY_TRAINING_MANAGER` | Skills, training matrix |

## Integration API

Send JSON POST to `/chrismes/api/integration_inbound.php`:

```bash
curl -X POST https://your-domain.com/chrismes/api/integration_inbound.php \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "transaction_number": "ERP-001",
    "message_type": "WO_CREATE",
    "org_id": 1,
    "org_code": "DEMO",
    "part_number": "WIDGET-001",
    "quantity": 10,
    "priority": 30
  }'
```

Set `INTEGRATION_TOKEN` as an environment variable, or define it in `config.php`.

Supported message types:
- `WO_CREATE` — Create a work order from ERP (requires `ALLOW_WO_CREATION=false`)
- `PART_SYNC` — Sync part master from ERP (requires `PARTS_LOCKED=true`)

## More Information
Visit [https://chris-martin.co.uk/chrismes](https://chris-martin.co.uk/chrismes)
