-- =============================================================================
-- ChrisMES v10.5.0 - install/schema.sql
-- Full database schema. Run this ONCE to create the database structure.
-- =============================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;

CREATE DATABASE IF NOT EXISTS `chrismes`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `chrismes`;

-- ── Organisations ─────────────────────────────────────────────────────────────
CREATE TABLE `orgs` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`       VARCHAR(5) NOT NULL UNIQUE,
  `name`       VARCHAR(120) NOT NULL,
  `org_type`   ENUM('OE','MRO') NOT NULL DEFAULT 'OE',
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME DEFAULT NULL
) ENGINE=InnoDB;

-- ── Departments ───────────────────────────────────────────────────────────────
CREATE TABLE `departments` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`     INT UNSIGNED NOT NULL,
  `code`       VARCHAR(10) NOT NULL,
  `name`       VARCHAR(120) NOT NULL,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  UNIQUE KEY `uq_dept` (`org_id`,`code`),
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`)
) ENGINE=InnoDB;

-- ── Resources (workstations / machines) ──────────────────────────────────────
CREATE TABLE `resources` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `dept_id`    INT UNSIGNED NOT NULL,
  `code`       VARCHAR(20) NOT NULL,
  `name`       VARCHAR(120) NOT NULL,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  FOREIGN KEY (`dept_id`) REFERENCES `departments`(`id`)
) ENGINE=InnoDB;

-- ── Users ─────────────────────────────────────────────────────────────────────
CREATE TABLE `users` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `username`        VARCHAR(50) NOT NULL UNIQUE,
  `surname`         VARCHAR(80) NOT NULL,
  `firstname`       VARCHAR(80) NOT NULL,
  `known_as`        VARCHAR(80) NOT NULL,
  `persona`         ENUM('IT_ADMIN','SUPERVISOR','OPERATOR','TESTER','INSPECTOR','FINAL_TESTER',
                        'MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER') NOT NULL,
  `org_id`          INT UNSIGNED DEFAULT NULL,
  `password_hash`   VARCHAR(255) NOT NULL,
  `is_active`       TINYINT(1) NOT NULL DEFAULT 1,
  `is_direct`       TINYINT(1) NOT NULL DEFAULT 0,
  `is_test_account` TINYINT(1) NOT NULL DEFAULT 0,
  `dark_mode`       TINYINT(1) NOT NULL DEFAULT 0,
  `last_login`      DATETIME DEFAULT NULL,
  `created_at`      DATETIME NOT NULL,
  `updated_at`      DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`)
) ENGINE=InnoDB;

-- ── Units of Measure ──────────────────────────────────────────────────────────
CREATE TABLE `units_of_measure` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`       VARCHAR(10) NOT NULL UNIQUE,
  `name`       VARCHAR(60) NOT NULL,
  `is_system`  TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL
) ENGINE=InnoDB;

-- ── Inventory Locations ───────────────────────────────────────────────────────
CREATE TABLE `inventory_locations` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`     INT UNSIGNED NOT NULL,
  `code`       VARCHAR(30) NOT NULL,
  `name`       VARCHAR(120) DEFAULT NULL,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`)
) ENGINE=InnoDB;

-- ── Serial Number Registers ───────────────────────────────────────────────────
CREATE TABLE `serial_registers` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`      INT UNSIGNED NOT NULL,
  `code`        VARCHAR(30) NOT NULL,
  `prefix`      VARCHAR(10) NOT NULL DEFAULT '',
  `suffix`      VARCHAR(10) NOT NULL DEFAULT '',
  `pad_length`  TINYINT UNSIGNED NOT NULL DEFAULT 5,
  `start_seq`   INT UNSIGNED NOT NULL DEFAULT 1,
  `end_seq`     INT UNSIGNED NOT NULL DEFAULT 99999,
  `current_seq` INT UNSIGNED NOT NULL DEFAULT 1,
  `created_at`  DATETIME NOT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`)
) ENGINE=InnoDB;

-- ── Item Master (Parts) ───────────────────────────────────────────────────────
CREATE TABLE `parts` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`           INT UNSIGNED NOT NULL,
  `part_number`      VARCHAR(40) NOT NULL,
  `revision`         VARCHAR(10) NOT NULL DEFAULT 'A',
  `description`      VARCHAR(200) NOT NULL,
  `uom_id`           INT UNSIGNED NOT NULL,
  `serial_controlled`TINYINT(1) NOT NULL DEFAULT 1,
  `make_buy`         ENUM('Make','Buy') NOT NULL DEFAULT 'Make',
  `shelf_lifed`      TINYINT(1) NOT NULL DEFAULT 0,
  `item_version`     INT UNSIGNED NOT NULL DEFAULT 1,
  `created_at`       DATETIME NOT NULL,
  `updated_at`       DATETIME DEFAULT NULL,
  UNIQUE KEY `uq_part` (`org_id`,`part_number`),
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`),
  FOREIGN KEY (`uom_id`) REFERENCES `units_of_measure`(`id`)
) ENGINE=InnoDB;

-- ── Documents (Work Instructions) ────────────────────────────────────────────
CREATE TABLE `documents` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`      INT UNSIGNED NOT NULL,
  `part_id`     INT UNSIGNED DEFAULT NULL,
  `doc_code`    VARCHAR(60) NOT NULL DEFAULT '',
  `description` VARCHAR(200) NOT NULL,
  `created_by`  INT UNSIGNED DEFAULT NULL,
  `created_at`  DATETIME NOT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`),
  FOREIGN KEY (`part_id`) REFERENCES `parts`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `document_revisions` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `doc_id`          INT UNSIGNED NOT NULL,
  `revision_number` INT UNSIGNED NOT NULL DEFAULT 1,
  `filename`        VARCHAR(255) NOT NULL,
  `status`          ENUM('Draft','Approved','Archived') NOT NULL DEFAULT 'Draft',
  `uploaded_by`     INT UNSIGNED DEFAULT NULL,
  `uploaded_at`     DATETIME NOT NULL,
  `approved_by`     INT UNSIGNED DEFAULT NULL,
  `approved_at`     DATETIME DEFAULT NULL,
  UNIQUE KEY `uq_doc_rev` (`doc_id`,`revision_number`),
  FOREIGN KEY (`doc_id`) REFERENCES `documents`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`uploaded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Skills ────────────────────────────────────────────────────────────────────
CREATE TABLE `skills` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`        INT UNSIGNED DEFAULT NULL,
  `code`          VARCHAR(20) NOT NULL,
  `name`          VARCHAR(120) NOT NULL,
  `description`   TEXT DEFAULT NULL,
  `validity_days` INT UNSIGNED DEFAULT NULL,
  `created_at`    DATETIME NOT NULL,
  `updated_at`    DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `user_skills` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED NOT NULL,
  `skill_id`     INT UNSIGNED NOT NULL,
  `trained_date` DATE DEFAULT NULL,
  `expiry_date`  DATE DEFAULT NULL,
  `status`       ENUM('Pending','Approved','Revoked') NOT NULL DEFAULT 'Pending',
  `assigned_by`  INT UNSIGNED DEFAULT NULL,
  `assigned_at`  DATETIME DEFAULT NULL,
  `approved_by`  INT UNSIGNED DEFAULT NULL,
  `approved_at`  DATETIME DEFAULT NULL,
  UNIQUE KEY `uq_user_skill` (`user_id`,`skill_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`skill_id`) REFERENCES `skills`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`assigned_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Routings ──────────────────────────────────────────────────────────────────
CREATE TABLE `routings` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`      INT UNSIGNED NOT NULL,
  `part_id`     INT UNSIGNED NOT NULL,
  `name`        VARCHAR(60) NOT NULL,
  `revision`    INT UNSIGNED NOT NULL DEFAULT 1,
  `status`      ENUM('Draft','Approved','Archived') NOT NULL DEFAULT 'Draft',
  `created_by`  INT UNSIGNED DEFAULT NULL,
  `created_at`  DATETIME NOT NULL,
  `approved_by` INT UNSIGNED DEFAULT NULL,
  `approved_at` DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`),
  FOREIGN KEY (`part_id`) REFERENCES `parts`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `routing_operations` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `routing_id`  INT UNSIGNED NOT NULL,
  `op_number`   INT UNSIGNED NOT NULL,
  `op_name`     VARCHAR(120) NOT NULL,
  `behaviour`   ENUM('Clocking','Non-Clocking') NOT NULL DEFAULT 'Clocking',
  `op_type`     ENUM('Standard','Inspection','Final Test','Final Inspection','Book to Stock','Material Kitting') NOT NULL DEFAULT 'Standard',
  `dept_id`     INT UNSIGNED DEFAULT NULL,
  `resource_id` INT UNSIGNED DEFAULT NULL,
  `doc_rev_id`  INT UNSIGNED DEFAULT NULL,
  `setup_mins`  INT UNSIGNED NOT NULL DEFAULT 0,
  `actual_mins` INT UNSIGNED NOT NULL DEFAULT 0,
  `skill_id`    INT UNSIGNED DEFAULT NULL,
  `gate_type`   ENUM('CLOCK_ON','COMPLETION','BOTH') DEFAULT NULL,
  UNIQUE KEY `uq_op` (`routing_id`,`op_number`),
  FOREIGN KEY (`routing_id`) REFERENCES `routings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`dept_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`resource_id`) REFERENCES `resources`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`doc_rev_id`) REFERENCES `document_revisions`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`skill_id`) REFERENCES `skills`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `quality_variables` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `routing_id`  INT UNSIGNED NOT NULL,
  `op_id`       INT UNSIGNED NOT NULL,
  `code`        VARCHAR(20) NOT NULL,
  `name`        VARCHAR(120) NOT NULL,
  `uom_id`      INT UNSIGNED NOT NULL,
  `lower_limit` DECIMAL(18,6) DEFAULT NULL,
  `target`      DECIMAL(18,6) DEFAULT NULL,
  `upper_limit` DECIMAL(18,6) DEFAULT NULL,
  FOREIGN KEY (`routing_id`) REFERENCES `routings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`op_id`) REFERENCES `routing_operations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`uom_id`) REFERENCES `units_of_measure`(`id`)
) ENGINE=InnoDB;

-- ── Work Orders ───────────────────────────────────────────────────────────────
CREATE TABLE `work_orders` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`           INT UNSIGNED NOT NULL,
  `part_id`          INT UNSIGNED NOT NULL,
  `routing_id`       INT UNSIGNED NOT NULL,
  `wo_number`        VARCHAR(20) NOT NULL UNIQUE,
  `status`           ENUM('Open','In Progress','Hard Hold','Soft Hold','Complete','Cancelled') NOT NULL DEFAULT 'Open',
  `quantity`         INT UNSIGNED NOT NULL DEFAULT 1,
  `serial_controlled`TINYINT(1) NOT NULL DEFAULT 1,
  `priority`         TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `planned_start`    DATETIME DEFAULT NULL,
  `planned_finish`   DATETIME DEFAULT NULL,
  `completed_at`     DATETIME DEFAULT NULL,
  `notes`            TEXT DEFAULT NULL,
  `created_by`       INT UNSIGNED DEFAULT NULL,
  `created_at`       DATETIME NOT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`),
  FOREIGN KEY (`part_id`) REFERENCES `parts`(`id`),
  FOREIGN KEY (`routing_id`) REFERENCES `routings`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `work_order_serials` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `wo_id`         INT UNSIGNED NOT NULL,
  `serial_number` VARCHAR(60) NOT NULL,
  `current_op_id` INT UNSIGNED NOT NULL,
  `quantity`      INT UNSIGNED NOT NULL DEFAULT 1,
  `status`        ENUM('Available','In Progress','Complete','Hold','Scrapped') NOT NULL DEFAULT 'Available',
  `created_at`    DATETIME NOT NULL,
  UNIQUE KEY `uq_wo_serial` (`wo_id`,`serial_number`),
  FOREIGN KEY (`wo_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`current_op_id`) REFERENCES `routing_operations`(`id`)
) ENGINE=InnoDB;

-- ── Clock Events ──────────────────────────────────────────────────────────────
CREATE TABLE `clock_events` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `wo_id`         INT UNSIGNED NOT NULL,
  `wo_serial_id`  INT UNSIGNED NOT NULL,
  `routing_op_id` INT UNSIGNED NOT NULL,
  `user_id`       INT UNSIGNED NOT NULL,
  `clock_on`      DATETIME NOT NULL,
  `clock_off`     DATETIME DEFAULT NULL,
  INDEX `idx_ce_wo` (`wo_id`),
  INDEX `idx_ce_serial` (`wo_serial_id`),
  INDEX `idx_ce_open` (`wo_serial_id`,`clock_off`),
  FOREIGN KEY (`wo_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`wo_serial_id`) REFERENCES `work_order_serials`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`routing_op_id`) REFERENCES `routing_operations`(`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB;

-- ── Quality Results ───────────────────────────────────────────────────────────
CREATE TABLE `quality_results` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `wo_id`           INT UNSIGNED NOT NULL,
  `wo_serial_id`    INT UNSIGNED NOT NULL,
  `quality_var_id`  INT UNSIGNED NOT NULL,
  `value`           DECIMAL(18,6) NOT NULL,
  `in_spec`         TINYINT(1) NOT NULL DEFAULT 1,
  `recorded_by`     INT UNSIGNED DEFAULT NULL,
  `recorded_at`     DATETIME NOT NULL,
  UNIQUE KEY `uq_qr` (`wo_serial_id`,`quality_var_id`),
  FOREIGN KEY (`wo_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`wo_serial_id`) REFERENCES `work_order_serials`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`quality_var_id`) REFERENCES `quality_variables`(`id`),
  FOREIGN KEY (`recorded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Non-Conformances ──────────────────────────────────────────────────────────
CREATE TABLE `nonconformances` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `nc_number`   VARCHAR(20) NOT NULL UNIQUE,
  `org_id`      INT UNSIGNED NOT NULL,
  `wo_id`       INT UNSIGNED DEFAULT NULL,
  `part_id`     INT UNSIGNED DEFAULT NULL,
  `serial_number`VARCHAR(60) DEFAULT NULL,
  `description` TEXT NOT NULL,
  `status`      ENUM('Open','Under Review','Closed') NOT NULL DEFAULT 'Open',
  `disposition` ENUM('Scrap','Rework','Use As Is','Return to Vendor') DEFAULT NULL,
  `resolution`  TEXT DEFAULT NULL,
  `raised_by`   INT UNSIGNED DEFAULT NULL,
  `raised_at`   DATETIME NOT NULL,
  `updated_at`  DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`),
  FOREIGN KEY (`wo_id`) REFERENCES `work_orders`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`part_id`) REFERENCES `parts`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`raised_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Calibration ───────────────────────────────────────────────────────────────
CREATE TABLE `calibration_items` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `org_id`        INT UNSIGNED NOT NULL,
  `code`          VARCHAR(30) NOT NULL,
  `name`          VARCHAR(120) NOT NULL,
  `location`      VARCHAR(80) DEFAULT NULL,
  `interval_days` INT UNSIGNED NOT NULL DEFAULT 365,
  `last_cal_date` DATE DEFAULT NULL,
  `next_cal_date` DATE DEFAULT NULL,
  `created_at`    DATETIME NOT NULL,
  `updated_at`    DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`)
) ENGINE=InnoDB;

-- ── Broadcast Messages ────────────────────────────────────────────────────────
CREATE TABLE `broadcast_messages` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `message`    VARCHAR(500) NOT NULL,
  `colour`     VARCHAR(20) NOT NULL DEFAULT 'warning',
  `is_active`  TINYINT(1) NOT NULL DEFAULT 0,
  `created_by` INT UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Integration ───────────────────────────────────────────────────────────────
CREATE TABLE `integration_inbound` (
  `id`                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `transaction_number` VARCHAR(60) NOT NULL UNIQUE,
  `org_id`             INT UNSIGNED DEFAULT NULL,
  `message_type`       VARCHAR(40) NOT NULL,
  `payload`            MEDIUMTEXT NOT NULL,
  `status`             ENUM('Received','Processed','Error') NOT NULL DEFAULT 'Received',
  `error_message`      TEXT DEFAULT NULL,
  `received_at`        DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE `integration_outbound` (
  `id`                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `transaction_number` VARCHAR(60) NOT NULL UNIQUE,
  `org_id`             INT UNSIGNED NOT NULL,
  `message_type`       VARCHAR(40) NOT NULL,
  `payload`            MEDIUMTEXT NOT NULL,
  `status`             ENUM('Pending','Sent','Error') NOT NULL DEFAULT 'Pending',
  `placed_at`          DATETIME NOT NULL,
  `sent_at`            DATETIME DEFAULT NULL,
  FOREIGN KEY (`org_id`) REFERENCES `orgs`(`id`)
) ENGINE=InnoDB;

-- ── Audit & Security Logs ─────────────────────────────────────────────────────
CREATE TABLE `audit_log` (
  `id`          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `entity_type` VARCHAR(40) NOT NULL,
  `entity_id`   INT UNSIGNED NOT NULL,
  `action`      VARCHAR(30) NOT NULL,
  `detail`      TEXT DEFAULT NULL,
  `user_id`     INT UNSIGNED DEFAULT NULL,
  `created_at`  DATETIME NOT NULL,
  INDEX `idx_al_entity` (`entity_type`,`entity_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `security_log` (
  `id`          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `event`       VARCHAR(40) NOT NULL,
  `severity`    ENUM('Low','Medium','High','Critical') NOT NULL DEFAULT 'Low',
  `detail`      TEXT DEFAULT NULL,
  `user_id`     INT UNSIGNED DEFAULT NULL,
  `ip_address`  VARCHAR(45) DEFAULT NULL,
  `created_at`  DATETIME NOT NULL,
  INDEX `idx_sl_severity` (`severity`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

SET foreign_key_checks = 1;
