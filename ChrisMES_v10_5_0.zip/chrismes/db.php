<?php
// =============================================================================
// ChrisMES - db.php
// Version: 10.5.0
// PDO database connector. Include this file wherever DB access is needed.
// =============================================================================

require_once __DIR__ . '/config.php';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST, DB_NAME, DB_CHARSET
        );
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log and show a safe error — never expose credentials
            error_log('ChrisMES DB connection failed: ' . $e->getMessage());
            http_response_code(503);
            die('<h1>Service Unavailable</h1><p>Database connection failed. Please contact IT Admin.</p>');
        }
    }
    return $pdo;
}

/**
 * Convenience: run a query and return all rows.
 */
function db_rows(string $sql, array $params = []): array {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Convenience: run a query and return a single row (or null).
 */
function db_row(string $sql, array $params = []): ?array {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Convenience: run an INSERT/UPDATE/DELETE; return affected row count.
 */
function db_exec(string $sql, array $params = []): int {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->rowCount();
}

/**
 * Convenience: return the last inserted auto-increment ID.
 */
function db_last_id(): string {
    return db()->lastInsertId();
}
