<?php
// =============================================================================
// ChrisMES - routings/index.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Routings';
$action  = $_GET['action'] ?? 'list';
$view_id = (int)($_GET['id'] ?? 0);

// ── Create routing ────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create') {
    require_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP');
    $part_id = (int)$_POST['part_id'];
    $part    = db_row('SELECT p.*,o.code AS org_code FROM parts p JOIN orgs o ON o.id=p.org_id WHERE p.id=?',[$part_id]);
    if (!$part) { flash_set('danger','Part not found.'); header('Location: /chrismes/routings/index.php'); exit; }

    $routing_name = $part['org_code'] . '-' . $part['part_number'];
    db_exec('INSERT INTO routings (org_id,part_id,name,revision,status,created_by,created_at)
             VALUES (?,?,?,1,?,?,NOW())',[$part['org_id'],$part_id,$routing_name,'Draft',current_user()['id']]);
    $r_id = (int)db_last_id();
    audit_log('routing',$r_id,'CREATE',"Routing {$routing_name} created");
    flash_set('success','Routing created at Revision 1 (Draft).');
    header('Location: /chrismes/routings/editor.php?id='.$r_id); exit;
}

// ── Approve routing ───────────────────────────────────────────────────────────
if ($action === 'approve' && $view_id) {
    require_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP');
    $routing = db_row('SELECT * FROM routings WHERE id=?',[$view_id]);
    if (!$routing) { flash_set('danger','Routing not found.'); header('Location: /chrismes/routings/index.php'); exit; }
    if (!AUTO_APPROVE && $routing['created_by'] == current_user()['id']) {
        flash_set('danger','You cannot approve your own routing. A different user must approve.'); header('Location: /chrismes/routings/editor.php?id='.$view_id); exit;
    }
    db_exec('UPDATE routings SET status=?,approved_by=?,approved_at=NOW() WHERE id=?',['Approved',current_user()['id'],$view_id]);
    audit_log('routing',$view_id,'APPROVE',"Approved by ".current_user()['username']);
    flash_set('success','Routing approved.');
    header('Location: /chrismes/routings/editor.php?id='.$view_id); exit;
}

// ── List ──────────────────────────────────────────────────────────────────────
$org_id = user_org_id();
$params = $org_id ? [$org_id] : [];
$where  = $org_id ? 'WHERE r.org_id=?' : '';
$routings = db_rows("SELECT r.*,p.part_number,p.description,o.code AS org_code,
                     u.known_as AS approved_by_name
                     FROM routings r
                     JOIN parts p ON p.id=r.part_id
                     JOIN orgs o ON o.id=r.org_id
                     LEFT JOIN users u ON u.id=r.approved_by
                     $where ORDER BY r.name, r.revision DESC", $params);

$parts = db_rows('SELECT p.id,p.part_number,p.description,o.code AS org_code FROM parts p JOIN orgs o ON o.id=p.org_id' . ($org_id?' WHERE p.org_id=?':'') . ' ORDER BY p.part_number', $params);

include __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="mb-0 text-muted">Manage operation routings for manufactured parts.</p>
    <?php if (has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal">
        <i class="bi bi-plus-circle me-1"></i>Create Routing
    </button>
    <?php endif; ?>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr><th>Org</th><th>Routing Name</th><th>Part</th><th>Rev</th><th>Status</th><th>Approved By</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($routings as $r): ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($r['org_code']) ?></span></td>
                <td><code><?= h($r['name']) ?></code></td>
                <td><?= h($r['description']) ?></td>
                <td><?= h($r['revision']) ?></td>
                <td><span class="badge <?= $r['status']==='Approved'?'bg-success':($r['status']==='Draft'?'bg-warning text-dark':'bg-secondary') ?>"><?= h($r['status']) ?></span></td>
                <td><?= h($r['approved_by_name'] ?? '—') ?></td>
                <td>
                    <a href="/chrismes/routings/editor.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-pencil-square me-1"></i>Open
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($routings)): ?><tr><td colspan="7" class="text-center text-muted py-3">No routings yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="?action=create">
                <div class="modal-header"><h5 class="modal-title">Create Routing</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Part Number <span class="text-danger">*</span></label>
                        <select name="part_id" class="form-select" required>
                            <option value="">— Select Part —</option>
                            <?php foreach ($parts as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= h($p['org_code']) ?> / <?= h($p['part_number']) ?> — <?= h($p['description']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <p class="text-muted small">The routing will be named <code>ORG-PARTNUMBER</code> automatically.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
