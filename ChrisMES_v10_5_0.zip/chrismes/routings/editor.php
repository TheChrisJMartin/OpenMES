<?php
// =============================================================================
// ChrisMES - routings/editor.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();

$routing_id = (int)($_GET['id'] ?? 0);
$routing = db_row('SELECT r.*,p.part_number,p.description,o.code AS org_code,o.id AS org_id,
                   u.known_as AS approved_by_name
                   FROM routings r JOIN parts p ON p.id=r.part_id JOIN orgs o ON o.id=r.org_id
                   LEFT JOIN users u ON u.id=r.approved_by WHERE r.id=?',[$routing_id]);
if (!$routing) { flash_set('danger','Routing not found.'); header('Location: /chrismes/routings/index.php'); exit; }

$page_title = 'Routing: ' . $routing['name'] . ' Rev ' . $routing['revision'];
$can_edit   = $routing['status'] === 'Draft' && has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP');

// ── Save operation ────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_op'])) {
    if (!$can_edit) { flash_set('danger','Routing not editable.'); header('Location: /chrismes/routings/editor.php?id='.$routing_id); exit; }
    $op_id       = (int)($_POST['op_id'] ?? 0);
    $op_number   = (int)$_POST['op_number'];
    $op_name     = trim($_POST['op_name'] ?? '');
    $behaviour   = $_POST['behaviour'] ?? 'Clocking';
    $op_type     = $_POST['op_type'] ?? 'Standard';
    $dept_id     = $_POST['dept_id'] !== '' ? (int)$_POST['dept_id'] : null;
    $resource_id = $_POST['resource_id'] !== '' ? (int)$_POST['resource_id'] : null;
    $doc_rev_id  = $_POST['doc_rev_id'] !== '' ? (int)$_POST['doc_rev_id'] : null;
    $setup_mins  = (int)($_POST['setup_mins'] ?? 0);
    $actual_mins = (int)($_POST['actual_mins'] ?? 0);
    $skill_id    = $_POST['skill_id'] !== '' ? (int)$_POST['skill_id'] : null;
    $gate_type   = $_POST['gate_type'] ?? null;

    if ($op_id) {
        db_exec('UPDATE routing_operations SET op_number=?,op_name=?,behaviour=?,op_type=?,dept_id=?,resource_id=?,doc_rev_id=?,setup_mins=?,actual_mins=?,skill_id=?,gate_type=? WHERE id=? AND routing_id=?',
            [$op_number,$op_name,$behaviour,$op_type,$dept_id,$resource_id,$doc_rev_id,$setup_mins,$actual_mins,$skill_id,$gate_type,$op_id,$routing_id]);
    } else {
        db_exec('INSERT INTO routing_operations (routing_id,op_number,op_name,behaviour,op_type,dept_id,resource_id,doc_rev_id,setup_mins,actual_mins,skill_id,gate_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            [$routing_id,$op_number,$op_name,$behaviour,$op_type,$dept_id,$resource_id,$doc_rev_id,$setup_mins,$actual_mins,$skill_id,$gate_type]);
    }
    flash_set('success','Operation saved.');
    header('Location: /chrismes/routings/editor.php?id='.$routing_id.'&tab=ops'); exit;
}

// ── Delete operation ──────────────────────────────────────────────────────────
if (isset($_GET['del_op']) && $can_edit) {
    db_exec('DELETE FROM routing_operations WHERE id=? AND routing_id=?',[(int)$_GET['del_op'],$routing_id]);
    flash_set('success','Operation removed.');
    header('Location: /chrismes/routings/editor.php?id='.$routing_id.'&tab=ops'); exit;
}

// ── Save quality variable ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_qv'])) {
    if (!$can_edit) { flash_set('danger','Not editable.'); header('Location: /chrismes/routings/editor.php?id='.$routing_id.'&tab=qv'); exit; }
    $qv_id    = (int)($_POST['qv_id'] ?? 0);
    $op_id    = (int)$_POST['op_id_qv'];
    $code_qv  = strtoupper(trim($_POST['code_qv'] ?? ''));
    $name_qv  = trim($_POST['name_qv'] ?? '');
    $uom_id   = (int)$_POST['uom_id_qv'];
    $low      = $_POST['low']    !== '' ? (float)$_POST['low']    : null;
    $target   = $_POST['target'] !== '' ? (float)$_POST['target'] : null;
    $high     = $_POST['high']   !== '' ? (float)$_POST['high']   : null;
    if ($qv_id) {
        db_exec('UPDATE quality_variables SET op_id=?,code=?,name=?,uom_id=?,lower_limit=?,target=?,upper_limit=? WHERE id=? AND routing_id=?',
            [$op_id,$code_qv,$name_qv,$uom_id,$low,$target,$high,$qv_id,$routing_id]);
    } else {
        db_exec('INSERT INTO quality_variables (routing_id,op_id,code,name,uom_id,lower_limit,target,upper_limit) VALUES (?,?,?,?,?,?,?,?)',
            [$routing_id,$op_id,$code_qv,$name_qv,$uom_id,$low,$target,$high]);
    }
    flash_set('success','Quality variable saved.');
    header('Location: /chrismes/routings/editor.php?id='.$routing_id.'&tab=qv'); exit;
}

if (isset($_GET['del_qv']) && $can_edit) {
    db_exec('DELETE FROM quality_variables WHERE id=? AND routing_id=?',[(int)$_GET['del_qv'],$routing_id]);
    flash_set('success','Variable removed.');
    header('Location: /chrismes/routings/editor.php?id='.$routing_id.'&tab=qv'); exit;
}

// ── Load data ─────────────────────────────────────────────────────────────────
$operations = db_rows('SELECT ro.*,d.code AS dept_code,r.code AS res_code,dr.revision_number,doc.description AS doc_desc,s.name AS skill_name
                       FROM routing_operations ro
                       LEFT JOIN departments d ON d.id=ro.dept_id
                       LEFT JOIN resources r ON r.id=ro.resource_id
                       LEFT JOIN document_revisions dr ON dr.id=ro.doc_rev_id
                       LEFT JOIN documents doc ON doc.id=dr.doc_id
                       LEFT JOIN skills s ON s.id=ro.skill_id
                       WHERE ro.routing_id=? ORDER BY ro.op_number', [$routing_id]);

$quality_vars = db_rows('SELECT qv.*,ro.op_number,u.code AS uom_code FROM quality_variables qv JOIN routing_operations ro ON ro.id=qv.op_id JOIN units_of_measure u ON u.id=qv.uom_id WHERE qv.routing_id=? ORDER BY ro.op_number,qv.code', [$routing_id]);

$depts     = db_rows('SELECT d.id,d.code,d.name,o.code AS org_code FROM departments d JOIN orgs o ON o.id=d.org_id WHERE d.org_id=? AND d.is_active=1 ORDER BY d.code',[$routing['org_id']]);
$resources = db_rows('SELECT r.id,r.code,r.name,d.code AS dept_code FROM resources r JOIN departments d ON d.id=r.dept_id WHERE d.org_id=? AND r.is_active=1 ORDER BY r.code',[$routing['org_id']]);
$doc_revs  = db_rows("SELECT dr.id,dr.revision_number,doc.description,doc.part_number FROM document_revisions dr JOIN documents doc ON doc.id=dr.doc_id WHERE dr.status='Approved' AND doc.org_id=? ORDER BY doc.description",[$routing['org_id']]);
$uoms      = db_rows('SELECT id,code FROM units_of_measure ORDER BY code');
$skills    = db_rows('SELECT id,code,name FROM skills WHERE org_id=? OR org_id IS NULL ORDER BY code',[$routing['org_id']]);

$op_types  = ['Standard','Inspection','Final Test','Final Inspection','Book to Stock','Material Kitting'];
$behaviours= ['Clocking','Non-Clocking'];
$gate_types= ['CLOCK_ON','COMPLETION','BOTH'];

// Inspection ops for quality variables dropdown
$inspection_ops = array_filter($operations, fn($o) => in_array($o['op_type'],['Inspection','Final Test','Final Inspection']));

$active_tab = $_GET['tab'] ?? 'ops';
include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex align-items-center gap-3 mb-4">
    <a href="/chrismes/routings/index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
        <h5 class="mb-0"><?= h($routing['name']) ?> <span class="text-muted fw-normal">Rev <?= h($routing['revision']) ?></span></h5>
        <small class="text-muted"><?= h($routing['part_number']) ?> — <?= h($routing['description']) ?></small>
    </div>
    <span class="badge ms-2 <?= $routing['status']==='Approved'?'bg-success':($routing['status']==='Draft'?'bg-warning text-dark':'bg-secondary') ?>">
        <?= h($routing['status']) ?>
    </span>
    <div class="ms-auto d-flex gap-2">
        <?php if ($routing['status'] === 'Draft' && has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
        <a href="/chrismes/routings/index.php?action=approve&id=<?= $routing_id ?>"
           class="btn btn-success" data-confirm="Approve this routing revision?">
            <i class="bi bi-check-circle me-1"></i>Approve
        </a>
        <?php endif; ?>
    </div>
</div>

<?php if ($routing['status'] === 'Approved'): ?>
<div class="alert alert-success small">
    <i class="bi bi-check-circle me-1"></i>
    Approved by <?= h($routing['approved_by_name']) ?> on <?= date('d M Y H:i', strtotime($routing['approved_at'])) ?>
</div>
<?php endif; ?>

<ul class="nav nav-tabs mb-4">
    <li class="nav-item"><a class="nav-link <?= $active_tab==='ops'?'active':'' ?>" href="?id=<?= $routing_id ?>&tab=ops">Operations</a></li>
    <li class="nav-item"><a class="nav-link <?= $active_tab==='qv'?'active':'' ?>" href="?id=<?= $routing_id ?>&tab=qv">Quality Variables</a></li>
</ul>

<?php if ($active_tab === 'ops'): ?>
<!-- ── Operations Tab ── -->
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-semibold">Operations</span>
        <?php if ($can_edit): ?>
        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#opModal" onclick="resetOpForm()">
            <i class="bi bi-plus-circle me-1"></i>Add Operation
        </button>
        <?php endif; ?>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr><th>Op#</th><th>Name</th><th>Behaviour</th><th>Type</th><th>Department</th><th>Resource</th><th>Document</th><th>Setup</th><th>Actual</th><th>Skill</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($operations as $op): ?>
            <tr class="<?= $op['behaviour']==='Non-Clocking'?'op-row-nonclocking':'' ?> <?= in_array($op['op_type'],['Inspection','Final Inspection'])?'op-row-inspection':'' ?> <?= in_array($op['op_type'],['Final Test'])?'op-row-test':'' ?> <?= $op['op_type']==='Book to Stock'?'op-row-bookstock':'' ?>">
                <td><strong><?= str_pad((int)$op['op_number'],3,'0',STR_PAD_LEFT) ?></strong></td>
                <td><?= h($op['op_name']) ?></td>
                <td><span class="badge <?= $op['behaviour']==='Non-Clocking'?'bg-secondary':'bg-primary' ?>"><?= h($op['behaviour']) ?></span></td>
                <td><span class="badge bg-info text-dark"><?= h($op['op_type']) ?></span></td>
                <td><?= h($op['dept_code'] ?? '—') ?></td>
                <td><?= h($op['res_code'] ?? '—') ?></td>
                <td><?= $op['doc_rev_id'] ? h($op['doc_desc']).' Rev '.format_revision((int)$op['revision_number']) : '—' ?></td>
                <td><?= $op['setup_mins'] ? h($op['setup_mins']).'m' : '—' ?></td>
                <td><?= $op['actual_mins'] ? h($op['actual_mins']).'m' : '—' ?></td>
                <td><?= $op['skill_name'] ? '<span class="badge bg-warning text-dark">'.h($op['skill_name']).'</span>' : '—' ?></td>
                <td>
                    <?php if ($can_edit): ?>
                    <button class="btn btn-sm btn-outline-secondary" onclick="editOp(<?= htmlspecialchars(json_encode($op)) ?>)">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <a href="?id=<?= $routing_id ?>&del_op=<?= $op['id'] ?>"
                       class="btn btn-sm btn-outline-danger" data-confirm="Remove operation <?= $op['op_number'] ?>?">
                        <i class="bi bi-trash"></i>
                    </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($operations)): ?><tr><td colspan="11" class="text-center text-muted py-3">No operations yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Operation Modal -->
<?php if ($can_edit): ?>
<div class="modal fade" id="opModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post">
                <input type="hidden" name="save_op" value="1">
                <input type="hidden" name="op_id" id="op_id" value="0">
                <div class="modal-header"><h5 class="modal-title" id="opModalTitle">Add Operation</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Op Number <span class="text-danger">*</span></label>
                            <input type="number" name="op_number" id="op_number" class="form-control" placeholder="010" required>
                        </div>
                        <div class="col-md-9">
                            <label class="form-label">Operation Name <span class="text-danger">*</span></label>
                            <input type="text" name="op_name" id="op_name" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Behaviour</label>
                            <select name="behaviour" id="op_behaviour" class="form-select">
                                <?php foreach ($behaviours as $b): ?><option><?= $b ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Operation Type</label>
                            <select name="op_type" id="op_type" class="form-select">
                                <?php foreach ($op_types as $t): ?><option><?= $t ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Department</label>
                            <select name="dept_id" id="op_dept" class="form-select">
                                <option value="">— None —</option>
                                <?php foreach ($depts as $d): ?><option value="<?= $d['id'] ?>"><?= h($d['code']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Resource</label>
                            <select name="resource_id" id="op_resource" class="form-select">
                                <option value="">— None —</option>
                                <?php foreach ($resources as $r): ?><option value="<?= $r['id'] ?>"><?= h($r['code']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Work Instruction (Approved)</label>
                            <select name="doc_rev_id" id="op_doc" class="form-select">
                                <option value="">— None —</option>
                                <?php foreach ($doc_revs as $dr): ?><option value="<?= $dr['id'] ?>"><?= h($dr['description']) ?> Rev <?= format_revision((int)$dr['revision_number']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Setup (mins)</label>
                            <input type="number" name="setup_mins" id="op_setup" class="form-control" value="0" min="0">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Actual (mins)</label>
                            <input type="number" name="actual_mins" id="op_actual" class="form-control" value="0" min="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Skill Required</label>
                            <select name="skill_id" id="op_skill" class="form-select">
                                <option value="">— None —</option>
                                <?php foreach ($skills as $s): ?><option value="<?= $s['id'] ?>"><?= h($s['code']) ?> — <?= h($s['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Gate</label>
                            <select name="gate_type" id="op_gate" class="form-select">
                                <option value="">—</option>
                                <?php foreach ($gate_types as $g): ?><option value="<?= $g ?>"><?= $g ?></option><?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Operation</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetOpForm() {
    document.getElementById('op_id').value = '0';
    document.getElementById('opModalTitle').textContent = 'Add Operation';
    document.getElementById('op_number').value = '';
    document.getElementById('op_name').value = '';
    document.getElementById('op_behaviour').value = 'Clocking';
    document.getElementById('op_type').value = 'Standard';
    document.getElementById('op_dept').value = '';
    document.getElementById('op_resource').value = '';
    document.getElementById('op_doc').value = '';
    document.getElementById('op_setup').value = '0';
    document.getElementById('op_actual').value = '0';
    document.getElementById('op_skill').value = '';
    document.getElementById('op_gate').value = '';
}
function editOp(op) {
    document.getElementById('op_id').value = op.id;
    document.getElementById('opModalTitle').textContent = 'Edit Operation ' + op.op_number;
    document.getElementById('op_number').value = op.op_number;
    document.getElementById('op_name').value = op.op_name;
    document.getElementById('op_behaviour').value = op.behaviour;
    document.getElementById('op_type').value = op.op_type;
    document.getElementById('op_dept').value = op.dept_id || '';
    document.getElementById('op_resource').value = op.resource_id || '';
    document.getElementById('op_doc').value = op.doc_rev_id || '';
    document.getElementById('op_setup').value = op.setup_mins || 0;
    document.getElementById('op_actual').value = op.actual_mins || 0;
    document.getElementById('op_skill').value = op.skill_id || '';
    document.getElementById('op_gate').value = op.gate_type || '';
    new bootstrap.Modal(document.getElementById('opModal')).show();
}
</script>
<?php endif; ?>

<?php elseif ($active_tab === 'qv'): ?>
<!-- ── Quality Variables Tab ── -->
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-semibold">Quality Variables</span>
        <?php if ($can_edit && !empty($inspection_ops)): ?>
        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#qvModal" onclick="resetQvForm()">
            <i class="bi bi-plus-circle me-1"></i>Add Variable
        </button>
        <?php elseif (empty($inspection_ops)): ?>
        <span class="text-muted small">Add Inspection/Test operations first.</span>
        <?php endif; ?>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light"><tr><th>Op</th><th>Code</th><th>Name</th><th>UoM</th><th>Lower</th><th>Target</th><th>Upper</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($quality_vars as $qv): ?>
            <tr>
                <td><code><?= str_pad((int)$qv['op_number'],3,'0',STR_PAD_LEFT) ?></code></td>
                <td><code><?= h($qv['code']) ?></code></td>
                <td><?= h($qv['name']) ?></td>
                <td><?= h($qv['uom_code']) ?></td>
                <td><?= $qv['lower_limit'] ?? '—' ?></td>
                <td><?= $qv['target'] ?? '—' ?></td>
                <td><?= $qv['upper_limit'] ?? '—' ?></td>
                <td>
                    <?php if ($can_edit): ?>
                    <a href="?id=<?= $routing_id ?>&del_qv=<?= $qv['id'] ?>&tab=qv"
                       class="btn btn-sm btn-outline-danger" data-confirm="Remove this variable?">
                        <i class="bi bi-trash"></i>
                    </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($quality_vars)): ?><tr><td colspan="8" class="text-center text-muted py-3">No quality variables defined.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($can_edit): ?>
<div class="modal fade" id="qvModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <input type="hidden" name="save_qv" value="1">
                <input type="hidden" name="qv_id" id="qv_id" value="0">
                <div class="modal-header"><h5 class="modal-title">Add Quality Variable</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Operation (Inspection / Test only) <span class="text-danger">*</span></label>
                        <select name="op_id_qv" class="form-select" required>
                            <option value="">— Select —</option>
                            <?php foreach ($inspection_ops as $iop): ?>
                            <option value="<?= $iop['id'] ?>"><?= str_pad((int)$iop['op_number'],3,'0',STR_PAD_LEFT) ?> — <?= h($iop['op_name']) ?> (<?= h($iop['op_type']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Code</label><input type="text" name="code_qv" class="form-control text-uppercase" placeholder="BREW-TEMP" required></div>
                        <div class="col-md-8"><label class="form-label">Name</label><input type="text" name="name_qv" class="form-control" placeholder="Brew Temperature" required></div>
                        <div class="col-md-4"><label class="form-label">UoM</label>
                            <select name="uom_id_qv" class="form-select" required>
                                <option value="">—</option>
                                <?php foreach ($uoms as $u): ?><option value="<?= $u['id'] ?>"><?= h($u['code']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2-5"><label class="form-label">Lower</label><input type="number" step="any" name="low" class="form-control" placeholder="Optional"></div>
                        <div class="col-md-2-5"><label class="form-label">Target</label><input type="number" step="any" name="target" class="form-control" placeholder="Optional"></div>
                        <div class="col-md-2-5"><label class="form-label">Upper</label><input type="number" step="any" name="high" class="form-control" placeholder="Optional"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>function resetQvForm() { /* reset if needed */ }</script>
<?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
