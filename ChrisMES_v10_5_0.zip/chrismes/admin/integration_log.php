<?php
// =============================================================================
// ChrisMES - admin/integration_log.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Integration Log';
$tab = $_GET['tab'] ?? 'inbound';

$inbound  = db_rows("SELECT * FROM integration_inbound ORDER BY received_at DESC LIMIT 100");
$outbound = db_rows("SELECT * FROM integration_outbound ORDER BY placed_at DESC LIMIT 100");
include __DIR__ . '/../includes/header.php';
?>
<ul class="nav nav-tabs mb-4">
    <li class="nav-item"><a class="nav-link <?= $tab==='inbound'?'active':'' ?>" href="?tab=inbound">Inbound</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab==='outbound'?'active':'' ?>" href="?tab=outbound">Outbound</a></li>
</ul>
<?php if ($tab === 'inbound'): ?>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small">
            <thead class="table-light"><tr><th>Transaction #</th><th>Org</th><th>Type</th><th>Status</th><th>Received</th><th>Error</th></tr></thead>
            <tbody>
            <?php foreach ($inbound as $r): ?>
            <tr>
                <td><code><?= h($r['transaction_number']) ?></code></td>
                <td><?= h($r['org_id']) ?></td>
                <td><span class="badge bg-info text-dark"><?= h($r['message_type']) ?></span></td>
                <td><span class="badge <?= $r['status']==='Processed'?'bg-success':($r['status']==='Error'?'bg-danger':'bg-warning text-dark') ?>"><?= h($r['status']) ?></span></td>
                <td><?= date('d M y H:i',strtotime($r['received_at'])) ?></td>
                <td class="text-danger small"><?= h($r['error_message'] ?? '') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($inbound)): ?><tr><td colspan="6" class="text-center text-muted py-3">No inbound messages.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small">
            <thead class="table-light"><tr><th>Transaction #</th><th>Org</th><th>Type</th><th>Status</th><th>Placed</th></tr></thead>
            <tbody>
            <?php foreach ($outbound as $r): ?>
            <tr>
                <td><code><?= h($r['transaction_number']) ?></code></td>
                <td><?= h($r['org_id']) ?></td>
                <td><span class="badge bg-primary"><?= h($r['message_type']) ?></span></td>
                <td><span class="badge <?= $r['status']==='Sent'?'bg-success':($r['status']==='Error'?'bg-danger':'bg-warning text-dark') ?>"><?= h($r['status'] ?? 'Pending') ?></span></td>
                <td><?= date('d M y H:i',strtotime($r['placed_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($outbound)): ?><tr><td colspan="5" class="text-center text-muted py-3">No outbound messages.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
