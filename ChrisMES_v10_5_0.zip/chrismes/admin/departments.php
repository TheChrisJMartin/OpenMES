<?php
// =============================================================================
// ChrisMES - admin/departments.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Departments';
$action  = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

if (DEPTS_LOCKED && $action !== 'list') {
    flash_set('warning','Department editing is disabled via config.php.');
    header('Location: /chrismes/admin/departments.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $org_id = (int)$_POST['org_id'];
    $code   = strtoupper(trim($_POST['code'] ?? ''));
    $name   = trim($_POST['name'] ?? '');
    $active = isset($_POST['is_active']) ? 1 : 0;
    $errors = [];
    if (!$code || strlen($code) > 10) $errors[] = 'Code required (max 10 chars).';
    if (!$name)  $errors[] = 'Name required.';
    if (!$org_id) $errors[] = 'Organisation required.';
    if (!$errors) {
        if ($id) {
            db_exec('UPDATE departments SET org_id=?,code=?,name=?,is_active=?,updated_at=NOW() WHERE id=?',[$org_id,$code,$name,$active,$id]);
            audit_log('department',$id,'UPDATE',"Updated by ".current_user()['username']);
            flash_set('success','Department updated.');
        } else {
            db_exec('INSERT INTO departments (org_id,code,name,is_active,created_at) VALUES (?,?,?,?,NOW())',[$org_id,$code,$name,$active]);
            audit_log('department',(int)db_last_id(),'CREATE',"Created by ".current_user()['username']);
            flash_set('success','Department created.');
        }
        header('Location: /chrismes/admin/departments.php'); exit;
    }
    $action = $id ? 'edit' : 'create'; $edit_id = $id;
}

$edit_dept = null;
if ($action === 'edit' && $edit_id) $edit_dept = db_row('SELECT * FROM departments WHERE id=?',[$edit_id]);

$orgs  = db_rows('SELECT id,code,name FROM orgs WHERE is_active=1 ORDER BY code');
$depts = db_rows('SELECT d.*,o.code AS org_code FROM departments d JOIN orgs o ON o.id=d.org_id ORDER BY o.code,d.code');
include __DIR__ . '/../includes/header.php';
?>
<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="mb-0 text-muted">Departments belong to an organisation and group workstations.</p>
    <?php if (!DEPTS_LOCKED): ?><a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Department</a><?php endif; ?>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light"><tr><th>Org</th><th>Code</th><th>Name</th><th>Active</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($depts as $d): ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($d['org_code']) ?></span></td>
                <td><code><?= h($d['code']) ?></code></td>
                <td><?= h($d['name']) ?></td>
                <td><?= $d['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
                <td><?php if (!DEPTS_LOCKED): ?><a href="?action=edit&id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a><?php endif; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card" style="max-width:520px">
    <div class="card-header fw-semibold"><?= $edit_dept ? 'Edit: '.h($edit_dept['code']) : 'Add Department' ?></div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_dept['id'] ?? 0) ?>">
            <div class="mb-3">
                <label class="form-label">Organisation <span class="text-danger">*</span></label>
                <select name="org_id" class="form-select" required>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o): ?>
                    <option value="<?= $o['id'] ?>" <?= ($edit_dept['org_id'] ?? '') == $o['id'] ? 'selected' : '' ?>><?= h($o['code']) ?> — <?= h($o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Code <span class="text-danger">*</span> <small class="text-muted">(max 10)</small></label>
                <input type="text" name="code" class="form-control text-uppercase" maxlength="10" value="<?= h($_POST['code'] ?? $edit_dept['code'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= h($_POST['name'] ?? $edit_dept['name'] ?? '') ?>" required>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="is_active" id="ia" <?= ($_POST['is_active'] ?? $edit_dept['is_active'] ?? 1) ? 'checked' : '' ?>>
                <label class="form-check-label" for="ia">Active</label>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="/chrismes/admin/departments.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
