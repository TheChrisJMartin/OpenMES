<?php
// =============================================================================
// ChrisMES - admin/resources.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Resources';
$action  = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

if (RESOURCES_LOCKED && $action !== 'list') {
    flash_set('warning','Resource editing disabled via config.php.');
    header('Location: /chrismes/admin/resources.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id      = (int)($_POST['id'] ?? 0);
    $dept_id = (int)$_POST['dept_id'];
    $code    = strtoupper(trim($_POST['code'] ?? ''));
    $name    = trim($_POST['name'] ?? '');
    $active  = isset($_POST['is_active']) ? 1 : 0;
    $errors  = [];
    if (!$code) $errors[] = 'Code required.';
    if (!$name) $errors[] = 'Name required.';
    if (!$dept_id) $errors[] = 'Department required.';
    if (!$errors) {
        if ($id) {
            db_exec('UPDATE resources SET dept_id=?,code=?,name=?,is_active=?,updated_at=NOW() WHERE id=?',[$dept_id,$code,$name,$active,$id]);
        } else {
            db_exec('INSERT INTO resources (dept_id,code,name,is_active,created_at) VALUES (?,?,?,?,NOW())',[$dept_id,$code,$name,$active]);
        }
        flash_set('success','Resource saved.');
        header('Location: /chrismes/admin/resources.php'); exit;
    }
    $action = $id ? 'edit' : 'create'; $edit_id = $id;
}

$edit_res = null;
if ($action === 'edit' && $edit_id) $edit_res = db_row('SELECT * FROM resources WHERE id=?',[$edit_id]);

$depts = db_rows('SELECT d.id,d.code AS dept_code,d.name AS dept_name,o.code AS org_code FROM departments d JOIN orgs o ON o.id=d.org_id WHERE d.is_active=1 ORDER BY o.code,d.code');
$resources = db_rows('SELECT r.*,d.code AS dept_code,o.code AS org_code FROM resources r JOIN departments d ON d.id=r.dept_id JOIN orgs o ON o.id=d.org_id ORDER BY o.code,d.code,r.code');

include __DIR__ . '/../includes/header.php';
?>
<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="mb-0 text-muted">Individual workstations or machines within departments.</p>
    <?php if (!RESOURCES_LOCKED): ?><a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Resource</a><?php endif; ?>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light"><tr><th>Org</th><th>Department</th><th>Code</th><th>Name</th><th>Active</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($resources as $r): ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($r['org_code']) ?></span></td>
                <td><?= h($r['dept_code']) ?></td>
                <td><code><?= h($r['code']) ?></code></td>
                <td><?= h($r['name']) ?></td>
                <td><?= $r['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
                <td><?php if (!RESOURCES_LOCKED): ?><a href="?action=edit&id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a><?php endif; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card" style="max-width:520px">
    <div class="card-header fw-semibold"><?= $edit_res ? 'Edit Resource' : 'Add Resource' ?></div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_res['id'] ?? 0) ?>">
            <div class="mb-3">
                <label class="form-label">Department <span class="text-danger">*</span></label>
                <select name="dept_id" class="form-select" required>
                    <option value="">— Select —</option>
                    <?php foreach ($depts as $d): ?>
                    <option value="<?= $d['id'] ?>" <?= ($edit_res['dept_id'] ?? '') == $d['id'] ? 'selected' : '' ?>><?= h($d['org_code']) ?> / <?= h($d['dept_code']) ?> — <?= h($d['dept_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Code <span class="text-danger">*</span></label>
                <input type="text" name="code" class="form-control text-uppercase" value="<?= h($edit_res['code'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= h($edit_res['name'] ?? '') ?>" required>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="is_active" <?= ($edit_res['is_active'] ?? 1) ? 'checked' : '' ?>>
                <label class="form-check-label">Active</label>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="/chrismes/admin/resources.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
