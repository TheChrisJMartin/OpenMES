<?php
// =============================================================================
// ChrisMES - admin/serial_registers.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN','QUALITY_ENGINEER');
$page_title = 'Serial Number Registers';
$action = $_GET['action'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $org_id    = (int)$_POST['org_id'];
    $code      = strtoupper(trim($_POST['code'] ?? ''));
    $prefix    = strtoupper(trim($_POST['prefix'] ?? ''));
    $suffix    = strtoupper(trim($_POST['suffix'] ?? ''));
    $pad       = max(1,(int)$_POST['pad_length']);
    $start_seq = (int)$_POST['start_seq'];
    $end_seq   = (int)$_POST['end_seq'];
    $errors = [];
    if (!$code)   $errors[] = 'Register code required.';
    if (!$org_id) $errors[] = 'Organisation required.';
    if ($end_seq <= $start_seq) $errors[] = 'End sequence must be greater than start.';
    if (!$errors) {
        db_exec('INSERT INTO serial_registers (org_id,code,prefix,suffix,pad_length,start_seq,end_seq,current_seq,created_at) VALUES (?,?,?,?,?,?,?,?,NOW())',
            [$org_id,$code,$prefix,$suffix,$pad,$start_seq,$end_seq,$start_seq]);
        flash_set('success','Register created.');
        header('Location: /chrismes/admin/serial_registers.php'); exit;
    }
    $action = 'create';
}

$orgs = db_rows('SELECT id,code,name FROM orgs WHERE is_active=1 ORDER BY code');
$regs = db_rows('SELECT r.*,o.code AS org_code FROM serial_registers r JOIN orgs o ON o.id=r.org_id ORDER BY o.code,r.code');
include __DIR__ . '/../includes/header.php';
?>
<div class="row g-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-hash me-2"></i>Serial Number Registers</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light"><tr><th>Org</th><th>Code</th><th>Prefix</th><th>Pad</th><th>Range</th><th>Current</th><th>Remaining</th></tr></thead>
                    <tbody>
                    <?php foreach ($regs as $r):
                        $remaining = $r['end_seq'] - $r['current_seq'] + 1;
                        $pct = 100 - round(($remaining / ($r['end_seq'] - $r['start_seq'] + 1)) * 100);
                    ?>
                    <tr>
                        <td><span class="badge bg-secondary"><?= h($r['org_code']) ?></span></td>
                        <td><code><?= h($r['code']) ?></code></td>
                        <td><code><?= h($r['prefix']) ?>{'<?= h($r['pad_length']) ?> digits'}<?= h($r['suffix']) ?></code></td>
                        <td><?= h($r['pad_length']) ?></td>
                        <td><?= h($r['start_seq']) ?>–<?= h($r['end_seq']) ?></td>
                        <td><?= h($r['current_seq']) ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="progress flex-grow-1" style="height:8px">
                                    <div class="progress-bar <?= $pct > 80 ? 'bg-danger' : ($pct > 60 ? 'bg-warning' : 'bg-success') ?>" style="width:<?= $pct ?>%"></div>
                                </div>
                                <small><?= number_format($remaining) ?></small>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header fw-semibold">Create Register</div>
            <div class="card-body">
                <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Organisation <span class="text-danger">*</span></label>
                        <select name="org_id" class="form-select" required>
                            <option value="">— Select —</option>
                            <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>"><?= h($o['code']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Register Code <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control text-uppercase" placeholder="e.g. BIKE-A" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col"><label class="form-label">Prefix</label><input type="text" name="prefix" class="form-control text-uppercase" placeholder="A"></div>
                        <div class="col"><label class="form-label">Suffix</label><input type="text" name="suffix" class="form-control text-uppercase"></div>
                        <div class="col"><label class="form-label">Pad</label><input type="number" name="pad_length" class="form-control" value="5" min="1" max="12"></div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col"><label class="form-label">Start</label><input type="number" name="start_seq" class="form-control" value="1" min="0" required></div>
                        <div class="col"><label class="form-label">End</label><input type="number" name="end_seq" class="form-control" value="99999" required></div>
                    </div>
                    <div class="alert alert-info small p-2">
                        Example: Prefix=A, Pad=5, Start=1 generates <code>A00001</code>, <code>A00002</code>…
                    </div>
                    <button type="submit" class="btn btn-primary">Create Register</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
