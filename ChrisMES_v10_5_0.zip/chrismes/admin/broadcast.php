<?php
// =============================================================================
// ChrisMES - admin/broadcast.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Broadcast Messages';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message'] ?? '');
    $colour  = $_POST['colour'] ?? 'warning';
    if ($message) {
        db_exec('UPDATE broadcast_messages SET is_active=0');
        db_exec('INSERT INTO broadcast_messages (message,colour,is_active,created_by,created_at) VALUES (?,?,1,?,NOW())',
            [$message,$colour,current_user()['id']]);
        flash_set('success','Broadcast message activated.');
    }
    header('Location: /chrismes/admin/broadcast.php'); exit;
}
if (isset($_GET['deactivate'])) {
    db_exec('UPDATE broadcast_messages SET is_active=0');
    flash_set('success','Broadcast cleared.');
    header('Location: /chrismes/admin/broadcast.php'); exit;
}

$active = db_row("SELECT * FROM broadcast_messages WHERE is_active=1");
$history= db_rows("SELECT bm.*,u.known_as FROM broadcast_messages bm LEFT JOIN users u ON u.id=bm.created_by ORDER BY created_at DESC LIMIT 20");
include __DIR__ . '/../includes/header.php';
?>
<div class="row g-4">
    <div class="col-lg-6">
        <div class="card mb-4">
            <div class="card-header fw-semibold"><i class="bi bi-megaphone me-2"></i>Active Broadcast</div>
            <div class="card-body">
                <?php if ($active): ?>
                <div class="alert alert-<?= h($active['colour']) ?>"><?= h($active['message']) ?></div>
                <a href="?deactivate=1" class="btn btn-outline-danger btn-sm" data-confirm="Clear the broadcast?">
                    <i class="bi bi-x-circle me-1"></i>Clear Message
                </a>
                <?php else: ?>
                <p class="text-muted">No active broadcast.</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header fw-semibold">Set Broadcast Message</div>
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Message <span class="text-danger">*</span></label>
                        <input type="text" name="message" class="form-control" placeholder="e.g. Fire alarm test at 14:00 today." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Colour</label>
                        <select name="colour" class="form-select">
                            <option value="warning">Warning (yellow)</option>
                            <option value="danger">Danger (red)</option>
                            <option value="info">Info (blue)</option>
                            <option value="success">Success (green)</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-megaphone me-1"></i>Activate</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header fw-semibold">Broadcast History</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light"><tr><th>Message</th><th>Colour</th><th>By</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php foreach ($history as $h2): ?>
                    <tr>
                        <td><?= h($h2['message']) ?></td>
                        <td><span class="badge bg-<?= h($h2['colour']) ?>"><?= h($h2['colour']) ?></span></td>
                        <td><?= h($h2['known_as'] ?? '—') ?></td>
                        <td><?= date('d M y H:i',strtotime($h2['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
