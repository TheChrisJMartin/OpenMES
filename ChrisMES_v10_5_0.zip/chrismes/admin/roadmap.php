<?php
// =============================================================================
// ChrisMES - admin/roadmap.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Roadmap & Changelog';
include __DIR__ . '/../includes/header.php';
?>
<div class="card mb-4">
    <div class="card-header fw-semibold"><i class="bi bi-map me-2"></i>ChrisMES Roadmap</div>
    <div class="card-body">
        <p class="text-muted">The roadmap is maintained on the project site. Visit <a href="https://chris-martin.co.uk/chrismes" target="_blank">chris-martin.co.uk/chrismes</a> for upcoming features and the feature request tracker.</p>
    </div>
</div>
<div class="card">
    <div class="card-header fw-semibold"><i class="bi bi-clock-history me-2"></i>Changelog</div>
    <ul class="list-group list-group-flush small">
        <li class="list-group-item">
            <span class="badge bg-primary me-2">v10.5.0</span>
            <strong>June 2026</strong> — Full release: operator screen, quality variables, skill gating, calibration register, training matrix, supervisor view, analytics, integration framework, broadcast messages.
        </li>
        <li class="list-group-item">
            <span class="badge bg-secondary me-2">v10.4.x</span>
            <strong>2025</strong> — Serial allocator transactional rewrite, dark mode, Bootstrap 5.3.
        </li>
        <li class="list-group-item">
            <span class="badge bg-secondary me-2">v10.3.x</span>
            <strong>2024</strong> — Non-conformance module, NC number generator, disposition workflow.
        </li>
        <li class="list-group-item">
            <span class="badge bg-secondary me-2">v10.2.x</span>
            <strong>2024</strong> — Routing editor, quality variables, document management, PDF viewer.
        </li>
        <li class="list-group-item">
            <span class="badge bg-secondary me-2">v10.1.x</span>
            <strong>2023</strong> — Work order creation, serial allocation, clock on/off, time bookings.
        </li>
        <li class="list-group-item">
            <span class="badge bg-secondary me-2">v10.0.0</span>
            <strong>2023</strong> — Initial release: item master, orgs, departments, resources, UoM, users.
        </li>
    </ul>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
