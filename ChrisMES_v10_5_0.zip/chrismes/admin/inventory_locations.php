<?php
// =============================================================================
// ChrisMES - admin/inventory_locations.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Inventory Locations';

$orgs = db_rows('SELECT id,code,name FROM orgs WHERE is_active=1 ORDER BY code');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $org_id = (int)$_POST['org_id'];
    $code   = strtoupper(trim($_POST['code'] ?? ''));
    $name   = trim($_POST['name'] ?? '');
    $active = isset($_POST['is_active']) ? 1 : 0;
    $errors = [];
    if (!$code) $errors[] = 'Location code required.';
    if (!$org_id) $errors[] = 'Organisation required.';
    if (!$errors) {
        if ($id) {
            db_exec('UPDATE inventory_locations SET org_id=?,code=?,name=?,is_active=?,updated_at=NOW() WHERE id=?',[$org_id,$code,$name,$active,$id]);
        } else {
            db_exec('INSERT INTO inventory_locations (org_id,code,name,is_active,created_at) VALUES (?,?,?,?,NOW())',[$org_id,$code,$name,$active]);
        }
        flash_set('success','Location saved.');
        header('Location: /chrismes/admin/inventory_locations.php'); exit;
    }
}

if (isset($_GET['delete'])) {
    db_exec('DELETE FROM inventory_locations WHERE id=?',[(int)$_GET['delete']]);
    flash_set('success','Location deleted.');
    header('Location: /chrismes/admin/inventory_locations.php'); exit;
}

$locs = db_rows('SELECT l.*,o.code AS org_code FROM inventory_locations l JOIN orgs o ON o.id=l.org_id ORDER BY o.code,l.code');
include __DIR__ . '/../includes/header.php';
?>
<div class="row g-4">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-geo-alt me-2"></i>Inventory Locations</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light"><tr><th>Org</th><th>Code</th><th>Name</th><th>Active</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($locs as $l): ?>
                    <tr>
                        <td><span class="badge bg-secondary"><?= h($l['org_code']) ?></span></td>
                        <td><code><?= h($l['code']) ?></code></td>
                        <td><?= h($l['name']) ?></td>
                        <td><?= $l['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
                        <td>
                            <a href="?delete=<?= $l['id'] ?>" class="btn btn-sm btn-outline-danger"
                               data-confirm="Delete location <?= h($l['code']) ?>?"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header fw-semibold">Add Location</div>
            <div class="card-body">
                <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
                <form method="post">
                    <input type="hidden" name="id" value="0">
                    <div class="mb-3">
                        <label class="form-label">Organisation <span class="text-danger">*</span></label>
                        <select name="org_id" class="form-select" required>
                            <option value="">— Select —</option>
                            <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>"><?= h($o['code']) ?> — <?= h($o['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Code <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control text-uppercase" placeholder="e.g. STORES-A1" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Main Stores Bay A">
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="is_active" checked>
                        <label class="form-check-label">Active</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Location</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
