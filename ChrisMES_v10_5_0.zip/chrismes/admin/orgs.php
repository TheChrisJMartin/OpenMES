<?php
// =============================================================================
// ChrisMES - admin/orgs.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');

$page_title = 'Organisations';
$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

if (ORGS_LOCKED && $action !== 'list') {
    flash_set('warning', 'Organisation editing is disabled in config.php.');
    header('Location: /chrismes/admin/orgs.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id   = (int)($_POST['id'] ?? 0);
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $name = trim($_POST['name'] ?? '');
    $type = $_POST['org_type'] ?? 'OE';
    $active = isset($_POST['is_active']) ? 1 : 0;

    $errors = [];
    if (!$code || strlen($code) > 5) $errors[] = 'Code is required (max 5 chars).';
    if (!$name)                       $errors[] = 'Name is required.';
    if (!in_array($type, ['OE','MRO'])) $errors[] = 'Invalid org type.';

    if (!$errors) {
        if ($id) {
            // Code cannot be changed
            db_exec('UPDATE orgs SET name=?,org_type=?,is_active=?,updated_at=NOW() WHERE id=?', [$name,$type,$active,$id]);
            audit_log('org', $id, 'UPDATE', "Updated by ".current_user()['username']);
            flash_set('success', 'Organisation updated.');
        } else {
            $exists = db_row('SELECT id FROM orgs WHERE code=?', [$code]);
            if ($exists) $errors[] = 'Org code already exists.';
            if (!$errors) {
                db_exec('INSERT INTO orgs (code,name,org_type,is_active,created_at) VALUES (?,?,?,?,NOW())',
                    [$code,$name,$type,$active]);
                audit_log('org', (int)db_last_id(), 'CREATE', "Created by ".current_user()['username']);
                flash_set('success', 'Organisation created.');
            }
        }
        if (empty($errors)) { header('Location: /chrismes/admin/orgs.php'); exit; }
    }
    $action = $id ? 'edit' : 'create'; $edit_id = $id;
}

$edit_org = null;
if ($action === 'edit' && $edit_id) {
    $edit_org = db_row('SELECT * FROM orgs WHERE id=?', [$edit_id]);
}

$orgs = db_rows('SELECT * FROM orgs ORDER BY code');
include __DIR__ . '/../includes/header.php';
?>

<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="text-muted mb-0">Manage manufacturing organisations. Org codes are permanent once created.</p>
    <?php if (!ORGS_LOCKED): ?>
    <a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Organisation</a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr><th>Code</th><th>Name</th><th>Type</th><th>Active</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($orgs as $o): ?>
            <tr>
                <td><code class="fw-bold"><?= h($o['code']) ?></code></td>
                <td><?= h($o['name']) ?></td>
                <td><?= h($o['org_type']) ?></td>
                <td><?= $o['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
                <td>
                    <?php if (!ORGS_LOCKED): ?>
                    <a href="?action=edit&id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php else: ?>
<div class="card" style="max-width:520px">
    <div class="card-header fw-semibold">
        <?= $edit_org ? 'Edit Organisation: ' . h($edit_org['code']) : 'Add Organisation' ?>
    </div>
    <div class="card-body">
        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div>
        <?php endif; ?>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_org['id'] ?? 0) ?>">
            <div class="mb-3">
                <label class="form-label">Code <span class="text-danger">*</span> <small class="text-muted">(2–5 chars, permanent)</small></label>
                <input type="text" name="code" class="form-control text-uppercase" maxlength="5"
                       value="<?= h($_POST['code'] ?? $edit_org['code'] ?? '') ?>"
                       <?= $edit_org ? 'readonly' : '' ?> required>
            </div>
            <div class="mb-3">
                <label class="form-label">Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= h($_POST['name'] ?? $edit_org['name'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Type</label>
                <select name="org_type" class="form-select">
                    <?php foreach (['OE'=>'OE — Original Equipment','MRO'=>'MRO — Maintenance, Repair & Overhaul'] as $v=>$l): ?>
                    <option value="<?= $v ?>" <?= ($edit_org['org_type'] ?? 'OE') === $v ? 'selected' : '' ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="is_active" id="is_active"
                       <?= ($_POST['is_active'] ?? $edit_org['is_active'] ?? 1) ? 'checked' : '' ?>>
                <label class="form-check-label" for="is_active">Active</label>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="/chrismes/admin/orgs.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
