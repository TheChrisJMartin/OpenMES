<?php
// =============================================================================
// ChrisMES - admin/uom.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Units of Measure';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $name = trim($_POST['name'] ?? '');
    $errors = [];
    if (!$code) $errors[] = 'Code required.';
    if (!$name) $errors[] = 'Name required.';
    if (!$errors) {
        $exists = db_row('SELECT id FROM units_of_measure WHERE code=?',[$code]);
        if ($exists) { $errors[] = 'Code already exists.'; }
        else {
            db_exec('INSERT INTO units_of_measure (code,name,is_system,created_at) VALUES (?,?,0,NOW())',[$code,$name]);
            flash_set('success',"UoM {$code} added.");
            header('Location: /chrismes/admin/uom.php'); exit;
        }
    }
}

if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    $uom = db_row('SELECT * FROM units_of_measure WHERE id=?',[$del_id]);
    if ($uom && !$uom['is_system']) {
        db_exec('DELETE FROM units_of_measure WHERE id=? AND is_system=0',[$del_id]);
        flash_set('success','UoM deleted.');
    } else {
        flash_set('danger','System UoMs cannot be deleted.');
    }
    header('Location: /chrismes/admin/uom.php'); exit;
}

$uoms = db_rows('SELECT * FROM units_of_measure ORDER BY is_system DESC, code');
include __DIR__ . '/../includes/header.php';
?>
<div class="row g-4">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-rulers me-2"></i>Units of Measure</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small align-middle">
                    <thead class="table-light"><tr><th>Code</th><th>Name</th><th>Type</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($uoms as $u): ?>
                    <tr>
                        <td><code><?= h($u['code']) ?></code></td>
                        <td><?= h($u['name']) ?></td>
                        <td><?= $u['is_system'] ? '<span class="badge bg-primary">System</span>' : '<span class="badge bg-secondary">Custom</span>' ?></td>
                        <td>
                            <?php if (!$u['is_system']): ?>
                            <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger"
                               data-confirm="Delete UoM <?= h($u['code']) ?>?"><i class="bi bi-trash"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header fw-semibold">Add Custom UoM</div>
            <div class="card-body">
                <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Code <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control text-uppercase" placeholder="e.g. MTR" value="<?= h($_POST['code'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Metre" value="<?= h($_POST['name'] ?? '') ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add UoM</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
