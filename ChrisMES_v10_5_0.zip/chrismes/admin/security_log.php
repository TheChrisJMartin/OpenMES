<?php
// =============================================================================
// ChrisMES - admin/security_log.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');
$page_title = 'Security Log';
$filter_sev = $_GET['sev'] ?? '';
$filter_params = [];
$where = 'WHERE 1=1 ';
if ($filter_sev) { $where .= 'AND sl.severity=? '; $filter_params[] = $filter_sev; }
$logs = db_rows("SELECT sl.*,u.known_as FROM security_log sl LEFT JOIN users u ON u.id=sl.user_id $where ORDER BY sl.created_at DESC LIMIT 200", $filter_params);
include __DIR__ . '/../includes/header.php';
?>
<div class="d-flex gap-2 mb-4">
    <?php foreach (['','Low','Medium','High','Critical'] as $s): ?>
    <a href="?sev=<?= $s ?>" class="btn btn-sm <?= $s===$filter_sev?'btn-primary':'btn-outline-secondary' ?>"><?= $s?:' All' ?></a>
    <?php endforeach; ?>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light"><tr><th>Date/Time</th><th>Event</th><th>Severity</th><th>User</th><th>IP</th><th>Detail</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $sl): ?>
            <tr>
                <td><?= date('d M y H:i:s',strtotime($sl['created_at'])) ?></td>
                <td><code><?= h($sl['event']) ?></code></td>
                <td><span class="badge <?= match($sl['severity']){'Critical'=>'bg-danger','High'=>'bg-danger','Medium'=>'bg-warning text-dark','Low'=>'bg-info text-dark',default=>'bg-secondary'} ?>"><?= h($sl['severity']) ?></span></td>
                <td><?= h($sl['known_as'] ?? '—') ?></td>
                <td><?= h($sl['ip_address'] ?? '') ?></td>
                <td><?= h($sl['detail']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($logs)): ?><tr><td colspan="6" class="text-center text-muted py-3">No events.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
