<?php
// =============================================================================
// ChrisMES - admin/users.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN');

$page_title = 'User Management';
$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

// ── Save ──────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $username   = strtoupper(trim($_POST['username'] ?? ''));
    $surname    = trim($_POST['surname'] ?? '');
    $firstname  = trim($_POST['firstname'] ?? '');
    $known_as   = trim($_POST['known_as'] ?? '');
    $persona    = $_POST['persona'] ?? '';
    $org_id     = $_POST['org_id'] !== '' ? (int)$_POST['org_id'] : null;
    $is_active  = isset($_POST['is_active']) ? 1 : 0;
    $is_direct  = isset($_POST['is_direct']) ? 1 : 0;
    $is_test    = isset($_POST['is_test_account']) ? 1 : 0;
    $password   = $_POST['password'] ?? '';

    $valid_personas = ['IT_ADMIN','SUPERVISOR','OPERATOR','TESTER','INSPECTOR','FINAL_TESTER',
                       'MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER'];

    $errors = [];
    if (!$username)                         $errors[] = 'Username is required.';
    if (!$surname)                          $errors[] = 'Surname is required.';
    if (!$firstname)                        $errors[] = 'First name is required.';
    if (!$known_as)                         $errors[] = 'Known As is required.';
    if (!in_array($persona, $valid_personas)) $errors[] = 'Invalid persona.';
    if ($persona !== 'IT_ADMIN' && !$org_id) $errors[] = 'Organisation is required for non-IT-Admin users.';

    // Check username uniqueness
    if (!$errors) {
        $existing = db_row('SELECT id FROM users WHERE username = ? AND id != ?', [$username, $id]);
        if ($existing) $errors[] = 'Username already exists.';
    }

    if (!$errors) {
        $hash = $id && !$password ? null : password_hash($password ?: $username, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST]);

        if ($id) {
            // Update
            if ($hash) {
                db_exec('UPDATE users SET username=?,surname=?,firstname=?,known_as=?,persona=?,org_id=?,
                         is_active=?,is_direct=?,is_test_account=?,password_hash=?,updated_at=NOW() WHERE id=?',
                    [$username,$surname,$firstname,$known_as,$persona,$org_id,$is_active,$is_direct,$is_test,$hash,$id]);
            } else {
                db_exec('UPDATE users SET username=?,surname=?,firstname=?,known_as=?,persona=?,org_id=?,
                         is_active=?,is_direct=?,is_test_account=?,updated_at=NOW() WHERE id=?',
                    [$username,$surname,$firstname,$known_as,$persona,$org_id,$is_active,$is_direct,$is_test,$id]);
            }
            security_log('USER_CHANGE', 'High', "User {$username} updated by " . current_user()['username']);
            audit_log('user', $id, 'UPDATE', "Updated by " . current_user()['username']);
            flash_set('success', 'User updated successfully.');
        } else {
            // Create
            db_exec('INSERT INTO users (username,surname,firstname,known_as,persona,org_id,is_active,is_direct,is_test_account,password_hash,created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,NOW())',
                [$username,$surname,$firstname,$known_as,$persona,$org_id,$is_active,$is_direct,$is_test,$hash]);
            $new_id = db_last_id();
            security_log('USER_CHANGE', 'High', "User {$username} created by " . current_user()['username']);
            audit_log('user', $new_id, 'CREATE', "Created by " . current_user()['username']);
            flash_set('success', 'User created successfully.');
        }
        header('Location: /chrismes/admin/users.php');
        exit;
    }
    $action = $id ? 'edit' : 'create';
    $edit_id = $id;
}

// ── Load for edit ─────────────────────────────────────────────────────────────
$edit_user = null;
if ($action === 'edit' && $edit_id) {
    $edit_user = db_row('SELECT * FROM users WHERE id = ?', [$edit_id]);
    if (!$edit_user) { flash_set('danger', 'User not found.'); header('Location: /chrismes/admin/users.php'); exit; }
}

// ── Orgs for dropdown ─────────────────────────────────────────────────────────
$orgs = db_rows('SELECT id, code, name FROM orgs WHERE is_active = 1 ORDER BY code');

// ── User list ─────────────────────────────────────────────────────────────────
$search = trim($_GET['q'] ?? '');
$users = db_rows(
    "SELECT u.*, o.code AS org_code FROM users u LEFT JOIN orgs o ON o.id = u.org_id
     WHERE (u.username LIKE ? OR u.surname LIKE ? OR u.known_as LIKE ?)
     ORDER BY u.surname, u.firstname",
    ["%$search%", "%$search%", "%$search%"]
);

include __DIR__ . '/../includes/header.php';
?>

<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <form class="d-flex gap-2" method="get">
            <input type="text" name="q" class="form-control form-control-sm" placeholder="Search users…" value="<?= h($search) ?>">
            <button class="btn btn-sm btn-outline-secondary">Search</button>
            <?php if ($search): ?><a href="?" class="btn btn-sm btn-outline-danger">Clear</a><?php endif; ?>
        </form>
    </div>
    <a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add User</a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr>
                    <th>Username</th><th>Known As</th><th>Surname</th><th>First Name</th>
                    <th>Persona</th><th>Org</th><th>Active</th><th>Direct</th><th>Test</th><th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><code><?= h($u['username']) ?></code></td>
                <td><?= h($u['known_as']) ?></td>
                <td><?= h($u['surname']) ?></td>
                <td><?= h($u['firstname']) ?></td>
                <td><span class="badge bg-secondary"><?= h($u['persona']) ?></span></td>
                <td><?= h($u['org_code'] ?? '—') ?></td>
                <td><?= $u['is_active'] ? '<i class="bi bi-check-circle text-success"></i>' : '<i class="bi bi-x-circle text-danger"></i>' ?></td>
                <td><?= $u['is_direct'] ? 'Direct' : 'Indirect' ?></td>
                <td><?= $u['is_test_account'] ? '<i class="bi bi-bug text-warning"></i>' : '' ?></td>
                <td>
                    <a href="?action=edit&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-pencil"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($users)): ?>
            <tr><td colspan="10" class="text-center py-3 text-muted">No users found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php else: ?>
<!-- ── Create / Edit form ── -->
<div class="card" style="max-width:680px">
    <div class="card-header fw-semibold">
        <i class="bi bi-person<?= $edit_user ? '-gear' : '-plus' ?> me-2"></i>
        <?= $edit_user ? 'Edit User: ' . h($edit_user['username']) : 'Add User' ?>
    </div>
    <div class="card-body">
        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_user['id'] ?? 0) ?>">

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Username <span class="text-danger">*</span></label>
                    <input type="text" name="username" class="form-control text-uppercase"
                           value="<?= h($_POST['username'] ?? $edit_user['username'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Known As <span class="text-danger">*</span></label>
                    <input type="text" name="known_as" class="form-control"
                           value="<?= h($_POST['known_as'] ?? $edit_user['known_as'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Surname <span class="text-danger">*</span></label>
                    <input type="text" name="surname" class="form-control"
                           value="<?= h($_POST['surname'] ?? $edit_user['surname'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">First Name <span class="text-danger">*</span></label>
                    <input type="text" name="firstname" class="form-control"
                           value="<?= h($_POST['firstname'] ?? $edit_user['firstname'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Persona <span class="text-danger">*</span></label>
                    <select name="persona" class="form-select" id="personaSelect">
                        <?php
                        $personas = ['IT_ADMIN','SUPERVISOR','OPERATOR','TESTER','INSPECTOR','FINAL_TESTER',
                                     'MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER'];
                        $sel_persona = $_POST['persona'] ?? $edit_user['persona'] ?? '';
                        foreach ($personas as $p): ?>
                        <option value="<?= $p ?>" <?= $p === $sel_persona ? 'selected' : '' ?>><?= $p ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6" id="orgRow">
                    <label class="form-label">Organisation</label>
                    <select name="org_id" class="form-select">
                        <option value="">— Select —</option>
                        <?php
                        $sel_org = $_POST['org_id'] ?? $edit_user['org_id'] ?? '';
                        foreach ($orgs as $o): ?>
                        <option value="<?= $o['id'] ?>" <?= $o['id'] == $sel_org ? 'selected' : '' ?>><?= h($o['code']) ?> — <?= h($o['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Password <?= $edit_user ? '(leave blank to keep current)' : '' ?></label>
                    <input type="password" name="password" class="form-control" autocomplete="new-password">
                    <div class="form-text">In Test Mode, test accounts use their username as password.</div>
                </div>
                <div class="col-12">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active"
                               <?= ($_POST['is_active'] ?? $edit_user['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="is_direct" id="is_direct"
                               <?= ($_POST['is_direct'] ?? $edit_user['is_direct'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_direct">Direct Labour</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="is_test_account" id="is_test_account"
                               <?= ($_POST['is_test_account'] ?? $edit_user['is_test_account'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_test_account">Test Account</label>
                    </div>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Save</button>
                <a href="/chrismes/admin/users.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
// Hide org field for IT_ADMIN
const personaSel = document.getElementById('personaSelect');
const orgRow = document.getElementById('orgRow');
function toggleOrg() { orgRow.style.display = personaSel.value === 'IT_ADMIN' ? 'none' : ''; }
personaSel.addEventListener('change', toggleOrg);
toggleOrg();
</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
