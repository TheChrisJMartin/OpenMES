<?php
// =============================================================================
// ChrisMES - items/index.php (Item Master)
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Item Master';
$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);

// ── Save ──────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !PARTS_LOCKED) {
    require_role('IT_ADMIN');
    $id          = (int)($_POST['id'] ?? 0);
    $org_id      = (int)$_POST['org_id'];
    $part_number = strtoupper(trim($_POST['part_number'] ?? ''));
    $revision    = strtoupper(trim($_POST['revision'] ?? ''));
    $description = trim($_POST['description'] ?? '');
    $uom_id      = (int)$_POST['uom_id'];
    $serial_ctrl = isset($_POST['serial_controlled']) ? 1 : 0;
    $make_buy    = $_POST['make_buy'] ?? 'Make';
    $shelf_lifed = isset($_POST['shelf_lifed']) ? 1 : 0;
    $errors = [];

    if (!$part_number) $errors[] = 'Part number required.';
    if (!$description) $errors[] = 'Description required.';
    if (!$org_id) $errors[] = 'Organisation required.';
    if (!$uom_id) $errors[] = 'Unit of Measure required.';
    if (!in_array($make_buy,['Make','Buy'])) $errors[] = 'Invalid Make/Buy.';

    if (!$errors && !$id) {
        $exists = db_row('SELECT id FROM parts WHERE part_number=? AND org_id=?',[$part_number,$org_id]);
        if ($exists) $errors[] = 'Part number already exists in this org.';
    }

    if (!$errors) {
        if ($id) {
            // Get old values for audit
            $old = db_row('SELECT * FROM parts WHERE id=?',[$id]);
            db_exec('UPDATE parts SET revision=?,description=?,uom_id=?,serial_controlled=?,make_buy=?,shelf_lifed=?,item_version=item_version+1,updated_at=NOW() WHERE id=?',
                [$revision,$description,$uom_id,$serial_ctrl,$make_buy,$shelf_lifed,$id]);
            // Audit changed fields
            $changes = [];
            foreach (['revision','description','make_buy'] as $f) {
                if (($old[$f] ?? '') !== ($_POST[$f] ?? '')) $changes[] = "{$f}: '{$old[$f]}' → '{$_POST[$f]}'";
            }
            audit_log('part',$id,'UPDATE',implode('; ',$changes));
            flash_set('success','Part updated. Item version incremented.');
        } else {
            db_exec('INSERT INTO parts (org_id,part_number,revision,description,uom_id,serial_controlled,make_buy,shelf_lifed,item_version,created_at)
                     VALUES (?,?,?,?,?,?,?,?,1,NOW())',
                [$org_id,$part_number,$revision,$description,$uom_id,$serial_ctrl,$make_buy,$shelf_lifed]);
            $new_id = (int)db_last_id();
            audit_log('part',$new_id,'CREATE',"Part {$part_number} created");
            flash_set('success','Part created.');
        }
        header('Location: /chrismes/items/index.php'); exit;
    }
    $action = $id ? 'edit' : 'create'; $edit_id = $id;
}

// ── Load edit ──────────────────────────────────────────────────────────────────
$edit_part = null;
if (($action==='edit'||$action==='view') && $edit_id) {
    $edit_part = db_row('SELECT p.*,o.code AS org_code,u.code AS uom_code FROM parts p JOIN orgs o ON o.id=p.org_id JOIN units_of_measure u ON u.id=p.uom_id WHERE p.id=?',[$edit_id]);
}

$orgs = db_rows('SELECT id,code,name FROM orgs WHERE is_active=1 ORDER BY code');
$uoms = db_rows('SELECT id,code,name FROM units_of_measure ORDER BY code');

// ── Org filter for list ───────────────────────────────────────────────────────
$org_id_filter = user_org_id() ?? (int)($_GET['org_id'] ?? 0);
$search = trim($_GET['q'] ?? '');
$filter_params = [];
$where = 'WHERE 1=1 ';
if ($org_id_filter) { $where .= 'AND p.org_id=? '; $filter_params[] = $org_id_filter; }
if ($search) { $where .= 'AND (p.part_number LIKE ? OR p.description LIKE ?) '; $filter_params[] = "%$search%"; $filter_params[] = "%$search%"; }
$parts = db_rows("SELECT p.*,o.code AS org_code,u.code AS uom_code FROM parts p JOIN orgs o ON o.id=p.org_id JOIN units_of_measure u ON u.id=p.uom_id $where ORDER BY o.code,p.part_number", $filter_params);

include __DIR__ . '/../includes/header.php';
?>

<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <form class="d-flex gap-2 flex-wrap" method="get">
        <input type="text" name="q" class="form-control form-control-sm" style="width:200px" placeholder="Search parts…" value="<?= h($search) ?>">
        <?php if (is_it_admin()): ?>
        <select name="org_id" class="form-select form-select-sm" style="width:140px">
            <option value="">All Orgs</option>
            <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>" <?= $o['id']==$org_id_filter?'selected':'' ?>><?= h($o['code']) ?></option><?php endforeach; ?>
        </select>
        <?php endif; ?>
        <button class="btn btn-sm btn-outline-secondary">Search</button>
    </form>
    <?php if (is_it_admin() && !PARTS_LOCKED): ?>
    <a href="?action=create" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Part</a>
    <?php endif; ?>
</div>
<?php if (PARTS_LOCKED): ?>
<div class="alert alert-info small"><i class="bi bi-lock me-1"></i>Parts are mastered by ERP integration. Manual editing is disabled (PARTS_LOCKED=true in config.php).</div>
<?php endif; ?>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr><th>Org</th><th>Part Number</th><th>Rev</th><th>Description</th><th>UoM</th><th>S/N</th><th>M/B</th><th>Ver</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($parts as $p): ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($p['org_code']) ?></span></td>
                <td><code><?= h($p['part_number']) ?></code></td>
                <td><?= h($p['revision']) ?></td>
                <td><?= h($p['description']) ?></td>
                <td><?= h($p['uom_code']) ?></td>
                <td><?= $p['serial_controlled'] ? '<i class="bi bi-check2 text-success"></i>' : '<i class="bi bi-x text-muted"></i>' ?></td>
                <td><span class="badge <?= $p['make_buy']==='Make'?'bg-primary':'bg-secondary' ?>"><?= h($p['make_buy']) ?></span></td>
                <td><small class="text-muted">v<?= h($p['item_version']) ?></small></td>
                <td>
                    <?php if (is_it_admin() && !PARTS_LOCKED): ?>
                    <a href="?action=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                    <?php endif; ?>
                    <a href="?action=view&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($parts)): ?><tr><td colspan="9" class="text-center text-muted py-3">No parts found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($action === 'view' && $edit_part): ?>
<div class="card mb-4" style="max-width:700px">
    <div class="card-header d-flex justify-content-between">
        <span class="fw-semibold"><i class="bi bi-box-seam me-2"></i><?= h($edit_part['part_number']) ?></span>
        <span class="badge bg-secondary">v<?= h($edit_part['item_version']) ?></span>
    </div>
    <div class="card-body">
        <dl class="row mb-0">
            <dt class="col-sm-4">Org</dt><dd class="col-sm-8"><?= h($edit_part['org_code']) ?></dd>
            <dt class="col-sm-4">Part Number</dt><dd class="col-sm-8"><code><?= h($edit_part['part_number']) ?></code></dd>
            <dt class="col-sm-4">Revision</dt><dd class="col-sm-8"><?= h($edit_part['revision']) ?></dd>
            <dt class="col-sm-4">Description</dt><dd class="col-sm-8"><?= h($edit_part['description']) ?></dd>
            <dt class="col-sm-4">UoM</dt><dd class="col-sm-8"><?= h($edit_part['uom_code']) ?></dd>
            <dt class="col-sm-4">Serial Controlled</dt><dd class="col-sm-8"><?= $edit_part['serial_controlled'] ? 'Yes' : 'No (Lot)' ?></dd>
            <dt class="col-sm-4">Make / Buy</dt><dd class="col-sm-8"><?= h($edit_part['make_buy']) ?></dd>
            <dt class="col-sm-4">Shelf Lifed</dt><dd class="col-sm-8"><?= $edit_part['shelf_lifed'] ? 'Yes' : 'No' ?></dd>
        </dl>
    </div>
    <div class="card-footer">
        <a href="/chrismes/items/index.php" class="btn btn-outline-secondary btn-sm">Back</a>
        <?php if (is_it_admin() && !PARTS_LOCKED): ?>
        <a href="?action=edit&id=<?= $edit_part['id'] ?>" class="btn btn-primary btn-sm ms-2">Edit</a>
        <?php endif; ?>
    </div>
</div>
<!-- Audit history -->
<?php
$audit_rows = db_rows("SELECT al.*,u.known_as FROM audit_log al LEFT JOIN users u ON u.id=al.user_id WHERE al.entity_type='part' AND al.entity_id=? ORDER BY al.created_at DESC LIMIT 30",[$edit_id]);
?>
<div class="card" style="max-width:700px">
    <div class="card-header fw-semibold small">Audit History</div>
    <div class="table-responsive">
        <table class="table table-hover mb-0 small">
            <thead class="table-light"><tr><th>Date/Time</th><th>Action</th><th>By</th><th>Detail</th></tr></thead>
            <tbody>
            <?php foreach ($audit_rows as $al): ?>
            <tr><td><?= date('d M y H:i', strtotime($al['created_at'])) ?></td><td><?= h($al['action']) ?></td><td><?= h($al['known_as'] ?? '—') ?></td><td><?= h($al['detail']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php else: ?>
<!-- Create / Edit form -->
<div class="card" style="max-width:620px">
    <div class="card-header fw-semibold"><?= $edit_part ? 'Edit Part: '.h($edit_part['part_number']) : 'Add Part' ?></div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int)($edit_part['id'] ?? 0) ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Organisation <span class="text-danger">*</span></label>
                    <select name="org_id" class="form-select" <?= $edit_part ? 'disabled' : 'required' ?>>
                        <option value="">— Select —</option>
                        <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>" <?= ($edit_part['org_id'] ?? '') == $o['id'] ? 'selected' : '' ?>><?= h($o['code']) ?></option><?php endforeach; ?>
                    </select>
                    <?php if ($edit_part): ?><input type="hidden" name="org_id" value="<?= $edit_part['org_id'] ?>"><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Part Number <span class="text-danger">*</span> <?= $edit_part ? '<small class="text-muted">(cannot change)</small>' : '' ?></label>
                    <input type="text" name="part_number" class="form-control text-uppercase"
                           value="<?= h($edit_part['part_number'] ?? '') ?>" <?= $edit_part ? 'readonly' : 'required' ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Revision</label>
                    <input type="text" name="revision" class="form-control text-uppercase" value="<?= h($_POST['revision'] ?? $edit_part['revision'] ?? 'A') ?>">
                </div>
                <div class="col-md-8">
                    <label class="form-label">Description <span class="text-danger">*</span></label>
                    <input type="text" name="description" class="form-control" value="<?= h($_POST['description'] ?? $edit_part['description'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">UoM <span class="text-danger">*</span></label>
                    <select name="uom_id" class="form-select" required>
                        <option value="">— Select —</option>
                        <?php foreach ($uoms as $u): ?><option value="<?= $u['id'] ?>" <?= ($edit_part['uom_id'] ?? '') == $u['id'] ? 'selected' : '' ?>><?= h($u['code']) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Make / Buy</label>
                    <select name="make_buy" class="form-select">
                        <?php foreach (['Make','Buy'] as $mb): ?><option value="<?= $mb ?>" <?= ($edit_part['make_buy'] ?? 'Make') === $mb ? 'selected' : '' ?>><?= $mb ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="serial_controlled" id="sc" <?= ($edit_part['serial_controlled'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="sc">Serial Controlled</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="shelf_lifed" id="sl" <?= ($edit_part['shelf_lifed'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="sl">Shelf Lifed</label>
                    </div>
                </div>
            </div>
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="/chrismes/items/index.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
