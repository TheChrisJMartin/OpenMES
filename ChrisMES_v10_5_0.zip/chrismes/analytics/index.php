<?php
// =============================================================================
// ChrisMES - analytics/index.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Analytics';

$org_id = user_org_id();
$params = $org_id ? [$org_id] : [];
$org_w  = $org_id ? 'AND wo.org_id=?' : '';
$nc_org = $org_id ? 'WHERE nc.org_id=?' : '';

$period = (int)($_GET['days'] ?? 30);

// WO completions per day
$daily_wos = db_rows(
    "SELECT DATE(completed_at) AS day,COUNT(*) AS cnt FROM work_orders wo
     WHERE completed_at >= DATE_SUB(NOW(),INTERVAL ? DAY) AND status='Complete' $org_w
     GROUP BY day ORDER BY day ASC",
    array_merge([$period], $params)
);

// Efficiency by op type
$eff_by_type = db_rows(
    "SELECT ro.op_type,
            AVG(CASE WHEN ce.clock_off IS NOT NULL AND ro.actual_mins > 0
                THEN ro.actual_mins*60/TIMESTAMPDIFF(SECOND,ce.clock_on,ce.clock_off)*100
                ELSE NULL END) AS avg_eff,
            COUNT(ce.id) AS bookings
     FROM clock_events ce
     JOIN routing_operations ro ON ro.id=ce.routing_op_id
     JOIN work_orders wo ON wo.id=ce.wo_id
     WHERE ce.clock_on >= DATE_SUB(NOW(),INTERVAL ? DAY) $org_w
     GROUP BY ro.op_type",
    array_merge([$period], $params)
);

// NC rate by month
$nc_by_month = db_rows(
    "SELECT DATE_FORMAT(raised_at,'%Y-%m') AS month,COUNT(*) AS cnt
     FROM nonconformances nc $nc_org
     GROUP BY month ORDER BY month DESC LIMIT 12",
    $params
);

// Top NCs by disposition
$nc_by_disp = db_rows(
    "SELECT COALESCE(disposition,'Pending') AS disp,COUNT(*) AS cnt
     FROM nonconformances nc $nc_org GROUP BY disp ORDER BY cnt DESC",
    $params
);

// Operator productivity
$op_prod = db_rows(
    "SELECT u.known_as,COUNT(ce.id) AS bookings,
            SUM(TIMESTAMPDIFF(MINUTE,ce.clock_on,ce.clock_off)) AS total_mins
     FROM clock_events ce JOIN users u ON u.id=ce.user_id
     JOIN work_orders wo ON wo.id=ce.wo_id
     WHERE ce.clock_off IS NOT NULL AND ce.clock_on >= DATE_SUB(NOW(),INTERVAL ? DAY) $org_w
     GROUP BY u.id ORDER BY total_mins DESC LIMIT 10",
    array_merge([$period], $params)
);

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <form class="d-flex gap-2" method="get">
        <label class="form-label my-auto">Period:</label>
        <?php foreach ([7,30,90] as $d): ?>
        <a href="?days=<?= $d ?>" class="btn btn-sm <?= $d===$period?'btn-primary':'btn-outline-secondary' ?>"><?= $d ?> days</a>
        <?php endforeach; ?>
    </form>
</div>

<div class="row g-4">
    <!-- WO Completions chart (simple bar) -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-bar-chart me-2"></i>WO Completions (Last <?= $period ?> Days)</div>
            <div class="card-body">
                <?php if ($daily_wos): ?>
                <?php $max = max(array_column($daily_wos,'cnt')); ?>
                <div class="d-flex align-items-end gap-1" style="height:140px">
                    <?php foreach ($daily_wos as $d):
                        $h = $max > 0 ? round($d['cnt']/$max*100) : 0;
                    ?>
                    <div class="flex-grow-1 bg-primary rounded-top" style="height:<?= $h ?>%" title="<?= $d['day'] ?>: <?= $d['cnt'] ?> WOs"></div>
                    <?php endforeach; ?>
                </div>
                <div class="d-flex justify-content-between text-muted small mt-1">
                    <span><?= $daily_wos[0]['day'] ?></span>
                    <span><?= end($daily_wos)['day'] ?></span>
                </div>
                <?php else: ?>
                <p class="text-muted text-center py-3">No completions in this period.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Efficiency by op type -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-speedometer me-2"></i>Efficiency by Operation Type</div>
            <div class="table-responsive">
                <table class="table mb-0 small">
                    <thead class="table-light"><tr><th>Op Type</th><th>Bookings</th><th>Avg Efficiency</th></tr></thead>
                    <tbody>
                    <?php foreach ($eff_by_type as $et):
                        $eff = $et['avg_eff'] ? round((float)$et['avg_eff']) : null;
                    ?>
                    <tr>
                        <td><?= h($et['op_type']) ?></td>
                        <td><?= h($et['bookings']) ?></td>
                        <td>
                            <?php if ($eff !== null): ?>
                            <div class="d-flex align-items-center gap-2">
                                <div class="efficiency-bar flex-grow-1">
                                    <div class="fill" style="width:<?= min(200,$eff) ?>%"></div>
                                </div>
                                <small><?= $eff ?>%</small>
                            </div>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($eff_by_type)): ?><tr><td colspan="3" class="text-center text-muted py-3">No data.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- NCs by month -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header fw-semibold"><i class="bi bi-exclamation-triangle me-2"></i>NC Volume by Month</div>
            <div class="table-responsive">
                <table class="table mb-0 small">
                    <thead class="table-light"><tr><th>Month</th><th>NCs Raised</th><th>Bar</th></tr></thead>
                    <tbody>
                    <?php
                    $nc_max = $nc_by_month ? max(array_column($nc_by_month,'cnt')) : 1;
                    foreach ($nc_by_month as $nm):
                    ?>
                    <tr>
                        <td><?= h($nm['month']) ?></td>
                        <td><?= h($nm['cnt']) ?></td>
                        <td><div class="efficiency-bar"><div class="fill" style="width:<?= round($nm['cnt']/$nc_max*100) ?>%"></div></div></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($nc_by_month)): ?><tr><td colspan="3" class="text-center text-muted py-3">No NCs.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- NC by disposition -->
    <div class="col-lg-3">
        <div class="card">
            <div class="card-header fw-semibold">NCs by Disposition</div>
            <ul class="list-group list-group-flush small">
            <?php foreach ($nc_by_disp as $nd): ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span><?= h($nd['disp']) ?></span>
                    <span class="badge bg-secondary rounded-pill"><?= h($nd['cnt']) ?></span>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- Operator productivity -->
    <div class="col-lg-3">
        <div class="card">
            <div class="card-header fw-semibold">Top Operators by Hours</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light"><tr><th>Operator</th><th>Hours</th></tr></thead>
                    <tbody>
                    <?php foreach ($op_prod as $op): ?>
                    <tr>
                        <td><?= h($op['known_as']) ?></td>
                        <td><?= round($op['total_mins'] / 60, 1) ?>h</td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($op_prod)): ?><tr><td colspan="2" class="text-center text-muted py-3">No data.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
