<?php
// =============================================================================
// ChrisMES - login.php
// Version: 10.5.0
// =============================================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/functions.php';

session_start();

// Already logged in
if (isset($_SESSION['user'])) {
    header('Location: /chrismes/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $user = db_row(
            'SELECT u.*, o.code AS org_code FROM users u
             LEFT JOIN orgs o ON o.id = u.org_id
             WHERE u.username = ? AND u.is_active = 1',
            [$username]
        );

        $valid = false;

        if ($user) {
            // Normal bcrypt check
            if (password_verify($password, $user['password_hash'])) {
                $valid = true;
            }
            // Test mode: username == password for test accounts
            if (!$valid && TEST_MODE && $user['is_test_account'] && $password === $username) {
                $valid = true;
            }
        }

        if ($valid) {
            // Build session
            $_SESSION['user'] = [
                'id'        => $user['id'],
                'username'  => $user['username'],
                'surname'   => $user['surname'],
                'firstname' => $user['firstname'],
                'known_as'  => $user['known_as'],
                'persona'   => $user['persona'],
                'org_id'    => $user['org_id'],
                'org_code'  => $user['org_code'],
                'dark_mode' => (bool)$user['dark_mode'],
                'direct'    => (bool)$user['is_direct'],
            ];

            // Update last login
            db_exec('UPDATE users SET last_login = NOW() WHERE id = ?', [$user['id']]);

            security_log('LOGIN_OK', 'Low', "User {$username} logged in", $user['id']);

            $redirect = $_SESSION['redirect_after_login'] ?? '/chrismes/index.php';
            unset($_SESSION['redirect_after_login']);
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid username or password.';
            security_log('LOGIN_FAIL', 'Medium', "Failed login attempt for username: {$username}");
        }
    }
}

$dark = false; // No session yet
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In — <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f0f4f8; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { width: 100%; max-width: 420px; }
        .brand-icon { font-size: 3rem; color: #0d6efd; }
    </style>
</head>
<body>
<div class="login-card">
    <div class="card shadow-sm">
        <div class="card-body p-4 p-md-5">
            <div class="text-center mb-4">
                <i class="bi bi-cpu-fill brand-icon"></i>
                <h1 class="h3 mt-2 fw-bold"><?= SITE_NAME ?></h1>
                <p class="text-muted small">Manufacturing Execution System</p>
            </div>

            <?php if ($error): ?>
            <div class="alert alert-danger"><?= h($error) ?></div>
            <?php endif; ?>

            <?php if (TEST_MODE): ?>
            <div class="alert alert-warning small">
                <i class="bi bi-exclamation-triangle me-1"></i>
                <strong>Test Mode Active</strong> — use your username as your password for test accounts.
            </div>
            <?php endif; ?>

            <form method="post" action="">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username"
                           value="<?= h($_POST['username'] ?? '') ?>"
                           autocomplete="username" autofocus required>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password"
                           autocomplete="current-password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
                </button>
            </form>
        </div>
    </div>
    <p class="text-center text-muted small mt-3">
        <?= SITE_NAME ?> v<?= SITE_VERSION ?> &mdash; <a href="<?= SITE_URL ?>" class="text-muted"><?= SITE_URL ?></a>
    </p>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
