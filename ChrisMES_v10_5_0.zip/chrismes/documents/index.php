<?php
// =============================================================================
// ChrisMES - documents/index.php (Work Instructions)
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Work Instructions';
$action = $_GET['action'] ?? 'list';

// ── Upload new document ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'upload') {
    require_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP');
    $org_id      = (int)$_POST['org_id'];
    $part_id     = $_POST['part_id'] !== '' ? (int)$_POST['part_id'] : null;
    $description = trim($_POST['description'] ?? '');
    $errors = [];
    if (!$org_id) $errors[] = 'Organisation required.';
    if (!$description) $errors[] = 'Description required.';
    if (empty($_FILES['pdf_file']['tmp_name'])) $errors[] = 'PDF file required.';

    if (!$errors) {
        $upload_dir = __DIR__ . '/../uploads/documents/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

        $guid     = strtoupper(bin2hex(random_bytes(8)));
        $doc_code = $part_id ? '' : 'GENERIC-DOC-' . $guid;
        $filename = $guid . '_' . basename($_FILES['pdf_file']['name']);
        move_uploaded_file($_FILES['pdf_file']['tmp_name'], $upload_dir . $filename);

        // Insert document header
        db_exec('INSERT INTO documents (org_id,part_id,doc_code,description,created_by,created_at)
                 VALUES (?,?,?,?,?,NOW())',
            [$org_id, $part_id, $doc_code, $description, current_user()['id']]);
        $doc_id = (int)db_last_id();

        // Insert revision 1
        db_exec('INSERT INTO document_revisions (doc_id,revision_number,filename,status,uploaded_by,uploaded_at)
                 VALUES (?,?,?,?,?,NOW())',
            [$doc_id, 1, $filename, 'Draft', current_user()['id']]);

        audit_log('document', $doc_id, 'UPLOAD', "Rev 000001 uploaded");
        flash_set('success', 'Document uploaded at Revision 000001 (Draft).');
        header('Location: /chrismes/documents/index.php?action=view&id=' . $doc_id); exit;
    }
}

// ── Approve revision ──────────────────────────────────────────────────────────
if ($action === 'approve' && isset($_GET['rev_id'])) {
    require_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP');
    $rev_id = (int)$_GET['rev_id'];
    $rev = db_row('SELECT dr.*,d.created_by FROM document_revisions dr JOIN documents d ON d.id=dr.doc_id WHERE dr.id=?',[$rev_id]);
    if (!$rev) { flash_set('danger','Revision not found.'); header('Location: /chrismes/documents/index.php'); exit; }

    $user = current_user();
    // Must be different user unless AUTO_APPROVE
    if (!AUTO_APPROVE && $rev['uploaded_by'] == $user['id']) {
        flash_set('danger','You cannot approve your own upload. A different user must approve.');
        header('Location: /chrismes/documents/index.php?action=view&id='.$rev['doc_id']); exit;
    }

    db_exec('UPDATE document_revisions SET status=?,approved_by=?,approved_at=NOW() WHERE id=?',['Approved',$user['id'],$rev_id]);
    audit_log('document_revision',$rev_id,'APPROVE',"Approved by {$user['username']}");
    flash_set('success','Document approved and now Active.');
    header('Location: /chrismes/documents/index.php?action=view&id='.$rev['doc_id']); exit;
}

// ── Upload new revision ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'revise') {
    require_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP');
    $doc_id = (int)$_POST['doc_id'];
    if (empty($_FILES['pdf_file']['tmp_name'])) {
        flash_set('danger','PDF file required.'); header('Location: /chrismes/documents/index.php?action=view&id='.$doc_id); exit;
    }
    $last = db_row('SELECT MAX(revision_number) AS mx FROM document_revisions WHERE doc_id=?',[$doc_id]);
    $new_rev = (int)$last['mx'] + 1;
    $guid = strtoupper(bin2hex(random_bytes(8)));
    $upload_dir = __DIR__ . '/../uploads/documents/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
    $filename = $guid . '_' . basename($_FILES['pdf_file']['name']);
    move_uploaded_file($_FILES['pdf_file']['tmp_name'], $upload_dir . $filename);
    db_exec('INSERT INTO document_revisions (doc_id,revision_number,filename,status,uploaded_by,uploaded_at)
             VALUES (?,?,?,?,?,NOW())',[$doc_id,$new_rev,$filename,'Draft',current_user()['id']]);
    audit_log('document',$doc_id,'REVISE',"Rev ".format_revision($new_rev)." uploaded");
    flash_set('success','New revision uploaded as Draft.');
    header('Location: /chrismes/documents/index.php?action=view&id='.$doc_id); exit;
}

// ── View document ─────────────────────────────────────────────────────────────
$view_doc = null;
$revisions = [];
if ($action === 'view' && isset($_GET['id'])) {
    $view_doc = db_row('SELECT d.*,o.code AS org_code,p.part_number FROM documents d JOIN orgs o ON o.id=d.org_id LEFT JOIN parts p ON p.id=d.part_id WHERE d.id=?',[(int)$_GET['id']]);
    if ($view_doc) {
        $revisions = db_rows('SELECT dr.*,up.known_as AS uploader,ap.known_as AS approver FROM document_revisions dr LEFT JOIN users up ON up.id=dr.uploaded_by LEFT JOIN users ap ON ap.id=dr.approved_by WHERE dr.doc_id=? ORDER BY dr.revision_number DESC',[$view_doc['id']]);
    }
}

// ── List ──────────────────────────────────────────────────────────────────────
$org_id_filter = user_org_id();
$docs_params = $org_id_filter ? [$org_id_filter] : [];
$docs_where = $org_id_filter ? 'WHERE d.org_id=?' : '';
$docs = db_rows("SELECT d.*,o.code AS org_code,p.part_number,
                 (SELECT status FROM document_revisions WHERE doc_id=d.id ORDER BY revision_number DESC LIMIT 1) AS latest_status,
                 (SELECT MAX(revision_number) FROM document_revisions WHERE doc_id=d.id) AS latest_rev
                 FROM documents d JOIN orgs o ON o.id=d.org_id LEFT JOIN parts p ON p.id=d.part_id $docs_where ORDER BY d.created_at DESC", $docs_params);

$orgs  = db_rows('SELECT id,code FROM orgs WHERE is_active=1 ORDER BY code');
$parts = db_rows('SELECT id,part_number,description FROM parts' . ($org_id_filter ? ' WHERE org_id=?' : '') . ' ORDER BY part_number', $org_id_filter ? [$org_id_filter] : []);

include __DIR__ . '/../includes/header.php';
?>

<?php if ($action === 'list'): ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="mb-0 text-muted">PDF work instructions with revision control.</p>
    <?php if (has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
        <i class="bi bi-upload me-1"></i>Upload Document
    </button>
    <?php endif; ?>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr><th>Org</th><th>Code / Part</th><th>Description</th><th>Latest Rev</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($docs as $d): ?>
            <tr>
                <td><span class="badge bg-secondary"><?= h($d['org_code']) ?></span></td>
                <td><code><?= h($d['part_number'] ?: $d['doc_code']) ?></code></td>
                <td><?= h($d['description']) ?></td>
                <td><?= $d['latest_rev'] ? format_revision((int)$d['latest_rev']) : '—' ?></td>
                <td>
                    <?php $st = $d['latest_status'] ?? 'Draft'; ?>
                    <span class="badge <?= $st==='Approved'?'bg-success':($st==='Draft'?'bg-warning text-dark':'bg-secondary') ?>"><?= h($st) ?></span>
                </td>
                <td><a href="?action=view&id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i> View</a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($docs)): ?><tr><td colspan="6" class="text-center text-muted py-3">No documents yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="?action=upload" enctype="multipart/form-data">
                <div class="modal-header"><h5 class="modal-title">Upload Work Instruction</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Organisation <span class="text-danger">*</span></label>
                        <select name="org_id" class="form-select" required>
                            <option value="">— Select —</option>
                            <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>" <?= $org_id_filter==$o['id']?'selected':'' ?>><?= h($o['code']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Attach to Part (leave blank for Generic)</label>
                        <select name="part_id" class="form-select">
                            <option value="">— Generic Document —</option>
                            <?php foreach ($parts as $p): ?><option value="<?= $p['id'] ?>"><?= h($p['part_number']) ?> — <?= h($p['description']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description <span class="text-danger">*</span></label>
                        <input type="text" name="description" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">PDF File <span class="text-danger">*</span></label>
                        <input type="file" name="pdf_file" class="form-control" accept=".pdf" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-upload me-1"></i>Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php elseif ($action === 'view' && $view_doc): ?>
<div class="mb-3">
    <a href="/chrismes/documents/index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>
<div class="row g-4">
    <div class="col-lg-5">
        <div class="card mb-3">
            <div class="card-header fw-semibold"><i class="bi bi-file-earmark-pdf me-2"></i>Document Details</div>
            <div class="card-body small">
                <dl class="row mb-0">
                    <dt class="col-4">Org</dt><dd class="col-8"><?= h($view_doc['org_code']) ?></dd>
                    <dt class="col-4">Code</dt><dd class="col-8"><code><?= h($view_doc['part_number'] ?: $view_doc['doc_code']) ?></code></dd>
                    <dt class="col-4">Description</dt><dd class="col-8"><?= h($view_doc['description']) ?></dd>
                </dl>
            </div>
        </div>
        <div class="card">
            <div class="card-header fw-semibold">Revisions</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light"><tr><th>Rev</th><th>Status</th><th>Uploaded</th><th>Approved</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($revisions as $rv): ?>
                    <tr>
                        <td><code><?= format_revision((int)$rv['revision_number']) ?></code></td>
                        <td><span class="badge <?= $rv['status']==='Approved'?'bg-success':($rv['status']==='Draft'?'bg-warning text-dark':'bg-secondary') ?>"><?= h($rv['status']) ?></span></td>
                        <td><?= h($rv['uploader']) ?><br><small class="text-muted"><?= date('d M y', strtotime($rv['uploaded_at'])) ?></small></td>
                        <td><?= $rv['approver'] ? h($rv['approver']).'<br><small class="text-muted">'.date('d M y', strtotime($rv['approved_at'])).'</small>' : '—' ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-secondary"
                                onclick="loadPdf('/chrismes/uploads/documents/<?= h($rv['filename']) ?>')">
                                <i class="bi bi-eye"></i>
                            </button>
                            <?php if ($rv['status'] === 'Draft' && has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
                            <a href="?action=approve&rev_id=<?= $rv['id'] ?>" class="btn btn-sm btn-success"
                               data-confirm="Approve this revision?"><i class="bi bi-check-circle me-1"></i>Approve</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (has_role('IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP')): ?>
            <div class="card-footer">
                <form method="post" action="?action=revise" enctype="multipart/form-data" class="d-flex gap-2 align-items-center">
                    <input type="hidden" name="doc_id" value="<?= $view_doc['id'] ?>">
                    <input type="file" name="pdf_file" class="form-control form-control-sm" accept=".pdf" required>
                    <button type="submit" class="btn btn-sm btn-outline-primary text-nowrap"><i class="bi bi-upload me-1"></i>New Revision</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-7">
        <div id="pdf-viewer-container">
            <?php if ($revisions): ?>
            <iframe id="pdf-frame" src="/chrismes/uploads/documents/<?= h($revisions[0]['filename']) ?>"></iframe>
            <?php else: ?>
            <div class="d-flex align-items-center justify-content-center h-100 text-muted">
                <span>No PDF uploaded yet.</span>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
function loadPdf(url) {
    document.getElementById('pdf-frame').src = url;
}
</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
