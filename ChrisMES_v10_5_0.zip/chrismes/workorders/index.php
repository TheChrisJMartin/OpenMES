<?php
// =============================================================================
// ChrisMES - workorders/index.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();
$page_title = 'Work Orders';

$org_id = user_org_id();
$status_filter = $_GET['status'] ?? '';
$search = trim($_GET['q'] ?? '');

$where = 'WHERE 1=1';
$params = [];
if ($org_id) { $where .= ' AND wo.org_id=?'; $params[] = $org_id; }
if ($status_filter) { $where .= ' AND wo.status=?'; $params[] = $status_filter; }
if ($search) { $where .= ' AND (wo.wo_number LIKE ? OR p.part_number LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }

$wos = db_rows(
    "SELECT wo.*,p.part_number,p.description,o.code AS org_code,
            (SELECT COUNT(*) FROM nonconformances nc WHERE nc.wo_id=wo.id AND nc.status='Open') AS open_nc,
            (SELECT COUNT(*) FROM work_order_serials WHERE wo_id=wo.id) AS total_serials
     FROM work_orders wo
     JOIN parts p ON p.id=wo.part_id
     JOIN orgs o ON o.id=wo.org_id
     $where ORDER BY wo.priority ASC, wo.created_at DESC LIMIT 200",
    $params
);

$statuses = ['Open','In Progress','Hard Hold','Soft Hold','Complete','Cancelled'];
include __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <form class="d-flex gap-2 flex-wrap" method="get">
        <input type="text" name="q" class="form-control form-control-sm" style="width:180px" placeholder="WO # or Part…" value="<?= h($search) ?>">
        <select name="status" class="form-select form-select-sm" style="width:140px">
            <option value="">All Statuses</option>
            <?php foreach ($statuses as $s): ?><option <?= $s===$status_filter?'selected':'' ?>><?= h($s) ?></option><?php endforeach; ?>
        </select>
        <button class="btn btn-sm btn-outline-secondary">Filter</button>
        <a href="?" class="btn btn-sm btn-outline-danger">Clear</a>
    </form>
    <?php if (has_role('IT_ADMIN','SUPERVISOR') && ALLOW_WO_CREATION): ?>
    <a href="/chrismes/workorders/create.php" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Create WO</a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 small align-middle">
            <thead class="table-light">
                <tr><th>WO Number</th><th>Org</th><th>Part</th><th>Description</th><th>Qty</th><th>Priority</th><th>Status</th><th>Open NC</th><th>Planned Finish</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($wos as $wo):
                $pri_class = $wo['priority'] <= 20 ? 'priority-high' : ($wo['priority'] <= 40 ? 'priority-medium' : 'priority-normal');
                $overdue = $wo['planned_finish'] && $wo['planned_finish'] < date('Y-m-d H:i:s') && !in_array($wo['status'],['Complete','Cancelled']);
            ?>
            <tr>
                <td><a href="/chrismes/workorders/view.php?wo=<?= urlencode($wo['wo_number']) ?>" class="fw-semibold"><?= h($wo['wo_number']) ?></a></td>
                <td><span class="badge bg-secondary"><?= h($wo['org_code']) ?></span></td>
                <td><code><?= h($wo['part_number']) ?></code></td>
                <td><?= h($wo['description']) ?></td>
                <td><?= h($wo['quantity']) ?></td>
                <td><span class="<?= $pri_class ?>"><?= h($wo['priority']) ?></span></td>
                <td>
                    <span class="badge <?= match($wo['status']) {
                        'Open'       => 'bg-primary',
                        'In Progress'=> 'bg-warning text-dark',
                        'Hard Hold'  => 'bg-danger',
                        'Soft Hold'  => 'bg-warning text-dark',
                        'Complete'   => 'bg-success',
                        'Cancelled'  => 'bg-secondary',
                        default      => 'bg-secondary',
                    } ?>"><?= h($wo['status']) ?></span>
                </td>
                <td><?= $wo['open_nc'] > 0 ? '<span class="badge bg-danger">'.$wo['open_nc'].'</span>' : '—' ?></td>
                <td class="<?= $overdue ? 'text-danger fw-semibold' : '' ?>">
                    <?= $wo['planned_finish'] ? date('d M y', strtotime($wo['planned_finish'])) : '—' ?>
                    <?= $overdue ? ' ⚠' : '' ?>
                </td>
                <td>
                    <a href="/chrismes/workorders/view.php?wo=<?= urlencode($wo['wo_number']) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($wos)): ?><tr><td colspan="10" class="text-center text-muted py-3">No work orders found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
