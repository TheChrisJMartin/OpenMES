<?php
// =============================================================================
// ChrisMES - workorders/view.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();

$wo_number = $_GET['wo'] ?? '';
$wo = db_row('SELECT wo.*,p.part_number,p.description,p.serial_controlled,o.code AS org_code,
              r.name AS routing_name,r.revision AS routing_rev,
              u.known_as AS created_by_name
              FROM work_orders wo
              JOIN parts p ON p.id=wo.part_id JOIN orgs o ON o.id=wo.org_id
              JOIN routings r ON r.id=wo.routing_id
              LEFT JOIN users u ON u.id=wo.created_by
              WHERE wo.wo_number=?', [$wo_number]);
if (!$wo) { flash_set('danger','Work order not found.'); header('Location: /chrismes/workorders/index.php'); exit; }

// Org wall check
$org_id = user_org_id();
if ($org_id && $wo['org_id'] != $org_id) { flash_set('danger','Access denied.'); header('Location: /chrismes/workorders/index.php'); exit; }

$page_title = 'WO: ' . $wo['wo_number'];
$tab = $_GET['tab'] ?? 'detail';

// ── Tab data ───────────────────────────────────────────────────────────────────
$serials = db_rows('SELECT ws.*,ro.op_number,ro.op_name,ro.op_type,u.known_as AS last_op_user
                    FROM work_order_serials ws
                    JOIN routing_operations ro ON ro.id=ws.current_op_id
                    LEFT JOIN clock_events ce ON ce.wo_serial_id=ws.id AND ce.clock_off IS NULL
                    LEFT JOIN users u ON u.id=ce.user_id
                    ORDER BY ws.serial_number', [$wo['id']]);

$ops_analytics = [];
$quality_records = [];
$time_bookings = [];
$routing_ops = [];
$change_log = [];

if ($tab === 'analytics') {
    $ops_analytics = db_rows(
        'SELECT ro.op_number,ro.op_name,ro.actual_mins AS planned,
                AVG(TIMESTAMPDIFF(SECOND,ce.clock_on,ce.clock_off))/60 AS avg_actual,
                COUNT(ce.id) AS bookings
         FROM routing_operations ro
         LEFT JOIN clock_events ce ON ce.routing_op_id=ro.id AND ce.wo_id=? AND ce.clock_off IS NOT NULL
         WHERE ro.routing_id=?
         GROUP BY ro.id ORDER BY ro.op_number',
        [$wo['id'], $wo['routing_id']]
    );
}
if ($tab === 'quality') {
    $quality_records = db_rows(
        'SELECT qr.*,ws.serial_number,qv.code,qv.name,qv.lower_limit,qv.target,qv.upper_limit,u.code AS uom_code,usr.known_as
         FROM quality_results qr
         JOIN work_order_serials ws ON ws.id=qr.wo_serial_id
         JOIN quality_variables qv ON qv.id=qr.quality_var_id
         JOIN units_of_measure u ON u.id=qv.uom_id
         LEFT JOIN users usr ON usr.id=qr.recorded_by
         WHERE qr.wo_id=? ORDER BY ws.serial_number,qv.code', [$wo['id']]
    );
}
if ($tab === 'time') {
    $time_bookings = db_rows(
        'SELECT ce.*,ws.serial_number,ro.op_number,ro.op_name,ro.actual_mins AS planned_mins,u.known_as
         FROM clock_events ce
         JOIN work_order_serials ws ON ws.id=ce.wo_serial_id
         JOIN routing_operations ro ON ro.id=ce.routing_op_id
         LEFT JOIN users u ON u.id=ce.user_id
         WHERE ce.wo_id=? ORDER BY ce.clock_on DESC', [$wo['id']]
    );
}
if ($tab === 'routing') {
    $routing_ops = db_rows(
        'SELECT ro.*,d.code AS dept_code,r.code AS res_code,doc.description AS doc_desc,dr.revision_number
         FROM routing_operations ro LEFT JOIN departments d ON d.id=ro.dept_id
         LEFT JOIN resources r ON r.id=ro.resource_id
         LEFT JOIN document_revisions dr ON dr.id=ro.doc_rev_id
         LEFT JOIN documents doc ON doc.id=dr.doc_id
         WHERE ro.routing_id=? ORDER BY ro.op_number', [$wo['routing_id']]
    );
}
if ($tab === 'changelog') {
    $change_log = db_rows(
        'SELECT al.*,u.known_as FROM audit_log al LEFT JOIN users u ON u.id=al.user_id
         WHERE al.entity_type IN (\'work_order\',\'work_order_serial\') AND al.entity_id=?
         ORDER BY al.created_at DESC LIMIT 100', [$wo['id']]
    );
}

$status_badge = match($wo['status']) {
    'Open'       => 'bg-primary',
    'In Progress'=> 'bg-warning text-dark',
    'Hard Hold'  => 'bg-danger',
    'Soft Hold'  => 'bg-warning text-dark',
    'Complete'   => 'bg-success',
    'Cancelled'  => 'bg-secondary',
    default      => 'bg-secondary',
};

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex align-items-center gap-3 mb-4 flex-wrap">
    <a href="/chrismes/workorders/index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
        <h5 class="mb-0"><?= h($wo['wo_number']) ?> <span class="badge <?= $status_badge ?>"><?= h($wo['status']) ?></span></h5>
        <small class="text-muted"><?= h($wo['part_number']) ?> — <?= h($wo['description']) ?></small>
    </div>
    <div class="ms-auto d-flex gap-2">
        <a href="/chrismes/operator/index.php?wo=<?= urlencode($wo['wo_number']) ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-play-circle me-1"></i>Operator Screen
        </a>
    </div>
</div>

<ul class="nav nav-tabs mb-4">
    <?php foreach (['detail'=>'WO Detail','analytics'=>'Op Analytics','quality'=>'Quality Records','time'=>'Time Bookings','routing'=>'Routing','changelog'=>'Change Log'] as $t=>$label): ?>
    <li class="nav-item"><a class="nav-link <?= $tab===$t?'active':'' ?>" href="?wo=<?= urlencode($wo_number) ?>&tab=<?= $t ?>"><?= $label ?></a></li>
    <?php endforeach; ?>
</ul>

<?php if ($tab === 'detail'): ?>
<div class="row g-4">
    <div class="col-md-5">
        <div class="card mb-4">
            <div class="card-header fw-semibold">Work Order Details</div>
            <div class="card-body small">
                <dl class="row mb-0">
                    <dt class="col-5">WO Number</dt><dd class="col-7"><code><?= h($wo['wo_number']) ?></code></dd>
                    <dt class="col-5">Org</dt><dd class="col-7"><?= h($wo['org_code']) ?></dd>
                    <dt class="col-5">Part</dt><dd class="col-7"><code><?= h($wo['part_number']) ?></code></dd>
                    <dt class="col-5">Description</dt><dd class="col-7"><?= h($wo['description']) ?></dd>
                    <dt class="col-5">Routing</dt><dd class="col-7"><?= h($wo['routing_name']) ?> Rev <?= h($wo['routing_rev']) ?></dd>
                    <dt class="col-5">Control</dt><dd class="col-7"><?= $wo['serial_controlled'] ? 'Serialised' : 'Lot Controlled' ?></dd>
                    <dt class="col-5">Quantity</dt><dd class="col-7"><?= h($wo['quantity']) ?></dd>
                    <dt class="col-5">Priority</dt><dd class="col-7"><?= h($wo['priority']) ?></dd>
                    <dt class="col-5">Created By</dt><dd class="col-7"><?= h($wo['created_by_name']) ?></dd>
                    <dt class="col-5">Created</dt><dd class="col-7"><?= date('d M Y H:i', strtotime($wo['created_at'])) ?></dd>
                    <dt class="col-5">Planned Start</dt><dd class="col-7"><?= $wo['planned_start'] ? date('d M Y', strtotime($wo['planned_start'])) : '—' ?></dd>
                    <dt class="col-5">Planned Finish</dt><dd class="col-7"><?= $wo['planned_finish'] ? date('d M Y', strtotime($wo['planned_finish'])) : '—' ?></dd>
                    <?php if ($wo['notes']): ?><dt class="col-5">Notes</dt><dd class="col-7"><?= h($wo['notes']) ?></dd><?php endif; ?>
                </dl>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card">
            <div class="card-header fw-semibold">Serial / Lot Status</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light"><tr><th>Serial / Lot</th><th>Current Op</th><th>Op Type</th><th>Status</th><th>Last Operator</th></tr></thead>
                    <tbody>
                    <?php foreach ($serials as $ws): ?>
                    <tr>
                        <td><code><?= h($ws['serial_number']) ?></code></td>
                        <td><?= str_pad((int)$ws['op_number'],3,'0',STR_PAD_LEFT) ?> — <?= h($ws['op_name']) ?></td>
                        <td><span class="badge bg-info text-dark"><?= h($ws['op_type']) ?></span></td>
                        <td><span class="badge <?= match($ws['status']){
                            'Available'=>'bg-success','In Progress'=>'bg-warning text-dark','Complete'=>'bg-primary',
                            'Scrapped'=>'bg-secondary','Hold'=>'bg-danger',default=>'bg-light text-dark'} ?>"><?= h($ws['status']) ?></span></td>
                        <td><?= h($ws['last_op_user'] ?? '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php elseif ($tab === 'analytics'): ?>
<div class="card">
    <div class="card-header fw-semibold">Operation Efficiency</div>
    <div class="table-responsive">
        <table class="table mb-0 small">
            <thead class="table-light"><tr><th>Op</th><th>Name</th><th>Planned (min)</th><th>Avg Actual (min)</th><th>Efficiency</th><th>Bookings</th></tr></thead>
            <tbody>
            <?php foreach ($ops_analytics as $oa):
                $eff = $oa['planned'] && $oa['avg_actual'] ? round($oa['planned'] / $oa['avg_actual'] * 100) : null;
            ?>
            <tr>
                <td><?= str_pad((int)$oa['op_number'],3,'0',STR_PAD_LEFT) ?></td>
                <td><?= h($oa['op_name']) ?></td>
                <td><?= $oa['planned'] ?? '—' ?></td>
                <td><?= $oa['avg_actual'] ? round((float)$oa['avg_actual'],1) : '—' ?></td>
                <td>
                    <?php if ($eff !== null): ?>
                    <div class="efficiency-bar" style="width:160px">
                        <div class="fill" style="width:<?= min(200,$eff) ?>%"></div>
                    </div>
                    <small><?= $eff ?>%</small>
                    <?php else: ?>—<?php endif; ?>
                </td>
                <td><?= (int)$oa['bookings'] ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($tab === 'quality'): ?>
<div class="card">
    <div class="card-header fw-semibold">Quality Records</div>
    <div class="table-responsive">
        <table class="table mb-0 small">
            <thead class="table-light"><tr><th>Serial</th><th>Variable</th><th>Value</th><th>UoM</th><th>Lower</th><th>Target</th><th>Upper</th><th>Result</th><th>Recorded By</th></tr></thead>
            <tbody>
            <?php foreach ($quality_records as $qr): ?>
            <tr>
                <td><code><?= h($qr['serial_number']) ?></code></td>
                <td><?= h($qr['name']) ?></td>
                <td class="fw-semibold"><?= h($qr['value']) ?></td>
                <td><?= h($qr['uom_code']) ?></td>
                <td><?= h($qr['lower_limit'] ?? '—') ?></td>
                <td><?= h($qr['target'] ?? '—') ?></td>
                <td><?= h($qr['upper_limit'] ?? '—') ?></td>
                <td><?= $qr['in_spec'] ? '<span class="badge bg-success">Pass</span>' : '<span class="badge bg-danger">Fail</span>' ?></td>
                <td><?= h($qr['known_as'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($quality_records)): ?><tr><td colspan="9" class="text-center text-muted py-3">No quality records.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($tab === 'time'): ?>
<div class="card">
    <div class="card-header fw-semibold">Time Bookings</div>
    <div class="table-responsive">
        <table class="table mb-0 small">
            <thead class="table-light"><tr><th>Serial</th><th>Op</th><th>Operator</th><th>Clock On</th><th>Clock Off</th><th>Duration</th><th>Planned (min)</th><th>Efficiency</th></tr></thead>
            <tbody>
            <?php foreach ($time_bookings as $tb):
                $dur = $tb['clock_off'] ? (strtotime($tb['clock_off']) - strtotime($tb['clock_on'])) : null;
                $eff = ($dur && $tb['planned_mins']) ? round($tb['planned_mins']*60 / $dur * 100) : null;
            ?>
            <tr>
                <td><code><?= h($tb['serial_number']) ?></code></td>
                <td><?= str_pad((int)$tb['op_number'],3,'0',STR_PAD_LEFT) ?> <?= h($tb['op_name']) ?></td>
                <td><?= h($tb['known_as'] ?? '—') ?></td>
                <td><?= date('d M y H:i', strtotime($tb['clock_on'])) ?></td>
                <td><?= $tb['clock_off'] ? date('d M y H:i', strtotime($tb['clock_off'])) : '<span class="text-warning">Active</span>' ?></td>
                <td><?= $dur ? fmt_duration($dur) : '—' ?></td>
                <td><?= h($tb['planned_mins'] ?? '—') ?></td>
                <td><?= $eff !== null ? $eff.'%' : '—' ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($time_bookings)): ?><tr><td colspan="8" class="text-center text-muted py-3">No time bookings.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($tab === 'routing'): ?>
<div class="card">
    <div class="card-header fw-semibold">Routing Snapshot — <?= h($wo['routing_name']) ?> Rev <?= h($wo['routing_rev']) ?></div>
    <div class="table-responsive">
        <table class="table mb-0 small">
            <thead class="table-light"><tr><th>Op#</th><th>Name</th><th>Behaviour</th><th>Type</th><th>Dept</th><th>Resource</th><th>Document</th><th>Setup</th><th>Actual</th></tr></thead>
            <tbody>
            <?php foreach ($routing_ops as $op): ?>
            <tr>
                <td><code><?= str_pad((int)$op['op_number'],3,'0',STR_PAD_LEFT) ?></code></td>
                <td><?= h($op['op_name']) ?></td>
                <td><span class="badge <?= $op['behaviour']==='Non-Clocking'?'bg-secondary':'bg-primary' ?>"><?= h($op['behaviour']) ?></span></td>
                <td><?= h($op['op_type']) ?></td>
                <td><?= h($op['dept_code'] ?? '—') ?></td>
                <td><?= h($op['res_code'] ?? '—') ?></td>
                <td><?= $op['doc_rev_id'] ? h($op['doc_desc']) : '—' ?></td>
                <td><?= $op['setup_mins'] ? $op['setup_mins'].'m' : '—' ?></td>
                <td><?= $op['actual_mins'] ? $op['actual_mins'].'m' : '—' ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($tab === 'changelog'): ?>
<div class="card">
    <div class="card-header fw-semibold">Change Log</div>
    <div class="table-responsive">
        <table class="table mb-0 small">
            <thead class="table-light"><tr><th>Date/Time</th><th>Action</th><th>By</th><th>Detail</th></tr></thead>
            <tbody>
            <?php foreach ($change_log as $cl): ?>
            <tr>
                <td><?= date('d M y H:i', strtotime($cl['created_at'])) ?></td>
                <td><?= h($cl['action']) ?></td>
                <td><?= h($cl['known_as'] ?? '—') ?></td>
                <td><?= h($cl['detail']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($change_log)): ?><tr><td colspan="4" class="text-center text-muted py-3">No events logged.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
