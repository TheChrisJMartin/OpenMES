<?php
// =============================================================================
// ChrisMES - workorders/create.php
// Version: 10.5.0
// =============================================================================
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_role('IT_ADMIN','SUPERVISOR');
$page_title = 'Create Work Order';

if (!ALLOW_WO_CREATION) {
    flash_set('warning','Work order creation is disabled. ERP is mastering work orders (ALLOW_WO_CREATION=false).');
    header('Location: /chrismes/workorders/index.php'); exit;
}

$org_id   = user_org_id();
$errors   = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sel_org_id  = (int)$_POST['org_id'];
    $part_id     = (int)$_POST['part_id'];
    $routing_id  = (int)$_POST['routing_id'];
    $quantity    = (int)$_POST['quantity'];
    $reg_id      = (int)$_POST['register_id'];
    $priority    = (int)($_POST['priority'] ?? 50);
    $planned_start= trim($_POST['planned_start'] ?? '');
    $planned_finish=trim($_POST['planned_finish'] ?? '');
    $notes       = trim($_POST['notes'] ?? '');

    $part    = db_row('SELECT p.*,o.code AS org_code FROM parts p JOIN orgs o ON o.id=p.org_id WHERE p.id=?',[$part_id]);
    $routing = db_row('SELECT * FROM routings WHERE id=? AND status=?',[$routing_id,'Approved']);

    if (!$part) $errors[] = 'Invalid part selected.';
    if (!$routing) $errors[] = 'Invalid or unapproved routing.';
    if ($quantity < 1) $errors[] = 'Quantity must be at least 1.';
    if ($part && $part['serial_controlled'] && $quantity > MAX_SERIALS_PER_WO)
        $errors[] = 'Serialised WOs limited to ' . MAX_SERIALS_PER_WO . ' items.';
    if ($part && !$part['serial_controlled'] && $quantity > MAX_LOT_QTY_PER_WO)
        $errors[] = 'Lot WOs limited to ' . MAX_LOT_QTY_PER_WO . ' items.';

    if (!$errors) {
        try {
            $pdo = db();
            $pdo->beginTransaction();

            $wo_number = generate_wo_number($part['org_code']);

            db_exec('INSERT INTO work_orders (org_id,part_id,routing_id,wo_number,status,quantity,serial_controlled,priority,planned_start,planned_finish,notes,created_by,created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())',
                [$sel_org_id,$part_id,$routing_id,$wo_number,'Open',$quantity,$part['serial_controlled']?1:0,$priority,
                 $planned_start?:null,$planned_finish?:null,$notes,current_user()['id']]);
            $wo_id = (int)db_last_id();

            // Allocate serials or lot number
            if ($part['serial_controlled']) {
                $serials = allocate_serials($reg_id, $quantity);
                foreach ($serials as $sn) {
                    db_exec('INSERT INTO work_order_serials (wo_id,serial_number,current_op_id,status,created_at)
                             SELECT ?,?,ro.id,?,NOW() FROM routing_operations ro WHERE ro.routing_id=? ORDER BY ro.op_number ASC LIMIT 1',
                        [$wo_id,$sn,'Available',$routing_id]);
                }
            } else {
                // Lot: single entry with system lot number
                $lot_row = db_row('SELECT COUNT(*)+1 AS cnt FROM work_order_serials ws JOIN work_orders wo ON wo.id=ws.wo_id WHERE wo.org_id=?',[$sel_org_id]);
                $lot_num = 'LOT' . str_pad((int)$lot_row['cnt'], 7, '0', STR_PAD_LEFT);
                db_exec('INSERT INTO work_order_serials (wo_id,serial_number,current_op_id,quantity,status,created_at)
                         SELECT ?,?,ro.id,?,?,NOW() FROM routing_operations ro WHERE ro.routing_id=? ORDER BY ro.op_number ASC LIMIT 1',
                    [$wo_id,$lot_num,$quantity,'Available',$routing_id]);
            }

            audit_log('work_order', $wo_id, 'CREATE', "WO {$wo_number} created");
            $pdo->commit();

            flash_set('success', "Work Order <strong>{$wo_number}</strong> created successfully.");
            header('Location: /chrismes/workorders/view.php?wo=' . urlencode($wo_number)); exit;

        } catch (Exception $e) {
            db()->rollBack();
            $errors[] = 'Failed to create work order: ' . $e->getMessage();
        }
    }
}

// Parts with approved routings
$parts_query = 'SELECT DISTINCT p.id,p.part_number,p.description,p.serial_controlled,o.code AS org_code,o.id AS org_id
                FROM parts p JOIN orgs o ON o.id=p.org_id
                JOIN routings r ON r.part_id=p.id AND r.status=\'Approved\'';
$parts_params = [];
if ($org_id) { $parts_query .= ' WHERE p.org_id=?'; $parts_params[] = $org_id; }
$parts_query .= ' ORDER BY p.part_number';
$parts = db_rows($parts_query, $parts_params);

$orgs = db_rows('SELECT id,code,name FROM orgs WHERE is_active=1 ORDER BY code');
$registers = db_rows('SELECT r.*,o.code AS org_code FROM serial_registers r JOIN orgs o ON o.id=r.org_id ORDER BY o.code,r.code');

include __DIR__ . '/../includes/header.php';
?>

<div class="card" style="max-width:720px">
    <div class="card-header fw-semibold"><i class="bi bi-plus-circle me-2"></i>Create Work Order</div>
    <div class="card-body">
        <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

        <form method="post" id="woForm">
            <div class="row g-3">
                <?php if (!$org_id): ?>
                <div class="col-md-6">
                    <label class="form-label">Organisation <span class="text-danger">*</span></label>
                    <select name="org_id" class="form-select" required>
                        <option value="">— Select —</option>
                        <?php foreach ($orgs as $o): ?><option value="<?= $o['id'] ?>"><?= h($o['code']) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                <input type="hidden" name="org_id" value="<?= $org_id ?>">
                <?php endif; ?>

                <div class="col-md-6">
                    <label class="form-label">Part Number <span class="text-danger">*</span></label>
                    <select name="part_id" class="form-select" id="partSelect" required>
                        <option value="">— Select Part —</option>
                        <?php foreach ($parts as $p): ?>
                        <option value="<?= $p['id'] ?>"
                                data-serial="<?= $p['serial_controlled'] ?>"
                                data-org="<?= $p['org_id'] ?>">
                            <?= h($p['org_code']) ?> / <?= h($p['part_number']) ?> — <?= h($p['description']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Routing Revision <span class="text-danger">*</span></label>
                    <select name="routing_id" class="form-select" id="routingSelect" required>
                        <option value="">— Select Part First —</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Quantity <span class="text-danger">*</span></label>
                    <input type="number" name="quantity" class="form-control" id="qty" min="1" value="1" required>
                    <div class="form-text" id="qty-hint"></div>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Priority <span class="text-muted small">(1=high, 99=low)</span></label>
                    <input type="number" name="priority" class="form-control" value="50" min="1" max="99">
                </div>

                <div class="col-md-6">
                    <label class="form-label">Serial Number Register</label>
                    <select name="register_id" class="form-select" id="registerSelect">
                        <option value="">— Default Register —</option>
                        <?php foreach ($registers as $r): ?>
                        <option value="<?= $r['id'] ?>" data-org="<?= $r['org_id'] ?>">
                            <?= h($r['org_code']) ?> / <?= h($r['code']) ?> (<?= number_format($r['end_seq'] - $r['current_seq']) ?> remaining)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Planned Start</label>
                    <input type="datetime-local" name="planned_start" class="form-control" value="<?= date('Y-m-d\TH:i') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Planned Finish</label>
                    <input type="datetime-local" name="planned_finish" class="form-control">
                </div>

                <div class="col-12">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="bi bi-check-circle me-1"></i>Create Work Order</button>
                <a href="/chrismes/workorders/index.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
const routingData = <?= json_encode(
    db_rows("SELECT r.id,r.part_id,r.revision,r.status FROM routings r WHERE r.status='Approved' ORDER BY r.part_id,r.revision DESC")
) ?>;

document.getElementById('partSelect').addEventListener('change', function() {
    const partId = this.value;
    const opt = this.options[this.selectedIndex];
    const isSerial = opt.dataset.serial == '1';

    // Update routing dropdown
    const rs = document.getElementById('routingSelect');
    rs.innerHTML = '<option value="">— Select Revision —</option>';
    routingData.filter(r => r.part_id == partId).forEach(r => {
        const o = document.createElement('option');
        o.value = r.id; o.textContent = 'Rev ' + r.revision + ' (' + r.status + ')';
        if (rs.options.length === 1) o.selected = true; // default to first (latest)
        rs.appendChild(o);
    });

    // Update quantity hint
    document.getElementById('qty-hint').textContent = isSerial
        ? 'Max ' + <?= MAX_SERIALS_PER_WO ?> + ' (serialised)'
        : 'Max ' + <?= MAX_LOT_QTY_PER_WO ?> + ' (lot)';
    document.getElementById('qty').max = isSerial ? <?= MAX_SERIALS_PER_WO ?> : <?= MAX_LOT_QTY_PER_WO ?>;
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
