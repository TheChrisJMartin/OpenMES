<?php
/**
 * logout.php — ChrisMES Logout
 * Version: 1.0.0
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
destroySession();
header('Location: ' . SITE_URL . '/login.php');
exit;
