-- ===========================================================================
-- OpenMES Bootstrap SQL v10.9.0
-- Complete schema + demo data for BIKE and TEACL organisations
-- Run this ONCE during initial setup via install.php
-- ===========================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------------
-- CORE TABLES
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS personas (
    id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code  VARCHAR(40)  NOT NULL,
    label VARCHAR(100) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_persona_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orgs (
    id       INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code     VARCHAR(5)   NOT NULL,
    name     VARCHAR(200) NOT NULL,
    org_type ENUM('OE','MRO') NOT NULL DEFAULT 'OE',
    is_admin TINYINT(1)   NOT NULL DEFAULT 0,
    active   TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_org_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username      VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    firstname     VARCHAR(100) NOT NULL DEFAULT '',
    surname       VARCHAR(100) NOT NULL DEFAULT '',
    known_as      VARCHAR(100) NOT NULL DEFAULT '',
    persona_id    INT UNSIGNED NOT NULL,
    org_id        INT UNSIGNED NULL,
    active        TINYINT(1)   NOT NULL DEFAULT 1,
    is_direct     TINYINT(1)   NOT NULL DEFAULT 1,
    is_test_acct  TINYINT(1)   NOT NULL DEFAULT 0,
    theme         ENUM('light','dark') NOT NULL DEFAULT 'dark',
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_username (username),
    KEY idx_user_persona (persona_id),
    KEY idx_user_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS departments (
    id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id  INT UNSIGNED NOT NULL,
    code    VARCHAR(10)  NOT NULL,
    name    VARCHAR(200) NOT NULL,
    active  TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_dept_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS resources (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id        INT UNSIGNED NOT NULL,
    department_id INT UNSIGNED NOT NULL,
    code          VARCHAR(50)  NOT NULL,
    name          VARCHAR(200) NOT NULL,
    active        TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_res_org (org_id),
    KEY idx_res_dept (department_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS uom (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code      VARCHAR(20)  NOT NULL,
    name      VARCHAR(100) NOT NULL,
    is_system TINYINT(1)   NOT NULL DEFAULT 0,
    active    TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_uom_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS parts (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id           INT UNSIGNED NOT NULL,
    part_number      VARCHAR(50)  NOT NULL,
    part_revision    VARCHAR(20)  NOT NULL DEFAULT 'A',
    description      VARCHAR(500) NOT NULL,
    uom_id           INT UNSIGNED NULL,
    serial_controlled TINYINT(1)  NOT NULL DEFAULT 1,
    make_or_buy      ENUM('MAKE','BUY') NOT NULL DEFAULT 'MAKE',
    shelf_lifed      TINYINT(1)   NOT NULL DEFAULT 0,
    planner_code     VARCHAR(20)  NULL,
    item_version     INT UNSIGNED NOT NULL DEFAULT 1,
    active           TINYINT(1)   NOT NULL DEFAULT 1,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_part_org (org_id, part_number),
    KEY idx_part_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventory_locations (
    id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id  INT UNSIGNED NOT NULL,
    code    VARCHAR(50)  NOT NULL,
    name    VARCHAR(200) NOT NULL,
    active  TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_loc_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS serial_registers (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id          INT UNSIGNED NOT NULL,
    register_code   VARCHAR(50)  NOT NULL,
    prefix          VARCHAR(20)  NOT NULL DEFAULT '',
    pad_length      INT UNSIGNED NOT NULL DEFAULT 5,
    suffix          VARCHAR(20)  NOT NULL DEFAULT '',
    start_seq       INT UNSIGNED NOT NULL DEFAULT 1,
    end_seq         INT UNSIGNED NOT NULL DEFAULT 99999,
    current_seq     INT UNSIGNED NOT NULL DEFAULT 0,
    active          TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_sr_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS calibration_tools (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id           INT UNSIGNED NOT NULL,
    asset_number     VARCHAR(50)  NOT NULL,
    asset_type       ENUM('T','TE') NOT NULL DEFAULT 'T',
    description      VARCHAR(500) NOT NULL,
    calibration_due  DATE         NULL,
    active           TINYINT(1)   NOT NULL DEFAULT 1,
    created_by       INT UNSIGNED NULL,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by       INT UNSIGNED NULL,
    updated_at       DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_asset_org (org_id, asset_number),
    KEY idx_ct_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS skills (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id      INT UNSIGNED NOT NULL,
    code        VARCHAR(50)  NOT NULL,
    name        VARCHAR(200) NOT NULL,
    description TEXT         NULL,
    active      TINYINT(1)   NOT NULL DEFAULT 1,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_skill_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_skills (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED NOT NULL,
    skill_id    INT UNSIGNED NOT NULL,
    status      ENUM('PENDING','APPROVED','EXPIRED','REVOKED') NOT NULL DEFAULT 'PENDING',
    expiry_date DATE         NULL,
    assigned_by INT UNSIGNED NULL,
    assigned_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_skill (user_id, skill_id),
    KEY idx_us_skill (skill_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documents (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id          INT UNSIGNED NOT NULL,
    part_id         INT UNSIGNED NULL,
    doc_number      VARCHAR(100) NOT NULL,
    description     VARCHAR(500) NOT NULL,
    revision        INT UNSIGNED NOT NULL DEFAULT 1,
    revision_label  VARCHAR(10)  NOT NULL DEFAULT '000001',
    status          ENUM('DRAFT','APPROVED','SUPERSEDED','ARCHIVED','WITHDRAWN') NOT NULL DEFAULT 'DRAFT',
    file_name       VARCHAR(500) NOT NULL,
    file_path       VARCHAR(1000) NOT NULL,
    file_size       INT UNSIGNED NULL,
    doc_owner       VARCHAR(100) NULL,
    review_date     DATE         NULL,
    uploaded_by     INT UNSIGNED NOT NULL,
    uploaded_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_by     INT UNSIGNED NULL,
    approved_at     DATETIME     NULL,
    PRIMARY KEY (id),
    KEY idx_doc_org (org_id),
    KEY idx_doc_part (part_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS routings (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id           INT UNSIGNED NOT NULL,
    part_id          INT UNSIGNED NOT NULL,
    routing_group_id INT UNSIGNED NOT NULL,
    routing_number   VARCHAR(100) NOT NULL,
    revision         INT UNSIGNED NOT NULL DEFAULT 1,
    revision_label   VARCHAR(10)  NOT NULL DEFAULT '000001',
    status           ENUM('DRAFT','APPROVED','SUPERSEDED','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
    uploaded_by      INT UNSIGNED NOT NULL,
    last_edited_by   INT UNSIGNED NULL,
    last_edited_at   DATETIME     NULL,
    approved_by      INT UNSIGNED NULL,
    approved_at      DATETIME     NULL,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_r_org (org_id),
    KEY idx_r_part (part_id),
    KEY idx_r_group (routing_group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS routing_operations (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    routing_id    INT UNSIGNED NOT NULL,
    op_number     VARCHAR(10)  NOT NULL,
    behaviour     ENUM('CLOCKING','NON-CLOCKING') NOT NULL DEFAULT 'CLOCKING',
    op_name       VARCHAR(200) NOT NULL,
    op_type       ENUM('STANDARD','INSPECTION','FINAL_TEST','FINAL_INSPECTION','BOOK_TO_STOCK','MATERIAL_KITTING') NOT NULL DEFAULT 'STANDARD',
    department_id INT UNSIGNED NULL,
    resource_id   INT UNSIGNED NULL,
    document_id   INT UNSIGNED NULL,
    setup_mins    DECIMAL(8,2) NULL,
    actual_mins   DECIMAL(8,2) NULL,
    sort_order    INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_ro_routing (routing_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS quality_variables (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    routing_id    INT UNSIGNED NOT NULL,
    op_id         INT UNSIGNED NOT NULL,
    org_id        INT UNSIGNED NOT NULL,
    code          VARCHAR(50)  NOT NULL,
    name          VARCHAR(200) NOT NULL,
    uom_id        INT UNSIGNED NULL,
    qv_type       ENUM('NUMERIC','PASS_FAIL','YES_NO') NOT NULL DEFAULT 'NUMERIC',
    lower_limit   DECIMAL(12,4) NULL,
    upper_limit   DECIMAL(12,4) NULL,
    target_value  DECIMAL(12,4) NULL,
    active        TINYINT(1)   NOT NULL DEFAULT 1,
    created_by    INT UNSIGNED NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     NULL,
    PRIMARY KEY (id),
    KEY idx_qv_routing (routing_id),
    KEY idx_qv_op (op_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS work_orders (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id        INT UNSIGNED NOT NULL,
    wo_number     VARCHAR(20)  NOT NULL,
    part_id       INT UNSIGNED NOT NULL,
    routing_id    INT UNSIGNED NOT NULL,
    control_type  ENUM('SERIALISED','LOT') NOT NULL DEFAULT 'SERIALISED',
    quantity      INT UNSIGNED NOT NULL DEFAULT 1,
    lot_number    VARCHAR(50)  NULL,
    status        ENUM('OPEN','IN_PROGRESS','ON_HOLD','COMPLETE','CANCELLED') NOT NULL DEFAULT 'OPEN',
    hold_type     ENUM('HARD','SOFT') NULL,
    priority      TINYINT UNSIGNED NOT NULL DEFAULT 50,
    fai_required  TINYINT(1)   NOT NULL DEFAULT 0,
    notes         TEXT         NULL,
    planned_start DATETIME     NULL,
    planned_finish DATETIME    NULL,
    created_by    INT UNSIGNED NOT NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_wo_number (wo_number),
    KEY idx_wo_org (org_id),
    KEY idx_wo_part (part_id),
    KEY idx_wo_routing (routing_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_sequence (
    org_id   INT UNSIGNED NOT NULL,
    next_seq INT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS serial_numbers (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id           INT UNSIGNED NOT NULL,
    org_id          INT UNSIGNED NOT NULL,
    serial_number   VARCHAR(50)  NOT NULL,
    current_op_id   INT UNSIGNED NULL,
    wip_location    VARCHAR(100) NULL,
    status          ENUM('NOT_STARTED','IN_PROGRESS','ON_HOLD','COMPLETE','SCRAPPED') NOT NULL DEFAULT 'NOT_STARTED',
    register_id     INT UNSIGNED NULL,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NULL,
    PRIMARY KEY (id),
    KEY idx_sn_wo (wo_id),
    KEY idx_sn_org (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_serials (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id     INT UNSIGNED NOT NULL,
    serial_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_ws_wo (wo_id),
    KEY idx_ws_serial (serial_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_active_clocks (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    serial_id     INT UNSIGNED NOT NULL,
    wo_id         INT UNSIGNED NOT NULL,
    op_id         INT UNSIGNED NOT NULL,
    user_id       INT UNSIGNED NOT NULL,
    clocked_on_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_serial_clock (serial_id),
    KEY idx_ac_wo (wo_id),
    KEY idx_ac_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_clock_events (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id           INT UNSIGNED NOT NULL,
    serial_id       INT UNSIGNED NOT NULL,
    op_id           INT UNSIGNED NOT NULL,
    user_id         INT UNSIGNED NOT NULL,
    event_type      ENUM('CLOCK_ON','CLOCK_OFF','COMPLETE','FORCE_CLOCKOFF') NOT NULL DEFAULT 'CLOCK_ON',
    clocked_on_at   DATETIME     NULL,
    clocked_off_at  DATETIME     NULL,
    duration_mins   DECIMAL(10,2) NULL,
    is_overrun      TINYINT(1)   NOT NULL DEFAULT 0,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ce_wo (wo_id),
    KEY idx_ce_serial (serial_id),
    KEY idx_ce_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_stock_bookings (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id        INT UNSIGNED NOT NULL,
    serial_id    INT UNSIGNED NOT NULL,
    location_id  INT UNSIGNED NOT NULL,
    booked_by    INT UNSIGNED NOT NULL,
    booked_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    release_note VARCHAR(500) NULL,
    PRIMARY KEY (id),
    KEY idx_bts_wo (wo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_tool_records (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id       INT UNSIGNED NOT NULL,
    serial_id   INT UNSIGNED NOT NULL,
    tool_id     INT UNSIGNED NOT NULL,
    recorded_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    recorded_by INT UNSIGNED NULL,
    notes       VARCHAR(200) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_wtr (wo_id, serial_id, tool_id),
    KEY idx_wtr_wo (wo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wo_change_log (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id       INT UNSIGNED NOT NULL,
    changed_by  INT UNSIGNED NOT NULL,
    change_type VARCHAR(50)  NOT NULL,
    description TEXT         NOT NULL,
    changed_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_wcl_wo (wo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS non_conformances (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id           INT UNSIGNED NOT NULL,
    wo_id            INT UNSIGNED NOT NULL,
    nc_number        VARCHAR(20)  NOT NULL,
    op_id            INT UNSIGNED NOT NULL,
    defect_desc      TEXT         NOT NULL,
    cause_category   ENUM('MAN','MACHINE','METHOD','MATERIAL','MEASUREMENT','ENVIRONMENT') NULL,
    status           ENUM('OPEN','UNDER_REVIEW','CLOSED') NOT NULL DEFAULT 'OPEN',
    disposition      ENUM('CONTINUE','SCRAP','REWORK') NULL,
    disposition_note TEXT         NULL,
    hold_type        ENUM('HARD','SOFT') NULL,
    raised_by        INT UNSIGNED NOT NULL,
    raised_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_nc_number (nc_number),
    KEY idx_nc_org (org_id),
    KEY idx_nc_wo (wo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS nc_serials (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nc_id     INT UNSIGNED NOT NULL,
    serial_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_ncs_nc (nc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS nc_corrective_actions (
    id                       INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nc_id                    INT UNSIGNED NOT NULL,
    ca_description           TEXT         NOT NULL,
    ca_owner                 VARCHAR(100) NULL,
    ca_due_date              DATE         NULL,
    effectiveness_review_date DATE        NULL,
    effectiveness_confirmed  TINYINT(1)   NOT NULL DEFAULT 0,
    created_by               INT UNSIGNED NOT NULL,
    created_at               DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_nca_nc (nc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS quality_results (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    wo_id         INT UNSIGNED NOT NULL,
    serial_id     INT UNSIGNED NOT NULL,
    op_id         INT UNSIGNED NOT NULL,
    qv_id         INT UNSIGNED NOT NULL,
    result_value  DECIMAL(12,4) NOT NULL,
    is_in_spec    TINYINT(1)   NOT NULL DEFAULT 1,
    nc_id         INT UNSIGNED NULL,
    collected_by  INT UNSIGNED NOT NULL,
    collected_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_qr_wo (wo_id),
    KEY idx_qr_serial (serial_id),
    KEY idx_qr_qv (qv_id),
    CONSTRAINT fk_qr_qv FOREIGN KEY (qv_id) REFERENCES quality_variables (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS op_required_tools (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    op_id      INT UNSIGNED NOT NULL,
    tool_id    INT UNSIGNED NOT NULL,
    notes      VARCHAR(200) NULL,
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_op_tool (op_id, tool_id),
    KEY idx_ort_op (op_id),
    KEY idx_ort_tool (tool_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS force_clockoff_log (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    serial_id       INT UNSIGNED NOT NULL,
    op_id           INT UNSIGNED NOT NULL,
    forced_off_user INT UNSIGNED NOT NULL,
    forced_by_user  INT UNSIGNED NOT NULL,
    reason          VARCHAR(500) NULL,
    forced_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_fcl_serial (serial_id),
    KEY idx_fcl_time (forced_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS integration_outbound (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    org_id          INT UNSIGNED NOT NULL,
    transaction_ref VARCHAR(50)  NOT NULL,
    message_type    ENUM('TimeAttendanceOUT','WorkOrderOUT','RoutingOUT','PartItemIN',
                         'DepartmentIN','ResourceIN','WorkOrderIN','WorkOrderMoveIN','WorkOrderMoveOUT')
                    NOT NULL,
    payload         MEDIUMTEXT   NULL,
    placed_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at    DATETIME     NULL,
    paused          TINYINT(1)   NOT NULL DEFAULT 0,
    error_code      VARCHAR(100) NULL,
    PRIMARY KEY (id),
    KEY idx_io_org (org_id),
    KEY idx_io_type (message_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS broadcast_messages (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    message    VARCHAR(128) NOT NULL,
    colour     ENUM('red','yellow','green') NOT NULL DEFAULT 'yellow',
    is_active  TINYINT(1)   NOT NULL DEFAULT 0,
    created_by INT UNSIGNED NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_log (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_type  VARCHAR(50)  NOT NULL,
    table_name  VARCHAR(100) NOT NULL,
    record_id   VARCHAR(100) NULL,
    org_id      INT UNSIGNED NULL,
    user_id     INT UNSIGNED NULL,
    username    VARCHAR(100) NULL,
    field_name  VARCHAR(100) NULL,
    old_value   TEXT         NULL,
    new_value   TEXT         NULL,
    notes       TEXT         NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_al_event (event_type),
    KEY idx_al_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS security_log (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_type VARCHAR(50)  NOT NULL,
    severity   ENUM('LOW','MEDIUM','HIGH') NOT NULL DEFAULT 'LOW',
    user_id    INT UNSIGNED NULL,
    username   VARCHAR(100) NULL,
    ip_address VARCHAR(45)  NULL,
    notes      TEXT         NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_sl_event (event_type),
    KEY idx_sl_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS system_config (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    config_key  VARCHAR(100) NOT NULL,
    config_val  TEXT         NOT NULL,
    data_type   ENUM('string','boolean','integer','timezone','theme') NOT NULL DEFAULT 'string',
    label       VARCHAR(200) NOT NULL DEFAULT '',
    description TEXT         NULL,
    sort_order  INT UNSIGNED NOT NULL DEFAULT 100,
    updated_by  INT UNSIGNED NULL,
    updated_at  DATETIME     NULL,
    PRIMARY KEY (id),
    KEY idx_sc_key (config_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS schema_version (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    version    VARCHAR(20)  NOT NULL,
    patch_file VARCHAR(200) NULL,
    notes      TEXT         NULL,
    applied_by INT UNSIGNED NULL,
    applied_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username     VARCHAR(100) NOT NULL,
    ip_address   VARCHAR(45)  NOT NULL,
    attempted_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    success      TINYINT(1)   NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_la_username (username),
    KEY idx_la_ip (ip_address),
    KEY idx_la_time (attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS deployments (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    version         VARCHAR(20)  NOT NULL,
    zip_filename    VARCHAR(200) NOT NULL,
    files_deployed  INT UNSIGNED NOT NULL DEFAULT 0,
    files_backed_up INT UNSIGNED NOT NULL DEFAULT 0,
    sql_patches     TEXT         NULL,
    sql_statements  TEXT         NULL,
    deployed_by     INT UNSIGNED NULL,
    status          ENUM('SUCCESS','PARTIAL','FAILED') NOT NULL DEFAULT 'SUCCESS',
    notes           TEXT         NULL,
    deployed_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS update_check_cache (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    latest_version  VARCHAR(20)  NOT NULL,
    release_url     VARCHAR(500) NOT NULL,
    zip_url         VARCHAR(500) NOT NULL,
    release_notes   TEXT         NULL,
    checked_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- SEED DATA - Personas
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO personas (code, label) VALUES
('IT_ADMIN',              'IT Admin'),
('SUPERVISOR',            'Supervisor'),
('OPERATOR',              'Operator'),
('TESTER',                'Tester'),
('INSPECTOR',             'Inspector'),
('FINAL_TESTER',          'Final Tester'),
('MFG_ENGINEER',          'MFG Engineer'),
('MFG_ENGINEER_SUP',      'MFG Engineer Supervisor'),
('ENGINEER',              'Engineer'),
('QUALITY_ENGINEER',      'Quality Engineer'),
('QUALITY_TRAINING_MANAGER', 'Quality Training Manager');

-- ---------------------------------------------------------------------------
-- SEED DATA - System UoM
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO uom (code, name, is_system) VALUES
('EA',  'Each',          1),
('KG',  'Kilogram',      1),
('G',   'Gram',          1),
('L',   'Litre',         1),
('ML',  'Millilitre',    1),
('M',   'Metre',         1),
('MM',  'Millimetre',    1),
('C',   'Celsius',       1),
('PSI', 'PSI',           1),
('NM',  'Newton Metre',  1),
('P/F', 'Pass / Fail',   1),
('Y/N', 'Yes / No',      1);

-- ---------------------------------------------------------------------------
-- SEED DATA - System Config
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO system_config (config_key, config_val, data_type, label, description, sort_order) VALUES
('SITE_VERSION',       '10.9.0',                            'string',   'Application Version',     'Updated automatically by deployer.',                              1),
('SITE_NAME',          'OpenMES',                           'string',   'Site Name',               'Displayed in page titles and navigation.',                        2),
('SITE_TAGLINE',       'Manufacturing Execution System',    'string',   'Site Tagline',            'Subtitle shown on login page and navigation.',                    3),
('SITE_TIMEZONE',      'Europe/London',                     'timezone', 'System Timezone',         'All timestamps displayed in this timezone.',                      4),
('MAINTENANCE_MODE',   '0',                                 'boolean',  'Maintenance Mode',        'When enabled non-admin users see the maintenance page.',          5),
('MAINTENANCE_MESSAGE','System is currently under maintenance. Please try again shortly.', 'string', 'Maintenance Message', 'Shown to users when maintenance mode is active.', 6),
('TEST_MODE',          '1',                                 'boolean',  'Test Mode',               'Enables username-as-password for test accounts. Disable before go-live.', 10),
('AUTO_APPROVE_DOCS',  '1',                                 'boolean',  'Auto-Approve Documents',  'Enables Auto-Approve button on documents and routings.',          20),
('ALLOW_WO_CREATION',  '1',                                 'boolean',  'Allow WO Creation',       'Set false when ERP masters work orders.',                         30),
('PARTS_LOCKED',       '0',                                 'boolean',  'Parts Locked',            'Set true when ERP masters parts - prevents manual edits.',        40),
('MAX_SERIALS_PER_WO', '100',                               'integer',  'Max Serials per WO',      'Maximum serial numbers per work order.',                          50),
('MAX_LOT_QTY_PER_WO', '1000',                              'integer',  'Max Lot Qty per WO',      'Maximum lot quantity per work order.',                            60),
('GITHUB_RELEASE_URL', 'https://api.github.com/repos/TheChrisJMartin/OpenMES/releases/latest', 'string', 'GitHub Release URL', 'GitHub API URL for update checks.', 200);

-- ---------------------------------------------------------------------------
-- SEED DATA - Admin Org
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO orgs (code, name, org_type, is_admin, active)
VALUES ('ADMIN', 'System Administration', 'OE', 1, 1);

-- ---------------------------------------------------------------------------
-- SEED DATA - IT Admin User (password = ITADMIN1 in test mode)
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'ITADMIN1',
       '$2y$12$placeholder_hash_replaced_by_install',
       'Admin', 'User', 'Admin',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o
WHERE p.code='IT_ADMIN' AND o.code='ADMIN'
LIMIT 1;

-- ---------------------------------------------------------------------------
-- SEED DATA - BIKE Org
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO orgs (code, name, org_type, active)
VALUES ('BIKE', 'Bike Manufacturing', 'OE', 1);

INSERT IGNORE INTO departments (org_id, code, name, active)
SELECT o.id, 'ASSEMBLY', 'Assembly', 1 FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO departments (org_id, code, name, active)
SELECT o.id, 'INSPECTION', 'Inspection & QC', 1 FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO departments (org_id, code, name, active)
SELECT o.id, 'PACKAGING', 'Packaging & Despatch', 1 FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO resources (org_id, department_id, code, name, active)
SELECT o.id, d.id, 'WS-FRAME-01', 'Frame Assembly Station 1', 1
FROM orgs o JOIN departments d ON d.org_id=o.id WHERE o.code='BIKE' AND d.code='ASSEMBLY';

INSERT IGNORE INTO resources (org_id, department_id, code, name, active)
SELECT o.id, d.id, 'WS-FRAME-02', 'Frame Assembly Station 2', 1
FROM orgs o JOIN departments d ON d.org_id=o.id WHERE o.code='BIKE' AND d.code='ASSEMBLY';

INSERT IGNORE INTO resources (org_id, department_id, code, name, active)
SELECT o.id, d.id, 'WS-INSPECT-01', 'Inspection Bench 1', 1
FROM orgs o JOIN departments d ON d.org_id=o.id WHERE o.code='BIKE' AND d.code='INSPECTION';

-- BIKE inventory locations
INSERT IGNORE INTO inventory_locations (org_id, code, name)
SELECT o.id, 'FG-BIKE-01', 'Finished Goods Store A' FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO inventory_locations (org_id, code, name)
SELECT o.id, 'HOLD-BIKE', 'Quality Hold Area' FROM orgs o WHERE o.code='BIKE';

-- BIKE serial registers
INSERT IGNORE INTO serial_registers (org_id, register_code, prefix, pad_length, start_seq, end_seq, current_seq)
SELECT o.id, 'DEF', 'DEF', 5, 1, 99999, 0 FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO serial_registers (org_id, register_code, prefix, pad_length, start_seq, end_seq, current_seq)
SELECT o.id, 'BIKE-A', 'A', 5, 1, 99999, 0 FROM orgs o WHERE o.code='BIKE';

-- BIKE WO sequence
INSERT IGNORE INTO wo_sequence (org_id, next_seq)
SELECT o.id, 1 FROM orgs o WHERE o.code='BIKE';

-- BIKE parts
INSERT IGNORE INTO parts (org_id, part_number, part_revision, description, uom_id, serial_controlled, make_or_buy)
SELECT o.id, 'MTB-BIKE-001', 'A', 'Mountain Bike - Completed Assembly', u.id, 1, 'MAKE'
FROM orgs o, uom u WHERE o.code='BIKE' AND u.code='EA';

INSERT IGNORE INTO parts (org_id, part_number, part_revision, description, uom_id, serial_controlled, make_or_buy)
SELECT o.id, 'ROAD-BIKE-001', 'A', 'Road Bike - Completed Assembly', u.id, 1, 'MAKE'
FROM orgs o, uom u WHERE o.code='BIKE' AND u.code='EA';

INSERT IGNORE INTO parts (org_id, part_number, part_revision, description, uom_id, serial_controlled, make_or_buy)
SELECT o.id, 'FRAME-MTB-001', 'A', 'Mountain Bike Frame - Aluminium', u.id, 1, 'BUY'
FROM orgs o, uom u WHERE o.code='BIKE' AND u.code='EA';

INSERT IGNORE INTO parts (org_id, part_number, part_revision, description, uom_id, serial_controlled, make_or_buy)
SELECT o.id, 'WHEEL-SET-001', 'A', 'Mountain Bike Wheel Set', u.id, 1, 'BUY'
FROM orgs o, uom u WHERE o.code='BIKE' AND u.code='EA';

-- BIKE calibration tools
INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'TE-BIKE-001', 'TE', 'Torque Screwdriver 1-25Nm', DATE_ADD(CURDATE(), INTERVAL 12 MONTH)
FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'TE-BIKE-002', 'TE', 'Tyre Pressure Gauge Digital', DATE_ADD(CURDATE(), INTERVAL 12 MONTH)
FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'T-BIKE-001', 'T', 'Chain Wear Indicator', NULL
FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'T-BIKE-002', 'T', 'Wheel Truing Stand', NULL
FROM orgs o WHERE o.code='BIKE';

-- BIKE skills
INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'BIKE-TORQUE', 'Torque Setting', 'Certified to use torque screwdriver to spec'
FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'BIKE-WHEEL', 'Wheel Building', 'Qualified to build and true wheels'
FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'BIKE-INSPECT', 'Bike Final Inspection', 'Authorised to perform final QC'
FROM orgs o WHERE o.code='BIKE';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'BIKE-BRAKE', 'Brake Setup & Test', 'Qualified for hydraulic and mechanical brakes'
FROM orgs o WHERE o.code='BIKE';

-- ---------------------------------------------------------------------------
-- SEED DATA - TEACL Org
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO orgs (code, name, org_type, active)
VALUES ('TEACL', 'Tea Club', 'OE', 1);

INSERT IGNORE INTO departments (org_id, code, name, active)
SELECT o.id, 'BREWING', 'Brewing', 1 FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO departments (org_id, code, name, active)
SELECT o.id, 'QC', 'Quality Control', 1 FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO resources (org_id, department_id, code, name, active)
SELECT o.id, d.id, 'BREW-STATION-01', 'Brewing Station 1', 1
FROM orgs o JOIN departments d ON d.org_id=o.id WHERE o.code='TEACL' AND d.code='BREWING';

INSERT IGNORE INTO resources (org_id, department_id, code, name, active)
SELECT o.id, d.id, 'BREW-STATION-02', 'Brewing Station 2', 1
FROM orgs o JOIN departments d ON d.org_id=o.id WHERE o.code='TEACL' AND d.code='BREWING';

INSERT IGNORE INTO inventory_locations (org_id, code, name)
SELECT o.id, 'FG-TEA-01', 'Finished Tea Storage' FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO serial_registers (org_id, register_code, prefix, pad_length, start_seq, end_seq, current_seq)
SELECT o.id, 'DEF', 'DEF', 5, 1, 99999, 0 FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO wo_sequence (org_id, next_seq)
SELECT o.id, 1 FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO parts (org_id, part_number, part_revision, description, uom_id, serial_controlled, make_or_buy)
SELECT o.id, 'TEA-BLEND-001', 'A', 'Premium Assam Tea Blend - 500g', u.id, 0, 'MAKE'
FROM orgs o, uom u WHERE o.code='TEACL' AND u.code='EA';

INSERT IGNORE INTO parts (org_id, part_number, part_revision, description, uom_id, serial_controlled, make_or_buy)
SELECT o.id, 'COFFEE-BLEND-001', 'A', 'Arabica Coffee Blend - 250g', u.id, 0, 'MAKE'
FROM orgs o, uom u WHERE o.code='TEACL' AND u.code='EA';

INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'TE-TEA-001', 'TE', 'Digital Thermometer', DATE_ADD(CURDATE(), INTERVAL 12 MONTH)
FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'T-TEA-001', 'T', 'Calibrated Silver Spoon 5ml', NULL
FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO calibration_tools (org_id, asset_number, asset_type, description, calibration_due)
SELECT o.id, 'T-TEA-002', 'T', 'Digital Kitchen Scale', DATE_ADD(CURDATE(), INTERVAL 6 MONTH)
FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'TEA-BREW1', 'Tea Brewing Level 1', 'Basic tea brewing - Assam and standard blends'
FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'TEA-TEMP', 'Temperature Measurement', 'Qualified to use calibrated thermometer'
FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'TEA-INSPECT', 'Beverage Inspection', 'Authorised for final quality check'
FROM orgs o WHERE o.code='TEACL';

INSERT IGNORE INTO skills (org_id, code, name, description)
SELECT o.id, 'COFFEE-BREW1', 'Coffee Brewing Level 1', 'Basic coffee brewing - Arabica standard method'
FROM orgs o WHERE o.code='TEACL';

-- ---------------------------------------------------------------------------
-- SEED DATA - Test users (all orgs)
-- ---------------------------------------------------------------------------
-- Passwords set by install.php using bcrypt. Listed here as placeholders.
-- In TEST_MODE username = password for all is_test_acct=1 users.

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'SUPERVISOR1', 'PLACEHOLDER', 'Supervisor', 'One', 'Supervisor',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o WHERE p.code='SUPERVISOR' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'OPERATOR1', 'PLACEHOLDER', 'Operator', 'One', 'Op1',
       p.id, o.id, 1, 1, 1
FROM personas p, orgs o WHERE p.code='OPERATOR' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'TESTER1', 'PLACEHOLDER', 'Tester', 'One', 'Tester1',
       p.id, o.id, 1, 1, 1
FROM personas p, orgs o WHERE p.code='TESTER' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'INSPECTOR1', 'PLACEHOLDER', 'Inspector', 'One', 'Inspector1',
       p.id, o.id, 1, 1, 1
FROM personas p, orgs o WHERE p.code='INSPECTOR' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'FINALTESTER1', 'PLACEHOLDER', 'Final', 'Tester', 'FinalTest1',
       p.id, o.id, 1, 1, 1
FROM personas p, orgs o WHERE p.code='FINAL_TESTER' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'MFGENG1', 'PLACEHOLDER', 'MFG', 'Engineer', 'MfgEng1',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o WHERE p.code='MFG_ENGINEER' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'ENGINEER1', 'PLACEHOLDER', 'Engineer', 'One', 'Eng1',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o WHERE p.code='ENGINEER' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'QUALITYENG1', 'PLACEHOLDER', 'Quality', 'Engineer', 'QualEng1',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o WHERE p.code='QUALITY_ENGINEER' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'TRAINMGR1', 'PLACEHOLDER', 'Training', 'Manager', 'TrainMgr1',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o WHERE p.code='QUALITY_TRAINING_MANAGER' AND o.code='BIKE';

INSERT IGNORE INTO users (username, password_hash, firstname, surname, known_as, persona_id, org_id, active, is_direct, is_test_acct)
SELECT 'TRAINMGR2', 'PLACEHOLDER', 'Training', 'Manager2', 'TrainMgr2',
       p.id, o.id, 1, 0, 1
FROM personas p, orgs o WHERE p.code='QUALITY_TRAINING_MANAGER' AND o.code='TEACL';

-- ---------------------------------------------------------------------------
-- SEED DATA - Schema version
-- ---------------------------------------------------------------------------
INSERT INTO schema_version (version, patch_file, notes)
VALUES ('10.9.0', 'bootstrap.sql', 'Initial installation via install.php');

SET FOREIGN_KEY_CHECKS = 1;

-- ===========================================================================
-- END OF BOOTSTRAP
-- ===========================================================================
