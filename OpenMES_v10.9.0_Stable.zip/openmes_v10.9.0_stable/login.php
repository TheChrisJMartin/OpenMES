<?php
/**
 * login.php — ChrisMES Login
 * Version: 1.0.0
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

// Already logged in → go to dashboard
if (isLoggedIn()) {
    header('Location: ' . SITE_URL . '/dashboard.php');
    exit;
}

$error    = '';
$redirect = $_GET['redirect'] ?? '/dashboard.php';

// Validate redirect stays on our domain (prevent open redirect)
if (!str_starts_with($redirect, '/')) {
    $redirect = '/dashboard.php';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $ip       = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        // CD005: Rate limit check
        $rateCheck = checkLoginRateLimit($username, $ip);
        if (!$rateCheck['allowed']) {
            $error = 'Account temporarily locked — too many failed attempts. Please wait 15 minutes.';
            writeSecurityLog('LOGIN_LOCKED', 'HIGH', null, $username,
                "Login locked for '{$username}' from {$ip}");
        } else {
            if ($rateCheck['wait'] > 0) sleep((int)$rateCheck['wait']);
            $user = attemptLogin($username, $password);
            if ($user) {
                recordLoginAttempt($username, $ip, true);
                writeSecurityLog('LOGIN_OK', 'LOW', (int)$user['id'], $username,
                    "Successful login for '{$username}'");
                createSession($user);
                header('Location: ' . SITE_URL . $redirect);
                exit;
            } else {
                recordLoginAttempt($username, $ip, false);
                writeSecurityLog('LOGIN_FAIL', 'MEDIUM', null, $username,
                    "Failed login for '{$username}' from {$ip}");
                writeAuditLog('LOGIN_FAILED', 'user', null, null, null, $username, null, null, null, 'Failed login attempt');
                $error = 'Invalid username or password.';
            }
        }
    }
}

$theme = DEFAULT_THEME;
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= $theme ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — <?= htmlspecialchars(SITE_NAME) ?></title>
    <style>
        [data-theme="dark"] {
            --bg: #0d1117; --bg-card: #161b22; --border: #30363d;
            --text: #e6edf3; --text-muted: #8b949e; --text-dim: #6e7681;
            --accent-blue: #388bfd; --accent-danger: #f85149;
            --bg-input: #0d1117; --border-focus: #388bfd;
        }
        [data-theme="light"] {
            --bg: #f6f8fa; --bg-card: #ffffff; --border: #d0d7de;
            --text: #1f2328; --text-muted: #57606a; --text-dim: #8c959f;
            --accent-blue: #0969da; --accent-danger: #cf222e;
            --bg-input: #ffffff; --border-focus: #0969da;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background: var(--bg);
            color: var(--text);
            font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-wrap {
            width: 100%;
            max-width: 380px;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 28px;
        }
        .logo-mark {
            width: 48px; height: 48px;
            background: var(--accent-blue);
            border-radius: 10px;
            display: inline-flex;
            align-items: center; justify-content: center;
            font-weight: 800; font-size: 20px; color: #fff;
            letter-spacing: -.5px;
            margin-bottom: 12px;
        }
        .login-logo h1 { font-size: 22px; font-weight: 700; }
        .login-logo p  { color: var(--text-muted); font-size: 12px; margin-top: 3px; }

        .login-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 28px;
        }
        .form-group { margin-bottom: 16px; }
        label { display: block; font-size: 12px; font-weight: 600; color: var(--text-muted); margin-bottom: 5px; }
        input {
            width: 100%; padding: 9px 11px;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 6px;
            color: var(--text);
            font-size: 14px;
        }
        input:focus { outline: none; border-color: var(--border-focus); box-shadow: 0 0 0 3px rgba(56,139,253,.12); }

        .btn-login {
            width: 100%;
            padding: 9px;
            background: var(--accent-blue);
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 4px;
            transition: opacity .15s;
        }
        .btn-login:hover { opacity: .88; }

        .alert-danger {
            background: rgba(248,81,73,.12);
            border: 1px solid rgba(248,81,73,.35);
            color: var(--accent-danger);
            padding: 10px 13px;
            border-radius: 6px;
            font-size: 13px;
            margin-bottom: 16px;
        }

        .test-mode-notice {
            margin-top: 16px;
            text-align: center;
            font-size: 11px;
            color: var(--text-dim);
        }
        .test-badge {
            display: inline-block;
            background: rgba(210,153,34,.2);
            color: #e3b341;
            border: 1px solid rgba(210,153,34,.35);
            border-radius: 4px;
            padding: 1px 7px;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: .05em;
            margin-right: 5px;
        }

        .footer-note {
            text-align: center;
            margin-top: 22px;
            font-size: 11px;
            color: var(--text-dim);
        }
    </style>
</head>
<body>
<div class="login-wrap">

    <div class="login-logo">
        <div class="logo-mark">CM</div>
        <h1><?= htmlspecialchars(SITE_NAME) ?></h1>
        <p><?= htmlspecialchars(SITE_TAGLINE) ?></p>
    </div>

    <div class="login-card">

        <?php if ($error): ?>
        <div class="alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="<?= htmlspecialchars(SITE_URL) ?>/login.php?redirect=<?= urlencode($redirect) ?>">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username"
                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                       autocomplete="username" autofocus required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" autocomplete="current-password" required>
            </div>
            <button type="submit" class="btn-login">Sign In</button>
        </form>

        <?php if (TEST_MODE): ?>
        <div class="test-mode-notice">
            <span class="test-badge">TEST MODE</span>
            Test accounts: use your username as your password.
        </div>
        <?php endif; ?>

    </div>

    <div class="footer-note">
        <?= htmlspecialchars(SITE_NAME) ?> v<?= SITE_VERSION ?> &mdash; Manufacturing Execution System
    </div>

</div>
</body>
</html>
