# ChrisMES Release Notes v10.5.4

Date: 2026-05-19 | No DB changes required.

## Defects
D033: PDF panel now scrollable — canvas renders at fit-width inside overflow container (max-height 80vh). Fit/Zoom buttons added.
D034: "Full Hold" label corrected to "Hard Hold" throughout operator.php.

## ISA-95 Features Loaded (F036-F052)
All 20 ISA-95 gap findings accepted and loaded as features F036-F052. See releases.php for full list.

## Roadmap Renumbered (F053)
R11=ISA-95 Review, R12=ISO-9001 Review, R13=Advanced Features (was R11),
R22=Supervisor Planner (new), R23=Non-Productive Bookings (new). 23 planned sprints total.

## Files: config.php, workorders/operator.php, includes/layout.php, releases.php, roadmap.php
