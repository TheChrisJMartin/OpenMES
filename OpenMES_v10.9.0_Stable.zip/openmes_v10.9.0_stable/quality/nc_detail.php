<?php
/**
 * quality/nc_detail.php — NC Detail View
 * Version: 10.5.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();

$ncId  = (int)($_GET['id'] ?? 0);
$scope = orgScope('nc');

$nc = dbFetchOne(
    "SELECT nc.*,
            w.wo_number, w.status AS wo_status, w.hold_type AS wo_hold_type,
            o.code AS org_code,
            p.part_number, p.description AS part_desc,
            ru.known_as AS raiser_name,
            du.known_as AS disposition_name,
            ro.op_number, ro.op_name, ro.op_type
     FROM non_conformances nc
     JOIN work_orders w ON w.id=nc.wo_id
     JOIN orgs o        ON o.id=nc.org_id
     JOIN parts p       ON p.id=w.part_id
     LEFT JOIN users ru ON ru.id=nc.raised_by
     LEFT JOIN users du ON du.id=nc.disposition_by
     LEFT JOIN routing_operations ro ON ro.id=nc.op_id
     WHERE nc.id=? AND ({$scope['sql']})",
    array_merge([$ncId], $scope['params'])
);

if (!$nc) {
    renderPageStart('Not Found');
    echo '<div class="alert alert-danger">NC not found or access denied.</div>';
    echo '<a href="' . SITE_SUBPATH . '/quality/nc_list.php" class="btn btn-secondary">← NCs</a>';
    renderPageEnd(); exit;
}

$ncSerials = dbFetchAll(
    "SELECT ns.*, sn.serial_number, sn.status AS sn_status
     FROM nc_serials ns
     JOIN serial_numbers sn ON sn.id=ns.serial_id
     WHERE ns.nc_id=?
     ORDER BY ns.defect_num, sn.serial_number",
    [$ncId]
);

$auditLog = dbFetchAll(
    "SELECT a.*, u.known_as FROM audit_log a
     LEFT JOIN users u ON u.id=a.user_id
     WHERE a.entity_type='non_conformance' AND a.entity_id=?
     ORDER BY a.created_at DESC",
    [(string)$ncId]
);


renderPageStart('NC — ' . $nc['nc_number']);
?>

<div class="page-header page-header-row">
    <div>
        <a href="<?= SITE_SUBPATH ?>/quality/nc_list.php"
           style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Non-Conformances</a>
        <h1 style="margin-top:4px;font-family:monospace;"><?= htmlspecialchars($nc['nc_number']) ?></h1>
        <p><?= htmlspecialchars($nc['part_number']) ?> — <?= htmlspecialchars($nc['part_desc']) ?></p>
    </div>
    <div style="display:flex;gap:8px;align-items:flex-start;flex-wrap:wrap;">
        <?= ncStatusBadge($nc['status']) ?>
        <?php if (in_array($nc['status'],['OPEN','UNDER_REVIEW']) &&
                  hasPersona(['IT_ADMIN','ENGINEER','QUALITY_ENGINEER'])): ?>
        <a href="<?= SITE_SUBPATH ?>/quality/nc_disposition.php?id=<?= $ncId ?>"
           class="btn btn-primary">Disposition</a>
        <?php endif; ?>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">

<!-- Left -->
<div>
    <div class="card">
        <div class="card-title">NC Details</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
            <div><span class="text-dim">NC Number:</span> <code><?= htmlspecialchars($nc['nc_number']) ?></code></div>
            <div><span class="text-dim">Org:</span> <code><?= htmlspecialchars($nc['org_code']) ?></code></div>
            <div><span class="text-dim">Work Order:</span>
                <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $nc['wo_id'] ?>"
                   style="color:var(--accent-blue);">
                    <code><?= htmlspecialchars($nc['wo_number']) ?></code>
                </a>
            </div>
            <div><span class="text-dim">Part:</span> <?= htmlspecialchars($nc['part_number']) ?></div>
            <div><span class="text-dim">Operation:</span>
                <code><?= str_pad($nc['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                <?= htmlspecialchars($nc['op_name']) ?>
            </div>
            <div><span class="text-dim">Hold Type:</span>
                <?php if (in_array($nc['status'],['OPEN','UNDER_REVIEW'])): ?>
                <span class="badge <?= $nc['hold_type']==='HARD'?'badge-red':'badge-yellow' ?>">
                    <?= htmlspecialchars($nc['hold_type']) ?> HOLD
                </span>
                <?php else: ?><span class="text-dim">Released</span><?php endif; ?>
            </div>
            <div><span class="text-dim">Raised by:</span> <?= htmlspecialchars($nc['raiser_name']??'—') ?></div>
            <div><span class="text-dim">Raised at:</span> <?= displayDate($nc['raised_at']) ?></div>
        </div>

        <div style="margin-top:14px;padding:12px;background:var(--bg);border-radius:5px;border:1px solid var(--border);">
            <div class="text-dim" style="font-size:11px;margin-bottom:4px;">DEFECT DESCRIPTION</div>
            <div style="font-size:13px;"><?= nl2br(htmlspecialchars($nc['defect_desc'])) ?></div>
        </div>

        <?php if ($nc['disposition']): ?>
        <div style="margin-top:14px;padding:12px;background:rgba(35,134,54,.07);border:1px solid rgba(35,134,54,.2);border-radius:5px;">
            <div class="text-dim" style="font-size:11px;margin-bottom:6px;">DISPOSITION</div>
            <div style="font-size:13px;margin-bottom:6px;">
                <strong><?= htmlspecialchars(str_replace('_',' ',$nc['disposition'])) ?></strong>
                by <?= htmlspecialchars($nc['disposition_name']??'—') ?>
                at <?= displayDate($nc['disposition_at']) ?>
            </div>
            <?php if ($nc['disposition_note']): ?>
            <div style="font-size:12px;color:var(--text-muted);"><?= nl2br(htmlspecialchars($nc['disposition_note'])) ?></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Affected serials -->
    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
            Affected Serials <span class="text-dim" style="font-size:12px;">(<?= count($ncSerials) ?>)</span>
        </div>
        <div class="table-wrap">
            <table style="margin:0;">
                <thead><tr><th>Defect #</th><th>Serial Number</th><th>Current Status</th></tr></thead>
                <tbody>
                <?php foreach ($ncSerials as $ns): ?>
                <tr>
                    <td><code class="font-mono">/<?= $ns['defect_num'] ?></code></td>
                    <td><code style="font-size:12px;"><?= htmlspecialchars($ns['serial_number']) ?></code></td>
                    <td>
                        <?php $st = $ns['sn_status']; echo match($st) {
                            'ON_HOLD'     => '<span class="badge badge-yellow">On Hold</span>',
                            'COMPLETE'    => '<span class="badge badge-green">Complete</span>',
                            'SCRAPPED'    => '<span class="badge badge-red">Scrapped</span>',
                            'IN_PROGRESS' => '<span class="badge badge-blue">In Progress</span>',
                            default       => '<span class="badge badge-grey">'.htmlspecialchars($st).'</span>',
                        }; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Right: Audit trail -->
<div>
    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">Audit Trail</div>
        <div class="table-wrap">
            <table style="margin:0;">
                <thead><tr><th>Date/Time</th><th>Event</th><th>User</th><th>Detail</th></tr></thead>
                <tbody>
                <?php foreach ($auditLog as $a): ?>
                <tr>
                    <td style="font-size:11px;white-space:nowrap;font-family:monospace;"><?= displayDate($a['created_at'],'d M H:i') ?></td>
                    <td><span class="badge badge-grey" style="font-size:10px;"><?= htmlspecialchars($a['event_type']) ?></span></td>
                    <td style="font-size:12px;"><?= htmlspecialchars($a['known_as']??'—') ?></td>
                    <td style="font-size:12px;"><?= htmlspecialchars($a['note']??'') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (!$auditLog): ?>
                <tr><td colspan="4" style="text-align:center;color:var(--text-dim);padding:16px;">No audit entries.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>

<?php renderPageEnd(); ?>
