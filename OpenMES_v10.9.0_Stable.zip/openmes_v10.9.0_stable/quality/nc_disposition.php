<?php
/**
 * quality/nc_disposition.php — NC Disposition by Engineer
 * Version: 7.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','ENGINEER','QUALITY_ENGINEER']);

$ncId  = (int)($_GET['id'] ?? 0);
$scope = orgScope('nc');
$error = '';

$nc = dbFetchOne(
    "SELECT nc.*, w.wo_number, w.id AS wo_id, o.code AS org_code,
            p.part_number, ru.known_as AS raiser_name,
            ro.op_number, ro.op_name
     FROM non_conformances nc
     JOIN work_orders w ON w.id=nc.wo_id
     JOIN orgs o        ON o.id=nc.org_id
     JOIN parts p       ON p.id=w.part_id
     LEFT JOIN users ru ON ru.id=nc.raised_by
     LEFT JOIN routing_operations ro ON ro.id=nc.op_id
     WHERE nc.id=? AND nc.status IN ('OPEN','UNDER_REVIEW') AND ({$scope['sql']})",
    array_merge([$ncId], $scope['params'])
);

if (!$nc) {
    renderPageStart('NC Not Found');
    echo '<div class="alert alert-danger">NC not found, already dispositioned, or access denied.</div>';
    echo '<a href="' . SITE_SUBPATH . '/quality/nc_list.php" class="btn btn-secondary">← NCs</a>';
    renderPageEnd(); exit;
}

$ncSerials = dbFetchAll(
    "SELECT ns.*, sn.serial_number FROM nc_serials ns
     JOIN serial_numbers sn ON sn.id=ns.serial_id WHERE ns.nc_id=?",
    [$ncId]
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $disposition = $_POST['disposition'] ?? '';
    $holdAction  = $_POST['hold_action'] ?? 'maintain';
    $note          = trim($_POST['disposition_note'] ?? '');
    $caAction      = trim($_POST['ca_action']      ?? ''); // F072 corrective action
    $caOwner       = trim($_POST['ca_owner']        ?? '');
    $caDueDate     = trim($_POST['ca_due_date']     ?? '') ?: null;
    $caEffReview   = trim($_POST['ca_eff_review']   ?? '') ?: null;
    $causeCat      = $_POST['cause_category'] ?? '';
    $causeValid    = ['MAN','MACHINE','METHOD','MATERIAL','MEASUREMENT','ENVIRONMENT',''];
    if (!in_array($causeCat, $causeValid)) $causeCat = '';

    if (!in_array($disposition, ['CONTINUE','SCRAP','REWORK']))
        $error = 'Please select a valid disposition.';

    if (!$error) {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            // Update NC
            $newStatus = ($disposition === 'SCRAP') ? 'SCRAPPED' : 'CLOSED';
            dbExecute(
                "UPDATE non_conformances SET
                    status=?, disposition=?, disposition_by=?, disposition_at=NOW(),
                    disposition_note=?, hold_type=?, updated_at=NOW()
                 WHERE id=?",
                [$newStatus, $disposition, $_SESSION['user_id'], $note,
                 $holdAction === 'soft' ? 'SOFT' : $nc['hold_type'], $ncId]
            );

            // Update serials based on disposition
            foreach ($ncSerials as $ns) {
                $newSnStatus = match($disposition) {
                    'SCRAP'    => 'SCRAPPED',
                    'CONTINUE' => 'NOT_STARTED',  // release back to work
                    'REWORK'   => 'NOT_STARTED',
                    default    => 'ON_HOLD',
                };
                dbExecute(
                    "UPDATE serial_numbers SET status=?, updated_at=NOW() WHERE id=?",
                    [$newSnStatus, $ns['serial_id']]
                );
            }

            // Update WO hold based on hold_action
            if ($holdAction === 'release') {
                // Check any other open NCs on this WO
                $otherOpenNCs = dbFetchOne(
                    "SELECT COUNT(*) AS n FROM non_conformances
                     WHERE wo_id=? AND status IN ('OPEN','UNDER_REVIEW') AND id!=?",
                    [$nc['wo_id'], $ncId]
                )['n'] ?? 0;

                if ((int)$otherOpenNCs === 0) {
                    $woNewStatus = ($disposition === 'SCRAP') ? 'IN_PROGRESS' : 'IN_PROGRESS';
                    dbExecute(
                        "UPDATE work_orders SET status=?, hold_type=NULL, updated_at=NOW() WHERE id=?",
                        [$woNewStatus, $nc['wo_id']]
                    );
                    dbInsert(
                        "INSERT INTO wo_change_log (wo_id,user_id,change_type,note) VALUES (?,?,?,?)",
                        [$nc['wo_id'],$_SESSION['user_id'],'HOLD_RELEASED',
                         "Hold released after NC {$nc['nc_number']} disposition: {$disposition}"]
                    );
                }
            } elseif ($holdAction === 'soft') {
                dbExecute(
                    "UPDATE work_orders SET hold_type='SOFT', updated_at=NOW() WHERE id=?",
                    [$nc['wo_id']]
                );
                dbInsert(
                    "INSERT INTO wo_change_log (wo_id,user_id,change_type,note) VALUES (?,?,?,?)",
                    [$nc['wo_id'],$_SESSION['user_id'],'HOLD_CHANGED_SOFT',
                     "Hold changed to SOFT after NC {$nc['nc_number']} disposition"]
                );
            }

            writeAuditLog('NC_DISPOSITIONED','non_conformance',(string)$ncId,$nc['org_id'],
                null,null,'disposition',null,$disposition,
                "NC {$nc['nc_number']} dispositioned: {$disposition}. Hold: {$holdAction}. {$note}");

            // D005: Fire WORKORDEROUT after scrap so ERP sees updated serial statuses
            if ($disposition === 'SCRAP') {
                $wo = dbFetchOne("SELECT * FROM work_orders WHERE id=?", [$nc['wo_id']]);
                if ($wo) {
                    // Check if ALL non-cancelled serials are now scrapped
                    $remaining = dbFetchOne(
                        "SELECT COUNT(*) AS n FROM serial_numbers
                          WHERE wo_id=? AND status NOT IN ('SCRAPPED','COMPLETE')",
                        [$nc['wo_id']]
                    );
                    // If nothing left to work, close the WO automatically
                    if ((int)($remaining['n'] ?? 0) === 0) {
                        dbExecute(
                            "UPDATE work_orders SET status='COMPLETE', hold_type=NULL, updated_at=NOW() WHERE id=?",
                            [$nc['wo_id']]
                        );
                        dbInsert(
                            "INSERT INTO wo_change_log (wo_id,user_id,change_type,note) VALUES (?,?,?,?)",
                            [$nc['wo_id'],$_SESSION['user_id'],'STATUS_CHANGE',
                             'WO auto-completed — all serials scrapped or complete']
                        );
                    }
                    // Fire WORKORDEROUT so ERP receives scrap status
                    $opCounts = dbFetchAll(
                        "SELECT ro.op_number, ro.op_name,
                                COUNT(sn.id) AS total,
                                SUM(sn.status='NOT_STARTED') AS not_started,
                                SUM(sn.status='IN_PROGRESS') AS in_progress,
                                SUM(sn.status='COMPLETE') AS complete,
                                SUM(sn.status='ON_HOLD') AS on_hold,
                                SUM(sn.status='SCRAPPED') AS scrapped
                           FROM serial_numbers sn
                           JOIN routing_operations ro ON ro.id = sn.current_op_id
                          WHERE sn.wo_id=?
                          GROUP BY ro.id, ro.op_number, ro.op_name
                          ORDER BY ro.sort_order, ro.op_number",
                        [$nc['wo_id']]
                    );
                    try {
                        dbInsert(
                            "INSERT INTO integration_outbound
                                (transaction_ref,org_id,message_type,payload,placed_at)
                             VALUES (?,?,'WORKORDEROUT',?,NOW())",
                            ['WOO-SCRAP-'.$wo['wo_number'].'-'.time(), $wo['org_id'],
                             json_encode([
                                 'messageType'     => 'WORKORDEROUT',
                                 'workOrder'       => $wo['wo_number'],
                                 'org'             => $wo['org_id'],
                                 'woStatus'        => $wo['status'],
                                 'eventType'       => 'SCRAP',
                                 'ncNumber'        => $nc['nc_number'],
                                 'eventTime'       => date('Y-m-d H:i:s'),
                                 'operationStatus' => $opCounts,
                             ])]
                        );
                    } catch (Throwable $intEx) {
                        error_log('[ChrisMES] WORKORDEROUT (scrap) failed: ' . $intEx->getMessage());
                    }
                }
            }

            // F072: Save corrective action record if provided
            if ($caAction !== '') {
                dbInsert(
                    "INSERT INTO nc_corrective_actions
                        (nc_id,ca_description,ca_owner,ca_due_date,effectiveness_review_date,created_by,created_at)
                      VALUES (?,?,?,?,?,?,NOW())",
                    [$ncId,$caAction,$caOwner ?: null,$caDueDate,$caEffReview,$_SESSION['user_id']]
                );
            }
            $pdo->commit();
            header('Location: '.SITE_URL.'/quality/nc_detail.php?id='.$ncId.'&dispositioned=1');
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

renderPageStart('Disposition — ' . $nc['nc_number']);
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/quality/nc_detail.php?id=<?= $ncId ?>"
       style="font-size:12px;color:var(--text-muted);text-decoration:none;">← NC Detail</a>
    <h1 style="margin-top:6px;">Disposition — <?= htmlspecialchars($nc['nc_number']) ?></h1>
    <p>WO <?= htmlspecialchars($nc['wo_number']) ?> — Op <?= str_pad($nc['op_number'],3,'0',STR_PAD_LEFT) ?> <?= htmlspecialchars($nc['op_name']) ?></p>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:920px;">

    <!-- NC summary -->
    <div class="card">
        <div class="card-title">NC Summary</div>
        <div style="font-size:13px;display:flex;flex-direction:column;gap:8px;">
            <div><span class="text-dim">NC:</span> <code><?= htmlspecialchars($nc['nc_number']) ?></code></div>
            <div><span class="text-dim">Part:</span> <?= htmlspecialchars($nc['part_number']) ?></div>
            <div><span class="text-dim">Raised by:</span> <?= htmlspecialchars($nc['raiser_name']??'—') ?></div>
            <div><span class="text-dim">Raised at:</span> <?= displayDate($nc['raised_at']) ?></div>
            <div><span class="text-dim">Current hold:</span>
                <span class="badge <?= $nc['hold_type']==='FULL'?'badge-red':'badge-yellow' ?>">
                    <?= htmlspecialchars($nc['hold_type']) ?> HOLD
                </span>
            </div>
        </div>
        <div style="margin-top:12px;padding:10px;background:var(--bg);border-radius:5px;border:1px solid var(--border);">
            <div class="text-dim" style="font-size:11px;margin-bottom:4px;">DEFECT</div>
            <div style="font-size:13px;"><?= nl2br(htmlspecialchars($nc['defect_desc'])) ?></div>
        </div>
        <div style="margin-top:12px;">
            <div class="text-dim" style="font-size:11px;margin-bottom:6px;">AFFECTED SERIALS</div>
            <?php foreach ($ncSerials as $ns): ?>
            <div style="font-family:monospace;font-size:12px;margin-bottom:3px;">
                /<?= $ns['defect_num'] ?> — <?= htmlspecialchars($ns['serial_number']) ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Disposition form -->
    <div class="card">
        <div class="card-title">Engineer Disposition</div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">


            <div class="form-group">
                <label>Disposition Decision <span style="color:var(--accent-danger)">*</span></label>
                <div style="display:flex;flex-direction:column;gap:8px;margin-top:4px;">
                    <label style="display:flex;align-items:flex-start;gap:10px;padding:10px;background:var(--bg);border:1px solid var(--border);border-radius:5px;cursor:pointer;">
                        <input type="radio" name="disposition" value="CONTINUE" required style="margin-top:2px;">
                        <div>
                            <strong style="font-size:13px;">Continue Processing</strong>
                            <div class="text-dim" style="font-size:11px;">Item meets requirements to continue — no rework needed.</div>
                        </div>
                    </label>
                    <label style="display:flex;align-items:flex-start;gap:10px;padding:10px;background:var(--bg);border:1px solid var(--border);border-radius:5px;cursor:pointer;">
                        <input type="radio" name="disposition" value="REWORK" style="margin-top:2px;">
                        <div>
                            <strong style="font-size:13px;">Rework</strong>
                            <div class="text-dim" style="font-size:11px;">Item requires rework — will be returned to the appropriate operation.</div>
                        </div>
                    </label>
                    <label style="display:flex;align-items:flex-start;gap:10px;padding:10px;background:rgba(248,81,73,.06);border:1px solid rgba(248,81,73,.25);border-radius:5px;cursor:pointer;">
                        <input type="radio" name="disposition" value="SCRAP" style="margin-top:2px;">
                        <div>
                            <strong style="font-size:13px;color:var(--accent-danger);">Scrap</strong>
                            <div class="text-dim" style="font-size:11px;">Item cannot be recovered — serial(s) will be marked as scrapped.</div>
                        </div>
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label>Work Order Hold Action</label>
                <select name="hold_action">
                    <option value="release">Release Hold — resume normal work</option>
                    <option value="soft">Change to Soft Hold — allow work to next Inspection op</option>
                    <option value="maintain">Maintain Full Hold</option>
                </select>
            </div>

            <div class="form-group">
                <label>Root Cause Category (6M)</label>
                <select name="cause_category" class="form-control" style="margin-bottom:4px;">
                    <option value="">— Select cause category —</option>
                    <?php
                    $cats = [
                        'MAN'         => 'Man — Human error, training, fatigue',
                        'MACHINE'     => 'Machine — Equipment, tooling, calibration',
                        'METHOD'      => 'Method — Process, procedure, design',
                        'MATERIAL'    => 'Material — Raw material, component, supplier',
                        'MEASUREMENT' => 'Measurement — Gauge, instrument, test method',
                        'ENVIRONMENT' => 'Environment — Temperature, humidity, cleanliness',
                    ];
                    foreach ($cats as $val => $label):
                        $sel = ($nc['cause_category'] ?? '') === $val ? 'selected' : '';
                    ?>
                    <option value="<?= htmlspecialchars($val) ?>" <?= $sel ?>><?= htmlspecialchars($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Disposition Notes</label>
                <textarea name="disposition_note" rows="3"
                          placeholder="Reason for disposition decision, any corrective actions…"
                          style="resize:vertical;"></textarea>
            </div>

            <div style="display:flex;gap:8px;">
                <button type="submit" class="btn btn-primary">Submit Disposition</button>
                <a href="<?= SITE_SUBPATH ?>/quality/nc_detail.php?id=<?= $ncId ?>"
                   class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php renderPageEnd(); ?>
