<?php
/**
 * quality/skills.php — Skills Library
 * Version: 9.0.0
 * Description: Create and manage the skills library.
 *              Maintained by QUALITY_TRAINING_MANAGER and IT_ADMIN.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN', 'QUALITY_TRAINING_MANAGER']);

$scope   = orgScope('s');
$message = '';
$error   = '';

// ── POST ──────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id     = (int)($_POST['id'] ?? 0);
    $code   = strtoupper(trim($_POST['code'] ?? ''));
    $name   = trim($_POST['name'] ?? '');
    $desc   = trim($_POST['description'] ?? '');
    $active = isset($_POST['active']) ? 1 : 0;
    $orgId  = hasPersona('IT_ADMIN')
              ? (int)($_POST['org_id'] ?? currentOrgId())
              : currentOrgId();

    if ($action === 'delete' && $id) {
        dbExecute("UPDATE skills SET active=0, updated_at=NOW() WHERE id=?", [$id]);
        writeAuditLog('SKILL_DEACTIVATE','skills',(string)$id,$orgId,null,null,null,null,null,"Deactivated skill ID {$id}");
        $message = 'Skill deactivated.';
    } elseif ($code === '') {
        $error = 'Skill code is required.';
    } elseif ($name === '') {
        $error = 'Skill name is required.';
    } else {
        try {
            if ($id === 0) {
                $newId = dbInsert(
                    "INSERT INTO skills (org_id,code,name,description,active,created_by)
                     VALUES (?,?,?,?,?,?)",
                    [$orgId,$code,$name,$desc,$active,$_SESSION['user_id']]
                );
                writeAuditLog('SKILL_CREATE','skills',(string)$newId,$orgId,null,null,
                    null,null,$code,"Created skill: {$code} — {$name}");
                $message = "Skill '{$code}' created.";
            } else {
                dbExecute(
                    "UPDATE skills SET code=?,name=?,description=?,active=?,updated_at=NOW() WHERE id=?",
                    [$code,$name,$desc,$active,$id]
                );
                writeAuditLog('SKILL_EDIT','skills',(string)$id,$orgId,null,null,
                    null,null,null,"Updated skill: {$code}");
                $message = "Skill '{$code}' updated.";
            }
        } catch (PDOException $e) {
            $error = str_contains($e->getMessage(),'Duplicate')
                ? "Skill code '{$code}' already exists in this organisation."
                : 'Database error: ' . $e->getMessage();
        }
    }
}

// ── Fetch ─────────────────────────────────────────────────────────────────────
$skills = dbFetchAll(
    "SELECT s.*, o.code AS org_code,
            (SELECT COUNT(*) FROM user_skills us WHERE us.skill_id = s.id AND us.status='APPROVED') AS holder_count
       FROM skills s
       JOIN orgs o ON o.id = s.org_id
      WHERE ({$scope['sql']})
      ORDER BY s.org_id, s.code",
    $scope['params']
);

$orgs = hasPersona('IT_ADMIN')
    ? dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code")
    : [];

$editSkill = null;
if (isset($_GET['edit'])) {
    $editSkill = dbFetchOne("SELECT * FROM skills WHERE id=?", [(int)$_GET['edit']]);
}

renderPageStart('Skills Library');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Skills Library</h1>
        <p>Define skills required for routing operations and assigned to operators.</p>
    </div>
    <button onclick="openModal()" class="btn btn-primary">+ Add Skill</button>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card" style="padding:0;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Name</th>
                    <th>Description</th>
                    <?php if (hasPersona('IT_ADMIN')): ?><th>Org</th><?php endif; ?>
                    <th>Approved Holders</th>
                    <th>Active</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($skills)): ?>
                <tr><td colspan="7" class="text-muted" style="text-align:center;padding:20px;">No skills defined yet.</td></tr>
            <?php else: ?>
            <?php foreach ($skills as $s): ?>
            <tr style="<?= !$s['active'] ? 'opacity:.5;' : '' ?>">
                <td><code style="font-weight:700;color:var(--accent-blue);"><?= htmlspecialchars($s['code']) ?></code></td>
                <td style="font-weight:500;"><?= htmlspecialchars($s['name']) ?></td>
                <td class="text-muted" style="font-size:12px;"><?= htmlspecialchars($s['description'] ?? '—') ?></td>
                <?php if (hasPersona('IT_ADMIN')): ?>
                <td><code style="font-size:11px;"><?= htmlspecialchars($s['org_code']) ?></code></td>
                <?php endif; ?>
                <td style="text-align:center;">
                    <a href="training.php?skill_id=<?= $s['id'] ?>" style="color:var(--accent-blue);font-weight:600;">
                        <?= (int)$s['holder_count'] ?>
                    </a>
                </td>
                <td><?= $s['active'] ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-grey">No</span>' ?></td>
                <td style="display:flex;gap:6px;">
                    <a href="?edit=<?= $s['id'] ?>" class="btn btn-secondary" style="padding:3px 10px;font-size:11px;">Edit</a>
                    <a href="training.php?skill_id=<?= $s['id'] ?>" class="btn btn-secondary" style="padding:3px 10px;font-size:11px;">Holders</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div id="skill-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);
     z-index:300;align-items:center;justify-content:center;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:8px;
                padding:24px;max-width:480px;width:94%;">
        <h2 style="font-size:16px;margin-bottom:16px;" id="modal-title">Add Skill</h2>
        <form method="POST">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f-id" value="0">

            <?php if (hasPersona('IT_ADMIN') && $orgs): ?>
            <div class="form-group">
                <label>Organisation</label>
                <select name="org_id" id="f-org">
                    <?php foreach ($orgs as $o): ?>
                    <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['code'].' — '.$o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <label>Skill Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="code" id="f-code" maxlength="30"
                       placeholder="e.g. BIKE-TORQUE"
                       style="text-transform:uppercase;" oninput="this.value=this.value.toUpperCase()" required>
            </div>
            <div class="form-group">
                <label>Skill Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="name" id="f-name" maxlength="120" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" id="f-desc" rows="3" style="resize:vertical;"></textarea>
            </div>
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;font-weight:400;cursor:pointer;">
                    <input type="checkbox" name="active" value="1" id="f-active" checked> Active
                </label>
            </div>
            <div style="display:flex;gap:8px;">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
const EDIT = <?= $editSkill ? json_encode($editSkill) : 'null' ?>;
function openModal(d) {
    d = d || null;
    document.getElementById('modal-title').textContent = d ? 'Edit Skill' : 'Add Skill';
    document.getElementById('f-id').value   = d ? d.id   : 0;
    document.getElementById('f-code').value = d ? d.code : '';
    document.getElementById('f-name').value = d ? d.name : '';
    document.getElementById('f-desc').value = d ? (d.description||'') : '';
    document.getElementById('f-active').checked = d ? (d.active==1) : true;
    if (document.getElementById('f-org') && d) document.getElementById('f-org').value = d.org_id;
    document.getElementById('skill-modal').style.display = 'flex';
}
function closeModal() { document.getElementById('skill-modal').style.display = 'none'; }
if (EDIT) openModal(EDIT);
</script>

<?php renderPageEnd(); ?>
