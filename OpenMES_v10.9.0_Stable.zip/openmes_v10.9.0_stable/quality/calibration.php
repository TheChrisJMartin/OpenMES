<?php
/**
 * quality/calibration.php — Calibration Database
 * Version: 9.0.0
 * Description: View and manage calibration tools and test equipment.
 *              Viewable by all users (org high-walled).
 *              Create/edit restricted to QUALITY_ENGINEER and IT_ADMIN.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();

$canEdit = hasPersona(['IT_ADMIN', 'QUALITY_ENGINEER']);
$scope   = orgScope('ct');
$message = '';
$error   = '';

// ── POST: save tool ───────────────────────────────────────────────────────────
if ($canEdit && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action      = $_POST['action'] ?? '';
    $id          = (int)($_POST['id'] ?? 0);
    $assetNum    = strtoupper(trim($_POST['asset_number'] ?? ''));
    $assetType   = in_array($_POST['asset_type'] ?? '', ['TOOL','TEST_EQUIPMENT'])
                   ? $_POST['asset_type'] : 'TOOL';
    $desc        = trim($_POST['description'] ?? '');
    $calDue      = trim($_POST['calibration_due'] ?? '') ?: null;
    $active      = isset($_POST['active']) ? 1 : 0;
    $orgId       = hasPersona('IT_ADMIN')
                   ? (int)($_POST['org_id'] ?? currentOrgId())
                   : currentOrgId();

    // Validate asset number prefix
    $validPrefix = ($assetType === 'TEST_EQUIPMENT')
                   ? str_starts_with($assetNum, 'TE-')
                   : str_starts_with($assetNum, 'T-');

    if ($action === 'delete' && $id && $canEdit) {
        dbExecute("UPDATE calibration_tools SET active=0, updated_by=?, updated_at=NOW() WHERE id=?",
            [$_SESSION['user_id'], $id]);
        writeAuditLog('TOOL_DEACTIVATE','calibration_tools',(string)$id,null,null,null,null,null,null,"Deactivated tool ID {$id}");
        $message = 'Tool deactivated.';
    } elseif ($assetNum === '') {
        $error = 'Asset number is required.';
    } elseif (!$validPrefix) {
        $error = $assetType === 'TEST_EQUIPMENT'
            ? 'Test equipment asset numbers must start with TE-'
            : 'Tool asset numbers must start with T-';
    } elseif ($desc === '') {
        $error = 'Description is required.';
    } else {
        try {
            if ($id === 0) {
                $newId = dbInsert(
                    "INSERT INTO calibration_tools
                        (org_id,asset_number,asset_type,description,calibration_due,active,created_by)
                     VALUES (?,?,?,?,?,?,?)",
                    [$orgId,$assetNum,$assetType,$desc,$calDue,$active,$_SESSION['user_id']]
                );
                writeAuditLog('TOOL_CREATE','calibration_tools',(string)$newId,$orgId,null,null,
                    null,null,$assetNum,"Created: {$assetNum} — {$desc}");
                $message = "Tool '{$assetNum}' created.";
            } else {
                $old = dbFetchOne("SELECT * FROM calibration_tools WHERE id=?", [$id]);
                dbExecute(
                    "UPDATE calibration_tools
                     SET asset_number=?,asset_type=?,description=?,calibration_due=?,active=?,
                         updated_by=?,updated_at=NOW()
                     WHERE id=?",
                    [$assetNum,$assetType,$desc,$calDue,$active,$_SESSION['user_id'],$id]
                );
                writeAuditLog('TOOL_EDIT','calibration_tools',(string)$id,$orgId,null,null,
                    null,null,null,"Updated: {$assetNum}");
                $message = "Tool '{$assetNum}' updated.";
            }
        } catch (PDOException $e) {
            $error = str_contains($e->getMessage(),'Duplicate')
                ? "Asset number '{$assetNum}' already exists in this organisation."
                : 'Database error: ' . $e->getMessage();
        }
    }
}

// ── Fetch tools ───────────────────────────────────────────────────────────────
$filterActive = ($_GET['show'] ?? 'active') !== 'all';
$activeWhere  = $filterActive ? 'AND ct.active = 1' : '';

$tools = dbFetchAll(
    "SELECT ct.*, o.code AS org_code, u.known_as AS creator_name
       FROM calibration_tools ct
       JOIN orgs o  ON o.id  = ct.org_id
       LEFT JOIN users u ON u.id = ct.created_by
      WHERE ({$scope['sql']}) {$activeWhere}
      ORDER BY ct.org_id, ct.asset_type, ct.asset_number",
    $scope['params']
);

$today = new DateTimeImmutable('today', new DateTimeZone(SITE_TIMEZONE));

function calStatus(DateTimeImmutable $today, ?string $dueDateStr): array {
    if (!$dueDateStr) return ['label' => 'No Cal Required', 'class' => 'badge-grey', 'expired' => false];
    $due  = new DateTimeImmutable($dueDateStr);
    $diff = (int)$today->diff($due)->days * ($due >= $today ? 1 : -1);
    if ($diff < 0)  return ['label' => 'EXPIRED',              'class' => 'badge-red',    'expired' => true];
    if ($diff <= 30) return ['label' => "Due in {$diff}d",     'class' => 'badge-yellow', 'expired' => false];
    return              ['label' => 'In Date',                 'class' => 'badge-green',  'expired' => false];
}

// For edit modal — fetch orgs if IT Admin
$orgs = hasPersona('IT_ADMIN')
    ? dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code")
    : [];

$editTool = null;
if (isset($_GET['edit']) && $canEdit) {
    $editTool = dbFetchOne("SELECT * FROM calibration_tools WHERE id=?", [(int)$_GET['edit']]);
}

renderPageStart('Calibration Database');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Calibration Database</h1>
        <p>Tools and test equipment — calibration status and records.</p>
    </div>
    <div style="display:flex;gap:8px;align-items:center;">
        <a href="?show=<?= $filterActive ? 'all' : 'active' ?>" class="btn btn-secondary">
            <?= $filterActive ? 'Show All' : 'Active Only' ?>
        </a>
        <?php if ($canEdit): ?>
        <button onclick="openModal()" class="btn btn-primary">+ Add Tool / TE</button>
        <?php endif; ?>
    </div>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Expired warning banner -->
<?php
$expired = array_filter($tools, fn($t) => calStatus($today, $t['calibration_due'])['expired']);
if ($expired):
?>
<div class="alert alert-danger">
    ⚠ <strong><?= count($expired) ?> item<?= count($expired) !== 1 ? 's' : '' ?> with expired calibration</strong>
    — these cannot be recorded against work order operations.
</div>
<?php endif; ?>

<div class="card" style="padding:0;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Asset No.</th>
                    <th>Type</th>
                    <th>Description</th>
                    <?php if (hasPersona('IT_ADMIN')): ?><th>Org</th><?php endif; ?>
                    <th>Cal Due</th>
                    <th>Status</th>
                    <th>Active</th>
                    <?php if ($canEdit): ?><th></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($tools)): ?>
                <tr><td colspan="8" class="text-muted" style="text-align:center;padding:20px;">No tools found.</td></tr>
            <?php else: ?>
            <?php foreach ($tools as $t):
                $cal = calStatus($today, $t['calibration_due']);
            ?>
            <tr style="<?= !$t['active'] ? 'opacity:.5;' : '' ?>">
                <td><code style="font-weight:700;color:var(--accent-blue);"><?= htmlspecialchars($t['asset_number']) ?></code></td>
                <td>
                    <?php if ($t['asset_type'] === 'TEST_EQUIPMENT'): ?>
                        <span class="badge badge-blue">Test Equipment</span>
                    <?php else: ?>
                        <span class="badge badge-grey">Tool</span>
                    <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($t['description']) ?></td>
                <?php if (hasPersona('IT_ADMIN')): ?>
                <td><code style="font-size:11px;"><?= htmlspecialchars($t['org_code']) ?></code></td>
                <?php endif; ?>
                <td class="font-mono" style="font-size:12px;">
                    <?= $t['calibration_due'] ? htmlspecialchars($t['calibration_due']) : '—' ?>
                </td>
                <td><span class="badge <?= $cal['class'] ?>"><?= $cal['label'] ?></span></td>
                <td><?= $t['active'] ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-grey">No</span>' ?></td>
                <?php if ($canEdit): ?>
                <td>
                    <a href="?edit=<?= $t['id'] ?>" class="btn btn-secondary" style="padding:3px 10px;font-size:11px;">Edit</a>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($canEdit): ?>
<!-- Add/Edit Modal -->
<div id="tool-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);
     z-index:300;align-items:center;justify-content:center;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:8px;
                padding:24px;max-width:520px;width:94%;max-height:90vh;overflow-y:auto;">
        <h2 style="font-size:16px;margin-bottom:16px;" id="modal-title">Add Tool / Test Equipment</h2>
        <form method="POST" id="tool-form">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f-id" value="0">

            <?php if (hasPersona('IT_ADMIN') && $orgs): ?>
            <div class="form-group">
                <label>Organisation</label>
                <select name="org_id" id="f-org">
                    <?php foreach ($orgs as $o): ?>
                    <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['code'] . ' — ' . $o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <label>Asset Type</label>
                <select name="asset_type" id="f-type" onchange="updatePrefix()">
                    <option value="TOOL">Tool (T- prefix)</option>
                    <option value="TEST_EQUIPMENT">Test Equipment (TE- prefix)</option>
                </select>
            </div>

            <div class="form-group">
                <label>Asset Number <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="asset_number" id="f-asset" placeholder="T-ORG-001"
                       style="text-transform:uppercase;" oninput="this.value=this.value.toUpperCase()" required>
                <div class="text-dim mt-1" id="prefix-hint">Must start with T-</div>
            </div>

            <div class="form-group">
                <label>Description <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="description" id="f-desc" required>
            </div>

            <div class="form-group">
                <label>Calibration Due Date <span class="text-dim">(leave blank if no calibration required)</span></label>
                <input type="date" name="calibration_due" id="f-caldue">
            </div>

            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;font-weight:400;cursor:pointer;">
                    <input type="checkbox" name="active" value="1" id="f-active" checked>
                    Active
                </label>
            </div>

            <div style="display:flex;gap:8px;margin-top:4px;">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
const EDIT_DATA = <?= $editTool ? json_encode($editTool) : 'null' ?>;

function openModal(data) {
    data = data || null;
    document.getElementById('modal-title').textContent = data ? 'Edit Tool / TE' : 'Add Tool / Test Equipment';
    document.getElementById('f-id').value      = data ? data.id : 0;
    document.getElementById('f-type').value    = data ? data.asset_type : 'TOOL';
    document.getElementById('f-asset').value   = data ? data.asset_number : '';
    document.getElementById('f-desc').value    = data ? data.description : '';
    document.getElementById('f-caldue').value  = data ? (data.calibration_due || '') : '';
    document.getElementById('f-active').checked= data ? (data.active == 1) : true;
    if (document.getElementById('f-org') && data) document.getElementById('f-org').value = data.org_id;
    updatePrefix();
    document.getElementById('tool-modal').style.display = 'flex';
}
function closeModal() { document.getElementById('tool-modal').style.display = 'none'; }
function updatePrefix() {
    const t = document.getElementById('f-type').value;
    document.getElementById('prefix-hint').textContent =
        t === 'TEST_EQUIPMENT' ? 'Must start with TE-' : 'Must start with T-';
}
// Auto-open if edit param set
if (EDIT_DATA) openModal(EDIT_DATA);
</script>
<?php endif; ?>

<?php renderPageEnd(); ?>
