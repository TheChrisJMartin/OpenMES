<?php
/**
 * quality/training.php — Training Matrix & Skill Assignments
 * Version: 9.0.0
 * Description: Assign skills to users, approve them, and manage expiry dates.
 *              Quality Training Manager maintains; IT Admin has full access.
 *              Shows 30-day expiry warnings on this screen.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN', 'QUALITY_TRAINING_MANAGER']);

$scope   = orgScope('us');  // scoped via user's org
$message = '';
$error   = '';
$today   = new DateTimeImmutable('today', new DateTimeZone(SITE_TIMEZONE));

// ── Expire lapsed skills (belt-and-braces alongside DB event) ─────────────────
dbExecute(
    "UPDATE user_skills SET status='EXPIRED'
      WHERE status='APPROVED'
        AND expiry_date IS NOT NULL
        AND expiry_date < CURDATE()"
);

// ── POST ──────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action'] ?? '';
    $usId    = (int)($_POST['us_id'] ?? 0);
    $userId  = (int)($_POST['user_id']  ?? 0);
    $skillId = (int)($_POST['skill_id'] ?? 0);
    $expiry  = trim($_POST['expiry_date'] ?? '') ?: null;
    $notes   = trim($_POST['notes'] ?? '');

    if ($action === 'assign' && $userId && $skillId) {
        // Check skill belongs to this user's org
        $skill = dbFetchOne("SELECT * FROM skills WHERE id=?", [$skillId]);
        $user  = dbFetchOne("SELECT * FROM users  WHERE id=?", [$userId]);
        if (!$skill || !$user) {
            $error = 'Invalid user or skill.';
        } else {
            try {
                dbInsert(
                    "INSERT INTO user_skills
                        (user_id,skill_id,assigned_by,assigned_at,expiry_date,status,notes)
                     VALUES (?,?,?,NOW(),?,'PENDING',?)
                     ON DUPLICATE KEY UPDATE
                        expiry_date=VALUES(expiry_date),
                        assigned_by=VALUES(assigned_by),
                        assigned_at=NOW(),
                        status=IF(status='REVOKED','PENDING',status),
                        notes=VALUES(notes)",
                    [$userId,$skillId,$_SESSION['user_id'],$expiry,$notes]
                );
                writeAuditLog('SKILL_ASSIGN','user_skills',null,$skill['org_id'],null,null,
                    null,null,null,"Assigned skill {$skill['code']} to user ID {$userId}");
                $message = 'Skill assigned — pending approval.';
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }

    } elseif ($action === 'approve' && $usId) {
        dbExecute(
            "UPDATE user_skills SET status='APPROVED', approved_by=?, approved_at=NOW() WHERE id=?",
            [$_SESSION['user_id'], $usId]
        );
        writeAuditLog('SKILL_APPROVE','user_skills',(string)$usId,null,null,null,
            'status','PENDING','APPROVED',"Approved skill assignment ID {$usId}");
        $message = 'Skill approved — operator can now use this skill at gated operations.';

    } elseif ($action === 'revoke' && $usId) {
        dbExecute(
            "UPDATE user_skills SET status='REVOKED', updated_at=NOW() WHERE id=?",
            [$usId]
        );
        writeAuditLog('SKILL_REVOKE','user_skills',(string)$usId,null,null,null,
            'status','APPROVED','REVOKED',"Revoked skill assignment ID {$usId}");
        $message = 'Skill revoked.';

    } elseif ($action === 'update_expiry' && $usId) {
        dbExecute(
            "UPDATE user_skills SET expiry_date=?, status=IF(status='EXPIRED','APPROVED',status) WHERE id=?",
            [$expiry, $usId]
        );
        writeAuditLog('SKILL_EXPIRY_UPDATE','user_skills',(string)$usId,null,null,null,
            'expiry_date',null,$expiry,"Updated expiry for skill assignment ID {$usId}");
        $message = 'Expiry date updated.';
    }
}

// ── Filters ───────────────────────────────────────────────────────────────────
$filterSkillId = (int)($_GET['skill_id'] ?? 0);
$filterUserId  = (int)($_GET['user_id']  ?? 0);
$filterStatus  = $_GET['status'] ?? '';

// ── Fetch user skill records ──────────────────────────────────────────────────
$orgScope = orgScope('sk');
$where    = '(' . $orgScope['sql'] . ')';
$params   = $orgScope['params'];

if ($filterSkillId) { $where .= ' AND us.skill_id=?'; $params[] = $filterSkillId; }
if ($filterUserId)  { $where .= ' AND us.user_id=?';  $params[] = $filterUserId;  }
if ($filterStatus)  { $where .= ' AND us.status=?';   $params[] = $filterStatus;  }

$records = dbFetchAll(
    "SELECT us.*,
            u.known_as, u.firstname, u.surname, u.username,
            sk.code AS skill_code, sk.name AS skill_name, sk.org_id,
            o.code AS org_code,
            assigner.known_as AS assigned_by_name,
            approver.known_as AS approved_by_name
       FROM user_skills us
       JOIN users  u       ON u.id  = us.user_id
       JOIN skills sk      ON sk.id = us.skill_id
       JOIN orgs   o       ON o.id  = sk.org_id
       LEFT JOIN users assigner ON assigner.id = us.assigned_by
       LEFT JOIN users approver ON approver.id = us.approved_by
      WHERE {$where}
      ORDER BY us.status='PENDING' DESC, sk.code, u.known_as",
    $params
);

// Expiry warning — approaching in 30 days
$expiringRecords = array_filter($records, function($r) use ($today) {
    if ($r['status'] !== 'APPROVED' || !$r['expiry_date']) return false;
    $due  = new DateTimeImmutable($r['expiry_date']);
    $diff = (int)$today->diff($due)->days * ($due >= $today ? 1 : -1);
    return $diff >= 0 && $diff <= 30;
});

// For assign form
$orgScopeSimple = orgScope();
$availableUsers = dbFetchAll(
    "SELECT u.id, u.known_as, u.username, p.code AS persona_code
       FROM users u
       JOIN personas p ON p.id = u.persona_id
      WHERE ({$orgScopeSimple['sql']})
        AND u.active=1
        AND p.code IN ('OPERATOR','TESTER','INSPECTOR','FINAL_TESTER',
                       'SUPERVISOR','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER')
      ORDER BY u.known_as",
    $orgScopeSimple['params']
);
$availableSkills = dbFetchAll(
    "SELECT s.id, s.code, s.name, o.code AS org_code
       FROM skills s JOIN orgs o ON o.id = s.org_id
      WHERE ({$orgScopeSimple['sql']}) AND s.active=1
      ORDER BY s.code",
    $orgScopeSimple['params']
);

function skillStatusBadge(string $status): string {
    return match($status) {
        'APPROVED' => '<span class="badge badge-green">Approved</span>',
        'PENDING'  => '<span class="badge badge-yellow">Pending Approval</span>',
        'EXPIRED'  => '<span class="badge badge-red">Expired</span>',
        'REVOKED'  => '<span class="badge badge-grey">Revoked</span>',
        default    => '<span class="badge badge-grey">'.htmlspecialchars($status).'</span>',
    };
}

renderPageStart('Training Matrix');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Training Matrix</h1>
        <p>Assign, approve and manage operator skill certifications.</p>
    </div>
    <button onclick="document.getElementById('assign-panel').style.display='block';this.style.display='none';"
            class="btn btn-primary">+ Assign Skill</button>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Expiry warning -->
<?php if ($expiringRecords): ?>
<div class="alert alert-warning">
    ⚠ <strong><?= count($expiringRecords) ?> skill<?= count($expiringRecords) !== 1 ? 's' : '' ?> expiring within 30 days</strong>
    — review and renew below.
</div>
<?php endif; ?>

<!-- Assign skill panel -->
<div id="assign-panel" style="display:none;" class="card" style="margin-bottom:16px;">
    <div class="card-title">Assign Skill to Operator</div>
    <form method="POST" style="display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:12px;align-items:end;flex-wrap:wrap;">
        <input type="hidden" name="action" value="assign">
        <div class="form-group" style="margin:0;">
            <label>User</label>
            <select name="user_id" required>
                <option value="">— Select User —</option>
                <?php foreach ($availableUsers as $u): ?>
                <option value="<?= $u['id'] ?>">
                    <?= htmlspecialchars($u['known_as'] . ' (' . $u['username'] . ')') ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group" style="margin:0;">
            <label>Skill</label>
            <select name="skill_id" required>
                <option value="">— Select Skill —</option>
                <?php foreach ($availableSkills as $sk): ?>
                <option value="<?= $sk['id'] ?>">
                    <?= htmlspecialchars($sk['code'] . ' — ' . $sk['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group" style="margin:0;">
            <label>Expiry Date <span class="text-dim">(optional)</span></label>
            <input type="date" name="expiry_date" min="<?= date('Y-m-d') ?>">
        </div>
        <div style="display:flex;gap:6px;">
            <button type="submit" class="btn btn-primary">Assign</button>
            <button type="button" class="btn btn-secondary"
                    onclick="document.getElementById('assign-panel').style.display='none';
                             document.querySelector('.btn-primary[onclick]').style.display='';">Cancel</button>
        </div>
    </form>
</div>

<!-- Filter bar -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">
    <form method="GET" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Status</label>
            <select name="status" onchange="this.form.submit()">
                <option value="">All Statuses</option>
                <option value="PENDING"  <?= $filterStatus==='PENDING'  ?'selected':'' ?>>Pending</option>
                <option value="APPROVED" <?= $filterStatus==='APPROVED' ?'selected':'' ?>>Approved</option>
                <option value="EXPIRED"  <?= $filterStatus==='EXPIRED'  ?'selected':'' ?>>Expired</option>
                <option value="REVOKED"  <?= $filterStatus==='REVOKED'  ?'selected':'' ?>>Revoked</option>
            </select>
        </div>
        <?php if ($filterSkillId): ?>
        <input type="hidden" name="skill_id" value="<?= $filterSkillId ?>">
        <?php endif; ?>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="training.php" class="btn btn-secondary">Clear</a>
    </form>
</div>

<div class="card" style="padding:0;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Skill</th>
                    <?php if (hasPersona('IT_ADMIN')): ?><th>Org</th><?php endif; ?>
                    <th>Status</th>
                    <th>Expiry</th>
                    <th>Assigned By</th>
                    <th>Approved By</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($records)): ?>
                <tr><td colspan="8" class="text-muted" style="text-align:center;padding:20px;">No skill records found.</td></tr>
            <?php else: ?>
            <?php foreach ($records as $r):
                $isExpiring = false;
                $daysLeft   = null;
                if ($r['status'] === 'APPROVED' && $r['expiry_date']) {
                    $due      = new DateTimeImmutable($r['expiry_date']);
                    $daysLeft = (int)$today->diff($due)->days * ($due >= $today ? 1 : -1);
                    $isExpiring = ($daysLeft >= 0 && $daysLeft <= 30);
                }
            ?>
            <tr style="<?= $isExpiring ? 'background:rgba(210,153,34,.07);' : '' ?>">
                <td>
                    <div style="font-weight:600;"><?= htmlspecialchars($r['known_as']) ?></div>
                    <div class="text-dim" style="font-size:11px;"><?= htmlspecialchars($r['username']) ?></div>
                </td>
                <td>
                    <div><code style="color:var(--accent-blue);font-weight:600;"><?= htmlspecialchars($r['skill_code']) ?></code></div>
                    <div class="text-dim" style="font-size:11px;"><?= htmlspecialchars($r['skill_name']) ?></div>
                </td>
                <?php if (hasPersona('IT_ADMIN')): ?>
                <td><code style="font-size:11px;"><?= htmlspecialchars($r['org_code']) ?></code></td>
                <?php endif; ?>
                <td><?= skillStatusBadge($r['status']) ?></td>
                <td>
                    <?php if ($r['expiry_date']): ?>
                        <span style="font-family:monospace;font-size:12px;"><?= htmlspecialchars($r['expiry_date']) ?></span>
                        <?php if ($isExpiring): ?>
                            <span class="badge badge-yellow" style="font-size:9px;"><?= $daysLeft ?>d left</span>
                        <?php elseif ($r['status'] === 'EXPIRED'): ?>
                            <span class="badge badge-red" style="font-size:9px;">Lapsed</span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="text-dim">No expiry</span>
                    <?php endif; ?>
                </td>
                <td class="text-dim" style="font-size:12px;"><?= htmlspecialchars($r['assigned_by_name'] ?? '—') ?></td>
                <td class="text-dim" style="font-size:12px;"><?= htmlspecialchars($r['approved_by_name'] ?? '—') ?></td>
                <td>
                    <div style="display:flex;gap:4px;flex-wrap:wrap;">
                    <?php if ($r['status'] === 'PENDING'): ?>
                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="action" value="approve">
                            <input type="hidden" name="us_id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-primary" style="padding:3px 10px;font-size:11px;">✓ Approve</button>
                        </form>
                    <?php endif; ?>
                    <?php if (in_array($r['status'], ['APPROVED','EXPIRED'])): ?>
                        <!-- Renew expiry -->
                        <form method="POST" style="margin:0;display:flex;gap:4px;align-items:center;">
                            <input type="hidden" name="action" value="update_expiry">
                            <input type="hidden" name="us_id" value="<?= $r['id'] ?>">
                            <input type="date" name="expiry_date"
                                   value="<?= htmlspecialchars($r['expiry_date'] ?? '') ?>"
                                   min="<?= date('Y-m-d') ?>"
                                   style="width:130px;padding:3px 6px;font-size:11px;">
                            <button type="submit" class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">Renew</button>
                        </form>
                    <?php endif; ?>
                    <?php if (in_array($r['status'], ['APPROVED','PENDING'])): ?>
                        <form method="POST" style="margin:0;" onsubmit="return confirm('Revoke this skill?')">
                            <input type="hidden" name="action" value="revoke">
                            <input type="hidden" name="us_id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-danger" style="padding:3px 8px;font-size:11px;">Revoke</button>
                        </form>
                    <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
