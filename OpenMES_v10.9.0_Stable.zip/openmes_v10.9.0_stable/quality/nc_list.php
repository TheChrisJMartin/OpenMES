<?php
/**
 * quality/nc_list.php — Non-Conformance List
 * Version: 10.5.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();

$scope        = orgScope('nc');
$filterStatus = $_GET['status'] ?? '';
$search       = trim($_GET['search'] ?? '');

$where  = '(' . $scope['sql'] . ')';
$params = $scope['params'];

if ($filterStatus && in_array($filterStatus,['OPEN','UNDER_REVIEW','CLOSED','SCRAPPED'])) {
    $where .= ' AND nc.status=?'; $params[] = $filterStatus;
}
if ($search) {
    $where .= ' AND (nc.nc_number LIKE ? OR w.wo_number LIKE ? OR nc.defect_desc LIKE ?)';
    $params[] = "%{$search}%"; $params[] = "%{$search}%"; $params[] = "%{$search}%";
}

$ncs = dbFetchAll(
    "SELECT nc.*,
            w.wo_number, o.code AS org_code,
            p.part_number,
            ru.known_as AS raiser_name,
            ro.op_number, ro.op_name,
            (SELECT COUNT(*) FROM nc_serials ns WHERE ns.nc_id=nc.id) AS serial_count
     FROM non_conformances nc
     JOIN work_orders w ON w.id=nc.wo_id
     JOIN orgs o        ON o.id=nc.org_id
     JOIN parts p       ON p.id=w.part_id
     LEFT JOIN users ru ON ru.id=nc.raised_by
     LEFT JOIN routing_operations ro ON ro.id=nc.op_id
     WHERE {$where}
     ORDER BY nc.raised_at DESC",
    $params
);


renderPageStart('Non-Conformances');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Non-Conformances</h1>
        <p>Quality non-conformances raised during work order execution.</p>
    </div>
</div>

<!-- Filters -->
<div class="card" style="padding:14px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                   placeholder="NC number, WO or defect…" style="width:220px;">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Status</label>
            <select name="status" style="width:150px;">
                <option value="">All</option>
                <option value="OPEN"         <?= $filterStatus==='OPEN'        ?'selected':'' ?>>Open</option>
                <option value="UNDER_REVIEW" <?= $filterStatus==='UNDER_REVIEW'?'selected':'' ?>>Under Review</option>
                <option value="CLOSED"       <?= $filterStatus==='CLOSED'      ?'selected':'' ?>>Closed</option>
                <option value="SCRAPPED"     <?= $filterStatus==='SCRAPPED'    ?'selected':'' ?>>Scrapped</option>
            </select>
        </div>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="<?= SITE_SUBPATH ?>/quality/nc_list.php" class="btn btn-secondary">Clear</a>
    </form>
</div>

<div class="card" style="padding:0;overflow:hidden;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>NC Number</th>
                    <th>WO</th>
                    <th>Part</th>
                    <th>Op</th>
                    <th>Status</th>
                    <th>Hold</th>
                    <th>Serials</th>
                    <th>Raised By</th>
                    <th>Raised At</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($ncs as $nc): ?>
            <tr>
                <td>
                    <a href="<?= SITE_SUBPATH ?>/quality/nc_detail.php?id=<?= $nc['id'] ?>"
                       style="color:var(--accent-blue);text-decoration:none;font-weight:700;font-family:monospace;">
                        <?= htmlspecialchars($nc['nc_number']) ?>
                    </a>
                </td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($nc['wo_number']) ?></code></td>
                <td style="font-size:12px;"><?= htmlspecialchars($nc['part_number']) ?></td>
                <td style="font-size:12px;">
                    <code><?= str_pad($nc['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                    <?= htmlspecialchars($nc['op_name']) ?>
                </td>
                <td><?= ncStatusBadge($nc['status']) ?></td>
                <td>
                    <?php if ($nc['status']==='OPEN' || $nc['status']==='UNDER_REVIEW'): ?>
                    <span class="badge <?= $nc['hold_type']==='HARD'?'badge-red':'badge-yellow' ?>">
                        <?= htmlspecialchars($nc['hold_type']) ?> HOLD
                    </span>
                    <?php else: ?>
                    <span class="text-dim">—</span>
                    <?php endif; ?>
                </td>
                <td class="text-muted"><?= (int)$nc['serial_count'] ?></td>
                <td style="font-size:12px;"><?= htmlspecialchars($nc['raiser_name']??'—') ?></td>
                <td style="font-size:11px;white-space:nowrap;"><?= displayDate($nc['raised_at'],'d M H:i') ?></td>
                <td>
                    <a href="<?= SITE_SUBPATH ?>/quality/nc_detail.php?id=<?= $nc['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">View</a>
                    <?php if (in_array($nc['status'],['OPEN','UNDER_REVIEW']) &&
                              hasPersona(['IT_ADMIN','ENGINEER','QUALITY_ENGINEER'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/quality/nc_disposition.php?id=<?= $nc['id'] ?>"
                       class="btn btn-primary" style="padding:3px 9px;font-size:11px;">Disposition</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$ncs): ?>
            <tr><td colspan="10" style="text-align:center;color:var(--text-dim);padding:32px;">
                No non-conformances found.
            </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
