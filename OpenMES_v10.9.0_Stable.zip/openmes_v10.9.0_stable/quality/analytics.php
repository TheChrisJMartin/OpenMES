<?php
/**
 * quality/analytics.php — Quality Analytics & SPC
 * Version: 10.7.0
 * F083: IMR chart with Western Electric rules, summary stats, Pareto chart.
 * Access: IT_ADMIN, MFG_ENGINEER, MFG_ENGINEER_SUP, QUALITY_ENGINEER, QUALITY_TRAINING_MANAGER
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER']);

$scope     = orgScope('qr');
$orgId     = (int)($_GET['org']      ?? ($scope['org_id'] ?? 0));
$routingId = (int)($_GET['routing']  ?? 0);
$opId      = (int)($_GET['op']       ?? 0);
$qvId      = (int)($_GET['qv']       ?? 0);
$limit     = min(50, max(10, (int)($_GET['limit'] ?? 20)));

// ── Selectors ─────────────────────────────────────────────────────────────────
$isAdmin = hasPersona('IT_ADMIN');
$orgs = $isAdmin
    ? dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code")
    : dbFetchAll("SELECT id,code,name FROM orgs WHERE id=? AND active=1", [$scope['org_id'] ?? 0]);

if (!$orgId && !empty($orgs)) $orgId = (int)$orgs[0]['id'];

$routings = $orgId
    ? dbFetchAll("SELECT r.id, CONCAT(o.code,'-',p.part_number) AS name
                    FROM routings r
                    JOIN parts p ON p.id=r.part_id
                    JOIN orgs   o ON o.id=r.org_id
                   WHERE r.org_id=? AND r.status='APPROVED'
                   ORDER BY name", [$orgId])
    : [];

$ops = $routingId
    ? dbFetchAll("SELECT id, op_number, op_name, op_type
                    FROM routing_operations
                   WHERE routing_id=?
                     AND op_type IN ('INSPECTION','FINAL_TEST','FINAL_INSPECTION')
                   ORDER BY sort_order", [$routingId])
    : [];

$qvs = $opId
    ? dbFetchAll("SELECT qv.id, qv.code, qv.name, qv.lower_limit, qv.upper_limit, qv.target_value,
                         u.code AS uom_code
                    FROM quality_variables qv
                    LEFT JOIN uom u ON u.id=qv.uom_id
                   WHERE qv.op_id=? AND qv.active=1
                   ORDER BY qv.code", [$opId])
    : [];

// ── Selected QV details ───────────────────────────────────────────────────────
$qv = null;
if ($qvId) {
    $qv = dbFetchOne("SELECT qv.*, u.code AS uom_code
                        FROM quality_variables qv
                        LEFT JOIN uom u ON u.id=qv.uom_id
                       WHERE qv.id=?", [$qvId]);
}

// ── Quality results for IMR chart ─────────────────────────────────────────────
$results = [];
$stats   = null;
$violations = [];

if ($qvId) {
    // F083: Query by qv.code across all routing revisions for this part
    // so results from earlier routing revisions are included
    $results = dbFetchAll(
        "SELECT qr.result_value, qr.is_in_spec, qr.collected_at,
                sn.serial_number, u.known_as AS operator
           FROM quality_results qr
           JOIN serial_numbers sn ON sn.id=qr.serial_id
           JOIN users u ON u.id=qr.collected_by
           JOIN quality_variables qv2 ON qv2.id=qr.qv_id
           JOIN quality_variables qv_sel ON qv_sel.id=?
          WHERE qv2.code=qv_sel.code
            AND qv2.org_id=qv_sel.org_id
          ORDER BY qr.collected_at DESC
          LIMIT ?",
        [$qvId, $limit]
    );
    $results = array_reverse($results); // oldest first for chart

    if (count($results) >= 2) {
        $values = array_column($results, 'result_value');
        $n      = count($values);
        $mean   = array_sum($values) / $n;

        // Standard deviation
        $variance = array_sum(array_map(fn($v) => pow($v - $mean, 2), $values)) / $n;
        $std      = sqrt($variance);

        // Moving ranges
        $mrs = [];
        for ($i = 1; $i < $n; $i++) {
            $mrs[] = abs($values[$i] - $values[$i-1]);
        }
        $mrMean = !empty($mrs) ? array_sum($mrs) / count($mrs) : 0;

        // Control limits (d2 = 1.128 for n=2)
        $d2  = 1.128;
        $ucl = $mean + 3 * ($mrMean / $d2);
        $lcl = $mean - 3 * ($mrMean / $d2);
        $s1u = $mean + 1 * ($mrMean / $d2);
        $s1l = $mean - 1 * ($mrMean / $d2);
        $s2u = $mean + 2 * ($mrMean / $d2);
        $s2l = $mean - 2 * ($mrMean / $d2);

        // MR control limits (D4 = 3.267 for n=2)
        $mrUcl = 3.267 * $mrMean;

        // Cp and Cpk
        $lsl = $qv['lower_limit'];
        $usl = $qv['upper_limit'];
        $cp  = ($std > 0 && $lsl !== null && $usl !== null)
            ? ($usl - $lsl) / (6 * $std) : null;
        $cpk = ($std > 0 && $lsl !== null && $usl !== null)
            ? min(($usl - $mean) / (3 * $std), ($mean - $lsl) / (3 * $std)) : null;

        $passCount = count(array_filter($results, fn($r) => $r['is_in_spec']));
        $failCount = $n - $passCount;

        $stats = compact('n','mean','std','ucl','lcl','s1u','s1l','s2u','s2l',
                         'mrMean','mrUcl','cp','cpk','passCount','failCount',
                         'values','mrs','d2');

        // ── Western Electric Rule Detection ───────────────────────────────────
        $violations = [];

        // Rule 1: 1 point beyond 3σ
        foreach ($values as $i => $v) {
            if ($v > $ucl || $v < $lcl) {
                $violations[] = ['rule'=>1,'idx'=>$i,'desc'=>'Rule 1: Point beyond 3σ control limit'];
            }
        }

        // Rule 2: 2 of 3 consecutive beyond 2σ same side
        for ($i = 2; $i < $n; $i++) {
            $window = [$values[$i-2],$values[$i-1],$values[$i]];
            $aboveCount = count(array_filter($window, fn($v) => $v > $s2u));
            $belowCount = count(array_filter($window, fn($v) => $v < $s2l));
            if ($aboveCount >= 2 || $belowCount >= 2) {
                $violations[] = ['rule'=>2,'idx'=>$i,'desc'=>'Rule 2: 2 of 3 points beyond 2σ same side'];
            }
        }

        // Rule 3: 4 of 5 consecutive beyond 1σ same side
        for ($i = 4; $i < $n; $i++) {
            $window = [$values[$i-4],$values[$i-3],$values[$i-2],$values[$i-1],$values[$i]];
            $aboveCount = count(array_filter($window, fn($v) => $v > $s1u));
            $belowCount = count(array_filter($window, fn($v) => $v < $s1l));
            if ($aboveCount >= 4 || $belowCount >= 4) {
                $violations[] = ['rule'=>3,'idx'=>$i,'desc'=>'Rule 3: 4 of 5 points beyond 1σ same side'];
            }
        }

        // Rule 4: 8 consecutive same side of centre line
        for ($i = 7; $i < $n; $i++) {
            $window = array_slice($values, $i-7, 8);
            $above = count(array_filter($window, fn($v) => $v > $mean));
            $below = count(array_filter($window, fn($v) => $v < $mean));
            if ($above === 8 || $below === 8) {
                $violations[] = ['rule'=>4,'idx'=>$i,'desc'=>'Rule 4: 8 consecutive points same side of centreline'];
            }
        }

        // Rule 5: 6 consecutive trending up or down
        for ($i = 5; $i < $n; $i++) {
            $window = array_slice($values, $i-5, 6);
            $up   = true; $down = true;
            for ($j = 1; $j < 6; $j++) {
                if ($window[$j] <= $window[$j-1]) $up   = false;
                if ($window[$j] >= $window[$j-1]) $down = false;
            }
            if ($up || $down) {
                $violations[] = ['rule'=>5,'idx'=>$i,'desc'=>'Rule 5: 6 consecutive points trending ' . ($up?'up':'down')];
            }
        }

        // Rule 6: 14 consecutive alternating up/down
        for ($i = 13; $i < $n; $i++) {
            $window = array_slice($values, $i-13, 14);
            $alt = true;
            for ($j = 2; $j < 14; $j++) {
                $prev2 = $window[$j-2]; $prev1 = $window[$j-1]; $curr = $window[$j];
                if (!(($curr > $prev1 && $prev1 < $prev2) || ($curr < $prev1 && $prev1 > $prev2))) {
                    $alt = false; break;
                }
            }
            if ($alt) {
                $violations[] = ['rule'=>6,'idx'=>$i,'desc'=>'Rule 6: 14 consecutive points alternating up/down'];
            }
        }

        // Rule 7: 15 consecutive within 1σ (hugging)
        for ($i = 14; $i < $n; $i++) {
            $window = array_slice($values, $i-14, 15);
            if (count(array_filter($window, fn($v) => $v >= $s1l && $v <= $s1u)) === 15) {
                $violations[] = ['rule'=>7,'idx'=>$i,'desc'=>'Rule 7: 15 consecutive points hugging centreline (within 1σ)'];
            }
        }

        // Rule 8: 8 consecutive beyond 1σ both sides
        for ($i = 7; $i < $n; $i++) {
            $window = array_slice($values, $i-7, 8);
            $beyond = count(array_filter($window, fn($v) => $v > $s1u || $v < $s1l));
            $above  = count(array_filter($window, fn($v) => $v > $s1u));
            $below  = count(array_filter($window, fn($v) => $v < $s1l));
            if ($beyond === 8 && $above > 0 && $below > 0) {
                $violations[] = ['rule'=>8,'idx'=>$i,'desc'=>'Rule 8: 8 consecutive points beyond 1σ both sides (mixture)'];
            }
        }

        // Deduplicate violations by rule+idx
        $seen = [];
        $violations = array_filter($violations, function($v) use (&$seen) {
            $key = $v['rule'] . '-' . $v['idx'];
            if (isset($seen[$key])) return false;
            $seen[$key] = true;
            return true;
        });
        $violations = array_values($violations);
    }
}

// ── Pareto data (NC defect codes for selected org / routing) ──────────────────
$paretoData = [];
if ($orgId) {
    $wherePareto  = 'n.org_id = ?';
    $paretoParams = [$orgId];
    if ($routingId) {
        // Filter to part linked to this routing
        $wherePareto  .= ' AND n.wo_id IN (SELECT id FROM work_orders WHERE routing_id=?)';
        $paretoParams[] = $routingId;
    }
    $paretoData = dbFetchAll(
        "SELECT COALESCE(n.cause_category, 'UNSPECIFIED') AS category,
                COUNT(*) AS cnt
           FROM non_conformances n
          WHERE {$wherePareto}
          GROUP BY category
          ORDER BY cnt DESC",
        $paretoParams
    );
}

// ── Encode data for JS ────────────────────────────────────────────────────────
$jsData = json_encode([
    'values'     => $stats ? $stats['values'] : [],
    'mrs'        => $stats ? $stats['mrs']    : [],
    'labels'     => array_map(fn($r) => substr($r['collected_at'],0,10) . ' ' . $r['serial_number'], $results),
    'mean'       => $stats['mean']   ?? 0,
    'ucl'        => $stats['ucl']    ?? 0,
    'lcl'        => $stats['lcl']    ?? 0,
    's1u'        => $stats['s1u']    ?? 0,
    's1l'        => $stats['s1l']    ?? 0,
    's2u'        => $stats['s2u']    ?? 0,
    's2l'        => $stats['s2l']    ?? 0,
    'mrMean'     => $stats['mrMean'] ?? 0,
    'mrUcl'      => $stats['mrUcl']  ?? 0,
    'lsl'        => $qv['lower_limit']  ?? null,
    'usl'        => $qv['upper_limit']  ?? null,
    'target'     => $qv['target_value'] ?? null,
    'violations' => array_column($violations, 'idx'),
    'pareto'     => $paretoData,
    'uom'        => $qv['uom_code'] ?? '',
]);

renderPageStart('Quality Analytics');
?>

<div class="page-header page-header-row" style="flex-wrap:wrap;gap:10px;">
    <div>
        <h1>Quality Analytics</h1>
        <p style="color:var(--text-muted);">IMR control charts, Western Electric rules, Pareto analysis</p>
    </div>
</div>

<!-- ── Selectors ─────────────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:14px;padding:14px 16px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <?php if ($isAdmin || count($orgs) > 1): ?>
        <div style="flex:1;min-width:140px;">
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Organisation</label>
            <select name="org" class="form-control" onchange="this.form.submit()" style="width:100%;">
                <?php foreach ($orgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $o['id']==$orgId?'selected':'' ?>>
                    <?= htmlspecialchars($o['code']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php else: ?>
        <input type="hidden" name="org" value="<?= $orgId ?>">
        <?php endif; ?>

        <div style="flex:2;min-width:180px;">
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Routing</label>
            <select name="routing" class="form-control" onchange="this.form.submit()" style="width:100%;">
                <option value="">— Select routing —</option>
                <?php foreach ($routings as $r): ?>
                <option value="<?= $r['id'] ?>" <?= $r['id']==$routingId?'selected':'' ?>>
                    <?= htmlspecialchars($r['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="flex:2;min-width:180px;">
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Operation</label>
            <select name="op" class="form-control" onchange="this.form.submit()" style="width:100%;" <?= !$routingId?'disabled':'' ?>>
                <option value="">— Select operation —</option>
                <?php foreach ($ops as $op): ?>
                <option value="<?= $op['id'] ?>" <?= $op['id']==$opId?'selected':'' ?>>
                    <?= htmlspecialchars($op['op_number'] . ' — ' . $op['op_name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="flex:2;min-width:180px;">
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Quality Variable</label>
            <select name="qv" class="form-control" onchange="this.form.submit()" style="width:100%;" <?= !$opId?'disabled':'' ?>>
                <option value="">— Select variable —</option>
                <?php foreach ($qvs as $v): ?>
                <option value="<?= $v['id'] ?>" <?= $v['id']==$qvId?'selected':'' ?>>
                    <?= htmlspecialchars($v['code'] . ' — ' . $v['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="min-width:100px;">
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Data points</label>
            <select name="limit" class="form-control" onchange="this.form.submit()" style="width:100%;">
                <?php foreach ([10,20,30,50] as $l): ?>
                <option value="<?= $l ?>" <?= $l==$limit?'selected':'' ?>>Last <?= $l ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>
</div>

<?php if ($qv && $stats): ?>

<!-- ── Summary Stats ─────────────────────────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-bottom:14px;">
    <?php
    $statCards = [
        ['n',         $stats['n'],                                 'Readings'],
        ['x̄',        number_format($stats['mean'], 3),            'Mean'],
        ['σ',         number_format($stats['std'],  3),            'Std Dev'],
        ['UCL',       number_format($stats['ucl'],  3),            'UCL (3σ)'],
        ['LCL',       number_format($stats['lcl'],  3),            'LCL (3σ)'],
        ['Cp',        $stats['cp']  !== null ? number_format($stats['cp'],  2) : '—', 'Cp'],
        ['Cpk',       $stats['cpk'] !== null ? number_format($stats['cpk'], 2) : '—', 'Cpk'],
        ['Pass',      $stats['passCount'],                         'In Spec'],
        ['Fail',      $stats['failCount'],                         'Out of Spec'],
    ];
    foreach ($statCards as [$label, $value, $sub]):
        $colour = match($label) {
            'Fail'  => $stats['failCount'] > 0 ? 'var(--accent-danger)' : '#3fb950',
            'Cpk'   => ($stats['cpk'] !== null && $stats['cpk'] < 1.33) ? 'var(--accent-warn)' : 'var(--text)',
            default => 'var(--text)',
        };
    ?>
    <div class="card" style="margin:0;padding:10px 12px;text-align:center;">
        <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;"><?= $sub ?></div>
        <div style="font-size:20px;font-weight:700;color:<?= $colour ?>;font-family:monospace;"><?= $value ?></div>
        <div style="font-size:10px;color:var(--text-dim);"><?= $label ?></div>
    </div>
    <?php endforeach; ?>
</div>

<?php if (!empty($violations)): ?>
<!-- ── Violations summary ─────────────────────────────────────────────────────── -->
<div class="alert alert-danger" style="margin-bottom:14px;">
    <strong>⚠ <?= count($violations) ?> Western Electric rule violation<?= count($violations)>1?'s':'' ?> detected</strong>
    — process may be out of statistical control. Review chart highlights below.
</div>
<?php else: ?>
<div class="alert alert-success" style="margin-bottom:14px;">
    ✓ No Western Electric rule violations detected in the last <?= $limit ?> readings.
</div>
<?php endif; ?>

<!-- ── IMR Charts ─────────────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:14px;padding:16px;">
    <div style="font-weight:600;font-size:14px;margin-bottom:4px;">
        Individuals Chart (I Chart)
        <span style="font-size:11px;color:var(--text-muted);margin-left:8px;">
            <?= htmlspecialchars($qv['name']) ?>
            <?= $qv['uom_code'] ? '(' . htmlspecialchars($qv['uom_code']) . ')' : '' ?>
        </span>
    </div>
    <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px;">
        UCL/LCL = mean ± 3σ &nbsp;|&nbsp; Zone lines at 1σ and 2σ &nbsp;|&nbsp;
        <?php if ($qv['lower_limit'] !== null): ?>
        Spec limits: LSL=<?= $qv['lower_limit'] ?> USL=<?= $qv['upper_limit'] ?>
        <?php else: ?> No spec limits defined <?php endif; ?>
    </div>
    <canvas id="iChart" style="width:100%;max-height:280px;"></canvas>
</div>

<div class="card" style="margin-bottom:14px;padding:16px;">
    <div style="font-weight:600;font-size:14px;margin-bottom:4px;">Moving Range Chart (MR Chart)</div>
    <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px;">
        MR̄ = <?= number_format($stats['mrMean'],3) ?> &nbsp;|&nbsp;
        UCL = <?= number_format($stats['mrUcl'],3) ?> (D4 × MR̄, D4=3.267 for n=2)
    </div>
    <canvas id="mrChart" style="width:100%;max-height:180px;"></canvas>
</div>

<?php if (!empty($violations)): ?>
<!-- ── Violations table ───────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:14px;padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
        Western Electric Rule Violations
    </div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr><th>Rule</th><th>Point #</th><th>Value</th><th>Description</th></tr>
            </thead>
            <tbody>
            <?php foreach ($violations as $v): ?>
            <tr>
                <td><span class="badge badge-red" style="font-size:10px;">Rule <?= $v['rule'] ?></span></td>
                <td style="font-family:monospace;"><?= $v['idx'] + 1 ?></td>
                <td style="font-family:monospace;"><?= number_format($stats['values'][$v['idx']], 3) ?></td>
                <td style="font-size:12px;"><?= htmlspecialchars($v['desc']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php elseif ($qvId): ?>
<div class="alert alert-warning" style="margin-bottom:14px;">
    No measurement data found for this quality variable. Collect at least 2 readings to generate charts.
</div>
<?php elseif ($orgId): ?>
<div class="card" style="padding:40px;text-align:center;color:var(--text-muted);">
    <div style="font-size:32px;margin-bottom:10px;">📊</div>
    <div style="font-size:14px;">Select a routing, operation and quality variable to generate charts.</div>
</div>
<?php endif; ?>

<!-- ── Pareto Chart ───────────────────────────────────────────────────────────── -->
<?php if (!empty($paretoData)): ?>
<div class="card" style="margin-bottom:14px;padding:16px;">
    <div style="font-weight:600;font-size:14px;margin-bottom:4px;">
        NC Cause Category Pareto
        <?php if ($routingId): ?>
        <span style="font-size:11px;color:var(--text-muted);margin-left:8px;">— filtered to selected routing</span>
        <?php endif; ?>
    </div>
    <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px;">
        Sorted by frequency — cumulative % line shows 80/20 boundary
    </div>
    <canvas id="paretoChart" style="width:100%;max-height:260px;"></canvas>
</div>
<?php endif; ?>

<!-- ── Western Electric Rules Reference ──────────────────────────────────────── -->
<div class="card" style="padding:14px 16px;">
    <div style="font-weight:600;font-size:13px;margin-bottom:10px;">Western Electric Detection Rules Reference</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:6px;">
        <?php
        $rules = [
            [1, 'Point beyond 3σ control limit', 'Assignable cause — immediate investigation'],
            [2, '2 of 3 consecutive beyond 2σ same side', 'Process shift or drift beginning'],
            [3, '4 of 5 consecutive beyond 1σ same side', 'Process has shifted'],
            [4, '8 consecutive same side of centreline', 'Sustained process shift'],
            [5, '6 consecutive trending up or down', 'Process drift — tool wear or setup change'],
            [6, '14 consecutive alternating up/down', 'Systematic cause — two alternating processes'],
            [7, '15 consecutive within 1σ (hugging)', 'Stratification — mixed data sources'],
            [8, '8 consecutive beyond 1σ both sides', 'Mixture — two different process populations'],
        ];
        foreach ($rules as [$num, $desc, $action]):
        ?>
        <div style="background:var(--bg);border:1px solid var(--border);border-radius:5px;padding:8px 10px;font-size:11px;">
            <span style="font-weight:700;color:var(--accent-blue);">Rule <?= $num ?>:</span>
            <?= htmlspecialchars($desc) ?>
            <div style="color:var(--text-dim);margin-top:2px;"><?= htmlspecialchars($action) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- ── Chart JS ──────────────────────────────────────────────────────────────── -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
(function() {
    const D = <?= $jsData ?>;
    if (!D.values.length) return;

    const isDark   = document.documentElement.dataset.theme === 'dark';
    const gridCol  = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    const textCol  = isDark ? '#8b949e' : '#595959';
    const vioSet   = new Set(D.violations);

    Chart.defaults.color = textCol;
    Chart.defaults.borderColor = gridCol;

    // ── Point colour helper ─────────────────────────────────────────────────────
    function pointColors(values, ucl, lcl, usl, lsl) {
        return values.map((v, i) => {
            if (vioSet.has(i))                           return '#ff6b6b'; // violation — red
            if (usl !== null && (v > usl || v < lsl))   return '#f0ad4e'; // out of spec — amber
            if (v > ucl || v < lcl)                      return '#ff6b6b'; // out of control — red
            return '#3fb950';                                               // in control — green
        });
    }

    // ── I Chart ────────────────────────────────────────────────────────────────
    const iCtx = document.getElementById('iChart').getContext('2d');
    const ptColors = pointColors(D.values, D.ucl, D.lcl, D.usl, D.lsl);

    const iDatasets = [
        // Zone fills (backgrounds)
        { label:'UCL', data: Array(D.values.length).fill(D.ucl),
          borderColor:'#cf222e', borderWidth:1.5, borderDash:[5,4],
          pointRadius:0, fill:false },
        { label:'LCL', data: Array(D.values.length).fill(D.lcl),
          borderColor:'#cf222e', borderWidth:1.5, borderDash:[5,4],
          pointRadius:0, fill:false },
        { label:'+2σ', data: Array(D.values.length).fill(D.s2u),
          borderColor:'#f0ad4e', borderWidth:1, borderDash:[3,4],
          pointRadius:0, fill:false },
        { label:'-2σ', data: Array(D.values.length).fill(D.s2l),
          borderColor:'#f0ad4e', borderWidth:1, borderDash:[3,4],
          pointRadius:0, fill:false },
        { label:'+1σ', data: Array(D.values.length).fill(D.s1u),
          borderColor:'#58a6ff', borderWidth:1, borderDash:[2,4],
          pointRadius:0, fill:false },
        { label:'-1σ', data: Array(D.values.length).fill(D.s1l),
          borderColor:'#58a6ff', borderWidth:1, borderDash:[2,4],
          pointRadius:0, fill:false },
        { label:'Mean', data: Array(D.values.length).fill(D.mean),
          borderColor:'#58a6ff', borderWidth:2,
          pointRadius:0, fill:false },
    ];

    // Spec limits if defined
    if (D.usl !== null) {
        iDatasets.push({ label:'USL', data: Array(D.values.length).fill(D.usl),
            borderColor:'#a371f7', borderWidth:2, borderDash:[8,4],
            pointRadius:0, fill:false });
        iDatasets.push({ label:'LSL', data: Array(D.values.length).fill(D.lsl),
            borderColor:'#a371f7', borderWidth:2, borderDash:[8,4],
            pointRadius:0, fill:false });
    }
    if (D.target !== null) {
        iDatasets.push({ label:'Target', data: Array(D.values.length).fill(D.target),
            borderColor:'#3fb950', borderWidth:1.5, borderDash:[4,3],
            pointRadius:0, fill:false });
    }

    // Actual values — last so they're on top
    iDatasets.push({
        label: 'Measured' + (D.uom ? ' (' + D.uom + ')' : ''),
        data: D.values,
        borderColor: '#58a6ff',
        backgroundColor: ptColors,
        pointBackgroundColor: ptColors,
        pointRadius: 6,
        pointHoverRadius: 8,
        borderWidth: 1.5,
        fill: false,
        tension: 0.1,
    });

    new Chart(iCtx, {
        type: 'line',
        data: { labels: D.labels, datasets: iDatasets },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: true, position: 'bottom',
                    labels: { filter: (i) => ['Measured','UCL','LCL','USL','LSL','Target','Mean'].includes(i.text),
                              boxWidth: 20, font: { size: 11 } } },
                tooltip: {
                    callbacks: {
                        afterBody: (items) => {
                            const idx = items[0]?.dataIndex;
                            if (vioSet.has(idx)) return ['⚠ Western Electric violation at this point'];
                            return [];
                        }
                    }
                }
            },
            scales: {
                x: { ticks: { font: { size: 10 }, maxRotation: 45 } },
                y: { ticks: { font: { size: 10 } } }
            }
        }
    });

    // ── MR Chart ───────────────────────────────────────────────────────────────
    if (D.mrs.length) {
        const mrCtx = document.getElementById('mrChart').getContext('2d');
        const mrLabels = D.labels.slice(1);
        const mrColors = D.mrs.map(v => v > D.mrUcl ? '#ff6b6b' : '#58a6ff');

        new Chart(mrCtx, {
            type: 'bar',
            data: {
                labels: mrLabels,
                datasets: [
                    { label: 'Moving Range',
                      data: D.mrs,
                      backgroundColor: mrColors,
                      borderColor: mrColors,
                      borderWidth: 1 },
                    { label: 'MR̄', type:'line',
                      data: Array(D.mrs.length).fill(D.mrMean),
                      borderColor:'#58a6ff', borderWidth:2,
                      pointRadius:0, fill:false },
                    { label: 'UCL', type:'line',
                      data: Array(D.mrs.length).fill(D.mrUcl),
                      borderColor:'#cf222e', borderWidth:1.5, borderDash:[5,4],
                      pointRadius:0, fill:false },
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: true, position: 'bottom',
                        labels: { boxWidth: 20, font: { size: 11 } } }
                },
                scales: {
                    x: { ticks: { font: { size: 10 }, maxRotation: 45 } },
                    y: { min: 0, ticks: { font: { size: 10 } } }
                }
            }
        });
    }

    // ── Pareto Chart ───────────────────────────────────────────────────────────
    const paretoEl = document.getElementById('paretoChart');
    if (paretoEl && D.pareto.length) {
        const pCtx    = paretoEl.getContext('2d');
        const pLabels = D.pareto.map(r => r.category);
        const pCounts = D.pareto.map(r => parseInt(r.cnt));
        const pTotal  = pCounts.reduce((a,b) => a+b, 0);
        let cum = 0;
        const pCumPct = pCounts.map(c => { cum += c; return Math.round(cum/pTotal*100); });

        const catColors = {
            'MAN':'#58a6ff','MACHINE':'#3fb950','METHOD':'#f0ad4e',
            'MATERIAL':'#a371f7','MEASUREMENT':'#ff6b6b','ENVIRONMENT':'#79c0ff',
            'UNSPECIFIED':'#8b949e'
        };

        new Chart(pCtx, {
            data: {
                labels: pLabels,
                datasets: [
                    { type:'bar', label:'Count',
                      data: pCounts,
                      backgroundColor: pLabels.map(l => catColors[l] || '#8b949e'),
                      yAxisID:'y' },
                    { type:'line', label:'Cumulative %',
                      data: pCumPct,
                      borderColor:'#f0ad4e', borderWidth:2,
                      pointRadius:4, fill:false,
                      yAxisID:'y2' },
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: true, position: 'bottom',
                        labels: { boxWidth: 20, font: { size: 11 } } },
                    annotation: {} // 80% line handled via dataset
                },
                scales: {
                    x: { ticks: { font: { size: 11 } } },
                    y: { beginAtZero: true, position:'left',
                         title: { display:true, text:'Count', font:{size:11} },
                         ticks: { font:{size:10} } },
                    y2: { beginAtZero: true, position:'right', max:100,
                          title: { display:true, text:'Cumulative %', font:{size:11} },
                          ticks: { font:{size:10}, callback: v => v+'%' },
                          grid: { drawOnChartArea:false } }
                }
            }
        });
    }
})();
</script>

<?php renderPageEnd(); ?>
