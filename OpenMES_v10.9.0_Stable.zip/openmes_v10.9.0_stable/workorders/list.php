<?php
/**
 * workorders/list.php — Work Order List
 * Version: 5.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();

$scope   = orgScope('w');
$search  = trim($_GET['search'] ?? '');
$filterStatus = $_GET['status'] ?? '';
$filterOrg    = (int)($_GET['org'] ?? 0);

$where  = '(' . $scope['sql'] . ')';
$params = $scope['params'];

if ($filterStatus && in_array($filterStatus,['OPEN','IN_PROGRESS','COMPLETE','ON_HOLD','CANCELLED'])) {
    $where .= ' AND w.status=?'; $params[] = $filterStatus;
}
if ($filterOrg && hasPersona('IT_ADMIN')) {
    $where .= ' AND w.org_id=?'; $params[] = $filterOrg;
}
if ($search) {
    $where .= ' AND (w.wo_number LIKE ? OR p.part_number LIKE ? OR p.description LIKE ?)';
    $params[] = "%{$search}%"; $params[] = "%{$search}%"; $params[] = "%{$search}%";
}

$workOrders = dbFetchAll(
    "SELECT w.*,
            o.code  AS org_code,
            p.part_number, p.description AS part_desc,
            r.revision_label AS routing_rev,
            u.known_as AS creator_name,
            (SELECT COUNT(*) FROM serial_numbers sn WHERE sn.wo_id=w.id) AS serial_count,
            (SELECT COUNT(*) FROM serial_numbers sn WHERE sn.wo_id=w.id AND sn.status='COMPLETE') AS serials_done
     FROM work_orders w
     JOIN orgs o    ON o.id=w.org_id
     JOIN parts p   ON p.id=w.part_id
     JOIN routings r ON r.id=w.routing_id
     LEFT JOIN users u ON u.id=w.created_by
     WHERE {$where}
     ORDER BY w.created_at DESC",
    $params
);

$orgs = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");


renderPageStart('Work Orders');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Work Orders</h1>
        <p>Manufacturing work orders — serialised and lot-controlled.</p>
    </div>
    <?php if (ALLOW_WO_CREATION && hasPersona(['IT_ADMIN','SUPERVISOR'])): ?>
    <a href="<?= SITE_SUBPATH ?>/workorders/create.php" class="btn btn-primary">+ Create Work Order</a>
    <?php endif; ?>
</div>

<?php if (!ALLOW_WO_CREATION): ?>
<div class="alert alert-info">ℹ Work order creation is disabled — controlled via ERP integration (ALLOW_WO_CREATION = false).</div>
<?php endif; ?>

<!-- Filters -->
<div class="card" style="padding:14px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                   placeholder="WO number or part…" style="width:200px;">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Status</label>
            <select name="status" style="width:140px;">
                <option value="">All</option>
                <option value="OPEN"        <?= $filterStatus==='OPEN'       ?'selected':'' ?>>Open</option>
                <option value="IN_PROGRESS" <?= $filterStatus==='IN_PROGRESS'?'selected':'' ?>>In Progress</option>
                <option value="ON_HOLD"     <?= $filterStatus==='ON_HOLD'    ?'selected':'' ?>>On Hold</option>
                <option value="COMPLETE"    <?= $filterStatus==='COMPLETE'   ?'selected':'' ?>>Complete</option>
                <option value="CANCELLED"   <?= $filterStatus==='CANCELLED'  ?'selected':'' ?>>Cancelled</option>
            </select>
        </div>
        <?php if (hasPersona('IT_ADMIN')): ?>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Org</label>
            <select name="org" style="width:110px;">
                <option value="0">All</option>
                <?php foreach ($orgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="<?= SITE_SUBPATH ?>/workorders/list.php" class="btn btn-secondary">Clear</a>
    </form>
</div>

<div class="card" style="padding:0;overflow:hidden;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>WO Number</th>
                    <th>Org</th>
                    <th>Part</th>
                    <th>Routing Rev</th>
                    <th>Type</th>
                    <th>Qty</th>
                    <th>Progress</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($workOrders as $wo):
                $progress = $wo['serial_count'] > 0
                    ? round(($wo['serials_done'] / $wo['serial_count']) * 100)
                    : 0;
            ?>
            <tr>
                <td>
                    <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $wo['id'] ?>"
                       style="color:var(--accent-blue);text-decoration:none;font-weight:600;font-family:monospace;font-size:13px;">
                        <?= htmlspecialchars($wo['wo_number']) ?>
                    </a>
                </td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($wo['org_code']) ?></code></td>
                <td>
                    <div style="font-size:12px;font-weight:600;"><?= htmlspecialchars($wo['part_number']) ?></div>
                    <div class="text-dim" style="font-size:11px;"><?= htmlspecialchars(substr($wo['part_desc'],0,40)) ?></div>
                </td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($wo['routing_rev']) ?></code></td>
                <td><?= $wo['control_type']==='SERIAL'
                    ? '<span class="badge badge-blue">Serial</span>'
                    : '<span class="badge badge-grey">Lot</span>' ?></td>
                <td class="font-mono"><?= number_format($wo['quantity']) ?></td>
                <td style="min-width:100px;">
                    <?php if ($wo['serial_count'] > 0): ?>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden;">
                            <div style="height:100%;width:<?= $progress ?>%;background:<?= $progress>=100?'var(--accent)':'var(--accent-blue)' ?>;border-radius:3px;"></div>
                        </div>
                        <span class="text-dim" style="font-size:11px;white-space:nowrap;"><?= $wo['serials_done'] ?>/<?= $wo['serial_count'] ?></span>
                    </div>
                    <?php else: ?>
                    <span class="text-dim" style="font-size:11px;">—</span>
                    <?php endif; ?>
                </td>
                <td><?= woStatusBadge($wo['status'], $wo['hold_type']) ?></td>
                <td style="font-size:11px;white-space:nowrap;"><?= displayDate($wo['created_at'],'d M Y') ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $wo['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">View</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$workOrders): ?>
            <tr><td colspan="10" style="text-align:center;color:var(--text-dim);padding:32px;">
                No work orders found.
                <?php if (ALLOW_WO_CREATION && hasPersona(['IT_ADMIN','SUPERVISOR'])): ?>
                <a href="<?= SITE_SUBPATH ?>/workorders/create.php" style="color:var(--accent-blue);">Create one</a>.
                <?php endif; ?>
            </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
