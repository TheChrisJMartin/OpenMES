<?php
/**
 * workorders/view.php — Work Order Detail & Audit
 * Version: 10.5.0
 * v10.2.0: Operation Analytics and Quality Records tabs added
 * v10.5.0: No operator button for COMPLETE/CANCELLED; HARD/SOFT hold colours;
 *           op completions + status changes in change log with op number;
 *           Routing tab: Planned Setup / Planned Actual labels;
 *           Time Bookings: Standard Time label, overrun as %;
 *           WO Detail: WO Routing Rev label; last clocked-on user per serial;
 *           Quality Records: enriched with spec position, tools/TE used.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();

$woId  = (int)($_GET['id'] ?? 0);
$scope = orgScope('w');

$wo = dbFetchOne(
    "SELECT w.*, o.code AS org_code, o.name AS org_name,
            p.part_number, p.description AS part_desc, p.serial_controlled,
            r.routing_number, r.revision_label AS routing_rev,
            u.known_as AS creator_name
     FROM work_orders w
     JOIN orgs o     ON o.id = w.org_id
     JOIN parts p    ON p.id = w.part_id
     JOIN routings r ON r.id = w.routing_id
     LEFT JOIN users u ON u.id = w.created_by
     WHERE w.id=? AND ({$scope['sql']})",
    array_merge([$woId], $scope['params'])
);

if (!$wo) {
    renderPageStart('Not Found');
    echo '<div class="alert alert-danger">Work order not found or access denied.</div>';
    echo '<a href="' . SITE_SUBPATH . '/workorders/list.php" class="btn btn-secondary">← Work Orders</a>';
    renderPageEnd(); exit;
}

// ── Serial numbers — include last clocked-on user ─────────────────────────────
$serials = dbFetchAll(
    "SELECT sn.*, ro.op_number, ro.op_name, ro.op_type,
            u.known_as AS last_operator
       FROM serial_numbers sn
       LEFT JOIN routing_operations ro ON ro.id = sn.current_op_id
       LEFT JOIN (
           SELECT ce1.serial_id, ce1.user_id
             FROM wo_clock_events ce1
            WHERE ce1.wo_id = ?
              AND ce1.id = (
                  SELECT MAX(ce2.id) FROM wo_clock_events ce2
                   WHERE ce2.serial_id = ce1.serial_id
              )
       ) last_ce ON last_ce.serial_id = sn.id
       LEFT JOIN users u ON u.id = last_ce.user_id
      WHERE sn.wo_id=? ORDER BY sn.serial_number",
    [$woId, $woId]
);

$operations = dbFetchAll(
    "SELECT ro.*, d.code AS dept_code, res.code AS res_code
       FROM routing_operations ro
       LEFT JOIN departments d   ON d.id  = ro.department_id
       LEFT JOIN resources res   ON res.id = ro.resource_id
      WHERE ro.routing_id=? ORDER BY ro.sort_order, ro.op_number",
    [$wo['routing_id']]
);

// ── Change log ────────────────────────────────────────────────────────────────
$changeLog = dbFetchAll(
    "SELECT cl.*, u.known_as,
            ro.op_number, ro.op_name
       FROM wo_change_log cl
       LEFT JOIN users u ON u.id = cl.user_id
       LEFT JOIN routing_operations ro ON ro.id = cl.op_id
      WHERE cl.wo_id=? ORDER BY cl.changed_at DESC",
    [$woId]
);

// ── Booked hours ──────────────────────────────────────────────────────────────
$bookedMins = 0;
try {
    $row = dbFetchOne(
        "SELECT COALESCE(SUM(duration_mins),0) AS total_mins
           FROM wo_clock_events
          WHERE wo_id=? AND event_type IN ('COMPLETE','CLOCK_OFF')",
        [$woId]
    );
    $bookedMins = (float)($row['total_mins'] ?? 0);
} catch (Throwable) { $bookedMins = 0; }

// ── Detailed time bookings ────────────────────────────────────────────────────
$timeBookings = [];
try {
    $timeBookings = dbFetchAll(
        "SELECT ce.*, sn.serial_number,
                ro.op_number, ro.op_name, ro.actual_mins AS std_mins,
                u.known_as AS operator_name
           FROM wo_clock_events ce
           JOIN serial_numbers sn ON sn.id = ce.serial_id
           LEFT JOIN routing_operations ro ON ro.id = ce.op_id
           LEFT JOIN users u ON u.id = ce.user_id
          WHERE ce.wo_id=? AND ce.event_type IN ('COMPLETE','CLOCK_OFF')
          ORDER BY ce.clocked_off_at DESC",
        [$woId]
    );
} catch (Throwable) { $timeBookings = []; }

// ── Open NCs — use raised_at not created_at ───────────────────────────────────
$openNCs = [];
try {
    $openNCs = dbFetchAll(
        "SELECT nc.id AS nc_id, nc.nc_number, nc.status, nc.hold_type,
                ro.op_number, ro.op_name,
                u.known_as AS raiser_name, nc.raised_at
           FROM non_conformances nc
           LEFT JOIN routing_operations ro ON ro.id = nc.op_id
           LEFT JOIN users u ON u.id = nc.raised_by
          WHERE nc.wo_id=? ORDER BY nc.raised_at DESC",
        [$woId]
    );
} catch (Throwable) { $openNCs = []; }

// ── Status counts ─────────────────────────────────────────────────────────────
$statusCounts = [];
foreach ($serials as $sn) {
    $statusCounts[$sn['status']] = ($statusCounts[$sn['status']] ?? 0) + 1;
}

// ── Operation analytics ───────────────────────────────────────────────────────
$opAnalytics = [];
try {
    $opAnalytics = dbFetchAll(
        "SELECT ro.op_number, ro.op_name, ro.op_type, ro.actual_mins AS std_mins,
                COUNT(ce.id)                     AS event_count,
                COUNT(DISTINCT ce.serial_id)     AS serials_worked,
                ROUND(AVG(ce.duration_mins), 1)  AS avg_actual_mins,
                ROUND(MIN(ce.duration_mins), 1)  AS min_actual_mins,
                ROUND(MAX(ce.duration_mins), 1)  AS max_actual_mins,
                SUM(ce.is_overrun)               AS overrun_count,
                ROUND(SUM(ce.duration_mins), 1)  AS total_mins
           FROM wo_clock_events ce
           JOIN routing_operations ro ON ro.id = ce.op_id
          WHERE ce.wo_id=? AND ce.event_type='COMPLETE' AND ce.duration_mins > 0
          GROUP BY ro.id, ro.op_number, ro.op_name, ro.op_type, ro.actual_mins
          ORDER BY ro.sort_order, ro.op_number",
        [$woId]
    );
} catch (Throwable) { $opAnalytics = []; }

// ── Quality records — enriched with tools/TE ─────────────────────────────────
$qualityRecords = [];
try {
    $qualityRecords = dbFetchAll(
        "SELECT qr.*,
                qv.code AS qv_code, qv.name AS qv_name,
                qv.lower_limit, qv.upper_limit, qv.target_value,
                uom.code AS uom_code,
                sn.serial_number,
                ro.op_number, ro.op_name,
                collector.known_as AS collected_by_name,
                nc.nc_number
           FROM quality_results qr
           JOIN quality_variables qv  ON qv.id  = qr.qv_id
           JOIN serial_numbers sn     ON sn.id  = qr.serial_id
           JOIN routing_operations ro ON ro.id  = qr.op_id
           LEFT JOIN uom              ON uom.id = qv.uom_id
           LEFT JOIN users collector  ON collector.id = qr.collected_by
           LEFT JOIN non_conformances nc ON nc.id = qr.nc_id
          WHERE qr.wo_id=?
          ORDER BY ro.sort_order, ro.op_number, sn.serial_number, qv.code",
        [$woId]
    );
} catch (Throwable) { $qualityRecords = []; }

// Fetch tools recorded per serial per op for QV tab
$toolRecords = [];
try {
    $toolRecords = dbFetchAll(
        "SELECT wtr.serial_id, wtr.op_id,
                ct.asset_number, ct.description AS tool_desc, ct.asset_type,
                recorder.known_as AS recorded_by_name, wtr.recorded_at
           FROM wo_tool_records wtr
           JOIN calibration_tools ct ON ct.id = wtr.tool_id
           LEFT JOIN users recorder  ON recorder.id = wtr.recorded_by
          WHERE wtr.wo_id=?
          ORDER BY wtr.recorded_at",
        [$woId]
    );
} catch (Throwable) { $toolRecords = []; }

// Index tools by "serial_id:op_id"
$toolsBySerialOp = [];
foreach ($toolRecords as $tr) {
    $key = $tr['serial_id'] . ':' . $tr['op_id'];
    $toolsBySerialOp[$key][] = $tr;
}

$qvPassCount = count(array_filter($qualityRecords, fn($r) => $r['is_in_spec']));
$qvFailCount = count($qualityRecords) - $qvPassCount;

$created = isset($_GET['created']);
$isClosedWo = in_array($wo['status'], ['COMPLETE','CANCELLED','SCRAPPED']);

renderPageStart('WO — ' . $wo['wo_number']);
?>

<?php if ($created): ?>
<div class="alert alert-success">✓ Work order <?= htmlspecialchars($wo['wo_number']) ?> created successfully.</div>
<?php endif; ?>

<div class="page-header page-header-row">
    <div>
        <a href="<?= SITE_SUBPATH ?>/workorders/list.php"
           style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Work Orders</a>
        <h1 style="margin-top:4px;font-family:monospace;"><?= htmlspecialchars($wo['wo_number']) ?></h1>
        <p><?= htmlspecialchars($wo['part_number']) ?> — <?= htmlspecialchars($wo['part_desc']) ?></p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start;">
        <?= woStatusBadge($wo['status'], $wo['hold_type']) ?>
        <?php if (!$isClosedWo): ?>
        <a href="<?= SITE_SUBPATH ?>/workorders/operator.php?id=<?= $wo['id'] ?>"
           class="btn btn-primary">Open Operator Screen</a>
        <?php else: ?>
        <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $wo['id'] ?>&tab=analytics"
           class="btn btn-secondary">📊 Analytics &amp; Audit</a>
        <?php endif; ?>
    </div>
</div>

<!-- Summary stats -->
<?php
$hrs  = floor($bookedMins / 60);
$mins = round(fmod($bookedMins, 60));
$statCards = [
    ['n' => $wo['quantity'],                 'l' => 'Total Qty',   'c' => 'var(--accent-blue)'],
    ['n' => $statusCounts['NOT_STARTED']??0, 'l' => 'Not Started', 'c' => 'var(--text-dim)'],
    ['n' => $statusCounts['IN_PROGRESS']??0, 'l' => 'In Progress', 'c' => 'var(--accent-blue)'],
    ['n' => $statusCounts['COMPLETE']??0,    'l' => 'Complete',     'c' => '#3fb950'],
    ['n' => $statusCounts['ON_HOLD']??0,     'l' => 'On Hold',      'c' => 'var(--accent-warn)'],
    ['n' => "{$hrs}h {$mins}m",             'l' => 'Booked Time',  'c' => 'var(--accent-blue)'],
];
?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">
    <?php foreach ($statCards as $sc): ?>
    <div class="card" style="margin:0;text-align:center;padding:12px;">
        <div style="font-size:20px;font-weight:700;color:<?= $sc['c'] ?>;font-family:monospace;"><?= $sc['n'] ?></div>
        <div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:2px;"><?= $sc['l'] ?></div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Planned dates / priority row -->
<?php if ($wo['planned_start'] || $wo['planned_finish'] || isset($wo['priority'])): ?>
<div class="card" style="padding:10px 16px;margin-bottom:14px;display:flex;gap:24px;flex-wrap:wrap;font-size:12px;">
    <?php if ($wo['planned_start']): ?>
    <div><span class="text-dim">Planned Start:</span> <strong><?= displayDate($wo['planned_start'],'d M Y H:i') ?></strong></div>
    <?php endif; ?>
    <?php if ($wo['planned_finish']): ?>
    <div><span class="text-dim">Planned Finish:</span> <strong><?= displayDate($wo['planned_finish'],'d M Y H:i') ?></strong></div>
    <?php endif; ?>
    <?php if (isset($wo['priority'])): ?>
    <div><span class="text-dim">Priority:</span>
        <strong style="color:<?= $wo['priority'] <= 20 ? 'var(--accent-danger)' : ($wo['priority'] <= 40 ? 'var(--accent-warn)' : 'var(--text)') ?>">
            <?= $wo['priority'] <= 20 ? '🔴 High' : ($wo['priority'] <= 40 ? '🟡 Elevated' : 'Normal') ?> (<?= $wo['priority'] ?>)
        </strong>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Open NCs alert -->
<?php if ($openNCs): ?>
<div class="alert alert-warning" style="margin-bottom:14px;">
    ⚠ <strong><?= count($openNCs) ?> Non-Conformance<?= count($openNCs)!==1?'s':'' ?></strong> on this work order.
    <?php foreach ($openNCs as $nc): ?>
    <span style="margin-left:8px;">
        <a href="<?= SITE_SUBPATH ?>/quality/nc_detail.php?id=<?= $nc['nc_id'] ?>"
           style="color:var(--accent-warn);font-weight:600;"><?= htmlspecialchars($nc['nc_number']) ?></a>
        <span class="text-dim" style="font-size:11px;">(op <?= str_pad($nc['op_number'],3,'0',STR_PAD_LEFT) ?> — <?= htmlspecialchars($nc['status']) ?>)</span>
    </span>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Tab nav -->
<div style="display:flex;gap:0;margin-bottom:14px;border-bottom:1px solid var(--border);overflow-x:auto;">
    <?php
    $activeTab = $_GET['tab'] ?? 'detail';
    $tabs = [
        'detail'    => 'WO Detail',
        'analytics' => 'Op Analytics',
        'quality'   => 'Quality Records',
        'bookings'  => 'Time Bookings',
        'routing'   => 'Routing',
        'changelog' => 'Change Log',
    ];
    foreach ($tabs as $key => $label):
        $isActive = $activeTab === $key;
    ?>
    <a href="?id=<?= $woId ?>&tab=<?= $key ?>"
       style="padding:8px 14px;font-size:12px;white-space:nowrap;text-decoration:none;
              border-bottom:2px solid <?= $isActive?'var(--accent-blue)':'transparent' ?>;
              color:<?= $isActive?'var(--accent-blue)':'var(--text-muted)' ?>;font-weight:<?= $isActive?'600':'400' ?>;">
        <?= $label ?>
        <?php if ($key==='bookings' && $timeBookings): ?>
        <span style="background:var(--accent-blue);color:#fff;border-radius:10px;padding:1px 5px;font-size:9px;margin-left:3px;"><?= count($timeBookings) ?></span>
        <?php endif; ?>
        <?php if ($key==='quality' && $qualityRecords): ?>
        <span style="background:<?= $qvFailCount>0?'var(--accent-danger)':'#3fb950' ?>;color:#fff;border-radius:10px;padding:1px 5px;font-size:9px;margin-left:3px;">
            <?= $qvFailCount>0 ? $qvFailCount.' fail' : count($qualityRecords).' pass' ?>
        </span>
        <?php endif; ?>
        <?php if ($key==='changelog' && $changeLog): ?>
        <span style="background:var(--border);color:var(--text-muted);border-radius:10px;padding:1px 5px;font-size:9px;margin-left:3px;"><?= count($changeLog) ?></span>
        <?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>

<?php if ($activeTab === 'detail'): ?>
<!-- ══ WO DETAIL ══════════════════════════════════════════════════════════ -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
    <div class="card">
        <div class="card-title">Work Order Details</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
            <div><span class="text-dim">WO:</span> <code><?= htmlspecialchars($wo['wo_number']) ?></code></div>
            <div><span class="text-dim">Org:</span> <code><?= htmlspecialchars($wo['org_code']) ?></code></div>
            <div><span class="text-dim">Part:</span> <code><?= htmlspecialchars($wo['part_number']) ?></code></div>
            <div><span class="text-dim">Control:</span> <?= $wo['control_type']==='SERIAL'?'Serialised':'Lot' ?></div>
            <div><span class="text-dim">Routing:</span> <code><?= htmlspecialchars($wo['routing_number']) ?></code></div>
            <div><span class="text-dim">WO Routing Rev:</span> <code><?= htmlspecialchars($wo['routing_rev']) ?></code></div>
            <?php if ($wo['lot_number']): ?>
            <div><span class="text-dim">Lot:</span> <code><?= htmlspecialchars($wo['lot_number']) ?></code></div>
            <?php endif; ?>
            <div><span class="text-dim">Created by:</span> <?= htmlspecialchars($wo['creator_name']??'—') ?></div>
            <div><span class="text-dim">Created at:</span> <?= displayDate($wo['created_at']) ?></div>
            <?php if (!empty($wo['planned_start'])): ?>
            <div><span class="text-dim">Planned Start:</span> <?= displayDate($wo['planned_start'],'d M Y H:i') ?></div>
            <?php endif; ?>
            <?php if (!empty($wo['planned_finish'])): ?>
            <div><span class="text-dim">Planned Finish:</span> <?= displayDate($wo['planned_finish'],'d M Y H:i') ?></div>
            <?php endif; ?>
        </div>
        <?php if ($wo['notes']): ?>
        <div style="margin-top:12px;padding:10px;background:var(--bg);border-radius:5px;font-size:13px;color:var(--text-muted);">
            <?= nl2br(htmlspecialchars($wo['notes'])) ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
            <?= $wo['control_type']==='SERIAL' ? 'Serial Numbers' : 'Lot Record' ?>
            <span class="text-dim" style="font-size:12px;margin-left:8px;">(<?= count($serials) ?>)</span>
        </div>
        <div class="table-wrap">
            <table style="margin:0;">
                <thead><tr><th>Serial / Lot</th><th>Current Op</th><th>Status</th><th>Last Operator</th></tr></thead>
                <tbody>
                <?php foreach ($serials as $sn): ?>
                <tr>
                    <td><code style="font-size:12px;"><?= htmlspecialchars($sn['serial_number']) ?></code></td>
                    <td style="font-size:12px;">
                        <?php if ($sn['op_number']): ?>
                        <code><?= str_pad($sn['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                        <?= htmlspecialchars($sn['op_name']??'') ?>
                        <?php else: ?><span class="text-dim">—</span><?php endif; ?>
                    </td>
                    <td><?= serialStatusBadge($sn['status']) ?></td>
                    <td style="font-size:11px;color:var(--text-muted);">
                        <?= htmlspecialchars($sn['last_operator'] ?? '—') ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($activeTab === 'analytics'): ?>
<!-- ══ OPERATION ANALYTICS ════════════════════════════════════════════════ -->
<?php if (empty($opAnalytics)): ?>
<div class="card" style="text-align:center;color:var(--text-dim);padding:32px;">
    No completed operation records yet.
</div>
<?php else:
    $maxAvg = max(array_map(fn($r) => max((float)$r['avg_actual_mins'], (float)$r['std_mins']), $opAnalytics));
?>
<div class="card" style="margin-bottom:16px;padding:16px 20px;">
    <div style="font-size:13px;font-weight:700;margin-bottom:14px;color:var(--text-muted);
                text-transform:uppercase;letter-spacing:.06em;">Duration vs Standard — Average Minutes per Serial</div>
    <?php foreach ($opAnalytics as $oa):
        $avg = (float)$oa['avg_actual_mins'];
        $std = (float)$oa['std_mins'];
        $avgPct = $maxAvg > 0 ? round(($avg / $maxAvg) * 100) : 0;
        $stdPct = $maxAvg > 0 ? round(($std / $maxAvg) * 100) : 0;
        $eff    = ($std > 0 && $avg > 0) ? round(($std / $avg) * 100) : null;
        $effColour = $eff === null ? 'var(--text-dim)'
                   : ($eff >= 90 ? '#3fb950' : ($eff >= 70 ? 'var(--accent-warn)' : 'var(--accent-danger)'));
    ?>
    <div style="margin-bottom:14px;">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;">
            <span>
                <code style="color:var(--accent-blue);">Op <?= str_pad($oa['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                <?= htmlspecialchars($oa['op_name']) ?>
                <span class="text-dim">(<?= $oa['serials_worked'] ?> serials)</span>
            </span>
            <span style="display:flex;gap:12px;align-items:center;">
                <span class="text-dim">Avg: <strong style="color:var(--text);"><?= $avg ?>m</strong></span>
                <?php if ($std > 0): ?>
                <span class="text-dim">Std: <?= $std ?>m</span>
                <span style="font-weight:700;color:<?= $effColour ?>;"><?= $eff ?>%</span>
                <?php endif; ?>
                <?php if ($oa['overrun_count'] > 0): ?>
                <span class="badge badge-red" style="font-size:9px;"><?= $oa['overrun_count'] ?> overrun<?= $oa['overrun_count']>1?'s':'' ?></span>
                <?php endif; ?>
            </span>
        </div>
        <!-- Actual bar -->
        <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden;margin-bottom:3px;">
            <div style="height:100%;width:<?= $avgPct ?>%;border-radius:4px;
                        background:<?= $eff!==null&&$eff<90?'var(--accent-danger)':'var(--accent-blue)' ?>;"></div>
        </div>
        <?php if ($std > 0): ?>
        <!-- Standard bar (ghost) -->
        <div style="height:4px;background:var(--border);border-radius:4px;overflow:hidden;">
            <div style="height:100%;width:<?= $stdPct ?>%;border-radius:4px;
                        background:rgba(110,118,129,.4);"></div>
        </div>
        <?php endif; ?>
        <div style="display:flex;gap:16px;font-size:10px;color:var(--text-dim);margin-top:3px;">
            <span>Min: <?= $oa['min_actual_mins'] ?>m</span>
            <span>Max: <?= $oa['max_actual_mins'] ?>m</span>
            <span>Total: <?= $oa['total_mins'] ?>m</span>
        </div>
    </div>
    <?php endforeach; ?>
    <div style="font-size:11px;color:var(--text-dim);margin-top:4px;">
        <span style="display:inline-block;width:12px;height:8px;background:var(--accent-blue);border-radius:2px;vertical-align:middle;margin-right:4px;"></span>Actual avg
        <span style="display:inline-block;width:12px;height:4px;background:rgba(110,118,129,.4);border-radius:2px;vertical-align:middle;margin:0 4px 0 12px;"></span>Standard
    </div>
</div>
<?php endif; ?>

<?php elseif ($activeTab === 'quality'): ?>
<!-- ══ QUALITY RECORDS ════════════════════════════════════════════════════ -->
<?php if (empty($qualityRecords)): ?>
<div class="card" style="text-align:center;color:var(--text-dim);padding:32px;">
    No quality variable results recorded on this work order.
</div>
<?php else:
    // Group by op then serial
    $byOp = [];
    foreach ($qualityRecords as $qr) {
        $byOp[$qr['op_number'] . '|' . $qr['op_name']][$qr['serial_number']][] = $qr;
    }
?>
<?php foreach ($byOp as $opKey => $bySerial):
    [$opNum, $opName] = explode('|', $opKey, 2);
?>
<div class="card" style="margin-bottom:16px;padding:0;overflow:hidden;">
    <div style="padding:10px 16px;border-bottom:1px solid var(--border);background:var(--bg);
                display:flex;align-items:center;gap:10px;">
        <code style="color:var(--accent-blue);font-weight:700;">Op <?= str_pad($opNum,3,'0',STR_PAD_LEFT) ?></code>
        <span style="font-weight:600;"><?= htmlspecialchars($opName) ?></span>
    </div>
    <?php foreach ($bySerial as $serialNum => $results): ?>
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);">
        <div style="font-size:12px;font-weight:700;font-family:monospace;
                    color:var(--accent-blue);margin-bottom:10px;">
            Serial: <?= htmlspecialchars($serialNum) ?>
        </div>

        <?php foreach ($results as $qr):
            $val   = (float)$qr['result_value'];
            $lower = $qr['lower_limit'] !== null ? (float)$qr['lower_limit'] : null;
            $upper = $qr['upper_limit'] !== null ? (float)$qr['upper_limit'] : null;
            $target= $qr['target_value'] !== null ? (float)$qr['target_value'] : null;
            $uom   = $qr['uom_code'] ? $qr['uom_code'] : '';

            // Position in spec (0% = lower limit, 100% = upper limit)
            $specPct = null;
            if ($lower !== null && $upper !== null && $upper > $lower) {
                $specPct = round(($val - $lower) / ($upper - $lower) * 100);
                $specPct = max(0, min(100, $specPct)); // clamp for display
            }
            $inSpec = (bool)$qr['is_in_spec'];
        ?>
        <div style="margin-bottom:12px;padding:10px 12px;border-radius:6px;
                    background:<?= $inSpec?'rgba(63,185,80,.05)':'rgba(248,81,73,.05)' ?>;
                    border-left:3px solid <?= $inSpec?'#3fb950':'var(--accent-danger)' ?>;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;flex-wrap:wrap;gap:6px;">
                <div>
                    <code style="color:var(--accent-blue);font-weight:600;font-size:11px;"><?= htmlspecialchars($qr['qv_code']) ?></code>
                    <span style="font-size:12px;margin-left:6px;"><?= htmlspecialchars($qr['qv_name']) ?></span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="font-size:18px;font-weight:800;font-family:monospace;
                                 color:<?= $inSpec?'#3fb950':'var(--accent-danger)' ?>;">
                        <?= $val ?><?= $uom ? ' '.$uom : '' ?>
                    </span>
                    <?= $inSpec ? '<span class="badge badge-green">PASS</span>' : '<span class="badge badge-red">FAIL</span>' ?>
                    <?php if ($qr['nc_number']): ?>
                    <span class="badge badge-red" style="font-size:10px;">NC: <?= htmlspecialchars($qr['nc_number']) ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($lower !== null && $upper !== null): ?>
            <!-- Spec position indicator -->
            <div style="margin-bottom:6px;">
                <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-dim);margin-bottom:2px;">
                    <span>Lower <?= $lower ?><?= $uom ?></span>
                    <?php if ($target !== null): ?><span>Target <?= $target ?><?= $uom ?></span><?php endif; ?>
                    <span>Upper <?= $upper ?><?= $uom ?></span>
                </div>
                <div style="height:10px;background:var(--border);border-radius:5px;position:relative;overflow:visible;">
                    <!-- Green spec zone -->
                    <div style="position:absolute;inset:0;background:rgba(63,185,80,.15);border-radius:5px;"></div>
                    <?php if ($target !== null): ?>
                    <!-- Target line -->
                    <?php $tgtPct = round(($target-$lower)/($upper-$lower)*100); ?>
                    <div style="position:absolute;top:-2px;bottom:-2px;width:2px;
                                left:<?= $tgtPct ?>%;background:rgba(56,139,253,.6);border-radius:1px;"></div>
                    <?php endif; ?>
                    <!-- Value marker -->
                    <div style="position:absolute;top:-3px;width:16px;height:16px;border-radius:50%;
                                left:calc(<?= $specPct ?>% - 8px);
                                background:<?= $inSpec?'#3fb950':'var(--accent-danger)' ?>;
                                border:2px solid var(--bg-card);box-shadow:0 1px 3px rgba(0,0,0,.3);"></div>
                </div>
            </div>
            <?php endif; ?>

            <div style="font-size:10px;color:var(--text-dim);">
                Recorded by <strong><?= htmlspecialchars($qr['collected_by_name']??'—') ?></strong>
                at <?= displayDate($qr['collected_at'], 'd M Y H:i') ?>
            </div>

            <?php
            // Show tools/TE used on this serial+op
            $toolKey = $qr['serial_id'] . ':' . $qr['op_id'];
            $usedTools = $toolsBySerialOp[$toolKey] ?? [];
            if ($usedTools):
            ?>
            <div style="margin-top:6px;font-size:10px;color:var(--text-dim);">
                <strong>Tools/TE used:</strong>
                <?php foreach ($usedTools as $t): ?>
                <span style="display:inline-block;margin-right:8px;">
                    <code style="color:var(--accent-blue);"><?= htmlspecialchars($t['asset_number']) ?></code>
                    <?= htmlspecialchars($t['tool_desc']) ?>
                </span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php elseif ($activeTab === 'bookings'): ?>
<!-- ══ TIME BOOKINGS ══════════════════════════════════════════════════════ -->
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;">
        <span style="font-weight:600;font-size:14px;">Time Bookings</span>
        <span class="text-dim" style="font-size:12px;"><?= count($timeBookings) ?> records</span>
        <span style="margin-left:auto;font-size:13px;">
            Total booked: <strong><?= $hrs ?>h <?= $mins ?>m</strong>
        </span>
    </div>
    <?php if ($timeBookings): ?>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr>
                    <th>Serial</th>
                    <th>Op</th>
                    <th>Operator</th>
                    <th>Event</th>
                    <th>Clocked On</th>
                    <th>Clocked Off</th>
                    <th>Duration</th>
                    <th>Standard Time</th>
                    <th>Efficiency</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $totalActual = 0;
            $totalStd    = 0;
            foreach ($timeBookings as $tb):
                $durMins = (float)$tb['duration_mins'];
                $stdMins = (int)($tb['std_mins'] ?? 0);
                $isOver  = $stdMins > 0 && $durMins > $stdMins;
                $effPct  = ($stdMins > 0 && $durMins > 0) ? round(($stdMins / $durMins) * 100) : null;
                $totalActual += $durMins;
                $totalStd    += $stdMins;
                $durH = floor($durMins/60); $durM = round(fmod($durMins,60),1);
            ?>
            <tr>
                <td><code style="font-size:11px;"><?= htmlspecialchars($tb['serial_number']) ?></code></td>
                <td style="font-size:12px;white-space:nowrap;">
                    <code><?= str_pad($tb['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                    <?= htmlspecialchars(substr($tb['op_name']??'',0,20)) ?>
                </td>
                <td style="font-size:12px;"><?= htmlspecialchars($tb['operator_name']??'—') ?></td>
                <td><span class="badge badge-grey" style="font-size:10px;"><?= htmlspecialchars($tb['event_type']) ?></span></td>
                <td style="font-size:11px;white-space:nowrap;font-family:monospace;">
                    <?= $tb['clocked_on_at'] ? displayDate($tb['clocked_on_at'],'d M H:i') : '—' ?>
                </td>
                <td style="font-size:11px;white-space:nowrap;font-family:monospace;">
                    <?= $tb['clocked_off_at'] ? displayDate($tb['clocked_off_at'],'d M H:i') : '—' ?>
                </td>
                <td style="font-family:monospace;font-size:12px;<?= $isOver?'color:var(--accent-danger);font-weight:700;':'' ?>">
                    <?= $durH>0 ? "{$durH}h " : '' ?><?= round($durM) ?>m
                </td>
                <td style="font-size:12px;color:var(--text-dim);">
                    <?= $stdMins > 0 ? $stdMins.'m' : '—' ?>
                </td>
                <td style="font-family:monospace;font-size:12px;">
                    <?php if ($effPct !== null): ?>
                    <span style="color:<?= $effPct>=90?'#3fb950':($effPct>=70?'var(--accent-warn)':'var(--accent-danger)') ?>;font-weight:700;">
                        <?= $effPct ?>%
                    </span>
                    <?php if ($isOver): ?>
                    <span class="badge badge-red" style="font-size:9px;margin-left:4px;">+<?= round($durMins-$stdMins) ?>m</span>
                    <?php endif; ?>
                    <?php else: ?><span class="text-dim">—</span><?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr style="border-top:2px solid var(--border);">
                    <td colspan="6" style="padding:10px 12px;font-weight:600;font-size:13px;">Totals</td>
                    <td style="font-family:monospace;font-size:12px;font-weight:700;padding:10px 12px;">
                        <?= floor($totalActual/60) ?>h <?= round(fmod($totalActual,60)) ?>m
                    </td>
                    <td style="font-size:12px;color:var(--text-dim);padding:10px 12px;">
                        <?= floor($totalStd/60) ?>h <?= round(fmod($totalStd,60)) ?>m
                    </td>
                    <td style="padding:10px 12px;">
                        <?php if ($totalStd > 0 && $totalActual > 0):
                            $overallEff = round(($totalStd/$totalActual)*100);
                        ?>
                        <span style="font-weight:700;font-family:monospace;
                            color:<?= $overallEff>=90?'#3fb950':($overallEff>=70?'var(--accent-warn)':'var(--accent-danger)') ?>;">
                            <?= $overallEff ?>%
                        </span>
                        <?php endif; ?>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php else: ?>
    <div style="text-align:center;color:var(--text-dim);padding:32px;">
        No time bookings yet.
    </div>
    <?php endif; ?>
</div>

<?php elseif ($activeTab === 'routing'): ?>
<!-- ══ ROUTING ════════════════════════════════════════════════════════════ -->
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
        Routing — <?= htmlspecialchars($wo['routing_number']) ?> Rev <?= htmlspecialchars($wo['routing_rev']) ?>
    </div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr><th>Op</th><th>Name</th><th>Type</th><th>Behaviour</th><th>Dept</th><th>Planned Setup (m)</th><th>Planned Actual (m)</th></tr>
            </thead>
            <tbody>
            <?php foreach ($operations as $op):
                $isNC = $op['behaviour']==='NON-CLOCKING';
            ?>
            <tr style="<?= $isNC?'color:var(--text-dim);':'' ?>">
                <td><code style="font-size:12px;"><?= str_pad($op['op_number'],3,'0',STR_PAD_LEFT) ?></code></td>
                <td style="font-size:12px;"><?= htmlspecialchars($op['op_name']) ?></td>
                <td style="font-size:11px;"><?= htmlspecialchars(str_replace('_',' ',$op['op_type'])) ?></td>
                <td><?= $isNC
                    ? '<span class="badge badge-grey" style="font-size:10px;">AUTO</span>'
                    : '<span class="badge badge-blue" style="font-size:10px;">CLOCK</span>' ?></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($op['dept_code']??'—') ?></code></td>
                <td class="text-dim" style="font-size:11px;"><?= (int)$op['setup_mins'] ?></td>
                <td class="text-dim" style="font-size:11px;"><?= (int)$op['actual_mins'] ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($activeTab === 'changelog'): ?>
<!-- ══ CHANGE LOG ════════════════════════════════════════════════════════ -->
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
        Change Log <span class="text-dim" style="font-size:12px;font-weight:400;">(<?= count($changeLog) ?> entries)</span>
    </div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr><th>Date/Time</th><th>Event</th><th>Operation</th><th>User</th><th>Note</th></tr>
            </thead>
            <tbody>
            <?php foreach ($changeLog as $cl): ?>
            <tr>
                <td style="font-size:11px;white-space:nowrap;font-family:monospace;">
                    <?= displayDate($cl['changed_at'],'d M Y H:i') ?>
                </td>
                <td>
                    <?php
                    $badgeClass = match(true) {
                        str_starts_with($cl['change_type'],'NC_')       => 'badge-red',
                        str_starts_with($cl['change_type'],'HOLD')      => 'badge-yellow',
                        str_starts_with($cl['change_type'],'STATUS')    => 'badge-blue',
                        str_starts_with($cl['change_type'],'OP_COMP')   => 'badge-green',
                        str_starts_with($cl['change_type'],'WO_COMPL')  => 'badge-green',
                        default                                          => 'badge-grey',
                    };
                    ?>
                    <span class="badge <?= $badgeClass ?>" style="font-size:10px;">
                        <?= htmlspecialchars(str_replace('_',' ',$cl['change_type'])) ?>
                    </span>
                </td>
                <td style="font-size:12px;white-space:nowrap;">
                    <?php if ($cl['op_number']): ?>
                    <code>Op <?= str_pad($cl['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                    <span class="text-dim"><?= htmlspecialchars($cl['op_name']??'') ?></span>
                    <?php else: ?>
                    <span class="text-dim">—</span>
                    <?php endif; ?>
                </td>
                <td style="font-size:12px;"><?= htmlspecialchars($cl['known_as']??'—') ?></td>
                <td style="font-size:12px;"><?= htmlspecialchars($cl['note']??'') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$changeLog): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--text-dim);padding:20px;">No changes recorded.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php renderPageEnd(); ?>
