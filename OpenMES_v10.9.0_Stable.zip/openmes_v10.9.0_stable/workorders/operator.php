<?php
/**
 * workorders/operator.php — Operator Execution Screen
 * Version: 10.5.4
 * Fix: IT Admin clock-on now works (orgScope alias fix)
 * Fix: Operations displayed as vertical list with serials grouped under each op
 * v10.1.0: Quality variable collection panel wired in for inspection/test ops
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();

$scope    = orgScope(); // no alias — used for WO lookup
$searchWo = trim($_GET['wo']       ?? '');
$searchRes= trim($_GET['resource'] ?? '');
$showMine = isset($_GET['mine']);
$woId     = (int)($_GET['id']      ?? 0);

$wo = null;
$workOrders = [];

// ── Scope for joins (needs alias) ─────────────────────────────────────────────
$scopeAlias = orgScope('w');

if ($woId) {
    $wo = dbFetchOne(
        "SELECT w.*,o.code AS org_code,p.part_number,p.description AS part_desc,
                r.routing_number,r.revision_label AS routing_rev,r.id AS routing_id
         FROM work_orders w
         JOIN orgs o ON o.id=w.org_id JOIN parts p ON p.id=w.part_id
         JOIN routings r ON r.id=w.routing_id
         WHERE w.id=? AND ({$scopeAlias['sql']}) AND w.status IN ('OPEN','IN_PROGRESS','ON_HOLD')",
        array_merge([$woId], $scopeAlias['params'])
    );
} elseif ($searchWo !== '') {
    $wo = dbFetchOne(
        "SELECT w.*,o.code AS org_code,p.part_number,p.description AS part_desc,
                r.routing_number,r.revision_label AS routing_rev,r.id AS routing_id
         FROM work_orders w
         JOIN orgs o ON o.id=w.org_id JOIN parts p ON p.id=w.part_id
         JOIN routings r ON r.id=w.routing_id
         WHERE w.wo_number=? AND ({$scopeAlias['sql']}) AND w.status IN ('OPEN','IN_PROGRESS','ON_HOLD')",
        array_merge([strtoupper($searchWo)], $scopeAlias['params'])
    );
} elseif ($showMine) {
    $workOrders = dbFetchAll(
        "SELECT DISTINCT w.*,o.code AS org_code,p.part_number,p.description AS part_desc
         FROM wo_active_clocks ac
         JOIN work_orders w ON w.id=ac.wo_id
         JOIN orgs o ON o.id=w.org_id JOIN parts p ON p.id=w.part_id
         WHERE ac.user_id=? AND ({$scopeAlias['sql']})",
        array_merge([$_SESSION['user_id']], $scopeAlias['params'])
    );
} elseif ($searchRes !== '') {
    $workOrders = dbFetchAll(
        "SELECT DISTINCT w.*,o.code AS org_code,p.part_number,p.description AS part_desc
         FROM serial_numbers sn
         JOIN work_orders w ON w.id=sn.wo_id
         JOIN orgs o ON o.id=w.org_id JOIN parts p ON p.id=w.part_id
         JOIN routing_operations ro ON ro.id=sn.current_op_id
         JOIN resources res ON res.id=ro.resource_id
         WHERE res.code LIKE ? AND ({$scopeAlias['sql']}) AND w.status IN ('OPEN','IN_PROGRESS')
           AND sn.status NOT IN ('COMPLETE','SCRAPPED')",
        array_merge(['%'.$searchRes.'%'], $scopeAlias['params'])
    );
}

// ── Load WO execution data ────────────────────────────────────────────────────
$operations   = [];
$serials      = [];
$activeClockMap = [];
$opMap        = [];
$locations    = [];

if ($wo) {
    $operations = dbFetchAll(
        "SELECT ro.*, d.code AS dept_code, d.name AS dept_name,
                res.code AS res_code, res.name AS res_name,
                doc.id AS doc_id, doc.doc_number
         FROM routing_operations ro
         LEFT JOIN departments d   ON d.id  = ro.department_id
         LEFT JOIN resources res   ON res.id = ro.resource_id
         LEFT JOIN documents doc   ON doc.id = ro.document_id AND doc.status='APPROVED'
         WHERE ro.routing_id=?
         ORDER BY ro.sort_order, ro.op_number",
        [$wo['routing_id']]
    );
    $opMap = array_column($operations, null, 'id');

    $serials = dbFetchAll(
        "SELECT sn.*, ro.op_number, ro.op_name, ro.behaviour,
                ro.op_type, ro.actual_mins AS std_mins, ro.id AS op_id_curr,
                ro.sort_order
         FROM serial_numbers sn
         LEFT JOIN routing_operations ro ON ro.id = sn.current_op_id
         WHERE sn.wo_id=? ORDER BY sn.serial_number",
        [$wo['id']]
    );

    // Map active clocks for current user
    $clockRows = dbFetchAll(
        "SELECT serial_id, clocked_on_at, op_id FROM wo_active_clocks WHERE wo_id=? AND user_id=?",
        [$wo['id'], $_SESSION['user_id']]
    );
    foreach ($clockRows as $cr) {
        $activeClockMap[$cr['serial_id']] = $cr['clocked_on_at'];
    }

    $locations = dbFetchAll(
        "SELECT id,code,name FROM inventory_locations WHERE org_id=? AND active=1 ORDER BY code",
        [$wo['org_id']]
    );

    // Group serials by current_op_id
    $serialsByOp = [];
    foreach ($serials as $sn) {
        $serialsByOp[$sn['current_op_id'] ?? 'done'][] = $sn;
    }

    // v10.1.0: Load quality variables per operation (inspection/test ops only)
    $qvByOp = [];
    $allQvs = dbFetchAll(
        "SELECT qv.*, ro.id AS op_id, u.code AS uom_code
           FROM quality_variables qv
           JOIN routing_operations ro ON ro.id = qv.op_id
           LEFT JOIN uom u ON u.id = qv.uom_id
          WHERE ro.routing_id = ? AND qv.active = 1
          ORDER BY qv.code",
        [$wo['routing_id']]
    );
    foreach ($allQvs as $qv) {
        $qvByOp[$qv['op_id']][] = $qv;
    }

    // Load already-collected results for this WO so we don't re-prompt
    $collectedResults = dbFetchAll(
        "SELECT serial_id, op_id FROM quality_results WHERE wo_id=?",
        [$wo['id']]
    );
    // Key: "serial_id:op_id"
    $collectedSet = [];
    foreach ($collectedResults as $cr) {
        $collectedSet[$cr['serial_id'] . ':' . $cr['op_id']] = true;
    }
} // end if ($wo)

renderPageStart('Operator Screen');
?>

<style>
/* ── Operator screen ── */
.wo-header {
    background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);
    padding:14px 18px;margin-bottom:14px;display:flex;gap:16px;align-items:center;flex-wrap:wrap;
}
.wo-title { font-size:20px;font-weight:700;font-family:monospace;color:var(--accent-blue); }

/* Op section */
.op-section {
    background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);
    margin-bottom:12px;overflow:hidden;
}
.op-section-header {
    padding:12px 16px;border-bottom:1px solid var(--border);
    display:flex;align-items:center;gap:12px;flex-wrap:wrap;
}
.op-section.has-serials .op-section-header { background:rgba(56,139,253,.06); }
.op-section.all-done    .op-section-header { background:rgba(35,134,54,.06); }
.op-section.non-clocking .op-section-header { background:var(--bg-card2); }

.op-num  { font-family:monospace;font-size:16px;font-weight:800;min-width:48px; }
.op-name { font-weight:600;font-size:14px;flex:1; }
.op-meta { font-size:11px;color:var(--text-dim);display:flex;gap:10px;flex-wrap:wrap; }

/* Serial rows within an op */
.serial-list { padding:10px 16px;display:flex;flex-direction:column;gap:6px; }
.serial-row {
    display:flex;align-items:center;gap:12px;padding:8px 12px;
    border:1px solid var(--border);border-radius:5px;background:var(--bg);
    cursor:pointer;transition:border-color .12s,background .12s;
}
.serial-row:hover { border-color:var(--accent-blue); }
.serial-row.not-started { border-color:var(--border); }
.serial-row.in-progress { border-color:var(--accent-blue);background:rgba(56,139,253,.06); }
.serial-row.clocked-on  { border-color:#3fb950;background:rgba(35,134,54,.08); }
.serial-row.complete    { border-color:var(--accent);background:rgba(35,134,54,.05);opacity:.7; }
.serial-row.on-hold     { border-color:var(--accent-warn);background:rgba(210,153,34,.07); }
.serial-row.scrapped    { border-color:var(--accent-danger);opacity:.5; }

.serial-row input[type=checkbox] { flex-shrink:0;width:16px;height:16px;cursor:pointer; }
.serial-sn   { font-family:monospace;font-size:13px;font-weight:600;min-width:120px; }
.serial-status { font-size:11px; }
.serial-timer  { font-family:monospace;font-size:12px;color:#3fb950;margin-left:auto; }
.serial-timer.overrun { color:var(--accent-danger); }

/* Action bar */
.action-bar {
    position:sticky;bottom:0;background:var(--bg-card2);
    border:1px solid var(--border);border-radius:var(--radius);
    padding:12px 16px;margin-bottom:14px;
    display:flex;gap:10px;flex-wrap:wrap;align-items:center;
    box-shadow:0 -2px 8px rgba(0,0,0,.3);
    z-index:40;
}

/* PDF panel */
/* F054: pdf-panel removed */
</style>

<!-- Search bar -->
<div class="page-header page-header-row" style="margin-bottom:12px;">
    <div><h1>Operator Screen</h1><p>Search for a work order to begin execution.</p></div>
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">WO Number</label>
            <input type="text" name="wo" value="<?= htmlspecialchars($searchWo) ?>"
                   placeholder="e.g. BIKE0000001" style="width:170px;text-transform:uppercase;"
                   oninput="this.value=this.value.toUpperCase()">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Resource / Workstation</label>
            <input type="text" name="resource" value="<?= htmlspecialchars($searchRes) ?>"
                   placeholder="e.g. ASSY01" style="width:140px;">
        </div>
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
    <a href="?mine=1" class="btn <?= $showMine?'btn-blue':'btn-secondary' ?>">My Clocked WOs</a>
    <a href="<?= SITE_SUBPATH ?>/workorders/operator.php" class="btn btn-secondary">Clear</a>
</div>

<!-- WO list (search results) -->
<?php if ($workOrders && !$wo): ?>
<div class="card">
    <div class="card-title"><?= $showMine ? 'Work Orders You Are Clocked On To' : 'Matching Work Orders' ?></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>WO Number</th><th>Org</th><th>Part</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($workOrders as $row): ?>
            <tr>
                <td><code style="font-family:monospace;font-weight:700;color:var(--accent-blue);"><?= htmlspecialchars($row['wo_number']) ?></code></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($row['org_code']) ?></code></td>
                <td><?= htmlspecialchars($row['part_number']) ?> — <?= htmlspecialchars(substr($row['part_desc'],0,40)) ?></td>
                <td><span class="badge badge-blue"><?= htmlspecialchars($row['status']) ?></span></td>
                <td><a href="?id=<?= $row['id'] ?>" class="btn btn-primary" style="padding:4px 12px;font-size:12px;">Open</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif (($searchWo || $woId) && !$wo): ?>
<div class="alert alert-warning">⚠ Work order not found, not active, or you don't have access to it.</div>

<?php elseif ($wo): ?>

<!-- ══ WO EXECUTION ══════════════════════════════════════════════════════════ -->

<?php
$isFullHold = ($wo['status']==='ON_HOLD' && $wo['hold_type']==='HARD');
$canWork    = !$isFullHold;
?>

<!-- WO Header -->
<div class="wo-header">
    <div>
        <div class="wo-title"><?= htmlspecialchars($wo['wo_number']) ?></div>
        <div style="font-size:13px;color:var(--text-muted);"><?= htmlspecialchars($wo['part_number']) ?> — <?= htmlspecialchars($wo['part_desc']) ?></div>
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-left:auto;">
        <span class="badge <?= $wo['status']==='ON_HOLD'?'badge-yellow':'badge-blue' ?>" style="font-size:12px;padding:5px 12px;">
            <?= htmlspecialchars($wo['status']) ?>
            <?= $wo['hold_type'] ? ' — '.htmlspecialchars($wo['hold_type']).' HOLD' : '' ?>
        </span>
        <span class="text-dim" style="font-size:12px;">Rev <code><?= htmlspecialchars($wo['routing_rev']) ?></code></span>
        <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $wo['id'] ?>"
           class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">ℹ Info</a>
    </div>
</div>

<?php if ($isFullHold): ?>
<div class="alert alert-warning">
    ⛔ <strong>Hard Hold</strong> — No work is permitted on this order. Contact your Engineer to release the hold.
</div>
<?php elseif ($wo['status']==='ON_HOLD'): ?>
<div class="alert alert-warning">
    ⚠ <strong>Soft Hold</strong> — Work may continue up to the next Inspection operation only.
</div>
<?php endif; ?>

<!-- Sticky action bar -->
<div class="action-bar" id="action-bar">
    <span style="font-size:12px;color:var(--text-muted);" id="sel-count">0 serials selected</span>
    <?php if ($canWork): ?>
    <button onclick="openNCModal()" class="btn btn-danger" style="background:var(--accent-danger);">⚠ Raise NC</button>
    <button onclick="clockAction('clock_on','selected')"  class="btn btn-primary">⏱ Clock On</button>
    <button onclick="clockAction('clock_on','all')"       class="btn btn-secondary">⏱ Clock On All</button>
    <button onclick="clockAction('clock_off','selected')" class="btn btn-secondary">⏹ Clock Off</button>
    <button onclick="clockAction('complete','selected')"  class="btn btn-primary" style="background:var(--accent);">✓ Complete</button>
    <?php endif; ?>
    <button onclick="selectAll(true)"  class="btn btn-secondary" style="margin-left:auto;padding:4px 10px;font-size:11px;">All</button>
    <button onclick="selectAll(false)" class="btn btn-secondary" style="padding:4px 10px;font-size:11px;">None</button>
</div>

<!-- F088: Only show ops that can be worked on (not COMPLETE, not SCRAPPED, not NON-CLOCKING unless clocked) -->
<!-- F054: PDF panel removed — work instructions open in new tab via serve_pdf.php -->

<!-- Operations — listed vertically, serials grouped under each op -->
<?php foreach ($operations as $op):
    $opSerials  = $serialsByOp[$op['id']] ?? [];
    $doneCount  = count(array_filter($serials, fn($s) => $s['status']==='COMPLETE'));
    $isNC       = $op['behaviour'] === 'NON-CLOCKING';
    $hasSns     = count($opSerials) > 0;
    $isBTS      = $op['op_type'] === 'BOOK_TO_STOCK';

    // Op section class
    $secClass = 'op-section';
    if ($isNC)       $secClass .= ' non-clocking';
    elseif ($hasSns) $secClass .= ' has-serials';
    else {
        $passedCheck = dbFetchOne(
            "SELECT COUNT(DISTINCT serial_id) AS n FROM wo_clock_events WHERE wo_id=? AND op_id=? AND event_type='COMPLETE'",
            [$wo['id'], $op['id']]
        )['n'] ?? 0;
        if ($passedCheck > 0) $secClass .= ' all-done';
    }

    // Count complete serials that just finished this routing
    // (they won't be in opSerials anymore — check done count)
?>
<div class="<?= $secClass ?>" data-op-id="<?= $op['id'] ?>">
    <div class="op-section-header">
        <div class="op-num"><?= str_pad($op['op_number'],3,'0',STR_PAD_LEFT) ?></div>
        <div>
            <div class="op-name"><?= htmlspecialchars($op['op_name']) ?></div>
            <div class="op-meta">
                <span><?= htmlspecialchars(str_replace('_',' ',$op['op_type'])) ?></span>
                <?php if ($op['dept_code']): ?>
                <span>📍 <?= htmlspecialchars($op['dept_code']) ?><?= $op['res_code'] ? ' › ' . htmlspecialchars($op['res_code']) : '' ?></span>
                <?php endif; ?>
                <?php if ($op['setup_mins'] || $op['actual_mins']): ?>
                <span>⏱ Setup <?= $op['setup_mins'] ?>m / Actual <?= $op['actual_mins'] ?>m</span>
                <?php endif; ?>
                <?php if ($isNC): ?>
                <span class="badge badge-grey" style="font-size:10px;">NON-CLOCKING — AUTO ADVANCE</span>
                <?php endif; ?>
            </div>
        </div>
        <div style="margin-left:auto;display:flex;gap:8px;align-items:center;">
            <?php if ($hasSns): ?>
            <span class="badge badge-blue"><?= count($opSerials) ?> unit<?= count($opSerials)!==1?'s':'' ?> here</span>
            <?php elseif (!$isNC): ?>
                <?php
                // How many serials have passed through this op?
                $passedThisOp = dbFetchOne(
                    "SELECT COUNT(DISTINCT serial_id) AS n FROM wo_clock_events
                     WHERE wo_id=? AND op_id=? AND event_type='COMPLETE'",
                    [$wo['id'], $op['id']]
                )['n'] ?? 0;
                ?>
                <?php if ($passedThisOp > 0): ?>
                <span class="badge badge-green">✓ <?= $passedThisOp ?> Complete</span>
                <?php else: ?>
                <span class="badge badge-grey" style="opacity:.5;">Not reached</span>
                <?php endif; ?>
            <?php endif; ?>
            <?php
            // F089: Show required tools for this operation
            $reqToolsForOp = dbFetchAll(
                "SELECT ort.tool_id, ct.asset_number, ct.description, ct.calibration_due,
                        CASE WHEN ct.calibration_due IS NULL THEN 'NO_CAL'
                             WHEN ct.calibration_due < CURDATE() THEN 'EXPIRED'
                             ELSE 'IN_DATE' END AS cal_status
                   FROM op_required_tools ort
                   JOIN calibration_tools ct ON ct.id=ort.tool_id
                  WHERE ort.op_id=?",
                [$op['op_id_curr'] ?? $op['id'] ?? 0]
            );
            if (!empty($reqToolsForOp) && ($op['clocked_on'] ?? false)):
            ?>
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:6px;
                        padding:10px 12px;margin-bottom:10px;font-size:12px;">
                <div style="font-weight:600;margin-bottom:6px;">🔧 Required Tools</div>
                <?php foreach ($reqToolsForOp as $rt): ?>
                <div style="display:flex;align-items:center;justify-content:space-between;
                            padding:4px 0;border-bottom:1px solid var(--border-subtle);">
                    <span>
                        <code style="font-size:11px;"><?= htmlspecialchars($rt['asset_number']) ?></code>
                        <?= htmlspecialchars($rt['description']) ?>
                        <?php if ($rt['cal_status'] === 'EXPIRED'): ?>
                        <span style="color:var(--accent-danger);font-size:10px;font-weight:700;"> EXPIRED CAL</span>
                        <?php endif; ?>
                    </span>
                    <?php
                    $recorded = dbFetchOne(
                        "SELECT id FROM wo_tool_records WHERE wo_id=? AND serial_id=? AND tool_id=?",
                        [$wo['id'], /* first serial */ $op['first_serial_id'] ?? 0, $rt['tool_id']]
                    );
                    ?>
                    <?php if ($recorded): ?>
                    <span style="color:#3fb950;font-size:11px;">✓ Recorded</span>
                    <?php elseif ($rt['cal_status'] === 'EXPIRED'): ?>
                    <span style="color:var(--accent-danger);font-size:11px;">Cannot record — expired</span>
                    <?php else: ?>
                    <form method="POST" action="<?= SITE_SUBPATH ?>/api/record_tool.php" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="wo_id"     value="<?= $wo['id'] ?>">
                        <input type="hidden" name="tool_id"   value="<?= $rt['tool_id'] ?>">
                        <input type="hidden" name="op_id"     value="<?= $op['op_id'] ?>">
                        <button type="submit" class="btn btn-secondary" style="font-size:10px;padding:2px 8px;">Record Use</button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php if ($op['doc_id'] && !$isNC): ?>
            <a href="<?= SITE_SUBPATH ?>/api/serve_pdf.php?id=<?= (int)$op['doc_id'] ?>"
               target="_blank" rel="noopener"
               class="btn btn-secondary" style="padding:4px 10px;font-size:11px;">
                📄 Open Work Instruction
            </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($hasSns): ?>
    <div class="serial-list">
        <?php foreach ($opSerials as $sn):
            $isClocked  = isset($activeClockMap[$sn['id']]);
            $isComplete = $sn['status'] === 'COMPLETE';
            $isScrapped = $sn['status'] === 'SCRAPPED';
            $isHeld     = $sn['status'] === 'ON_HOLD';
            // NON-CLOCKING op serials are visible but never workable — shown dimmed
            $workable   = $canWork && !$isComplete && !$isScrapped && !$isNC;
            $clockedOnTs= $isClocked
                ? (new DateTimeImmutable($activeClockMap[$sn['id']], new DateTimeZone('UTC')))->getTimestamp()
                : 0;

            $rowCls = match(true) {
                $isNC       => 'not-started',   // NON-CLOCKING: always shown as not-started (dimmed in CSS)
                $isClocked  => 'clocked-on',
                $isComplete => 'complete',
                $isScrapped => 'scrapped',
                $isHeld     => 'on-hold',
                $sn['status']==='IN_PROGRESS' => 'in-progress',
                default     => 'not-started',
            };
        ?>
        <div class="serial-row <?= $rowCls ?>"
             data-serial-id="<?= $sn['id'] ?>"
             data-workable="<?= $workable?'1':'0' ?>"
             style="<?= $isNC ? 'opacity:.5;cursor:default;background:var(--bg-card2);' : '' ?>"
             onclick="toggleRow(this)">

            <?php if ($workable): ?>
            <input type="checkbox" class="sn-check" value="<?= $sn['id'] ?>"
                   onclick="event.stopPropagation()" onchange="updateSelCount()">
            <?php elseif ($isNC): ?>
            <span style="font-size:10px;color:var(--text-dim);flex-shrink:0;">⏳</span>
            <?php else: ?>
            <span style="width:16px;flex-shrink:0;"></span>
            <?php endif; ?>

            <span class="serial-sn"><?= htmlspecialchars($sn['serial_number']) ?></span>

            <span class="serial-status">
                <?php if ($isNC): ?>
                <span class="badge badge-grey" style="font-size:10px;font-style:italic;">⏳ Waiting — Auto Advance</span>
                <?php elseif ($isClocked): ?>
                <span class="badge badge-green" style="font-size:10px;">Clocked On</span>
                <?php elseif ($isComplete): ?>
                <span class="badge badge-grey" style="font-size:10px;">Complete</span>
                <?php elseif ($isScrapped): ?>
                <span class="badge badge-red" style="font-size:10px;">Scrapped</span>
                <?php elseif ($isHeld): ?>
                <span class="badge badge-yellow" style="font-size:10px;">On Hold</span>
                <?php elseif ($sn['status']==='IN_PROGRESS'): ?>
                <span class="badge badge-blue" style="font-size:10px;">In Progress</span>
                <?php else: ?>
                <span class="badge badge-grey" style="font-size:10px;">Not Started</span>
                <?php endif; ?>
            </span>

            <?php if ($isClocked): ?>
            <span class="serial-timer"
                  id="timer-<?= $sn['id'] ?>"
                  data-ts="<?= $clockedOnTs ?>"
                  data-std="<?= (int)$sn['std_mins'] ?>">⏱ 00:00:00</span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>

        <?php if ($canWork && count($opSerials) > 1): ?>
        <div style="display:flex;gap:6px;margin-top:4px;">
            <button onclick="selectOp(<?= $op['id'] ?>, true)"
                    class="btn btn-secondary" style="padding:3px 10px;font-size:11px;">Select All in Op</button>
            <button onclick="selectOp(<?= $op['id'] ?>, false)"
                    class="btn btn-secondary" style="padding:3px 10px;font-size:11px;">Deselect</button>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php
    // v10.1.0: Quality Variable measurement panel
    // Show for each serial clocked on by this user on an inspection/test op that has QVs
    $opQvs = $qvByOp[$op['id']] ?? [];
    if ($canWork && !empty($opQvs) && $hasSns):
        // Find serials on this op that this user is clocked on to and haven't collected results yet
        $needsCollection = [];
        foreach ($opSerials as $sn) {
            $key = $sn['id'] . ':' . $op['id'];
            if (isset($activeClockMap[$sn['id']]) && !isset($collectedSet[$key])) {
                $needsCollection[] = $sn;
            }
        }
        // Also show already-collected serials as read-only
        $alreadyCollected = [];
        foreach ($opSerials as $sn) {
            $key = $sn['id'] . ':' . $op['id'];
            if (isset($collectedSet[$key])) {
                $alreadyCollected[] = $sn;
            }
        }
        if (!empty($needsCollection) || !empty($alreadyCollected)):
    ?>
    <div style="padding:14px 16px;border-top:2px solid var(--accent-warn);background:rgba(210,153,34,.06);">
        <div style="font-size:13px;font-weight:700;color:var(--accent-warn);margin-bottom:10px;">
            📐 Quality Measurements Required
        </div>

        <?php if (!empty($alreadyCollected)): ?>
        <div class="badge badge-green" style="margin-bottom:10px;display:inline-block;">
            ✓ <?= count($alreadyCollected) ?> serial<?= count($alreadyCollected)!==1?'s':'' ?> — measurements recorded
        </div>
        <?php endif; ?>

        <?php foreach ($needsCollection as $sn): ?>
        <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:6px;
                    padding:12px 14px;margin-bottom:10px;"
             id="qv-panel-<?= $sn['id'] ?>">
            <div style="font-size:12px;font-weight:700;font-family:monospace;
                        color:var(--accent-blue);margin-bottom:10px;">
                Serial: <?= htmlspecialchars($sn['serial_number']) ?>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
                <?php foreach ($opQvs as $qv): ?>
                <div>
                    <label style="display:block;font-size:11px;font-weight:600;
                                  color:var(--text-muted);margin-bottom:4px;">
                        <?= htmlspecialchars($qv['name']) ?>
                        <?php if ($qv['uom_code']): ?>
                            <span class="text-dim">(<?= htmlspecialchars($qv['uom_code']) ?>)</span>
                        <?php endif; ?>
                        <?php if ($qv['lower_limit'] !== null && $qv['upper_limit'] !== null): ?>
                            <span class="text-dim" style="font-weight:400;">
                                [<?= $qv['lower_limit'] ?> – <?= $qv['upper_limit'] ?>]
                            </span>
                        <?php endif; ?>
                    </label>
                    <input type="number" step="any"
                           id="qv-<?= $sn['id'] ?>-<?= $qv['id'] ?>"
                           data-qv-id="<?= $qv['id'] ?>"
                           data-serial-id="<?= $sn['id'] ?>"
                           data-lower="<?= $qv['lower_limit'] ?? '' ?>"
                           data-upper="<?= $qv['upper_limit'] ?? '' ?>"
                           data-name="<?= htmlspecialchars($qv['name']) ?>"
                           data-uom="<?= htmlspecialchars($qv['uom_code'] ?? '') ?>"
                           data-qv-type="<?= htmlspecialchars($qv['qv_type'] ?? 'NUMERIC') ?>"
                           class="qv-input"
                           placeholder="Enter value"
                           style="width:100%;padding:7px 9px;font-size:13px;
                                  <?= in_array($qv['qv_type']??'NUMERIC',['PASS_FAIL','YES_NO']) ? 'display:none;' : '' ?>">
                    <?php if (in_array($qv['qv_type'] ?? 'NUMERIC', ['PASS_FAIL','YES_NO'])): ?>
                    <?php $opt1 = $qv['qv_type']==='PASS_FAIL' ? 'Pass' : 'Yes';
                          $opt0 = $qv['qv_type']==='PASS_FAIL' ? 'Fail' : 'No'; ?>
                    <div style="display:flex;gap:8px;">
                        <button type="button"
                                onclick="setQvBinary(<?= $sn['id'] ?>,<?= $qv['id'] ?>,1,this)"
                                data-qv-id="<?= $qv['id'] ?>" data-serial-id="<?= $sn['id'] ?>"
                                data-qv-type="<?= htmlspecialchars($qv['qv_type']) ?>"
                                class="btn-qv-binary btn btn-secondary"
                                style="flex:1;font-weight:600;">
                            ✓ <?= $opt1 ?>
                        </button>
                        <button type="button"
                                onclick="setQvBinary(<?= $sn['id'] ?>,<?= $qv['id'] ?>,0,this)"
                                data-qv-id="<?= $qv['id'] ?>" data-serial-id="<?= $sn['id'] ?>"
                                data-qv-type="<?= htmlspecialchars($qv['qv_type']) ?>"
                                class="btn-qv-binary btn btn-secondary"
                                style="flex:1;font-weight:600;">
                            ✗ <?= $opt0 ?>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <div style="margin-top:10px;">
                <button onclick="submitQVs(<?= $sn['id'] ?>, <?= $op['id'] ?>, <?= count($opQvs) ?>)"
                        class="btn btn-warning"
                        id="qv-submit-<?= $sn['id'] ?>"
                        style="font-size:12px;padding:5px 14px;">
                    Submit Measurements
                </button>
                <span id="qv-status-<?= $sn['id'] ?>"
                      style="margin-left:10px;font-size:12px;color:var(--text-muted);"></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; endif; ?>

    <?php if ($isBTS && $hasSns && $locations && $canWork): ?>
    <div style="padding:12px 16px;border-top:1px solid var(--border);background:rgba(35,134,54,.05);">
        <strong style="font-size:13px;color:#3fb950;">📦 Book to Stock</strong>
        <div style="display:flex;gap:10px;align-items:flex-end;margin-top:8px;flex-wrap:wrap;">
            <div>
                <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Inventory Location</label>
                <select id="bts-location-<?= $op['id'] ?>" style="width:220px;">
                    <option value="">— Select —</option>
                    <?php foreach ($locations as $loc): ?>
                    <option value="<?= $loc['id'] ?>"><?= htmlspecialchars($loc['code'].' — '.$loc['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button onclick="bookToStock(<?= $op['id'] ?>)" class="btn btn-primary" style="background:var(--accent);">
                Book to Stock (<?= count($opSerials) ?> unit<?= count($opSerials)!==1?'s':'' ?>)
            </button>
            <?php
            // Store serial IDs for this op for BTS JS
            $btsIds = array_column($opSerials, 'id');
            ?>
            <input type="hidden" id="bts-ids-<?= $op['id'] ?>" value="<?= htmlspecialchars(json_encode($btsIds)) ?>">
        </div>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<?php endif; // end if $wo ?>

<script>
const WO_ID    = <?= $wo ? $wo['id'] : 'null' ?>;

// Map of op_id => {doc_id, doc_number} for auto-opening PDF on clock-on
const OP_DOC_MAP = <?php
    $opDocMap = [];
    foreach ($operations as $op) {
        if ($op['doc_id']) {
            $opDocMap[$op['id']] = [
                'doc_id'     => (int)$op['doc_id'],
                'doc_number' => $op['doc_number'] ?? ''
            ];
        }
    }
    echo json_encode($opDocMap);
?>;
const API_BASE = '<?= SITE_URL ?>/api';
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// ── Selection ─────────────────────────────────────────────────────────────────
function toggleRow(row) {
    if (row.dataset.workable !== '1') return;
    const chk = row.querySelector('.sn-check');
    if (chk) { chk.checked = !chk.checked; updateSelCount(); }
}
function selectAll(checked) {
    document.querySelectorAll('.sn-check').forEach(c => { c.checked = checked; });
    updateSelCount();
}
function selectOp(opId, checked) {
    // Select all checkboxes in serials whose data-op matches
    document.querySelectorAll(
        `.serial-row[data-workable="1"] .sn-check`
    ).forEach(chk => {
        const row = chk.closest('.serial-row');
        // Check if this row is inside the correct op section
        // Op sections have id="op-section-{opId}" — set below
        const section = row.closest('[data-op-id]');
        if (section && parseInt(section.dataset.opId) === opId) {
            chk.checked = checked;
        }
    });
    updateSelCount();
}
function updateSelCount() {
    const n = document.querySelectorAll('.sn-check:checked').length;
    document.getElementById('sel-count').textContent = n + ' serial' + (n!==1?'s':'') + ' selected';
}
function getSelectedIds() {
    return Array.from(document.querySelectorAll('.sn-check:checked')).map(c=>parseInt(c.value));
}
function getAllWorkableIds() {
    return Array.from(document.querySelectorAll('.sn-check')).map(c=>parseInt(c.value));
}

// ── Clock actions ─────────────────────────────────────────────────────────────
async function clockAction(action, scope) {
    if (!WO_ID) return;
    const ids = scope==='all' ? getAllWorkableIds() : getSelectedIds();
    if (!ids.length) { alert('Please select at least one serial number.'); return; }
    // Guard: complete requires the user to be clocked on
    if (action === 'complete') {
        const clockedOn = ids.filter(id => {
            const row = document.querySelector('.serial-row[data-serial-id="'+id+'"]');
            return row && row.classList.contains('clocked-on');
        });
        if (clockedOn.length === 0) {
            alert('You must be clocked on to complete an operation.\nClick "⏱ Clock On" first, then complete.');
            return;
        }
        if (clockedOn.length < ids.length) {
            // Some selected but not clocked on — only complete the clocked-on ones
            ids.length = 0;
            clockedOn.forEach(id => ids.push(id));
        }
    }
    const labels = {clock_on:'Clock on',clock_off:'Clock off',complete:'Complete'};
    if (!confirm(labels[action]+' '+ids.length+' serial(s)?')) return;

    const res  = await fetch(API_BASE+'/clock_action.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({action, wo_id:WO_ID, serial_ids:ids})
    });
    const data = await res.json();
    if (data.ok) {
        if (false && action === 'clock_on' && data.doc_id) { // F054: auto-open removed
            sessionStorage.setItem('autoOpenDoc', JSON.stringify({
                doc_id: data.doc_id,
                doc_number: Object.values(OP_DOC_MAP).find(d=>d.doc_id===data.doc_id)?.doc_number || ''
            }));
        } else if (action !== 'clock_on') {
            sessionStorage.removeItem('autoOpenDoc');
        }
        window.location.href='?id='+WO_ID;
    } else {
        alert(data.error || 'Unknown error');
    }
}

// ── Book to stock ─────────────────────────────────────────────────────────────
async function bookToStock(opId) {
    const locSel = document.getElementById('bts-location-'+opId);
    const locId  = parseInt(locSel?.value||0);
    if (!locId) { alert('Please select an inventory location.'); return; }
    const ids = JSON.parse(document.getElementById('bts-ids-'+opId).value||'[]');
    if (!ids.length) return;
    if (!confirm('Book '+ids.length+' serial(s) to stock?')) return;

    const res  = await fetch(API_BASE+'/book_stock.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({wo_id:WO_ID, serial_ids:ids, location_id:locId})
    });
    const data = await res.json();
    if (data.ok) { window.location.href='?id='+WO_ID; }
    else { alert('Error: '+(data.error||'Unknown')); }
}

// ── Live timers ───────────────────────────────────────────────────────────────
function fmt(s){ const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),ss=s%60;
    return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(ss).padStart(2,'0'); }

function tickTimers() {
    const now = Math.floor(Date.now()/1000);
    document.querySelectorAll('.serial-timer').forEach(el => {
        const ts  = parseInt(el.dataset.ts);
        const std = parseInt(el.dataset.std)*60;
        const el2 = Math.max(0, now-ts);
        el.textContent = '⏱ '+fmt(el2);
        el.className   = 'serial-timer'+(std>0&&el2>std?' overrun':'');
    });
}
setInterval(tickTimers,1000); tickTimers();

// ── Auto-open PDF if user clocked on (persists across page reload) ────────────
window.addEventListener('DOMContentLoaded', () => {
    const stored = sessionStorage.getItem('autoOpenDoc');
    if (stored && WO_ID) {
        try {
            const {doc_id, doc_number} = JSON.parse(stored);
            // Only auto-open if there are active clocked-on serials (user IS clocked on)
            const clockedCards = document.querySelectorAll('.serial-row.clocked-on');
            if (clockedCards.length > 0 && doc_id) {
                // F054: auto-open removed
            } else {
                sessionStorage.removeItem('autoOpenDoc');
            }
        } catch(e) { sessionStorage.removeItem('autoOpenDoc'); }
    }
});

// ── PDF viewer ────────────────────────────────────────────────────────────────
// F054: togglePDF removed

// F054: closePDF removed
// F054: renderPdfPage removed

</script>


<!-- NC Modal -->
<div id="nc-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);
     z-index:300;align-items:center;justify-content:center;">
    <div style="background:var(--bg-card);border:2px solid var(--accent-danger);border-radius:8px;
                padding:24px;max-width:500px;width:92%;max-height:85vh;overflow-y:auto;">
        <h2 style="font-size:16px;margin-bottom:10px;color:var(--accent-danger);">⚠ Raise Non-Conformance</h2>
        <div class="alert alert-warning" style="font-size:12px;margin-bottom:14px;">
            This will put the work order on <strong>Hard Hold</strong> and clock off selected serials.
        </div>
        <div class="form-group">
            <label style="font-size:12px;">Selected Serials</label>
            <div id="nc-serial-list" style="font-family:monospace;font-size:12px;color:var(--text-muted);
                 background:var(--bg);border:1px solid var(--border);border-radius:5px;
                 padding:8px;max-height:80px;overflow-y:auto;"></div>
        </div>
        <div class="form-group">
            <label style="font-size:12px;">Defect Description <span style="color:var(--accent-danger)">*</span></label>
            <textarea id="nc-defect" rows="4" placeholder="Describe the defect in detail…" style="resize:vertical;"></textarea>
        </div>
        <div style="display:flex;gap:8px;">
            <button onclick="submitNC()" class="btn btn-danger">Submit NC</button>
            <button onclick="closeNCModal()" class="btn btn-secondary">Cancel</button>
        </div>
    </div>
</div>

<script>
// ── NC Modal ──────────────────────────────────────────────────────────────────
function openNCModal() {
    const ids = getSelectedIds();
    if (!ids.length) { alert('Select at least one serial number first.'); return; }
    const list = document.getElementById('nc-serial-list');
    list.innerHTML = ids.map(id => {
        const row = document.querySelector('.serial-row[data-serial-id="'+id+'"]');
        return row?.querySelector('.serial-sn')?.textContent || 'Serial '+id;
    }).join('<br>');
    document.getElementById('nc-defect').value = '';
    document.getElementById('nc-modal').style.display = 'flex';
}

function closeNCModal() {
    document.getElementById('nc-modal').style.display = 'none';
}

async function submitNC() {
    const defect = document.getElementById('nc-defect').value.trim();
    if (!defect) { alert('Please describe the defect.'); return; }
    const ids = getSelectedIds();
    if (!ids.length) { closeNCModal(); return; }

    // Get op_id from the section containing the first selected serial
    let opId = null;
    const firstChk = document.querySelector('.sn-check:checked');
    if (firstChk) {
        const sec = firstChk.closest('[data-op-id]');
        opId = sec ? parseInt(sec.dataset.opId) : null;
    }
    if (!opId) { alert('Cannot determine current operation. Deselect and reselect a serial.'); return; }

    const res  = await fetch(API_BASE+'/raise_nc.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({wo_id:WO_ID, op_id:opId, serial_ids:ids, defect_desc:defect})
    });
    const data = await res.json();
    if (data.ok) {
        closeNCModal();
        alert('NC '+data.nc_number+' raised. Work order is now on HARD HOLD.');
        window.location.href = '?id='+WO_ID;
    } else {
        alert('Error: '+(data.error||'Unknown'));
    }
}
</script>


<script>
// ── v10.1.0: Quality Variable submission ──────────────────────────────────────
// F048: Set binary QV value (Pass/Fail, Yes/No)
function setQvBinary(serialId, qvId, val, btn) {
    // Store value in hidden input
    let hidden = document.getElementById(`qv-${serialId}-${qvId}`);
    if (!hidden) {
        hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.id = `qv-${serialId}-${qvId}`;
        hidden.className = 'qv-input';
        hidden.dataset.qvId = qvId;
        hidden.dataset.serialId = serialId;
        hidden.dataset.qvType = btn.dataset.qvType;
        btn.parentElement.appendChild(hidden);
    }
    hidden.value = val;
    // Highlight selected button
    btn.parentElement.querySelectorAll('.btn-qv-binary').forEach(b => {
        b.style.background = '';
        b.style.color = '';
    });
    btn.style.background = val === 1 ? '#3fb950' : 'var(--accent-danger)';
    btn.style.color = '#fff';
}

async function submitQVs(serialId, opId, expectedCount) {
    // Gather all inputs for this serial
    const inputs = document.querySelectorAll(`.qv-input[data-serial-id="${serialId}"]`);
    const results = [];
    let allFilled = true;

    inputs.forEach(inp => {
        const val = inp.value.trim();
        if (val === '') { allFilled = false; return; }
        results.push({ qv_id: parseInt(inp.dataset.qvId), value: parseFloat(val) });
    });

    if (!allFilled || results.length < expectedCount) {
        alert('Please enter all measurements before submitting.');
        return;
    }

    const statusEl = document.getElementById('qv-status-' + serialId);
    statusEl.textContent = 'Submitting…';

    const payload = { wo_id: WO_ID, serial_id: serialId, op_id: opId, results, confirm_nc: false };
    const res  = await fetch(API_BASE + '/submit_qv.php', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (data.out_of_spec && data.needs_confirm) {
        // Show warning and ask operator to confirm NC
        const reasons = data.reasons.join('\n• ');
        const confirm = window.confirm(
            '⚠ OUT OF SPECIFICATION\n\n• ' + reasons +
            '\n\nA Non-Conformance will be raised automatically and the work order placed on HARD HOLD.\n\nDo you want to proceed?'
        );
        if (!confirm) {
            statusEl.textContent = 'Cancelled — please re-check the measurements.';
            return;
        }
        // Re-submit with confirm_nc = true
        payload.confirm_nc = true;
        const res2  = await fetch(API_BASE + '/submit_qv.php', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data2 = await res2.json();
        if (data2.ok) {
            if (data2.nc_raised) {
                alert('NC ' + data2.nc_number + ' raised. Work order is now on HARD HOLD.');
            }
            window.location.href = '?id=' + WO_ID;
        } else {
            statusEl.textContent = '❌ Error: ' + (data2.error || 'Unknown error');
        }
        return;
    }

    if (data.ok) {
        statusEl.textContent = '✓ Recorded';
        document.getElementById('qv-panel-' + serialId).style.opacity = '0.5';
        document.getElementById('qv-submit-' + serialId).disabled = true;
        setTimeout(() => window.location.href = '?id=' + WO_ID, 800);
    } else {
        statusEl.textContent = '❌ ' + (data.error || 'Unknown error');
    }
}
</script>

<?php renderPageEnd(); ?>
