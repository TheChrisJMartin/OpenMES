<?php
/**
 * workorders/create.php — Work Order Creation
 * Version: 10.5.0
 * Fix: Only parts WITH approved routings shown in dropdown
 * Fix: Routing dropdown shows APPROVED (latest) and SUPERSEDED (older) revisions
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','SUPERVISOR']);

if (!ALLOW_WO_CREATION) {
    renderPageStart('Work Order Creation Disabled');
    echo '<div class="alert alert-warning">Work order creation is disabled (ALLOW_WO_CREATION = false).</div>';
    echo '<a href="' . SITE_SUBPATH . '/workorders/list.php" class="btn btn-secondary">← Work Orders</a>';
    renderPageEnd(); exit;
}

$scope    = orgScope('p');
$scopeReg = orgScope('sr');
$error = '';

// ── Only parts that have at least one APPROVED or SUPERSEDED routing ──────────
$parts = dbFetchAll(
    "SELECT p.id, p.part_number, p.description, p.serial_controlled, p.org_id,
            o.code AS org_code
     FROM parts p
     JOIN orgs o ON o.id = p.org_id
     WHERE ({$scope['sql']}) AND p.active=1
       AND EXISTS (
           SELECT 1 FROM routings r
           WHERE r.part_id = p.id
             AND r.status IN ('APPROVED','SUPERSEDED')
       )
     ORDER BY o.code, p.part_number",
    $scope['params']
);

$orgs = dbFetchAll(
    "SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code"
);

$registers = dbFetchAll(
    "SELECT sr.id, sr.register_code, sr.org_id,
            sr.prefix, sr.pad_length, sr.suffix,
            sr.end_seq, sr.current_seq,
            (sr.end_seq - sr.current_seq) AS remaining
     FROM serial_registers sr
     WHERE ({$scopeReg['sql']}) AND sr.active=1
     ORDER BY sr.org_id, sr.register_code",
    $scopeReg['params']
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $orgId       = (int)($_POST['org_id']      ?? 0);
    $partId      = (int)($_POST['part_id']      ?? 0);
    $routingId   = (int)($_POST['routing_id']   ?? 0);
    $controlType = in_array($_POST['control_type']??'', ['SERIAL','LOT'])
                   ? $_POST['control_type'] : 'SERIAL';
    $quantity    = (int)($_POST['quantity']     ?? 1);
    $registerId  = (int)($_POST['register_id']  ?? 0);
    $notes       = trim($_POST['notes']         ?? '');
    $priority    = max(1, min(99, (int)($_POST['priority'] ?? 50)));
    $plannedStart  = trim($_POST['planned_start']  ?? '') ?: date('Y-m-d H:i:s');
    $plannedFinish = trim($_POST['planned_finish'] ?? '') ?: null;
    $faiRequired   = isset($_POST['fai_required']) ? 1 : 0; // F062

    if (!$orgId)      $error = 'Please select an organisation.';
    elseif (!$partId)     $error = 'Please select a part number.';
    elseif (!$routingId)  $error = 'Please select a routing revision.';
    elseif (!$registerId) $error = 'Please select a serial number register.';
    elseif ($quantity < 1) $error = 'Quantity must be at least 1.';
    elseif ($controlType==='SERIAL' && $quantity > MAX_SERIALS_PER_WO)
        $error = 'Max '.MAX_SERIALS_PER_WO.' serials per WO (MAX_SERIALS_PER_WO).';
    elseif ($controlType==='LOT' && $quantity > MAX_LOT_QTY_PER_WO)
        $error = 'Max '.number_format(MAX_LOT_QTY_PER_WO).' pieces per lot WO (MAX_LOT_QTY_PER_WO).';

    if (!$error) {
        // Allow APPROVED or SUPERSEDED routing
        $routing = dbFetchOne(
            "SELECT * FROM routings WHERE id=? AND part_id=? AND status IN ('APPROVED','SUPERSEDED')",
            [$routingId, $partId]
        );
        if (!$routing) $error = 'Selected routing is not valid for this part.';
    }

    if (!$error) {
        $register = dbFetchOne(
            "SELECT * FROM serial_registers WHERE id=? AND org_id=?", [$registerId,$orgId]
        );
        if (!$register) {
            $error = 'Serial register not found for this organisation.';
        } elseif (($register['current_seq'] + $quantity) > $register['end_seq']) {
            $avail = $register['end_seq'] - $register['current_seq'];
            $error = "Register only has {$avail} numbers remaining.";
        }
    }

    if (!$error) {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $seq     = dbFetchOne("SELECT next_seq FROM wo_sequence WHERE org_id=? FOR UPDATE",[$orgId]);
            $woSeq   = $seq['next_seq'];
            $orgCode = dbFetchOne("SELECT code FROM orgs WHERE id=?",[$orgId])['code'];
            $woNum   = $orgCode . str_pad($woSeq,7,'0',STR_PAD_LEFT);
            dbExecute("UPDATE wo_sequence SET next_seq=next_seq+1 WHERE org_id=?",[$orgId]);

            $lotNumber = ($controlType==='LOT')
                ? $orgCode.'-LOT-'.str_pad($woSeq,7,'0',STR_PAD_LEFT) : null;

            $woId = dbInsert(
                "INSERT INTO work_orders
                    (org_id,wo_number,part_id,routing_id,control_type,quantity,lot_number,
                     status,created_by,notes,planned_start,planned_finish,priority,fai_required)
                 VALUES (?,?,?,?,?,?,?,'OPEN',?,?,?,?,?,?)",
                [$orgId,$woNum,$partId,$routingId,$controlType,$quantity,$lotNumber,
                 $_SESSION['user_id'],$notes,$plannedStart,$plannedFinish,$priority,$faiRequired]
            );

            // Get all ops in order so we can auto-advance past leading NON-CLOCKING ops
            $allOps = dbFetchAll(
                "SELECT id, behaviour FROM routing_operations
                 WHERE routing_id=? ORDER BY sort_order, op_number",
                [$routingId]
            );

            // Find the first CLOCKING op — serials start here, skipping NON-CLOCKING ops at the top
            $firstClockingOp = null;
            foreach ($allOps as $op) {
                if ($op['behaviour'] === 'CLOCKING') {
                    $firstClockingOp = $op;
                    break;
                }
            }
            // Fallback: if routing is ALL non-clocking (unusual), use the very first op
            $firstOp = $firstClockingOp ?? ($allOps[0] ?? null);

            $currentSeq = $register['current_seq'];
            $prefix     = $register['prefix'];
            $suffix     = $register['suffix'];
            $padLen     = (int)$register['pad_length'];

            if ($controlType==='SERIAL') {
                for ($i=0; $i<$quantity; $i++) {
                    $currentSeq++;
                    $sn = $prefix.str_pad($currentSeq,$padLen,'0',STR_PAD_LEFT).$suffix;
                    dbInsert(
                        "INSERT INTO serial_numbers (org_id,wo_id,serial_number,register_id,current_op_id,status)
                         VALUES (?,?,?,?,?,'NOT_STARTED')",
                        [$orgId,$woId,$sn,$registerId,$firstOp['id']??null]
                    );
                }
            } else {
                $currentSeq++;
                dbInsert(
                    "INSERT INTO serial_numbers (org_id,wo_id,serial_number,register_id,current_op_id,status)
                     VALUES (?,?,?,?,?,'NOT_STARTED')",
                    [$orgId,$woId,$lotNumber,$registerId,$firstOp['id']??null]
                );
            }

            dbExecute(
                "UPDATE serial_registers SET current_seq=?,updated_at=NOW() WHERE id=?",
                [$currentSeq,$registerId]
            );
            dbInsert(
                "INSERT INTO wo_change_log (wo_id,user_id,change_type,note) VALUES (?,?,?,?)",
                [$woId,$_SESSION['user_id'],'WO_CREATED',"Created {$woNum} — {$controlType} x{$quantity}"]
            );
            writeAuditLog('WO_CREATE','work_order',(string)$woId,$orgId,null,null,null,null,
                $woNum,"WO {$woNum}: part {$partId}, routing rev {$routing['revision_label']}, {$controlType} x{$quantity}");

            $pdo->commit();
            header('Location: '.SITE_URL.'/workorders/view.php?id='.$woId.'&created=1');
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $error = 'Failed to create work order: '.$e->getMessage();
        }
    }
}

renderPageStart('Create Work Order');
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/workorders/list.php"
       style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Work Orders</a>
    <h1 style="margin-top:6px;">Create Work Order</h1>
    <?php if (!$parts): ?>
    <div class="alert alert-warning" style="margin-top:10px;">
        ⚠ No parts with approved routings found for your organisation.
        <a href="<?= SITE_SUBPATH ?>/routings/list.php" style="color:var(--accent-blue);">Create and approve a routing</a> first.
    </div>
    <?php endif; ?>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 300px;gap:16px;align-items:start;max-width:960px;">

<div class="card">
<form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">


    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">

        <div class="form-group" style="margin:0;">
            <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
            <select name="org_id" id="org_sel" required onchange="onOrgChange()">
                <option value="">— Select —</option>
                <?php foreach ($orgs as $o):
                    if (!hasPersona('IT_ADMIN') && $o['id'] != currentOrgId()) continue;
                ?>
                <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['code'].' — '.$o['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="margin:0;">
            <label>Part Number <span style="color:var(--accent-danger)">*</span>
                <span class="text-dim" style="font-weight:400;"> — only parts with approved routings</span>
            </label>
            <select name="part_id" id="part_sel" required onchange="onPartChange()">
                <option value="">— Select organisation first —</option>
            </select>
        </div>
    </div>

    <div class="form-group">
        <label>Routing Revision <span style="color:var(--accent-danger)">*</span></label>
        <select name="routing_id" id="routing_sel" required onchange="onRoutingChange()">
            <option value="">— Select part first —</option>
        </select>
        <div class="text-dim" id="routing_hint" style="margin-top:3px;font-size:11px;"></div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
        <!-- Control type is derived from the part — hidden field, display only -->
        <input type="hidden" name="control_type" id="ctrl_type" value="SERIAL">
        <div class="form-group" style="margin:0;">
            <label>Control Type</label>
            <div id="ctrl_type_display" style="padding:8px 10px;background:var(--bg);border:1px solid var(--border);
                 border-radius:var(--radius);font-size:13px;color:var(--text-muted);">
                — select a part —
            </div>
            <div class="text-dim" style="font-size:11px;margin-top:3px;">Set by the part's configuration</div>
        </div>
        <div class="form-group" style="margin:0;">
            <label>Quantity <span style="color:var(--accent-danger)">*</span></label>
            <input type="number" name="quantity" id="qty_input"
                   min="1" max="<?= MAX_SERIALS_PER_WO ?>" value="1" required onchange="onRoutingChange()">
            <div class="text-dim" id="qty_hint" style="font-size:11px;margin-top:3px;">Max <?= MAX_SERIALS_PER_WO ?> serials</div>
        </div>
        <div class="form-group" style="margin:0;">
            <label>Serial Register <span style="color:var(--accent-danger)">*</span></label>
            <select name="register_id" id="reg_sel" required>
                <option value="">— Select org first —</option>
            </select>
        </div>
    </div>

    <!-- v10.5.0: Planned dates and priority -->
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:14px;">
        <div class="form-group" style="margin:0;">
            <label>Priority <span class="text-dim" style="font-weight:400;">(1=highest, 99=lowest)</span></label>
            <input type="number" name="priority" min="1" max="99" value="50">
        </div>
        <div class="form-group" style="margin:0;">
            <label>Planned Start</label>
            <input type="datetime-local" name="planned_start"
                   value="<?= date('Y-m-d\TH:i') ?>">
        </div>
        <div class="form-group" style="margin:0;">
            <label>Planned Finish <span class="text-dim" style="font-weight:400;">(optional)</span></label>
            <input type="datetime-local" name="planned_finish" id="planned_finish">
            <div class="text-dim" style="font-size:11px;margin-top:3px;" id="planned_finish_hint">
                Auto-calculated from standard times when routing selected
            </div>
        </div>
    </div>

    <div class="form-group" style="margin-top:14px;">
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:14px;
                        padding:12px;background:var(--bg);border:1px solid var(--border);border-radius:6px;">
            <input type="checkbox" name="fai_required" id="fai_required" value="1"
                   style="margin-top:3px;flex-shrink:0;">
            <label for="fai_required" style="margin:0;cursor:pointer;">
                <strong>First Article Inspection (FAI) Required</strong>
                <span style="color:var(--text-muted);font-size:11px;display:block;margin-top:2px;">
                    First serial on this routing revision will require a mandatory inspection gate
                    before production can continue (ISO-9001 Clause 8.1)
                </span>
            </label>
        </div>
        <label>Notes <span class="text-dim" style="font-weight:400;">(optional)</span></label>
        <textarea name="notes" rows="2" style="resize:vertical;"
                  placeholder="Any notes for this work order…"></textarea>
    </div>

    <div style="display:flex;gap:8px;">
        <button type="submit" class="btn btn-primary" <?= !$parts?'disabled':'' ?>>Create Work Order</button>
        <a href="<?= SITE_SUBPATH ?>/workorders/list.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>
</div>

<!-- Info sidebar -->
<div>
    <div class="card">
        <div class="card-title">WO Number Format</div>
        <p style="font-size:13px;color:var(--text-muted);">Assigned automatically:</p>
        <code style="font-size:15px;">ORGxxxxxxx</code>
        <p style="font-size:12px;color:var(--text-dim);margin-top:6px;">e.g. BIKE0000001</p>
        <div style="margin-top:10px;font-size:12px;color:var(--text-dim);">
            <div>Serialised max: <strong><?= MAX_SERIALS_PER_WO ?></strong></div>
            <div>Lot max: <strong><?= number_format(MAX_LOT_QTY_PER_WO) ?></strong></div>
        </div>
    </div>
    <div class="card" style="margin-top:0;">
        <div class="card-title">Routing Selection</div>
        <p style="font-size:12px;color:var(--text-muted);">
            The <strong>latest (approved)</strong> revision is selected by default.
            <strong>Superseded</strong> revisions can also be selected if needed —
            they are clearly labelled.
        </p>
    </div>
</div>

</div>

<script>
const allParts = <?= json_encode(array_values(array_map(fn($p)=>[
    'id'=>(int)$p['id'],'orgId'=>(int)$p['org_id'],
    'label'=>$p['part_number'].' — '.$p['description'],
    'serial'=>(int)$p['serial_controlled'],
], $parts))) ?>;

const allRegisters = <?= json_encode(array_values(array_map(fn($r)=>[
    'id'=>(int)$r['id'],'orgId'=>(int)$r['org_id'],
    'label'=>$r['register_code'].' ('.number_format($r['end_seq']-$r['current_seq']).' available)',
    'avail'=>(int)($r['end_seq']-$r['current_seq']),
], $registers))) ?>;

const MAX_SERIAL = <?= MAX_SERIALS_PER_WO ?>;
const MAX_LOT    = <?= MAX_LOT_QTY_PER_WO ?>;

// ── Org change — filter parts and registers ────────────────────────────────
function onOrgChange() {
    const orgId = parseInt(document.getElementById('org_sel').value) || 0;

    // Parts
    const pSel = document.getElementById('part_sel');
    pSel.innerHTML = '<option value="">— Select part —</option>';
    allParts.filter(p => !orgId || p.orgId === orgId).forEach(p => {
        const o = document.createElement('option');
        o.value = p.id;
        o.dataset.serial = p.serial;
        o.textContent = p.label;
        pSel.appendChild(o);
    });

    // Registers
    const rSel = document.getElementById('reg_sel');
    rSel.innerHTML = '<option value="">— Select register —</option>';
    allRegisters.filter(r => !orgId || r.orgId === orgId).forEach(r => {
        const o = document.createElement('option');
        o.value = r.id;
        o.textContent = r.label;
        if (r.avail < 10) o.style.color = 'var(--accent-danger)';
        rSel.appendChild(o);
    });

    // Reset routing
    document.getElementById('routing_sel').innerHTML = '<option value="">— Select part first —</option>';
    document.getElementById('routing_hint').textContent = '';

    // Reset control type display
    setControlType(null);
}

// ── Set control type hidden field and display ──────────────────────────────
function setControlType(isSerial) {
    const hidden  = document.getElementById('ctrl_type');
    const display = document.getElementById('ctrl_type_display');
    const qiEl    = document.getElementById('qty_input');
    const qhEl    = document.getElementById('qty_hint');

    if (isSerial === null) {
        hidden.value       = 'SERIAL';
        display.textContent = '— select a part —';
        display.style.color = 'var(--text-dim)';
        qiEl.max            = MAX_SERIAL;
        qhEl.textContent    = 'Max '+MAX_SERIAL+' serials';
        return;
    }
    if (isSerial) {
        hidden.value        = 'SERIAL';
        display.textContent = '🔵 Serialised';
        display.style.color = 'var(--accent-blue)';
        qiEl.max            = MAX_SERIAL;
        qhEl.textContent    = 'Max '+MAX_SERIAL+' serials per WO';
    } else {
        hidden.value        = 'LOT';
        display.textContent = '⚪ Lot Controlled';
        display.style.color = 'var(--text-muted)';
        qiEl.max            = MAX_LOT;
        qhEl.textContent    = 'Max '+MAX_LOT.toLocaleString()+' pieces per WO';
    }
}

// ── Part change — set control type + load routings ─────────────────────────
async function onPartChange() {
    const pSel  = document.getElementById('part_sel');
    const partId = parseInt(pSel.value) || 0;
    const rSel  = document.getElementById('routing_sel');
    const hint  = document.getElementById('routing_hint');

    // Set control type from the selected part's data attribute
    const opt = pSel.options[pSel.selectedIndex];
    if (partId && opt?.dataset.serial !== undefined) {
        setControlType(opt.dataset.serial === '1');
    } else {
        setControlType(null);
    }

    if (!partId) {
        rSel.innerHTML = '<option value="">— Select part first —</option>';
        hint.textContent = '';
        return;
    }

    rSel.innerHTML = '<option value="">Loading…</option>';
    hint.textContent = '';

    try {
        const res  = await fetch('<?= SITE_SUBPATH ?>/api/get_routings.php?part_id=' + partId);
        const data = await res.json();
        rSel.innerHTML = '';

        if (!data.length) {
            rSel.innerHTML = '<option value="">No approved routings found</option>';
            hint.textContent = '⚠ No approved routings for this part.';
            hint.style.color = 'var(--accent-warn)';
            return;
        }

        data.forEach((r, i) => {
            const o = document.createElement('option');
            o.value = r.id;
            o.textContent = r.routing_number
                + '  Rev ' + r.revision_label
                + (i === 0 && r.status === 'APPROVED' ? '  ← latest' : '')
                + (r.status === 'SUPERSEDED' ? '  [SUPERSEDED]' : '');
            if (r.status === 'SUPERSEDED') o.style.color = 'var(--accent-warn)';
            if (i === 0) o.selected = true;
            rSel.appendChild(o);
        });

        const approved = data.filter(r => r.status === 'APPROVED').length;
        const supers   = data.filter(r => r.status === 'SUPERSEDED').length;
        hint.textContent = approved + ' approved, ' + supers + ' superseded.';
        hint.style.color = 'var(--text-dim)';

        // Auto-calculate planned finish
        onRoutingChange();

    } catch (e) {
        rSel.innerHTML = '<option value="">Error loading routings</option>';
        hint.textContent = 'Could not load: ' + e.message;
        hint.style.color = 'var(--accent-danger)';
    }
}

// ── Routing change — auto-calculate planned finish ─────────────────────────
async function onRoutingChange() {
    const routingId = parseInt(document.getElementById('routing_sel').value) || 0;
    if (!routingId) return;

    try {
        const res  = await fetch('<?= SITE_SUBPATH ?>/api/get_routings.php?routing_id=' + routingId + '&std_mins=1');
        const data = await res.json();
        const hintEl   = document.getElementById('planned_finish_hint');
        const finishEl = document.getElementById('planned_finish');

        if (data.total_std_mins > 0) {
            const qty      = parseInt(document.getElementById('qty_input').value) || 1;
            const startVal = document.querySelector('[name="planned_start"]').value;
            if (startVal) {
                const totalMs  = data.total_std_mins * qty * 60 * 1000;
                const finishDt = new Date(new Date(startVal).getTime() + totalMs);
                const pad = n => String(n).padStart(2, '0');
                finishEl.value = finishDt.getFullYear() + '-' + pad(finishDt.getMonth()+1) + '-' +
                                 pad(finishDt.getDate()) + 'T' + pad(finishDt.getHours()) + ':' + pad(finishDt.getMinutes());
                hintEl.textContent = 'Auto-calculated: ' + data.total_std_mins + ' std mins × ' + qty + ' units';
                hintEl.style.color = 'var(--accent-blue)';
            }
        }
    } catch (e) { /* silently skip */ }
}

// ── Auto-select org on load if only one option ─────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    const s = document.getElementById('org_sel');
    if (s.options.length === 2) {
        s.selectedIndex = 1;
        onOrgChange();
    }
});
</script>

<?php renderPageEnd(); ?>
