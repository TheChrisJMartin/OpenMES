<?php
/**
 * dashboard.php — ChrisMES Dashboard
 * Version: 10.5.3.1
 * v10.5.3.1: WO status counts (Open/In Progress/Hard Hold/Soft Hold) per org card
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/db.php';

requireLogin();

$knownAs      = $_SESSION['known_as']      ?? 'User';
$personaLabel = $_SESSION['persona_label'] ?? '';

// ── Determine which orgs this user can see ────────────────────────────────────
// IT_ADMIN sees all business orgs; others see only their own
$isAdmin = hasPersona('IT_ADMIN');

if ($isAdmin) {
    $visibleOrgs = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
} else {
    $myOrgId = currentOrgId();
    $visibleOrgs = $myOrgId
        ? dbFetchAll("SELECT id,code,name FROM orgs WHERE id=? AND active=1", [$myOrgId])
        : [];
}

$orgIds = array_column($visibleOrgs, 'id');

// ── Stats ─────────────────────────────────────────────────────────────────────
function statsForOrgs(array $orgIds): array {
    if (!$orgIds) return ['users'=>0,'depts'=>0,'parts'=>0,'routings_draft'=>0,'routings_approved'=>0];
    $in = implode(',', array_map('intval', $orgIds));

    $users = dbFetchOne("SELECT COUNT(*) AS n FROM users WHERE org_id IN ({$in}) AND active=1")['n'] ?? 0;
    $depts = dbFetchOne("SELECT COUNT(*) AS n FROM departments WHERE org_id IN ({$in}) AND active=1")['n'] ?? 0;

    // Parts — table may not exist yet in older installs
    try {
        $parts = dbFetchOne("SELECT COUNT(*) AS n FROM parts WHERE org_id IN ({$in}) AND active=1")['n'] ?? 0;
    } catch (Throwable) { $parts = 0; }

    // Routings
    try {
        $rDraft    = dbFetchOne("SELECT COUNT(*) AS n FROM routings WHERE org_id IN ({$in}) AND status='DRAFT'")['n']    ?? 0;
        $rApproved = dbFetchOne("SELECT COUNT(*) AS n FROM routings WHERE org_id IN ({$in}) AND status='APPROVED'")['n'] ?? 0;
    } catch (Throwable) { $rDraft = 0; $rApproved = 0; }

    return ['users'=>$users,'depts'=>$depts,'parts'=>$parts,
            'routings_draft'=>$rDraft,'routings_approved'=>$rApproved];
}

// v10.5.3.1: Work order status counts per org
function woStatsForOrg(int $orgId): array {
    try {
        $open     = dbFetchOne("SELECT COUNT(*) AS n FROM work_orders WHERE org_id=? AND status='OPEN'",        [$orgId])['n'] ?? 0;
        $inProg   = dbFetchOne("SELECT COUNT(*) AS n FROM work_orders WHERE org_id=? AND status='IN_PROGRESS'",[$orgId])['n'] ?? 0;
        $hardHold = dbFetchOne("SELECT COUNT(*) AS n FROM work_orders WHERE org_id=? AND status='ON_HOLD' AND hold_type='HARD'",[$orgId])['n'] ?? 0;
        $softHold = dbFetchOne("SELECT COUNT(*) AS n FROM work_orders WHERE org_id=? AND status='ON_HOLD' AND hold_type='SOFT'",[$orgId])['n'] ?? 0;
    } catch (Throwable) { $open=0; $inProg=0; $hardHold=0; $softHold=0; }
    return ['open'=>(int)$open,'in_progress'=>(int)$inProg,'hard_hold'=>(int)$hardHold,'soft_hold'=>(int)$softHold];
}

$stats = statsForOrgs($orgIds);

// ── F076: GitHub update check (IT Admin only) ─────────────────────────────────
$updateInfo   = null;
$schemaVer    = null;
$schemaMismatch = false;
if ($isAdmin) {
    try {
        $schemaVer = dbFetchOne(
            "SELECT version FROM schema_version ORDER BY applied_at DESC LIMIT 1"
        );
        $schemaMismatch = $schemaVer && $schemaVer['version'] !== SITE_VERSION;
    } catch (Throwable) {}

    // Check GitHub update cache (1 hour)
    $githubUrl = defined('GITHUB_RELEASE_URL') ? GITHUB_RELEASE_URL :
        dbFetchOne("SELECT config_val FROM system_config WHERE config_key='GITHUB_RELEASE_URL'")['config_val'] ?? '';

    if ($githubUrl && isset($_GET['check_update'])) {
        // Perform live check
        try {
            $ctx = stream_context_create(['http'=>[
                'method'  => 'GET',
                'header'  => "User-Agent: ChrisMES/" . SITE_VERSION . "\r\n",
                'timeout' => 5,
            ]]);
            $raw = @file_get_contents($githubUrl, false, $ctx);
            if ($raw) {
                $release = json_decode($raw, true);
                if (!empty($release['tag_name'])) {
                    $latestVer = ltrim($release['tag_name'], 'v');
                    $zipUrl    = '';
                    foreach ($release['assets'] ?? [] as $asset) {
                        if (str_ends_with($asset['name'], '.zip')) {
                            $zipUrl = $asset['browser_download_url'];
                            break;
                        }
                    }
                    // Cache in DB
                    try {
                        dbExecute("DELETE FROM update_check_cache WHERE 1");
                        dbInsert(
                            "INSERT INTO update_check_cache (latest_version, release_url, zip_url, release_notes, checked_at)
                             VALUES (?, ?, ?, ?, NOW())",
                            [$latestVer, $release['html_url'] ?? '', $zipUrl,
                             substr($release['body'] ?? '', 0, 500)]
                        );
                    } catch (Throwable) {}
                    $updateInfo = ['version'=>$latestVer,'zip_url'=>$zipUrl,
                                   'release_url'=>$release['html_url']??'',
                                   'notes'=>substr($release['body']??'',0,300),
                                   'from_cache'=>false];
                }
            }
        } catch (Throwable) {}
    } elseif ($githubUrl) {
        // Use cache
        try {
            $cache = dbFetchOne(
                "SELECT * FROM update_check_cache
                  WHERE checked_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
                  ORDER BY checked_at DESC LIMIT 1"
            );
            if ($cache) {
                $updateInfo = ['version'=>$cache['latest_version'],'zip_url'=>$cache['zip_url'],
                               'release_url'=>$cache['release_url'],'notes'=>$cache['release_notes'],
                               'from_cache'=>true,'checked_at'=>$cache['checked_at']];
            }
        } catch (Throwable) {}
    }
}

renderPageStart('Dashboard');
?>

<div class="page-header">
    <h1>Welcome back, <?= htmlspecialchars($knownAs) ?></h1>
    <p style="color:var(--text-muted);">
        <?= htmlspecialchars($personaLabel) ?>
        &mdash;
        <?php if ($isAdmin): ?>
            All Organisations (<?= count($visibleOrgs) ?> orgs visible)
        <?php elseif (count($visibleOrgs) === 1): ?>
            <code><?= htmlspecialchars($visibleOrgs[0]['code']) ?></code> — <?= htmlspecialchars($visibleOrgs[0]['name']) ?>
        <?php else: ?>
            <?= count($visibleOrgs) ?> organisations
        <?php endif; ?>
    </p>
</div>

<?php if (TEST_MODE): ?>
<div class="alert alert-warning">
    <strong>⚠ Test Mode Active</strong> — Test accounts can log in using their username as their password.
    Set <code>TEST_MODE = false</code> in <code>config.php</code> before going live.
</div>
<?php endif; ?>

<!-- Per-org routing panel (for IT Admin or multi-org) -->
<?php if ($isAdmin || count($visibleOrgs) > 1): ?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;margin-bottom:20px;">
    <?php foreach ($visibleOrgs as $org):
        try {
            $orgDraft    = dbFetchOne("SELECT COUNT(*) AS n FROM routings WHERE org_id=? AND status='DRAFT'",    [$org['id']])['n'] ?? 0;
            $orgApproved = dbFetchOne("SELECT COUNT(*) AS n FROM routings WHERE org_id=? AND status='APPROVED'", [$org['id']])['n'] ?? 0;
            $orgParts    = dbFetchOne("SELECT COUNT(*) AS n FROM parts WHERE org_id=? AND active=1",             [$org['id']])['n'] ?? 0;
        } catch (Throwable) { $orgDraft=0; $orgApproved=0; $orgParts=0; }
        $wo = woStatsForOrg($org['id']);
    ?>
    <div class="card" style="margin:0;padding:14px 16px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
            <code style="font-size:13px;font-weight:700;color:var(--accent-blue);"><?= htmlspecialchars($org['code']) ?></code>
            <span style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($org['name']) ?></span>
        </div>
        <!-- Routing + parts row -->
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;text-align:center;margin-bottom:8px;">
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:5px;padding:8px 4px;">
                <div style="font-size:20px;font-weight:700;color:var(--accent-blue);font-family:monospace;"><?= $orgParts ?></div>
                <div style="font-size:10px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">Parts</div>
            </div>
            <div style="background:var(--bg);border:1px solid rgba(56,139,253,.3);border-radius:5px;padding:8px 4px;">
                <div style="font-size:20px;font-weight:700;color:var(--accent-blue);font-family:monospace;"><?= $orgDraft ?></div>
                <div style="font-size:10px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">Draft Routings</div>
            </div>
            <div style="background:var(--bg);border:1px solid rgba(35,134,54,.3);border-radius:5px;padding:8px 4px;">
                <div style="font-size:20px;font-weight:700;color:#3fb950;font-family:monospace;"><?= $orgApproved ?></div>
                <div style="font-size:10px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">Live Routings</div>
            </div>
        </div>
        <!-- v10.5.3.1: Work order status row -->
        <div style="font-size:10px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px;">Work Orders</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:5px;text-align:center;">
            <div style="background:var(--bg);border:1px solid rgba(56,139,253,.3);border-radius:5px;padding:7px 3px;">
                <div style="font-size:18px;font-weight:700;color:var(--accent-blue);font-family:monospace;"><?= $wo['open'] ?></div>
                <div style="font-size:9px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">Open</div>
            </div>
            <div style="background:var(--bg);border:1px solid rgba(35,134,54,.3);border-radius:5px;padding:7px 3px;">
                <div style="font-size:18px;font-weight:700;color:#3fb950;font-family:monospace;"><?= $wo['in_progress'] ?></div>
                <div style="font-size:9px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">In Progress</div>
            </div>
            <div style="background:var(--bg);border:1px solid rgba(192,0,0,.3);border-radius:5px;padding:7px 3px;">
                <div style="font-size:18px;font-weight:700;color:var(--accent-danger);font-family:monospace;"><?= $wo['hard_hold'] ?></div>
                <div style="font-size:9px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">⛔ Hard Hold</div>
            </div>
            <div style="background:var(--bg);border:1px solid rgba(191,143,0,.3);border-radius:5px;padding:7px 3px;">
                <div style="font-size:18px;font-weight:700;color:var(--accent-warn);font-family:monospace;"><?= $wo['soft_hold'] ?></div>
                <div style="font-size:9px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.04em;">⚠ Soft Hold</div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- F076: Schema mismatch warning -->
<?php if ($isAdmin && $schemaMismatch): ?>
<div class="alert alert-danger" style="margin-bottom:14px;">
    ⚠ <strong>Schema Version Mismatch:</strong>
    App is at <code><?= SITE_VERSION ?></code> but the database schema is at
    <code><?= htmlspecialchars($schemaVer['version']) ?></code>.
    Run the DB patch for this version via
    <a href="<?= SITE_SUBPATH ?>/admin/deploy.php" style="color:inherit;font-weight:700;">Administration → Deploy</a>.
</div>
<?php endif; ?>

<!-- F076: Update check panel (IT Admin only) -->
<?php if ($isAdmin): ?>
<div class="card" style="margin-bottom:16px;padding:12px 16px;">
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <div style="flex:1;">
            <div style="font-weight:600;font-size:13px;">System Version
                <code style="color:var(--accent-blue);margin-left:6px;"><?= SITE_VERSION ?></code>
                <?php if ($schemaVer): ?>
                <span class="text-dim" style="font-size:11px;margin-left:6px;">
                    DB schema: <code><?= htmlspecialchars($schemaVer['version']) ?></code>
                </span>
                <?php endif; ?>
            </div>
            <?php if ($updateInfo):
                $isNewer = version_compare($updateInfo['version'], SITE_VERSION, '>');
            ?>
            <div style="margin-top:6px;font-size:12px;">
                <?php if ($isNewer): ?>
                <span style="color:var(--accent-warn);font-weight:700;">
                    🔔 Update available: v<?= htmlspecialchars($updateInfo['version']) ?>
                </span>
                <?php if ($updateInfo['notes']): ?>
                <div style="color:var(--text-muted);font-size:11px;margin-top:3px;max-width:500px;">
                    <?= htmlspecialchars(substr($updateInfo['notes'],0,200)) ?>...
                </div>
                <?php endif; ?>
                <?php else: ?>
                <span style="color:#3fb950;">✓ You are on the latest version</span>
                <?php endif; ?>
                <?php if (!empty($updateInfo['from_cache'])): ?>
                <span class="text-dim" style="font-size:10px;margin-left:8px;">
                    Checked <?= displayDate($updateInfo['checked_at'],'d M H:i') ?>
                </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
            <a href="?check_update=1" class="btn btn-secondary" style="font-size:12px;padding:6px 14px;">
                🔍 Check for Updates
            </a>
            <?php if (!empty($updateInfo) && version_compare($updateInfo['version'], SITE_VERSION, '>') && !empty($updateInfo['zip_url'])): ?>
            <a href="<?= SITE_SUBPATH ?>/admin/deploy.php" class="btn btn-primary" style="font-size:12px;padding:6px 14px;">
                ⬆ Deploy v<?= htmlspecialchars($updateInfo['version']) ?>
            </a>
            <?php endif; ?>
            <?php if (!empty($updateInfo['release_url'])): ?>
            <a href="<?= htmlspecialchars($updateInfo['release_url']) ?>" target="_blank"
               class="btn btn-secondary" style="font-size:12px;padding:6px 14px;">
                Release Notes ↗
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Global stats row -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px;">
    <?php
    $statCards = [
        ['n'=>count($visibleOrgs),        'l'=>'Organisations',      'c'=>'var(--accent-blue)'],
        ['n'=>$stats['users'],             'l'=>'Active Users',       'c'=>'var(--accent-blue)'],
        ['n'=>$stats['depts'],             'l'=>'Departments',        'c'=>'var(--accent-blue)'],
        ['n'=>$stats['parts'],             'l'=>'Parts',              'c'=>'var(--accent-blue)'],
        ['n'=>$stats['routings_draft'],    'l'=>'Routings — Draft',   'c'=>'var(--accent-warn)'],
        ['n'=>$stats['routings_approved'], 'l'=>'Routings — Live',    'c'=>'#3fb950'],
    ];
    foreach ($statCards as $sc): ?>
    <div class="card" style="margin:0;text-align:center;padding:14px;">
        <div style="font-size:24px;font-weight:700;color:<?= $sc['c'] ?>;font-family:monospace;"><?= $sc['n'] ?></div>
        <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;"><?= $sc['l'] ?></div>
    </div>
    <?php endforeach; ?>
</div>

<?php
// v10.5.3.1: For single-org users who don't see the org grid above, show WO counts here
if (!$isAdmin && count($visibleOrgs) === 1):
    $wo = woStatsForOrg($visibleOrgs[0]['id']);
?>
<div class="card" style="margin-bottom:20px;padding:14px 16px;">
    <div style="font-weight:600;font-size:13px;margin-bottom:10px;">
        Work Orders —
        <code style="color:var(--accent-blue);"><?= htmlspecialchars($visibleOrgs[0]['code']) ?></code>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;text-align:center;">
        <div style="background:var(--bg);border:1px solid rgba(56,139,253,.3);border-radius:6px;padding:12px 6px;">
            <div style="font-size:28px;font-weight:700;color:var(--accent-blue);font-family:monospace;"><?= $wo['open'] ?></div>
            <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;">Open</div>
        </div>
        <div style="background:var(--bg);border:1px solid rgba(35,134,54,.3);border-radius:6px;padding:12px 6px;">
            <div style="font-size:28px;font-weight:700;color:#3fb950;font-family:monospace;"><?= $wo['in_progress'] ?></div>
            <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;">In Progress</div>
        </div>
        <div style="background:var(--bg);border:1px solid rgba(192,0,0,.3);border-radius:6px;padding:12px 6px;">
            <div style="font-size:28px;font-weight:700;color:var(--accent-danger);font-family:monospace;"><?= $wo['hard_hold'] ?></div>
            <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;">⛔ Hard Hold</div>
        </div>
        <div style="background:var(--bg);border:1px solid rgba(191,143,0,.3);border-radius:6px;padding:12px 6px;">
            <div style="font-size:28px;font-weight:700;color:var(--accent-warn);font-family:monospace;"><?= $wo['soft_hold'] ?></div>
            <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;">⚠ Soft Hold</div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- System status -->
<div class="card">
    <div class="card-title">System Status — Release <?= SITE_VERSION ?> Installed</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px;">
        <div><span class="text-dim">Product:</span> <strong><?= SITE_NAME ?></strong></div>
        <div><span class="text-dim">Version:</span> <code><?= SITE_VERSION ?></code></div>
        <div><span class="text-dim">URL:</span> <code><?= SITE_URL ?></code></div>
        <div><span class="text-dim">Timezone:</span> <code><?= SITE_TIMEZONE ?></code></div>
        <div><span class="text-dim">Current time:</span> <code><?= nowDisplay('d M Y H:i:s T') ?></code></div>
        <div><span class="text-dim">Test Mode:</span>
            <?= TEST_MODE
                ? '<span class="badge badge-yellow">ENABLED</span>'
                : '<span class="badge badge-green">DISABLED</span>' ?>
        </div>
    </div>
</div>

<!-- Quick links -->
<div class="card">
    <div class="card-title">Quick Access</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;">
        <?php if ($isAdmin): ?>
        <a href="<?= SITE_SUBPATH ?>/admin/orgs.php"         class="btn btn-secondary">Organisations</a>
        <a href="<?= SITE_SUBPATH ?>/admin/departments.php"   class="btn btn-secondary">Departments</a>
        <a href="<?= SITE_SUBPATH ?>/admin/resources.php"     class="btn btn-secondary">Resources</a>
        <a href="<?= SITE_SUBPATH ?>/admin/users.php"         class="btn btn-secondary">Users &amp; Roles</a>
        <a href="<?= SITE_SUBPATH ?>/admin/uom.php"           class="btn btn-secondary">Units of Measure</a>
        <a href="<?= SITE_SUBPATH ?>/roadmap.php"             class="btn btn-secondary">Roadmap</a>
        <?php endif; ?>
        <?php if (hasPersona(['SUPERVISOR','MFG_ENGINEER','MFG_ENGINEER_SUP','IT_ADMIN'])): ?>
        <a href="<?= SITE_SUBPATH ?>/workorders/list.php"     class="btn btn-secondary">Work Orders</a>
        <a href="<?= SITE_SUBPATH ?>/routings/list.php"       class="btn btn-secondary">Routings</a>
        <a href="<?= SITE_SUBPATH ?>/items/parts.php"         class="btn btn-secondary">Item Master</a>
        <?php endif; ?>
        <?php if (hasPersona(['OPERATOR','TESTER','INSPECTOR','FINAL_TESTER'])): ?>
        <a href="<?= SITE_SUBPATH ?>/workorders/operator.php" class="btn btn-blue">Operator Screen</a>
        <?php endif; ?>
        <a href="<?= SITE_SUBPATH ?>/docs/list.php"           class="btn btn-secondary">Documents</a>
        <a href="<?= SITE_SUBPATH ?>/supervisor.php"          class="btn btn-secondary">Supervisor View</a>
    </div>
</div>

<?php renderPageEnd(); ?>
