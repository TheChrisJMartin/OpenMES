<?php
/**
 * auth.php — ChrisMES Authentication & Session Helpers
 * Version: 10.6.0
 * v10.6.0: CD009 session cookie hardening; CD003 CSRF functions;
 *          CD005 login rate limiting and brute force protection
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/app_config.php';
loadAppConfig();

// ── CD009: Harden session cookie before session starts ────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => (defined('SITE_SUBPATH') && SITE_SUBPATH !== '') ? SITE_SUBPATH . '/' : '/',
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('CHRISMES_SESS');
    session_start();
}

// ── CD003: CSRF Token helpers ─────────────────────────────────────────────────
if (!function_exists('generateCsrfToken')) {
    function generateCsrfToken(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}
if (!function_exists('verifyCsrfToken')) {
    function verifyCsrfToken(string $token): void {
        if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            http_response_code(403);
            error_log('[ChrisMES] CSRF token mismatch from IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
            die('<div style="font-family:monospace;padding:40px;color:#c00;">
                <h2>403 &mdash; Invalid security token.</h2>
                <p><a href="javascript:history.back()">Go back</a> and try again.</p></div>');
        }
    }
}

// ── CD005: Login rate limiting ────────────────────────────────────────────────
if (!function_exists('checkLoginRateLimit')) {
    function checkLoginRateLimit(string $username, string $ip): array {
        try {
            $cutoff = date('Y-m-d H:i:s', time() - 900); // 15 min window
            $byUser = (int)(dbFetchOne(
                "SELECT COUNT(*) AS n FROM login_attempts WHERE username=? AND success=0 AND attempted_at>?",
                [$username, $cutoff])['n'] ?? 0);
            $byIp = (int)(dbFetchOne(
                "SELECT COUNT(*) AS n FROM login_attempts WHERE ip_address=? AND success=0 AND attempted_at>?",
                [$ip, $cutoff])['n'] ?? 0);
            $fails = max($byUser, $byIp);
            if ($fails >= 10) return ['allowed'=>false,'wait'=>0,'locked'=>true];
            if ($fails >= 5)  return ['allowed'=>true, 'wait'=>2,'locked'=>false];
            return ['allowed'=>true,'wait'=>0,'locked'=>false];
        } catch (Throwable) {
            return ['allowed'=>true,'wait'=>0,'locked'=>false];
        }
    }
}
if (!function_exists('recordLoginAttempt')) {
    function recordLoginAttempt(string $username, string $ip, bool $success): void {
        try {
            dbInsert("INSERT INTO login_attempts (username,ip_address,success,attempted_at) VALUES (?,?,?,NOW())",
                [$username, $ip, $success ? 1 : 0]);
            dbExecute("DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        } catch (Throwable) {}
    }
}

// ── Core Auth Functions ───────────────────────────────────────────────────────




/**
 * Attempt login. Returns user row on success, null on failure.
 */
function attemptLogin(string $username, string $password): ?array {
    $user = dbFetchOne(
        "SELECT u.*, p.code AS persona_code, p.label AS persona_label,
                o.code AS org_code, o.name AS org_name
         FROM users u
         JOIN personas p ON p.id = u.persona_id
         LEFT JOIN orgs o ON o.id = u.org_id
         WHERE u.username = ? AND u.active = 1",
        [$username]
    );

    if (!$user) return null;

    $passwordOk = false;

    // Test mode: username == password (lowercase) for test accounts
    if (TEST_MODE && $user['is_test_acct'] && strtolower($password) === strtolower($username)) {
        $passwordOk = true;
    }

    // Normal bcrypt check
    if (!$passwordOk && password_verify($password, $user['password_hash'])) {
        $passwordOk = true;
    }

    if (!$passwordOk) return null;

    return $user;
}

/**
 * Establish an authenticated session for the given user.
 */
function createSession(array $user): void {
    session_regenerate_id(true);

    $_SESSION['user_id']       = $user['id'];
    $_SESSION['username']      = $user['username'];
    $_SESSION['known_as']      = $user['known_as'];
    $_SESSION['persona_code']  = $user['persona_code'];
    $_SESSION['persona_label'] = $user['persona_label'];
    $_SESSION['org_id']        = $user['org_id'];      // null for IT_ADMIN
    $_SESSION['org_code']      = $user['org_code'];
    $_SESSION['org_name']      = $user['org_name'];
    $_SESSION['theme']         = $user['theme'];
    $_SESSION['logged_in_at']  = time();

    // Write audit log
    writeAuditLog('USER_LOGIN', 'user', (string)$user['id'], $user['org_id'], $user['id'], $user['username'], null, null, null, 'User logged in');

    // v10.5.0: Security log
    writeSecurityLog('LOGIN_OK', 'LOW', (int)$user['id'], $user['username'],
        "Successful login for {$user['username']} ({$user['known_as']})");
}

/**
 * Destroy the current session (logout).
 */
function destroySession(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $userId   = $_SESSION['user_id']   ?? null;
        $username = $_SESSION['username']  ?? null;
        $orgId    = $_SESSION['org_id']    ?? null;

        writeAuditLog('USER_LOGOUT', 'user', (string)$userId, $orgId, $userId, $username, null, null, null, 'User logged out');

        $_SESSION = [];
        session_destroy();
    }
}

/**
 * Check if the current request is authenticated. Returns bool.
 */
function isLoggedIn(): bool {
    if (empty($_SESSION['user_id'])) return false;

    // Session timeout check
    $timeout = SESSION_TIMEOUT_MINUTES * 60;
    if ((time() - ($_SESSION['logged_in_at'] ?? 0)) > $timeout) {
        destroySession();
        return false;
    }

    return true;
}

/**
 * Redirect to login page if not authenticated.
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        $redirect = urlencode($_SERVER['REQUEST_URI'] ?? '');
        header('Location: ' . SITE_URL . '/login.php?redirect=' . $redirect);
        exit;
    }
    // F077: Maintenance mode — redirect non-IT_ADMIN users
    if (defined('MAINTENANCE_MODE') && MAINTENANCE_MODE) {
        $persona = $_SESSION['persona_code'] ?? '';
        if ($persona !== 'IT_ADMIN') {
            // Don't redirect if already on maintenance page
            $uri = $_SERVER['REQUEST_URI'] ?? '';
            if (!str_ends_with($uri, 'maintenance.php')) {
                header('Location: ' . SITE_URL . '/maintenance.php');
                exit;
            }
        }
    }
}

/**
 * Require a specific persona (or array of personas). Shows 403 if not matched.
 */
function requirePersona(string|array $personas): void {
    requireLogin();
    $allowed = is_array($personas) ? $personas : [$personas];
    if (!in_array($_SESSION['persona_code'], $allowed, true)) {
        http_response_code(403);
        include __DIR__ . '/includes/403.php';
        exit;
    }
}

/**
 * Return current user's persona code.
 */
function currentPersona(): string {
    return $_SESSION['persona_code'] ?? '';
}

/**
 * Check if current user has one of the given personas.
 */
function hasPersona(string|array $personas): bool {
    $allowed = is_array($personas) ? $personas : [$personas];
    return in_array(currentPersona(), $allowed, true);
}

/**
 * Return current user's org_id (null for IT_ADMIN).
 */
function currentOrgId(): ?int {
    return isset($_SESSION['org_id']) ? (int)$_SESSION['org_id'] : null;
}

/**
 * Build a WHERE clause fragment to scope queries to the user's org.
 * IT_ADMIN gets no restriction; others get restricted to their org.
 *
 * @param string $alias  Table alias for the org_id column
 * @return array ['sql' => string, 'params' => array]
 */
function orgScope(string $alias = ''): array {
    $col = $alias ? "{$alias}.org_id" : 'org_id';
    if (currentPersona() === 'IT_ADMIN' || currentOrgId() === null) {
        return ['sql' => '1=1', 'params' => []];
    }
    return ['sql' => "{$col} = ?", 'params' => [currentOrgId()]];
}


// writeSecurityLog is defined here so it is available at login time,
// before helpers.php is necessarily included by the calling page.
if (!function_exists("writeSecurityLog")) {
    function writeSecurityLog(string $eventType, string $severity, ?int $userId, ?string $usernameAttempted, ?string $description, ?string $entityType = null, ?int $entityId = null): void {
        try {
            $ip = $_SERVER["HTTP_X_FORWARDED_FOR"] ?? $_SERVER["HTTP_X_REAL_IP"] ?? $_SERVER["REMOTE_ADDR"] ?? null;
            $ua = substr($_SERVER["HTTP_USER_AGENT"] ?? "", 0, 300);
            dbInsert("INSERT INTO security_log (event_type,severity,user_id,username_attempted,ip_address,user_agent,description,entity_type,entity_id,occurred_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())", [$eventType,$severity,$userId,$usernameAttempted,$ip,$ua,$description,$entityType,$entityId]);
        } catch (Throwable $e) { error_log("[ChrisMES] security_log write failed: " . $e->getMessage()); }
    }
}
// ── Audit Log Writer ─────────────────────────────────────────────────────────

/**
 * Write a record to audit_log.
 */
function writeAuditLog(
    string  $eventType,
    ?string $entityType  = null,
    ?string $entityId    = null,
    ?int    $orgId       = null,
    ?int    $userId      = null,
    ?string $username    = null,
    ?string $fieldName   = null,
    ?string $oldValue    = null,
    ?string $newValue    = null,
    ?string $note        = null
): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    // Fall back to session values if not explicitly passed
    if ($userId   === null) $userId   = $_SESSION['user_id']  ?? null;
    if ($username === null) $username = $_SESSION['username'] ?? null;
    if ($orgId    === null) $orgId    = currentOrgId();

    try {
        dbInsert(
            "INSERT INTO audit_log
                (event_type, entity_type, entity_id, org_id, user_id, username,
                 field_name, old_value, new_value, note, ip_address)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            [$eventType, $entityType, $entityId, $orgId, $userId, $username,
             $fieldName, $oldValue, $newValue, $note, $ip]
        );
    } catch (Throwable $e) {
        // Don't let audit failures break the app; log to PHP error log instead
        error_log('[ChrisMES] Audit log write failed: ' . $e->getMessage());
    }
}
