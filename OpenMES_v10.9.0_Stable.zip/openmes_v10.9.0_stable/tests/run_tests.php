<?php
/**
 * tests/run_tests.php — OpenMES Automated Test Suite
 * Version: 10.8.0
 * IT Admin only. Runs a comprehensive suite of checks and reports pass/fail.
 * Also detects PHP parse/fatal errors in key application files.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

// ── Test runner ───────────────────────────────────────────────────────────────
$results = [];
$startTime = microtime(true);

function test(string $category, string $name, callable $fn): void {
    global $results;
    try {
        $result = $fn();
        // fn returns: true = pass, string = fail with message, ['warn'=>msg] = warning
        if ($result === true) {
            $results[] = ['cat'=>$category,'name'=>$name,'status'=>'PASS','msg'=>''];
        } elseif (is_array($result) && isset($result['warn'])) {
            $results[] = ['cat'=>$category,'name'=>$name,'status'=>'WARN','msg'=>$result['warn']];
        } else {
            $results[] = ['cat'=>$category,'name'=>$name,'status'=>'FAIL',
                          'msg'=>is_string($result) ? $result : 'Test returned false'];
        }
    } catch (Throwable $e) {
        $results[] = ['cat'=>$category,'name'=>$name,'status'=>'FAIL',
                      'msg'=>'Exception: ' . $e->getMessage()];
    }
}

$root = dirname(__DIR__);

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 1: PHP FILE SYNTAX
// ══════════════════════════════════════════════════════════════════════════════
$keyFiles = [
    'auth.php', 'db.php', 'config.php', 'login.php', 'dashboard.php',
    'index.php', 'analytics.php', 'supervisor.php',
    'includes/layout.php', 'includes/helpers.php', 'includes/app_config.php',
    'includes/broadcast_banner.php',
    'admin/deploy.php', 'admin/users.php', 'admin/config.php',
    'admin/orgs.php', 'admin/departments.php', 'admin/resources.php',
    'admin/locations.php', 'admin/uom.php', 'admin/serial_registers.php',
    'admin/security_log.php',
    'workorders/create.php', 'workorders/operator.php',
    'workorders/list.php', 'workorders/view.php',
    'routings/edit.php', 'routings/list.php', 'routings/create.php',
    'routings/approve.php', 'routings/quality_vars.php',
    'routings/quality_vars_list.php',
    'docs/upload.php', 'docs/list.php', 'docs/view.php',
    'docs/approve.php', 'docs/reports.php', 'docs/serve_report.php',
    'items/parts.php',
    'quality/nc_list.php', 'quality/nc_detail.php',
    'quality/nc_disposition.php', 'quality/analytics.php',
    'api/serve_pdf.php', 'api/book_stock.php', 'api/clock_action.php',
    'api/clockon_serial.php', 'api/raise_nc.php', 'api/submit_qv.php',
];

foreach ($keyFiles as $file) {
    test('PHP Syntax', $file, function() use ($root, $file) {
        $path = $root . '/' . $file;
        if (!file_exists($path)) {
            return "File not found: {$file}";
        }
        $content = file_get_contents($path);
        if ($content === false) return "Cannot read file";

        // Syntax check: token_get_all raises E_COMPILE_WARNING on parse errors.
        // This is the only reliable check — brace counting is unreliable in
        // mixed PHP/HTML files because JS/CSS blocks contain their own braces.
        $parseError = null;
        set_error_handler(function($errno, $errstr) use (&$parseError) {
            $parseError = $errstr;
        });
        @token_get_all($content);
        restore_error_handler();
        if ($parseError) return "Parse error: {$parseError}";

        return true;
    });
}

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 2: DATABASE TABLES
// ══════════════════════════════════════════════════════════════════════════════
$requiredTables = [
    'orgs','users','personas','departments','resources',
    'parts','uom','routings','routing_operations',
    'work_orders','serial_numbers','wo_active_clocks','wo_stock_bookings',
    'wo_change_log','non_conformances','nc_serials','nc_corrective_actions',
    'quality_variables','quality_results',
    'documents','inventory_locations',
    'skills','user_skills',
    'calibration_tools',
    'integration_outbound',
    'system_config','schema_version',
    'login_attempts','deployments','update_check_cache',
    'security_log',
];

foreach ($requiredTables as $table) {
    test('Database Tables', "Table: {$table}", function() use ($table) {
        try {
            dbFetchOne("SELECT 1 FROM `{$table}` LIMIT 1");
            return true;
        } catch (Throwable $e) {
            if (str_contains($e->getMessage(), "doesn't exist")) return "Table missing";
            return true; // Table exists but is empty — that's fine
        }
    });
}

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 3: SCHEMA & VERSION
// ══════════════════════════════════════════════════════════════════════════════
test('Schema', 'Schema version exists', function() {
    $v = dbFetchOne("SELECT version FROM schema_version ORDER BY applied_at DESC LIMIT 1");
    return $v ? true : 'No schema version records found';
});

test('Schema', 'App version in system_config', function() {
    $v = dbFetchOne("SELECT config_val FROM system_config WHERE config_key='SITE_VERSION'");
    return $v ? true : 'SITE_VERSION not found in system_config';
});

test('Schema', 'Schema version matches app version', function() {
    $schema = dbFetchOne("SELECT version FROM schema_version ORDER BY applied_at DESC LIMIT 1");
    $app    = dbFetchOne("SELECT config_val FROM system_config WHERE config_key='SITE_VERSION'");
    if (!$schema || !$app) return ['warn' => 'Cannot compare — version records missing'];
    if ($schema['version'] !== $app['config_val']) {
        return ['warn' => "Schema={$schema['version']} App={$app['config_val']} — run DB patch"];
    }
    return true;
});

test('Schema', 'nc_corrective_actions table has correct columns', function() {
    try {
        $cols = dbFetchAll("SHOW COLUMNS FROM nc_corrective_actions");
        $names = array_column($cols, 'Field');
        $required = ['id','nc_id','ca_description','ca_owner','ca_due_date',
                     'effectiveness_review_date','created_by','created_at'];
        $missing = array_diff($required, $names);
        return empty($missing) ? true : 'Missing columns: ' . implode(', ', $missing);
    } catch (Throwable) {
        return 'Table does not exist — run db_patch_v10.8.0.sql';
    }
});

test('Schema', 'work_orders has fai_required column', function() {
    try {
        $cols = dbFetchAll("SHOW COLUMNS FROM work_orders");
        $names = array_column($cols, 'Field');
        return in_array('fai_required', $names) ? true : 'fai_required column missing — run db_patch_v10.8.0.sql';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
});

test('Schema', 'documents has doc_owner and review_date columns', function() {
    try {
        $cols = dbFetchAll("SHOW COLUMNS FROM documents");
        $names = array_column($cols, 'Field');
        $missing = array_diff(['doc_owner','review_date'], $names);
        return empty($missing) ? true : 'Missing: ' . implode(', ', $missing) . ' — run db_patch_v10.8.0.sql';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
});

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 4: CONFIGURATION
// ══════════════════════════════════════════════════════════════════════════════
test('Configuration', 'TEST_MODE status', function() {
    if (!defined('TEST_MODE')) return 'TEST_MODE not defined';
    return TEST_MODE
        ? ['warn' => 'TEST_MODE is ON — username=password for test accounts. Disable before go-live.']
        : true;
});

test('Configuration', 'SITE_URL correctly set', function() {
    if (!defined('SITE_URL')) return 'SITE_URL not defined';
    if (str_contains(SITE_URL, 'localhost') || str_contains(SITE_URL, '127.0.0.1')) {
        return ['warn' => 'SITE_URL points to localhost — OK for dev, not for production'];
    }
    if (str_contains(SITE_URL, 'dashboard.php') || str_contains(SITE_URL, '.php')) {
        return 'SITE_URL contains a PHP filename — should be base URL only (e.g. https://domain.com)';
    }
    return true;
});

test('Configuration', 'GITHUB_RELEASE_URL configured', function() {
    $v = dbFetchOne("SELECT config_val FROM system_config WHERE config_key='GITHUB_RELEASE_URL'");
    if (!$v || empty($v['config_val'])) {
        return ['warn' => 'GITHUB_RELEASE_URL not set — update checks disabled'];
    }
    return true;
});

test('Configuration', 'AUTO_APPROVE setting exists', function() {
    return defined('AUTO_APPROVE_DOCS') ? true : ['warn' => 'AUTO_APPROVE_DOCS not defined — check system_config'];
});

test('Configuration', 'Timezone configured', function() {
    if (!defined('SITE_TIMEZONE')) return ['warn' => 'SITE_TIMEZONE not defined'];
    try {
        new DateTimeZone(SITE_TIMEZONE);
        return true;
    } catch (Throwable) {
        return 'Invalid timezone: ' . SITE_TIMEZONE;
    }
});

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 5: FILE SYSTEM
// ══════════════════════════════════════════════════════════════════════════════
test('File System', 'Uploads directory exists', function() use ($root) {
    $path = $root . '/uploads/documents';
    return is_dir($path) ? true : 'Directory missing: uploads/documents';
});

test('File System', 'Uploads directory writable', function() use ($root) {
    $path = $root . '/uploads/documents';
    if (!is_dir($path)) return 'Directory missing';
    return is_writable($path) ? true : 'Directory not writable — check permissions';
});

test('File System', 'uploads/documents/.htaccess present', function() use ($root) {
    $path = $root . '/uploads/documents/.htaccess';
    return file_exists($path) ? true :
        ['warn' => '.htaccess missing from uploads/documents — direct file access may be possible'];
});

test('File System', 'docs/reports directory exists', function() use ($root) {
    return is_dir($root . '/docs/reports') ? true : 'docs/reports directory missing';
});

test('File System', 'System reports present', function() use ($root) {
    $reports = [
        'ISA95_Gap_Analysis.pdf',
        'ISO9001_Gap_Analysis.pdf',
        'Security_Vulnerability_Report.pdf',
        'User_Manual_v10.7.0.pdf',
    ];
    $missing = array_filter($reports, fn($f) => !file_exists($root . '/docs/reports/' . $f));
    return empty($missing) ? true :
        ['warn' => 'Missing reports: ' . implode(', ', $missing)];
});

test('File System', 'Web root .htaccess present', function() use ($root) {
    return file_exists($root . '/.htaccess') ? true :
        ['warn' => '.htaccess missing from web root — security headers and file protection inactive'];
});

test('File System', 'Deploy backup directory writable', function() use ($root) {
    $path = $root . '/_deploy_backups';
    if (!is_dir($path)) {
        @mkdir($path, 0755, true);
    }
    return is_writable($path) ? true :
        ['warn' => '_deploy_backups not writable — deployer cannot create backups'];
});

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 6: SECURITY
// ══════════════════════════════════════════════════════════════════════════════
test('Security', 'setup_passwords.php not present', function() use ($root) {
    return !file_exists($root . '/setup_passwords.php') ? true :
        'DANGER: setup_passwords.php found in web root — delete immediately';
});

// Removed: config (2).php test — not relevant on clean installs

test('Security', 'CSRF functions defined', function() {
    return function_exists('generateCsrfToken') && function_exists('verifyCsrfToken')
        ? true : 'CSRF functions not defined — check auth.php';
});

test('Security', 'login_attempts table accessible', function() {
    try {
        dbFetchOne("SELECT COUNT(*) AS n FROM login_attempts");
        return true;
    } catch (Throwable) {
        return 'login_attempts table missing — brute force protection inactive';
    }
});

test('Security', 'Password hashing bcrypt', function() {
    $hash = password_hash('test', PASSWORD_BCRYPT);
    return password_verify('test', $hash) ? true : 'password_hash/verify not working';
});

test('Security', 'ZipArchive extension available', function() {
    return class_exists('ZipArchive') ? true :
        'ZipArchive not available — in-app deployer cannot function';
});

test('Security', 'finfo extension available', function() {
    return function_exists('finfo_open') ? true :
        ['warn' => 'finfo not available — PDF MIME type validation inactive (CD007)'];
});

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 7: BUSINESS DATA
// ══════════════════════════════════════════════════════════════════════════════
test('Business Data', 'At least one active org exists', function() {
    $n = (int)(dbFetchOne("SELECT COUNT(*) AS n FROM orgs WHERE active=1 AND is_admin=0")['n'] ?? 0);
    return $n > 0 ? true : 'No active business orgs found';
});

test('Business Data', 'At least one IT Admin user exists', function() {
    $n = (int)(dbFetchOne(
        "SELECT COUNT(*) AS n FROM users u
         JOIN personas p ON p.id=u.persona_id
         WHERE p.code='IT_ADMIN' AND u.active=1")['n'] ?? 0);
    return $n > 0 ? true : 'No active IT Admin users found';
});

test('Business Data', 'Standard UoM present (EA)', function() {
    $v = dbFetchOne("SELECT id FROM uom WHERE code='EA'");
    return $v ? true : ['warn' => 'EA (Each) UoM not found — add standard UoMs'];
});

test('Business Data', 'Standard UoM present (KG)', function() {
    $v = dbFetchOne("SELECT id FROM uom WHERE code='KG'");
    return $v ? true : ['warn' => 'KG UoM not found — add standard UoMs'];
});

test('Business Data', 'Default serial register exists', function() {
    $v = dbFetchOne("SELECT id FROM serial_registers WHERE register_code LIKE 'DEF%'");
    return $v ? true : ['warn' => 'No default serial register found'];
});

test('Business Data', 'Personas table populated', function() {
    $n = (int)(dbFetchOne("SELECT COUNT(*) AS n FROM personas")['n'] ?? 0);
    return $n >= 10 ? true : "Only {$n} personas found — expected 11+";
});

test('Business Data', 'No work orders in invalid state', function() {
    $n = (int)(dbFetchOne(
        "SELECT COUNT(*) AS n FROM work_orders
         WHERE status NOT IN ('OPEN','IN_PROGRESS','ON_HOLD','COMPLETE','CANCELLED')")['n'] ?? 0);
    return $n === 0 ? true : "{$n} work orders have invalid status values";
});

test('Business Data', 'Inventory locations exist', function() {
    $n = (int)(dbFetchOne("SELECT COUNT(*) AS n FROM inventory_locations WHERE active=1")['n'] ?? 0);
    return $n > 0 ? true : ['warn' => 'No active inventory locations — Book to Stock will fail'];
});

// ══════════════════════════════════════════════════════════════════════════════
// CATEGORY 8: PHP ENVIRONMENT
// ══════════════════════════════════════════════════════════════════════════════
test('PHP Environment', 'PHP version 8.0+', function() {
    return version_compare(PHP_VERSION, '8.0.0', '>=') ? true :
        'PHP ' . PHP_VERSION . ' — OpenMES requires PHP 8.0+';
});

test('PHP Environment', 'PDO MySQL extension', function() {
    return in_array('mysql', PDO::getAvailableDrivers()) ? true :
        'PDO MySQL driver not available';
});

test('PHP Environment', 'upload_max_filesize adequate', function() {
    $max = ini_get('upload_max_filesize');
    $bytes = (int)$max * (str_ends_with($max,'M') ? 1048576 : (str_ends_with($max,'K') ? 1024 : 1));
    return $bytes >= 10485760 ? true :
        ['warn' => "upload_max_filesize={$max} — may prevent large release zip uploads (need 10M+)"];
});

test('PHP Environment', 'post_max_size adequate', function() {
    $max = ini_get('post_max_size');
    $bytes = (int)$max * (str_ends_with($max,'M') ? 1048576 : (str_ends_with($max,'K') ? 1024 : 1));
    return $bytes >= 10485760 ? true :
        ['warn' => "post_max_size={$max} — may prevent large zip uploads"];
});

test('PHP Environment', 'display_errors is off', function() {
    return !ini_get('display_errors') ? true :
        ['warn' => 'display_errors is ON — disable in production to prevent information disclosure'];
});

test('PHP Environment', 'Session working', function() {
    return session_status() === PHP_SESSION_ACTIVE ? true : 'Session not active';
});

// ── Summary ───────────────────────────────────────────────────────────────────
$elapsed   = round((microtime(true) - $startTime) * 1000);
$pass      = count(array_filter($results, fn($r) => $r['status'] === 'PASS'));
$fail      = count(array_filter($results, fn($r) => $r['status'] === 'FAIL'));
$warn      = count(array_filter($results, fn($r) => $r['status'] === 'WARN'));
$total     = count($results);

renderPageStart('Test Suite');
?>

<div class="page-header page-header-row">
    <div>
        <h1>🧪 Automated Test Suite</h1>
        <p style="color:var(--text-muted);">OpenMES v<?= SITE_VERSION ?> — <?= $total ?> tests in <?= $elapsed ?>ms</p>
    </div>
    <a href="run_tests.php" class="btn btn-secondary">↻ Re-run</a>
</div>

<!-- Summary bar -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:10px;margin-bottom:18px;">
    <?php foreach ([
        ['Total',   $total, 'var(--text)'],
        ['Passed',  $pass,  '#3fb950'],
        ['Failed',  $fail,  'var(--accent-danger)'],
        ['Warnings',$warn,  'var(--accent-warn)'],
    ] as [$label,$val,$col]): ?>
    <div class="card" style="margin:0;text-align:center;padding:14px;">
        <div style="font-size:28px;font-weight:800;color:<?= $col ?>;font-family:monospace;"><?= $val ?></div>
        <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;"><?= $label ?></div>
    </div>
    <?php endforeach; ?>
</div>

<?php if ($fail > 0): ?>
<div class="alert alert-danger" style="margin-bottom:14px;">
    ⛔ <strong><?= $fail ?> test<?= $fail > 1 ? 's' : '' ?> failed.</strong>
    Review failures below and resolve before going live.
</div>
<?php elseif ($warn > 0): ?>
<div class="alert alert-warning" style="margin-bottom:14px;">
    ⚠ All tests passed with <?= $warn ?> warning<?= $warn > 1 ? 's' : '' ?>. Review warnings below.
</div>
<?php else: ?>
<div class="alert alert-success" style="margin-bottom:14px;">
    ✓ All <?= $total ?> tests passed.
</div>
<?php endif; ?>

<!-- Results by category -->
<?php
$categories = array_unique(array_column($results, 'cat'));
foreach ($categories as $cat):
    $catResults = array_filter($results, fn($r) => $r['cat'] === $cat);
    $catFail = count(array_filter($catResults, fn($r) => $r['status'] === 'FAIL'));
    $catWarn = count(array_filter($catResults, fn($r) => $r['status'] === 'WARN'));
    $catPass = count(array_filter($catResults, fn($r) => $r['status'] === 'PASS'));
    $catIcon = $catFail > 0 ? '⛔' : ($catWarn > 0 ? '⚠' : '✓');
    $catColor = $catFail > 0 ? 'var(--accent-danger)' : ($catWarn > 0 ? 'var(--accent-warn)' : '#3fb950');
?>
<div class="card" style="margin-bottom:14px;padding:0;overflow:hidden;">
    <div style="padding:10px 16px;border-bottom:1px solid var(--border);
                display:flex;align-items:center;justify-content:space-between;
                background:var(--bg);">
        <span style="font-weight:700;font-size:13px;">
            <span style="color:<?= $catColor ?>"><?= $catIcon ?></span>
            <?= htmlspecialchars($cat) ?>
        </span>
        <span style="font-size:11px;color:var(--text-muted);">
            <?= $catPass ?> passed
            <?= $catFail > 0 ? " &nbsp;|&nbsp; <span style='color:var(--accent-danger);font-weight:700;'>{$catFail} failed</span>" : '' ?>
            <?= $catWarn > 0 ? " &nbsp;|&nbsp; <span style='color:var(--accent-warn);'>{$catWarn} warnings</span>" : '' ?>
        </span>
    </div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr>
                    <th style="width:80px;">Status</th>
                    <th>Test</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($catResults as $r):
                $icon  = match($r['status']) { 'PASS'=>'✓','FAIL'=>'⛔','WARN'=>'⚠', default=>'' };
                $color = match($r['status']) {
                    'PASS' => '#3fb950',
                    'FAIL' => 'var(--accent-danger)',
                    'WARN' => 'var(--accent-warn)',
                    default => 'var(--text)'
                };
            ?>
            <tr>
                <td>
                    <span style="color:<?= $color ?>;font-weight:700;font-size:12px;">
                        <?= $icon ?> <?= $r['status'] ?>
                    </span>
                </td>
                <td style="font-size:12px;font-family:<?= $r['cat']==='PHP Syntax'?'monospace':'inherit' ?>;">
                    <?= htmlspecialchars($r['name']) ?>
                </td>
                <td style="font-size:12px;color:<?= $r['msg'] ? $color : 'var(--text-muted)' ?>;">
                    <?= $r['msg'] ? htmlspecialchars($r['msg']) : '—' ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endforeach; ?>

<div style="font-size:11px;color:var(--text-dim);text-align:center;margin-top:8px;">
    OpenMES Test Suite — <?= date('d M Y H:i:s') ?> — PHP <?= PHP_VERSION ?> — <?= $elapsed ?>ms
</div>

<?php renderPageEnd(); ?>
