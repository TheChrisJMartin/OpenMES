<?php
/**
 * roadmap.php — ChrisMES Release Roadmap
 * Version: 10.5.5
 * Product: ChrisMES — https://ChrisMES.Chris-Martin.co.uk
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/layout.php';

requireLogin();
requirePersona('IT_ADMIN');

$roadmap = [
    [
        'release'     => '1.0.0',
        'title'       => 'Foundation & Authentication',
        'status'      => 'delivered',
        'target'      => 'Sprint 1',
        'description' => 'Core infrastructure, database schema, authentication and multi-org shell.',
        'features'    => [
            'config.php — site name (ChrisMES), URL, timezone (Europe/London GMT/BST), test mode, feature switches',
            'db.php — PDO MySQL connector with helpers (dbFetchAll, dbFetchOne, dbExecute, dbInsert)',
            'install.sql — full database schema + seed data',
            'auth.php — requireLogin(), requirePersona(), orgScope(), writeAuditLog(), session timeout',
            'login.php — bcrypt (cost 12) passwords; TEST_MODE username=password for test accounts',
            'logout.php — session destruction + audit log',
            'dashboard.php — welcome screen with system stats and quick links',
            'roadmap.php — this file (IT Admin only)',
            'includes/layout.php — left-hand nav shell, CSS design system (dark/light), icon helpers',
            'api/set_theme.php — AJAX theme toggle saved to user profile',
            'setup_passwords.php — CLI tool to hash test account passwords',
            'Personas: IT_ADMIN, SUPERVISOR, OPERATOR, TESTER, INSPECTOR, FINAL_TESTER, MFG_ENGINEER, MFG_ENGINEER_SUP, ENGINEER, QUALITY_ENGINEER',
            'Test accounts: 12 BIKE users + 3 TEACLUB users; is_test_acct flag; TEST_MODE toggle',
            'Multi-org: IT Admin sees all; all others org high-walled via orgScope()',
            'Seed orgs: ADMIN, BIKE (4 depts, 10 resources), TEACLUB (3 depts, 4 resources)',
            'Standard UoMs: EA, KG, G, LTR, ML, MTR, MM, HR, MIN, SET, BOX, PCE (system-locked)',
            'Default serial register: DEF00000–DEF99999',
            'Integration table schema stubs: integration_inbound, integration_outbound',
            'audit_log table with indexes on entity, user, org, timestamp',
        ],
    ],
    [
        'release'     => '2.0.0',
        'title'       => 'Organisation, User & Item Master Management',
        'status'      => 'delivered',
        'target'      => 'Sprint 2',
        'description' => 'IT Admin CRUD screens for orgs, departments, resources, users and the item master.',
        'features'    => [
            'Org management: create/edit (5-char code + name); ORGS_LOCKED config switch',
            'Department management: 10-char code, org tree; DEPARTMENTS_LOCKED config switch',
            'Resource management: dept assignment, active flag; RESOURCES_LOCKED config switch',
            'User management: surname, firstname, known-as, active, direct/indirect, persona, org, test flag',
            'User privileges screen — assign/change persona',
            'Item Master: part number (immutable), revision, description, UoM, serial/lot, make/buy, shelf-life',
            'Part version auto-increment on tool-side change; PARTS_LOCKED config switch',
            'Audit log on all part, org, dept, resource changes',
            'UoM management: system UoMs locked; custom UoMs addable',
            'Inventory locations management screen',
            'Seed items: BIKE (Frame, Wheel, Tyre, Chain, Gear Set, Saddle, Handlebar, Brake Set); TEACLUB (Tea Bag, Coffee Bean, Cup, Lid, Water)',
        ],
    ],
    [
        'release'     => '3.0.0',
        'title'       => 'Document / Work Instruction Management',
        'status'      => 'delivered',
        'target'      => 'Sprint 3',
        'description' => 'PDF upload, revision control, approval workflow and in-browser rendering.',
        'features'    => [
            'PDF upload linked to org; optional part number attachment',
            'Generic docs: GENERIC-DOC-[GUID] with free text description',
            'Revision: starts 000001, increments on each new upload',
            'States: DRAFT → APPROVED → SUPERSEDED (no delete ever)',
            'Approval: different user (ME / ME Supervisor); IT Admin auto-approve (AUTO_APPROVE_DOCS config)',
            'Approval audit: approver + timestamp; auto-approve flagged with ⚡',
            'In-browser PDF rendering (PDF.js) with page navigation and zoom',
            'api/serve_pdf.php — authenticated PDF streamer, never exposes filesystem path',
            'Document list: filter by org, part, status',
            'New revision upload supersedes current approved revision automatically',
            'Revision history panel on view screen',
            'Seed documents for BIKE and TEACL orgs',
        ],
    ],
    [
        'release'     => '4.0.0',
        'title'       => 'Routing Editor, Document Enhancements & Revision Control',
        'status'      => 'delivered',
        'target'      => 'Sprint 4',
        'description' => 'Routing creation and operation editor. Also delivers document list improvements and the new ARCHIVED document status requested after Release 3.',
        'features'    => [
            '— Document Enhancements (carried from R3 feedback) —',
            'docs/list.php: show ALL revisions not just latest — full history visible on list screen',
            'Superseded badge changed to yellow (was grey)',
            'New ARCHIVED document status: superseded docs can be archived by MFG_ENGINEER_SUP',
            'Archived docs cannot be attached to routing operations or new work orders',
            'Archive action available on doc list and view screens',
            '— Routing Editor —',
            'Routing named ORG-PARTNUMBER; states DRAFT → APPROVED → ARCHIVED (no delete)',
            'Revision control 000001+; approval mirrors document workflow; AUTO_APPROVE_ROUTINGS config',
            'Routing editor: add/edit/reorder operations with drag handles',
            'Operation fields: number, CLOCKING/NON-CLOCKING behaviour, name, type, dept, resource, approved document',
            'Op types: Standard, Inspection, Final Test, Final Inspection, Book to Stock, Material Kitting',
            'Standard work durations per op: SETUP (mins) and ACTUAL (mins)',
            'Only APPROVED (non-archived) documents can be attached to operations',
            'Routing audit log: all changes recorded with user and timestamp',
            'Seed routings: BIKE Road Bike Assembly + MTB Assembly; TEACL Tea Brew + Coffee Brew',
            'Ops 001 and 999 seeded as NON-CLOCKING on all seed routings',
        ],
    ],
    [
        'release'     => '5.0.0',
        'title'       => 'Work Order Creation & Serial/Lot Management',
        'status'      => 'delivered',
        'target'      => 'Sprint 5',
        'description' => 'WO creation by IT Admin / Supervisor, serial/lot allocation, integration table activation.',
        'features'    => [
            'WO number format: ORGxxxxxxx e.g. BIKE0000001; carries part number + name + routing revision',
            'Routing selection: default latest approved; dropdown for earlier revision',
            'Serialised: up to MAX_SERIALS_PER_WO (config, default 100)',
            'Lot-controlled: up to MAX_LOT_QTY_PER_WO (config, default 1000); system lot number',
            'Serial register: pattern-based allocation; Quality Engineer managed',
            'WO list + search; WO info button (booked hours, routing rev, change log)',
            'ALLOW_WO_CREATION config switch',
            'Integration tables activated; message type enum defined',
        ],
    ],
    [
        'release'     => '6.0.0',
        'title'       => 'Operator Execution Screen & Clock On/Off',
        'status'      => 'delivered',
        'target'      => 'Sprint 6',
        'description' => 'Operator execution: clock on/off, live timer, PDF in-screen, partial quantities.',
        'features'    => [
            'Search by WO number, Resource, or currently clocked-on',
            'Colour-coded status: grey/blue/green/red per serial per op',
            'Clock on to 1 or all serials; live timer; PDF work instruction shown',
            'Clock off subset; complete op; partial quantity splits across ops',
            'Non-clocking ops auto-advanced; Book to Stock at op 999',
            'BTS blocked: open NCs or incomplete test records',
            'Overrun visual flag; full audit_event_log on all transitions',
        ],
    ],
    [
        'release'     => '7.0.0',
        'title'       => 'Non-Conformance & Disposition Workflow',
        'status'      => 'delivered',
        'target'      => 'Sprint 7',
        'description' => 'NC raising during execution, WO hold management, Engineer disposition.',
        'features'    => [
            'NC button while clocked on; NC0000001/1 numbering; sub-slash for multiple items/defects',
            'Serialised WOs: each serial recorded; NC puts WO on HOLD',
            'Disposition: Continue, Scrap, Modify WO Ops (not the master routing)',
            'Hold types: FULL HOLD, SOFT HOLD (work to next Inspection op only)',
            'NC list and detail for ENGINEER persona; full audit trail',
        ],
    ],
    [
        'release'     => '8.0.0',
        'title'       => 'Clock-On Bug Fix & Broadcast Messages',
        'status'      => 'delivered',
        'target'      => 'Sprint 8',
        'description' => 'Fixes the false "already clocked on" error when clocking onto serial numbers, and introduces the system-wide broadcast banner for IT Admins.',
        'features'    => [
            'BUG FIX: Clock-on false positive — wo_active_clocks check now scoped to current user + current op only',
            'BUG FIX: Stale wo_active_clocks rows from prior sessions no longer block re-clock-on',
            'FEATURE: Broadcast message banner — IT Admin can set a 128-char message with Red/Yellow/Green colour',
            'FEATURE: Banner displayed sticky below topbar on every page for all logged-in users',
            'FEATURE: Admin → Broadcast Message screen (admin/broadcast.php)',
            'FEATURE: Activate/deactivate toggle; only one message active at a time',
            'FEATURE: Message history table showing last 15 messages with creator and timestamp',
            'FEATURE: All broadcast changes written to audit_log',
            'DB: broadcast_messages table (db_patch_v8.1.0.sql)',
            'config.php: SITE_VERSION updated to 8.1.0',
            'includes/layout.php: banner rendered between topbar and content on every page',
            'includes/layout.php: Administration menu gains Broadcast Message link',
        ],
    ],
    [
        'release'     => '9.0.0',
        'title'       => 'Tooling, Calibration & Operator Skills',
        'status'      => 'delivered',
        'target'      => 'Sprint 9',
        'description' => 'Calibration database for tools and test equipment, tool recording during execution, and a skills matrix controlling who can clock on to or complete an operation.',
        'features'    => [
            '— Tooling & Calibration —',
            'New persona: QUALITY_TRAINING_MANAGER — owns skills library, training records, training approvals; reads NCs and supervisor screen',
            'Calibration database: maintained by Quality Engineer; org high-walled; viewable by all',
            'Tool record fields: unique asset number (T-prefix = tooling, TE-prefix = test equipment), description, org, calibration due date, active flag',
            'Seed tooling: BIKE — Torque Screwdriver (TE-BIKE-001), Tyre Pressure Gauge (TE-BIKE-002); TEACLUB — Calibrated Spoon (T-TEA-001), Thermometer (TE-TEA-001)',
            'Routing operation editor: optionally attach one or more tools/TE required for the operation',
            'Operator execution: record tooling/TE used while clocked on to an operation',
            'Expired calibration hard-blocks tool recording — clear warning message shown to operator',
            'Tool recording audit log: asset number, WO, operation, serial, user, timestamp',
            '— Operator Skills —',
            'Skills library: created and maintained by Quality Training Manager; org high-walled',
            'Example skills seeded: BIKE — Torque Setting, Wheel Building; TEACLUB — Tea Brewing Level 1, Temperature Measurement',
            'User skill records: skill, assigned by, approved by (Quality Training Manager), approval date, expiry date',
            'Skill expiry: on expiry date the skill lapses automatically and all associated gates are blocked',
            'Dashboard alert: Quality Training Manager sees operators with skills expiring within 30 days',
            'Routing operation editor: optionally attach one or more required skills per operation',
            'Gate type per skill requirement: CLOCK_ON, COMPLETION, or BOTH — set when adding skill to operation',
            'Execution enforcement: at clock-on and/or completion, system checks operator holds active (approved, non-expired) skill; blocks with clear message if not',
            'Skills matrix screen: shows all users and their skills with expiry status (Quality Training Manager view)',
            'Skill assignment screen: Quality Training Manager assigns skills to users and approves them',
        ],
    ],
    [
        'release'     => '10.0.0',
        'title'       => 'Quality Variables & ERP Integration Layer',
        'status'      => 'delivered',
        'target'      => 'Sprint 10',
        'description' => 'Quality variable collection at inspection and test operations, out-of-spec NC triggering, and ERP integration event generation.',
        'features'    => [
            '— Quality Variables —',
            'Quality variables defined per routing (tab on routing editor page)',
            'Variable fields: name, unit of measure, lower limit, upper limit, target value, linked operation',
            'Collection UI shown during operator execution at Inspection / Final Test / Final Inspection op types',
            'Out-of-spec result automatically triggers NC process on the affected serial',
            'Test records must be fully complete before Book to Stock is permitted',
            'Seed quality variables: TEACLUB — Tea Brew Temperature (lower 90°C, upper 100°C, target 95°C); BIKE — Tyre Pressure Front (90–110 PSI), Tyre Pressure Rear (100–120 PSI)',
            '— ERP Integration —',
            'TimeAttendanceOUT event on operation completion: WO, op number, serial, clock-on/off times, average duration per serial when multiple clocked',
            'TimeAttendanceOUT event on clock-off without completion',
            'Integration log screen (IT Admin): view inbound and outbound messages, status, payload, error codes',
            'Paused flag: IT Admin can pause outbound message processing per message or in bulk',
            'Inbound message stubs: WorkOrderIN, PartItemIN, DepartmentIN, ResourceIN, WorkOrderMoveIN — schema defined, processing framework in place',
            'UoM validation on PartItemIN: reject and audit log if UoM code not found in MES',
        ],
    ],
    [
                'release'     => '11.0.0',
        'title'       => 'ISA-95 Compliance Review',
        'status'      => 'delivered',
        'target'      => 'Sprint 11',
        'description' => 'Review ChrisMES against ISA-95 Parts 1, 2 and 3. Gap analysis complete — findings in gap register for promotion to feature backlog.',
        'features'    => [
            'ISA-95 gap analysis PDF report produced covering Parts 1, 2 and 3 (DELIVERED as part of R11 planning)',
            'Gap register with 20 findings: 4 HIGH, 7 MEDIUM, 9 LOW severity',
            'F036: Document/implement Site-level hierarchy mapping (GAP-001)',
            'F037: Persona-to-ISA-95 role mapping document (GAP-002)',
            'F038: Level 3/4 boundary document with ISA-95 annotations (GAP-003)',
            'F039: Qualification levels on Skills Library — Level 1/2/Assessor (GAP-004)',
            'F040: Personnel Class concept as prerequisite for Supervisor Planner (GAP-005)',
            'F041: Equipment capability attributes on Resources — capacity, op types, hours (GAP-006)',
            'F042: Material lot genealogy — deferred to Receiving Inspection sprint (GAP-007)',
            'F043: Planner Code UI on Parts screen — DB column exists, UI to be built (GAP-008)',
            'F044: D030 fix — QV changes on approved routing require new revision + approval; QV_BYPASS config for dev (GAP-009)',
            'F045: WorkOrderIN processing — WO creation from ERP schedule (GAP-012)',
            'F046: Supervisor dispatching — push WO to specific operator/workstation (GAP-013)',
            'F047: Indirect labour suppression (F033) and non-productive bookings (F034) (GAP-015)',
            'F048: PASS/FAIL/CONDITIONAL status codes on quality results + include in WorkOrderOUT (GAP-016)',
            'F049: Include planned vs actual hours in WorkOrderOUT payload (GAP-017)',
            'F050: OEE calculation in Analytics + KPI export to integration outbound (GAP-018)',
            'F051: Maintenance Management sprint — future requirement (GAP-019)',
            'F052: WIP location tracking at workstation level + inventory movement log (GAP-020)',
        ],
    ],
    [
        'release'     => '12.0.0',
        'title'       => 'ISO-9001:2015 Compliance Review',
        'status'      => 'delivered',
        'target'      => 'Sprint 12',
        'description' => 'Review of ChrisMES against ISO-9001:2015 QMS requirements. Gap analysis report (ChrisMES-ISO9001-GAP-001) produced with 30 findings across all clauses. Gap register reviewed and findings promoted to feature backlog.',
        'features'    => [
            'ISO-9001:2015 gap analysis PDF report produced (30 findings: 0 HIGH, 11 MEDIUM, 19 LOW)',
            'Gap register reviewed — all medium and low findings promoted to feature backlog',
            'F055: ISO-001/002 — QMS context and stakeholder requirements fields on org configuration',
            'F056: ISO-003 — QMS process map documentation; enforce all process gates in code',
            'F057: ISO-006 — Risk classification field on NCs (likelihood, severity, risk score)',
            'F058: ISO-007 — Quality objective targets with RAG status in Analytics dashboard',
            'F059: ISO-009 — Calibration certificate PDF attachment and calibration history log per asset; traceable-to-standard field',
            'F060: ISO-011 — Quality policy text on org config; display on operator dashboard; operator acknowledgement flag',
            'F061: ISO-013 — WITHDRAWN status for work instruction documents; review date and document owner fields',
            'F062: ISO-014 — First Article Inspection (FAI) flag on work orders — first serial on new routing revision triggers mandatory inspection',
            'F063: ISO-015 — Customer order reference field on work orders',
            'F064: ISO-017 — Supplier register and supplier quality ratings (scope into R14 Receiving Inspection)',
            'F065: ISO-018 — Environment as a quality variable type for production condition monitoring',
            'F066: ISO-020 — Customer-supplied flag on serial numbers and calibration tools',
            'F067: ISO-021 — Shelf-life expiry enforcement at WO creation and Book to Stock',
            'F044 (D030/F044) — ISO-022 highest priority: QV change control through routing approval (already in backlog from ISA-95)',
            'F068: ISO-023 — Formal release record with approver identity on Book to Stock action',
            'F069: ISO-025 — Period-over-period trend comparison in Analytics; KPI targets with RAG (links F058)',
            'F070: ISO-026 — Audit data export feature: all QMS-relevant data in single exportable view',
            'F071: ISO-027 — Management review record within ChrisMES',
            'F072: ISO-029 — Corrective action record on NC disposition: systemic fix, owner, due date, effectiveness review date',
            'F073: ISO-029 — NC trend analysis in Analytics: recurring defect codes, parts with highest NC rates',
        ],
    ],
    [
        'release'     => '13.0.0',
        'title'       => 'Advanced Features, Tooling Enforcement & System Hardening',
        'status'      => 'planned',
        'target'      => 'Sprint 13',
        'description' => 'Advanced features and hardening sprint incorporating ISA-95 and ISO-9001 gap analysis findings. Includes tooling enforcement, serial register enhancements, WorkOrderIN processing, quality data improvements, calibration certificates, corrective action records, and OEE analytics.',
        'features'    => [
            '— Tooling & Skills Enforcement —',
            'Pre-operation information panel on operator screen: shown before clock-on, lists all tools and skills required for the upcoming operation',
            'Panel shows calibration status of each tool and expiry status of each required skill inline',
            'Operation completion hard-blocked until all required tools have been recorded against the serial',
            'Clock-on hard-blocked if skill gate type is CLOCK_ON or BOTH and operator lacks the skill',
            '— Serial Registers & Part Families —',
            'Serial register screen (Quality Engineer): alphanumeric, hexadecimal (0-9,A-F), and alpha (A-Z counting) patterns (F030, F031)',
            'Aviation letter suppression per org — configurable from system config (F032)',
            'Part family management: group part numbers; shared serial register across family members',
            'F043: Planner Code UI on Parts screen',
            '— Advanced Routing —',
            'Exclusive operations in routing editor: define mutually exclusive op groups',
            '— Supervision & Administration —',
            'Supervisor / IT Admin: force clock-off any operator from the supervisor screen; audit logged',
            'F045: WorkOrderIN processing — WO creation from ERP schedule',
            'F048: PASS/FAIL/CONDITIONAL status codes on quality results + include in WorkOrderOUT',
            'F049: Planned vs actual hours in WorkOrderOUT payload',
            '— Integration hardening —',
            'RoutingOUT and WorkOrderMoveOUT events; full audit report screen; DB index optimisation',
            '— ISA-95 / ISO-9001 Features (from gap analysis reviews) —',
            'F044: D030 fix — QV changes on approved routing require new revision + approval; QV_BYPASS config for dev (CRITICAL — cited by ISA-95 GAP-009 AND ISO-9001 Clause 8.5.6)',
            'F043: Planner Code UI on Parts screen',
            'F045: WorkOrderIN processing from ERP schedule',
            'F048: PASS/FAIL/CONDITIONAL status codes on quality results; include in WorkOrderOUT',
            'F049: Planned vs actual hours in WorkOrderOUT payload',
            'F050: OEE (Availability x Performance x Quality) in Analytics; KPI export to integration',
            'F052: WIP location tracking at workstation level; inventory movement log',
            'F059: Calibration certificate PDF attachment; calibration history log per asset; traceable-to-standard field (ISO-9001 Clause 7.1.5)',
            'F061: WITHDRAWN document status; review date and document owner on work instructions (ISO-9001 Clause 7.5)',
            'F062: First Article Inspection (FAI) flag on work orders (ISO-9001 Clause 8.1)',
            'F064: Supplier register and supplier quality ratings — scope into R14 Receiving Inspection (ISO-9001 Clause 8.4)',
            'F068: Formal release record with approver identity on Book to Stock (ISO-9001 Clause 8.6)',
            'F069: Period-over-period trend comparison in Analytics (ISO-9001 Clause 9.1)',
            'F070: Audit data export — all QMS-relevant data in single exportable view (ISO-9001 Clause 9.2)',
            'F072: Corrective action record on NC disposition: systemic fix, owner, due date, effectiveness review date (ISO-9001 Clause 10.2)',
            'F073: NC trend analysis in Analytics: recurring defect codes, parts with highest NC rates (ISO-9001 Clause 10.2)',
        ],
    ],
    [
        'release'     => '14.0.0',
        'title'       => 'Receiving Inspection',
        'status'      => 'planned',
        'target'      => 'Sprint 14',
        'description' => 'Goods-in receiving inspection workflow. Requirements TBD.',
        'features'    => [
            'Goods receipt creation; inspection workflow; accept/reject/quarantine outcomes',
            'Integration with existing NC process for failed receipts',
            'Link to item master and inventory locations',
            'F042: Material lot genealogy / sublots',
            'Supplier certificate of conformance capture (under review)',
            'AQL sampling plans (under review)',
        ],
    ],
    [
        'release'     => '15.0.0',
        'title'       => 'Authorisation Profiles',
        'status'      => 'planned',
        'target'      => 'Sprint 15',
        'description' => 'Replace fixed-persona access control with configurable tick-box permission profiles.',
        'features'    => [
            'Permission profile builder: IT Admin defines named profiles with tick-box access rights',
            'Users assigned a profile rather than a fixed persona',
            'Existing personas migrated to equivalent profiles on upgrade',
            'Fine-grained access: individual screens and actions per profile',
            'Profile audit log',
        ],
    ],
    [
        'release'     => '16.0.0',
        'title'       => 'Repairs / MRO Execution',
        'status'      => 'planned',
        'target'      => 'Sprint 16',
        'description' => 'MRO repair order execution for MRO-type organisations.',
        'features'    => [
            'Repair order creation linked to a serialised asset',
            'Fault capture at receipt; flexible repair routing',
            'Parts consumption and labour booking',
            'Repair disposition: fixed, scrap, beyond economic repair',
            'Certificate of Conformance output',
        ],
    ],
    [
        'release'     => '17.0.0',
        'title'       => 'SAML / SSO Integration',
        'status'      => 'planned',
        'target'      => 'Sprint 17',
        'description' => 'SAML 2.0 Single Sign-On — ChrisMES as Service Provider.',
        'features'    => [
            'Azure AD, Okta, Google Workspace, ADFS support',
            'Just-In-Time user provisioning; role mapping from IdP groups',
            'Single Log-Out (SLO); username/password fallback for IT Admin',
            'All SAML events logged to security_log at HIGH severity',
        ],
    ],
    [
        'release'     => '18.0.0',
        'title'       => 'Control Sheet PDF Generation',
        'status'      => 'planned',
        'target'      => 'Sprint 18',
        'description' => 'Printable control sheets (PDF traveller documents) for work orders.',
        'features'    => [
            'Control sheet per WO or per serial; routing ops checklist; QV spec limits',
            'Operator sign-off boxes per operation',
            'Barcodes for WO and serial number (see R20)',
        ],
    ],
    [
        'release'     => '19.0.0',
        'title'       => 'Repair Report Card PDF Generation',
        'status'      => 'planned',
        'target'      => 'Sprint 19',
        'description' => 'Printable repair report cards for MRO repair orders. Requires R16.',
        'features'    => [
            'Asset details, fault description, repair actions, parts used, test results',
            'NC and disposition summary; Certificate of Conformance section',
            'Barcodes for repair order and asset (see R20)',
        ],
    ],
    [
        'release'     => '20.0.0',
        'title'       => 'Barcode Generation',
        'status'      => 'planned',
        'target'      => 'Sprint 20',
        'description' => 'Embed barcodes in control sheets (R18) and repair cards (R19). Browser camera scanning.',
        'features'    => [
            'Code 128 and QR code formats; embedded in PDF output',
            'Operator screen barcode scan to look up WO or serial',
            'Hardware barcode scanner support via keyboard wedge',
        ],
    ],
    [
        'release'     => '21.0.0',
        'title'       => 'RFID Labels via 3rd Party Software',
        'status'      => 'planned',
        'target'      => 'Sprint 21',
        'description' => 'Integration with 3rd party RFID label printing middleware.',
        'features'    => [
            'RFID_PRINT_OUT outbound message with payload for middleware',
            'UHF Gen 2 EPC standard (ISO 18000-6C)',
            'Hardware and middleware TBD',
        ],
    ],
    [
        'release'     => '22.0.0',
        'title'       => 'Supervisor Planner — MES Resource Planning',
        'status'      => 'planned',
        'target'      => 'Sprint 22',
        'description' => 'Electronic Program Guide (EPG) style resource planner for supervisors. Operators maintain shift availability; system proposes who works on which work order.',
        'features'    => [
            'F035: Supervisor Planner — EPG view of the org showing WOs, ops, and operator assignments',
            'F040: Personnel Class model prerequisite — operators grouped by skill set for scheduling',
            'F041: Equipment capability attributes prerequisite — resource capacity and availability',
            'F046: Supervisor dispatching — push WO to specific operator/workstation',
            'Operator shift pattern maintenance: 8/8/8/5, mark days off, set availability',
            'System proposes a plan based on: WO priority, op skill requirements, operator qualifications, planned hours',
            'Supervisor reviews and confirms the plan; plan creates operator assignments',
            'Live EPG view updates as operators clock on/off and complete operations',
            'F050: OEE and capacity utilisation displayed in planner view',
        ],
    ],
    [
        'release'     => '23.0.0',
        'title'       => 'Non-Productive Bookings',
        'status'      => 'planned',
        'target'      => 'Sprint 23',
        'description' => 'Allow operators to book time against non-productive project codes (Union Business, First Aid, Training etc.) with indirect labour TimeAttendanceOUT suppression.',
        'features'    => [
            'F034: Non-productive project codes defined at org level by IT Admin',
            'F033: Suppress TimeAttendanceOUT when booking user is flagged as Indirect labour',
            'F047: Indirect labour time routes to non-productive bookings, not production ops',
            'Operator screen: option to clock on to a project code rather than a WO',
            'Project code bookings appear in supervisor and analytics views separately from production time',
            'Integration: non-productive bookings published as NonProductiveOUT message type',
        ],
    ],
    [
        'release'     => '25.0.0',
        'title'       => 'Licensing Model',
        'status'      => 'planned',
        'target'      => 'Sprint 25',
        'description' => 'Licensing framework for ChrisMES. Full requirements TBD.',
        'features'    => [
            'Requirements to be defined in a future session',
            'Likely scope: licence key generation and validation, per-org or per-user licensing',
            'Licence expiry enforcement and renewal workflow',
            'Usage reporting and licence compliance dashboard',
            'Potential licence server integration',
        ],
    ],
];

function statusBadge(string $s): string {
    return match($s) {
        'delivered'   => '<span class="badge badge-green">✓ Delivered</span>',
        'in-progress' => '<span class="badge badge-blue">⟳ In Progress</span>',
        'deferred'    => '<span class="badge badge-yellow">Deferred</span>',
        default       => '<span class="badge badge-grey">Planned</span>',
    };
}

$total     = count($roadmap);
$features  = array_sum(array_map(fn($r) => count($r['features']), $roadmap));
$delivered = count(array_filter($roadmap, fn($r) => $r['status'] === 'delivered'));

renderPageStart('Release Roadmap');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Release Roadmap</h1>
        <p><?= SITE_NAME ?> &mdash; <code><?= SITE_URL ?></code> &mdash; AI-managed release cycle</p>
    </div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:22px;">
    <?php foreach ([
        [$total,           'Total Releases'],
        [$features,        'Feature Items'],
        [$delivered,       'Delivered'],
        [$total-$delivered,'Remaining'],
    ] as [$n, $l]): ?>
    <div class="card" style="margin:0;text-align:center;padding:16px;">
        <div style="font-size:26px;font-weight:700;color:var(--accent-blue);font-family:monospace;"><?= $n ?></div>
        <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:3px;"><?= $l ?></div>
    </div>
    <?php endforeach; ?>
</div>

<div style="display:flex;flex-direction:column;gap:10px;" id="roadmap-list">
<?php foreach ($roadmap as $i => $r):
    $bl = match($r['status']) {
        'delivered'   => 'var(--accent)',
        'in-progress' => 'var(--accent-blue)',
        'deferred'    => 'var(--accent-warn)',
        default       => 'var(--border)',
    };
    $startOpen = in_array($r['status'], ['delivered','in-progress']);
?>
<div style="background:var(--bg-card);border:1px solid var(--border);border-left:3px solid <?=$bl?>;border-radius:var(--radius);overflow:hidden;">
    <div style="display:flex;align-items:center;gap:12px;padding:13px 16px;cursor:pointer;"
         onclick="var b=this.nextElementSibling;b.style.display=b.style.display==='none'?'block':'none';this.querySelector('.c').style.transform=b.style.display==='block'?'rotate(180deg)':'rotate(0deg)'">
        <code style="font-size:11px;color:var(--text-dim);background:var(--bg);border:1px solid var(--border);border-radius:4px;padding:2px 8px;white-space:nowrap;">v<?= htmlspecialchars($r['release']) ?></code>
        <span style="flex:1;font-weight:600;"><?= htmlspecialchars($r['title']) ?></span>
        <span style="font-size:11px;color:var(--text-dim);white-space:nowrap;"><?= htmlspecialchars($r['target']) ?></span>
        <?= statusBadge($r['status']) ?>
        <span class="c" style="color:var(--text-dim);transition:transform .2s;font-size:11px;<?= $startOpen?'transform:rotate(180deg)':'' ?>">▼</span>
    </div>
    <div style="display:<?= $startOpen?'block':'none' ?>;border-top:1px solid var(--border);padding:14px 16px;">
        <p style="color:var(--text-muted);font-size:13px;margin-bottom:10px;"><?= htmlspecialchars($r['description']) ?></p>
        <div style="font-size:11px;color:var(--text-dim);margin-bottom:8px;"><?= count($r['features']) ?> feature items</div>
        <ul style="list-style:none;display:grid;grid-template-columns:1fr 1fr;gap:5px 18px;">
        <?php foreach ($r['features'] as $f): ?>
            <li style="display:flex;gap:6px;font-size:12px;color:var(--text-muted);align-items:flex-start;line-height:1.4;">
                <span style="color:var(--accent-blue);flex-shrink:0;">▸</span><?= htmlspecialchars($f) ?>
            </li>
        <?php endforeach; ?>
        </ul>
    </div>
</div>
<?php endforeach; ?>
</div>

<div style="margin-top:28px;padding-top:18px;border-top:1px solid var(--border);display:flex;justify-content:space-between;font-size:11px;color:var(--text-dim);font-family:monospace;flex-wrap:wrap;gap:6px;">
    <span>roadmap.php &mdash; ChrisMES v<?= SITE_VERSION ?> &mdash; AI-managed release versioning</span>
    <span>Generated: <?= date('d M Y H:i T') ?></span>
</div>

<?php renderPageEnd(); ?>
