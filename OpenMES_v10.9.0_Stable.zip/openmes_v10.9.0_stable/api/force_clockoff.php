<?php
/**
 * api/force_clockoff.php — Force Clock-Off
 * Version: 10.9.0
 * F090: Supervisor/IT Admin can forcefully clock an operator off a serial.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','SUPERVISOR']);
header('Content-Type: application/json');

verifyCsrfToken($_POST['csrf_token'] ?? '');

$serialId = (int)($_POST['serial_id'] ?? 0);
$reason   = trim($_POST['reason'] ?? '');

if (!$serialId) {
    echo json_encode(['ok'=>false,'error'=>'No serial specified.']); exit;
}

// Find active clock for this serial
$clock = dbFetchOne(
    "SELECT ac.*, sn.serial_number, sn.wo_id, sn.current_op_id,
            u.known_as AS operator_name
       FROM wo_active_clocks ac
       JOIN serial_numbers sn ON sn.id = ac.serial_id
       JOIN users u ON u.id = ac.user_id
      WHERE ac.serial_id = ?",
    [$serialId]
);

if (!$clock) {
    echo json_encode(['ok'=>false,'error'=>'No active clock found for this serial.']); exit;
}

$pdo = getDB();
$pdo->beginTransaction();
try {
    $now      = date('Y-m-d H:i:s');
    $duration = max(0, strtotime($now) - strtotime($clock['clocked_on_at']));

    // Insert clock event
    dbInsert(
        "INSERT INTO wo_clock_events
            (wo_id, serial_id, op_id, user_id, event_type, clocked_on_at, clocked_off_at, duration_mins)
         VALUES (?,?,?,?,?,?,?,?)",
        [$clock['wo_id'], $serialId, $clock['op_id'], $clock['user_id'],
         'FORCE_CLOCKOFF', $clock['clocked_on_at'], $now, $duration]
    );

    // Remove active clock
    dbExecute("DELETE FROM wo_active_clocks WHERE serial_id=?", [$serialId]);

    // Log force clock-off
    dbInsert(
        "INSERT INTO force_clockoff_log
            (serial_id, op_id, forced_off_user, forced_by_user, reason, forced_at)
         VALUES (?,?,?,?,?,NOW())",
        [$serialId, $clock['op_id'], $clock['user_id'],
         $_SESSION['user_id'], $reason ?: null]
    );

    // Audit log
    writeAuditLog('FORCE_CLOCKOFF', 'serial_number', (string)$serialId,
        null, null, null, null, null, null,
        "Force clock-off of {$clock['operator_name']} on serial {$clock['serial_number']} by {$_SESSION['known_as']}"
        . ($reason ? ". Reason: {$reason}" : ''));

    $pdo->commit();
    echo json_encode([
        'ok'       => true,
        'message'  => "Successfully clocked off {$clock['operator_name']} from serial {$clock['serial_number']}."
    ]);
} catch (Throwable $e) {
    $pdo->rollBack();
    echo json_encode(['ok'=>false,'error'=>'Failed: ' . $e->getMessage()]);
}
