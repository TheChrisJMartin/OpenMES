<?php
/**
 * api/clock_action.php — Clock On / Off / Complete handler
 * Version: 10.5.0
 *
 * Fix v8.1.0 (clock-on false positive bug):
 *   The wo_active_clocks duplicate check at the per-serial level was:
 *       SELECT id FROM wo_active_clocks WHERE serial_id = ?
 *   This checked if ANY user had a row for that serial, not just the current user.
 *   If a stale row existed (e.g. from a previous session not cleaned up, or another
 *   user's clock-on entry), it silently skipped the serial and the operator saw the
 *   popup claiming the serial was already clocked on.
 *
 *   Fix: The check now explicitly filters by the current user_id AND verifies the
 *   row's op_id matches the serial's current_op_id, so it only blocks genuine
 *   double-clock-on by the same user on the same operation.
 *
 *   The broader stale-row cleanup at the top of the clock_on branch already handles
 *   orphaned rows from other scenarios; this fix closes the per-serial gap.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
header('Content-Type: application/json');

$body      = json_decode(file_get_contents('php://input'), true) ?? [];
$action    = $body['action']     ?? '';
$woId      = (int)($body['wo_id']    ?? 0);
$serialIds = array_map('intval', $body['serial_ids'] ?? []);

if (!in_array($action, ['clock_on','clock_off','complete']) || !$woId || !$serialIds) {
    echo json_encode(['ok'=>false,'error'=>'Invalid parameters.']); exit;
}

// ── Fetch WO — no alias so orgScope works correctly ───────────────────────────
$scope = orgScope();
$wo = dbFetchOne(
    "SELECT * FROM work_orders WHERE id=? AND ({$scope['sql']})",
    array_merge([$woId], $scope['params'])
);

if (!$wo) {
    echo json_encode(['ok'=>false,'error'=>'Work order not found or access denied.']); exit;
}

if ($wo['status'] === 'ON_HOLD' && $wo['hold_type'] === 'HARD') {
    echo json_encode(['ok'=>false,'error'=>'Work order is on Hard Hold. Contact your Engineer to release it.']); exit;
}

$pdo = getDB();
$pdo->beginTransaction();

try {
    $processed = 0;
    $docId     = null;

    // ── Cross-op validation for CLOCK_ON ─────────────────────────────────────
    if ($action === 'clock_on') {

        // Step 1: Purge stale active_clock rows for this user
        dbExecute(
            "DELETE ac FROM wo_active_clocks ac
             JOIN routing_operations ro ON ro.id = ac.op_id
             WHERE ac.user_id = ? AND ro.behaviour = 'NON-CLOCKING'",
            [$_SESSION['user_id']]
        );
        dbExecute(
            "DELETE ac FROM wo_active_clocks ac
             JOIN serial_numbers sn ON sn.id = ac.serial_id
             WHERE ac.user_id = ?
               AND sn.status NOT IN ('IN_PROGRESS','NOT_STARTED')",
            [$_SESSION['user_id']]
        );
        dbExecute(
            "DELETE ac FROM wo_active_clocks ac
             JOIN serial_numbers sn ON sn.id = ac.serial_id
             WHERE ac.user_id = ?
               AND sn.current_op_id != ac.op_id
               AND sn.status = 'NOT_STARTED'",
            [$_SESSION['user_id']]
        );

        // Step 2: Auto-advance serials stuck on NON-CLOCKING ops in this WO
        $routingId = dbFetchOne("SELECT routing_id FROM work_orders WHERE id=?", [$woId])['routing_id'] ?? null;
        if ($routingId) {
            $ncOps = dbFetchAll(
                "SELECT id, sort_order FROM routing_operations
                 WHERE routing_id=? AND behaviour='NON-CLOCKING' ORDER BY sort_order",
                [$routingId]
            );
            foreach ($ncOps as $ncOp) {
                $nextClocking = dbFetchOne(
                    "SELECT id FROM routing_operations
                     WHERE routing_id=? AND sort_order > ? AND behaviour='CLOCKING'
                     ORDER BY sort_order LIMIT 1",
                    [$routingId, $ncOp['sort_order']]
                );
                if ($nextClocking) {
                    dbExecute(
                        "UPDATE serial_numbers
                         SET current_op_id=?, updated_at=NOW()
                         WHERE wo_id=? AND current_op_id=?
                           AND status NOT IN ('COMPLETE','SCRAPPED')",
                        [$nextClocking['id'], $woId, $ncOp['id']]
                    );
                }
            }
        }

        // Step 3: Resolve target op for the first requested serial
        $targetSerial = dbFetchOne(
            "SELECT sn.current_op_id, ro.behaviour, ro.op_number
             FROM serial_numbers sn
             LEFT JOIN routing_operations ro ON ro.id = sn.current_op_id
             WHERE sn.id=?",
            [$serialIds[0]]
        );
        $targetOpId = $targetSerial['current_op_id'] ?? null;

        // Step 4: Check if user is already clocked onto a DIFFERENT CLOCKING op
        // v8.2.0 FIX: Scope to the SAME wo_id. Previously no wo_id filter meant
        // a clock-on row on any other WO (e.g. TEACL0000001 op 40) would block
        // clock-on to this WO (e.g. TEACL0000003). Cross-WO clocking is valid.
        $existingClock = dbFetchOne(
            "SELECT ac.op_id, ro.op_number
             FROM wo_active_clocks ac
             JOIN routing_operations ro ON ro.id = ac.op_id
             WHERE ac.user_id = ?
               AND ac.wo_id   = ?
               AND ro.behaviour = 'CLOCKING'
             LIMIT 1",
            [$_SESSION['user_id'], $woId]
        );

        if ($existingClock && $targetOpId &&
            (int)$existingClock['op_id'] !== (int)$targetOpId) {
            $opNum = str_pad($existingClock['op_number'], 3, '0', STR_PAD_LEFT);
            $pdo->rollBack();
            echo json_encode([
                'ok'    => false,
                'error' => "You are already clocked on to Op {$opNum}. Clock off that operation before clocking on to a different one."
            ]);
            exit;
        }
    }

    foreach ($serialIds as $snId) {
        $sn = dbFetchOne(
            "SELECT sn.*, ro.op_number, ro.behaviour, ro.op_type,
                    ro.actual_mins AS std_mins, ro.sort_order, ro.id AS op_id_val
             FROM serial_numbers sn
             LEFT JOIN routing_operations ro ON ro.id = sn.current_op_id
             WHERE sn.id=? AND sn.wo_id=?",
            [$snId, $woId]
        );
        if (!$sn || in_array($sn['status'], ['COMPLETE','SCRAPPED'])) continue;

        // ── v9.0.0: Skill gate enforcement ───────────────────────────────────
        // Check before processing clock_on or complete actions.
        // Skills with gate_type CLOCK_ON or BOTH block clock-on.
        // Skills with gate_type COMPLETION or BOTH block completion.
        if (in_array($action, ['clock_on', 'complete']) && $sn['op_id_val']) {
            $gateTypes = $action === 'clock_on'
                ? ['CLOCK_ON', 'BOTH']
                : ['COMPLETION', 'BOTH'];

            $placeholders = implode(',', array_fill(0, count($gateTypes), '?'));
            $requiredSkills = dbFetchAll(
                "SELECT ros.skill_id, ros.gate_type, sk.code, sk.name
                   FROM routing_op_skills ros
                   JOIN skills sk ON sk.id = ros.skill_id
                  WHERE ros.op_id = ?
                    AND ros.gate_type IN ({$placeholders})",
                array_merge([$sn['op_id_val']], $gateTypes)
            );

            foreach ($requiredSkills as $req) {
                // Check operator holds this skill in APPROVED status and not expired
                $held = dbFetchOne(
                    "SELECT id FROM user_skills
                      WHERE user_id  = ?
                        AND skill_id = ?
                        AND status   = 'APPROVED'
                        AND (expiry_date IS NULL OR expiry_date >= CURDATE())",
                    [$_SESSION['user_id'], $req['skill_id']]
                );
                if (!$held) {
                    $pdo->rollBack();
                    $gateLabel = $action === 'clock_on' ? 'clock on to' : 'complete';
                    echo json_encode([
                        'ok'    => false,
                        'error' => "You do not hold the required skill to {$gateLabel} this operation: "
                                 . "{$req['code']} — {$req['name']}. "
                                 . "Contact your Quality Training Manager."
                    ]);
                    exit;
                }
            }
        }

        // ── CLOCK ON ─────────────────────────────────────────────────────────
        if ($action === 'clock_on') {

            // v8.1.0 FIX: Only block if THIS USER already has an active clock-on
            // for THIS serial on THIS operation.
            $existing = dbFetchOne(
                "SELECT id FROM wo_active_clocks
                  WHERE serial_id = ?
                    AND user_id   = ?
                    AND op_id     = ?",
                [$snId, $_SESSION['user_id'], $sn['op_id_val']]
            );
            if ($existing) continue; // genuine double-click by same user on same op

            dbInsert(
                "INSERT INTO wo_active_clocks (wo_id,serial_id,op_id,user_id,clocked_on_at)
                 VALUES (?,?,?,?,NOW())",
                [$woId, $snId, $sn['op_id_val'], $_SESSION['user_id']]
            );
            dbExecute(
                "UPDATE serial_numbers SET status='IN_PROGRESS', updated_at=NOW() WHERE id=?",
                [$snId]
            );
            dbInsert(
                "INSERT INTO wo_clock_events (wo_id,serial_id,op_id,user_id,event_type,clocked_on_at)
                 VALUES (?,?,?,?,'CLOCK_ON',NOW())",
                [$woId, $snId, $sn['op_id_val'], $_SESSION['user_id']]
            );
            writeAuditLog('CLOCK_ON','serial_number',(string)$snId,$wo['org_id'],null,null,
                'status','NOT_STARTED','IN_PROGRESS',
                "Clocked on: {$sn['serial_number']} WO {$wo['wo_number']} op {$sn['op_number']}");

            if ($docId === null && $sn['op_id_val']) {
                $opDoc = dbFetchOne(
                    "SELECT document_id FROM routing_operations WHERE id=?",
                    [$sn['op_id_val']]
                );
                $docId = $opDoc['document_id'] ?? null;
            }
            $processed++;

        // ── CLOCK OFF ────────────────────────────────────────────────────────
        } elseif ($action === 'clock_off') {
            $active = dbFetchOne(
                "SELECT * FROM wo_active_clocks WHERE serial_id=? AND user_id=?",
                [$snId, $_SESSION['user_id']]
            );
            if (!$active) continue;

            $durationMins = round(calcDuration($active['clocked_on_at']), 2);
            $isOverrun    = ($sn['std_mins'] > 0 && $durationMins > $sn['std_mins']) ? 1 : 0;

            dbExecute("DELETE FROM wo_active_clocks WHERE serial_id=?", [$snId]);
            dbInsert(
                "INSERT INTO wo_clock_events
                    (wo_id,serial_id,op_id,user_id,event_type,
                     clocked_on_at,clocked_off_at,duration_mins,is_overrun)
                 VALUES (?,?,?,?,'CLOCK_OFF',?,NOW(),?,?)",
                [$woId,$snId,$sn['op_id_val'],$_SESSION['user_id'],
                 $active['clocked_on_at'],$durationMins,$isOverrun]
            );
            fireTimeAttendanceOut($wo, $sn, $durationMins, $active['clocked_on_at'], 'CLOCK_OFF');
            writeAuditLog('CLOCK_OFF','serial_number',(string)$snId,$wo['org_id'],null,null,
                null,null,null,
                "Clocked off: {$sn['serial_number']} WO {$wo['wo_number']} op {$sn['op_number']} — {$durationMins}m");
            $processed++;

        // ── COMPLETE ─────────────────────────────────────────────────────────
        } elseif ($action === 'complete') {
            // F086: Check required tools have been recorded
            $reqTools = dbFetchAll(
                "SELECT ort.tool_id, ct.asset_number, ct.calibration_due
                   FROM op_required_tools ort
                   JOIN calibration_tools ct ON ct.id=ort.tool_id
                  WHERE ort.op_id=?",
                [$sn['op_id_val']]
            );
            foreach ($reqTools as $req) {
                // F087: Check calibration not expired
                if ($req['calibration_due'] && $req['calibration_due'] < date('Y-m-d')) {
                    $pdo->rollBack();
                    echo json_encode(['ok'=>false,'error'=>
                        "Tool {$req['asset_number']} has an expired calibration date. "
                        . "Contact your Quality Engineer before completing."]);
                    exit;
                }
                // Check tool recorded against this serial
                $recorded = dbFetchOne(
                    "SELECT id FROM wo_tool_records WHERE wo_id=? AND serial_id=? AND tool_id=?",
                    [$woId, $snId, $req['tool_id']]
                );
                if (!$recorded) {
                    $pdo->rollBack();
                    echo json_encode(['ok'=>false,'error'=>
                        "Required tool {$req['asset_number']} has not been recorded. "
                        . "Please record all required tools before completing."]);
                    exit;
                }
            }
            $active = dbFetchOne(
                "SELECT * FROM wo_active_clocks WHERE serial_id=? AND user_id=?",
                [$snId, $_SESSION['user_id']]
            );
            if (!$active) continue;

            // v10.5.0: SOFT hold blocks completion but allows clock-on
            if ($wo['status'] === 'ON_HOLD' && $wo['hold_type'] === 'SOFT' && $action === 'complete') {
                $pdo->rollBack();
                echo json_encode(['ok'=>false,'error'=>'Work order is on Soft Hold — you can clock on but cannot complete operations. Contact your Engineer.']);
                exit;
            }

            // v10.5.0: Block QV completeness check
            $pendingQvs = dbFetchOne(
                "SELECT COUNT(*) AS required,
                        (SELECT COUNT(*) FROM quality_results qr
                          WHERE qr.serial_id=? AND qr.op_id=?) AS collected
                   FROM quality_variables qv
                  WHERE qv.op_id=? AND qv.active=1",
                [$snId, $sn['op_id_val'], $sn['op_id_val']]
            );
            if ($pendingQvs && (int)$pendingQvs['required'] > 0
                && (int)$pendingQvs['collected'] < (int)$pendingQvs['required']) {
                $pdo->rollBack();
                echo json_encode([
                    'ok'    => false,
                    'error' => 'Quality measurements must be recorded before completing this operation. '
                             . 'Please enter all required measurements.',
                    'qv_required' => true,
                ]);
                exit;
            }

            $clockedOnAt  = $active['clocked_on_at'];
            $durationMins = round(calcDuration($clockedOnAt), 2);
            $isOverrun    = ($sn['std_mins'] > 0 && $durationMins > $sn['std_mins']) ? 1 : 0;

            dbExecute("DELETE FROM wo_active_clocks WHERE serial_id=?", [$snId]);

            dbInsert(
                "INSERT INTO wo_clock_events
                    (wo_id,serial_id,op_id,user_id,event_type,
                     clocked_on_at,clocked_off_at,duration_mins,is_overrun)
                 VALUES (?,?,?,?,'COMPLETE',?,NOW(),?,?)",
                [$woId,$snId,$sn['op_id_val'],$_SESSION['user_id'],
                 $clockedOnAt,$durationMins,$isOverrun]
            );
            fireTimeAttendanceOut($wo, $sn, $durationMins, $clockedOnAt, 'COMPLETE');

            $nextOp = dbFetchOne(
                "SELECT id,op_number,behaviour,op_type,sort_order
                 FROM routing_operations
                 WHERE routing_id=(SELECT routing_id FROM work_orders WHERE id=?)
                   AND sort_order > ?
                 ORDER BY sort_order, op_number LIMIT 1",
                [$woId, $sn['sort_order'] ?? 0]
            );

            if ($nextOp) {
                dbExecute(
                    "UPDATE serial_numbers SET current_op_id=?,status='NOT_STARTED',updated_at=NOW() WHERE id=?",
                    [$nextOp['id'], $snId]
                );
                if ($nextOp['behaviour'] === 'NON-CLOCKING') {
                    autoAdvanceNonClocking($woId, $snId, $nextOp, $wo);
                }
            } else {
                dbExecute(
                    "UPDATE serial_numbers SET status='COMPLETE',updated_at=NOW() WHERE id=?",
                    [$snId]
                );
            }

            writeAuditLog('OP_COMPLETE','serial_number',(string)$snId,$wo['org_id'],null,null,
                'op_number',null,(string)$sn['op_number'],
                "Completed op {$sn['op_number']}: {$sn['serial_number']} WO {$wo['wo_number']}");

            // v10.5.0: Log op completion in wo_change_log
            dbInsert(
                "INSERT INTO wo_change_log (wo_id,op_id,user_id,change_type,note) VALUES (?,?,?,?,?)",
                [$woId,$sn['op_id_val'],$_SESSION['user_id'],'OP_COMPLETE',
                 "Op {$sn['op_number']} completed on serial {$sn['serial_number']}"]
            );
            $processed++;
        }
    }

    updateWoStatus($woId);

    // v10.5.0: Fire WORKORDEROUT on any completion — communicates serial quantities per op
    if ($action === 'complete' && $processed > 0) {
        fireWorkOrderOut($woId, $wo);
    }

    $pdo->commit();

    if ($action === 'complete' && $processed === 0 && count($serialIds) > 0) {
        echo json_encode([
            'ok'    => false,
            'error' => 'You must be clocked on to an operation before completing it. Clock on first, then complete.'
        ]);
        exit;
    }
    echo json_encode(['ok'=>true,'processed'=>$processed,'doc_id'=>$docId]);

} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[ChrisMES] clock_action error: ' . $e->getMessage());
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function calcDuration(string $clockedOnAt): float {
    $on  = new DateTimeImmutable($clockedOnAt, new DateTimeZone('UTC'));
    $now = new DateTimeImmutable('now',         new DateTimeZone('UTC'));
    return round(($now->getTimestamp() - $on->getTimestamp()) / 60, 2);
}

function autoAdvanceNonClocking(int $woId, int $snId, array $op, array $wo): void {
    dbExecute("DELETE FROM wo_active_clocks WHERE serial_id=?", [$snId]);
    dbInsert(
        "INSERT INTO wo_clock_events (wo_id,serial_id,op_id,user_id,event_type,duration_mins)
         VALUES (?,?,?,?,'AUTO_ADVANCE',0)",
        [$woId,$snId,$op['id'],$_SESSION['user_id']]
    );
    $nextOp = dbFetchOne(
        "SELECT id,op_number,behaviour,op_type,sort_order FROM routing_operations
         WHERE routing_id=(SELECT routing_id FROM work_orders WHERE id=?)
           AND sort_order > (SELECT sort_order FROM routing_operations WHERE id=?)
         ORDER BY sort_order LIMIT 1",
        [$woId, $op['id']]
    );
    if ($nextOp) {
        dbExecute(
            "UPDATE serial_numbers SET current_op_id=?,status='NOT_STARTED',updated_at=NOW() WHERE id=?",
            [$nextOp['id'], $snId]
        );
        if ($nextOp['behaviour'] === 'NON-CLOCKING') {
            autoAdvanceNonClocking($woId, $snId, $nextOp, $wo);
        }
    } else {
        dbExecute("UPDATE serial_numbers SET status='COMPLETE',updated_at=NOW() WHERE id=?", [$snId]);
    }
}

function updateWoStatus(int $woId): void {
    $counts = dbFetchOne(
        "SELECT COUNT(*) AS total,
                SUM(status='COMPLETE')    AS done,
                SUM(status='IN_PROGRESS') AS inprog,
                SUM(status='NOT_STARTED') AS notstarted
         FROM serial_numbers WHERE wo_id=?",
        [$woId]
    );
    if (!$counts) return;
    $wo = dbFetchOne("SELECT status,hold_type FROM work_orders WHERE id=?", [$woId]);
    if ($wo['status'] === 'ON_HOLD') return;

    $new = 'OPEN';
    if ($counts['done'] >= $counts['total']) $new = 'COMPLETE';
    elseif ($counts['inprog'] > 0 || $counts['done'] > 0) $new = 'IN_PROGRESS';

    if ($new !== $wo['status']) {
        dbExecute("UPDATE work_orders SET status=?,updated_at=NOW() WHERE id=?",[$new,$woId]);
        dbInsert(
            "INSERT INTO wo_change_log (wo_id,op_id,user_id,change_type,note) VALUES (?,NULL,?,?,?)",
            [$woId,$_SESSION['user_id'],'STATUS_CHANGE',"Status changed to {$new}"]
        );
    }
}

// v10.5.0: WORKORDEROUT — publishes serial quantity status per operation to ERP
function fireWorkOrderOut(int $woId, array $wo): void {
    try {
        // Gather serial counts per current operation
        $opCounts = dbFetchAll(
            "SELECT ro.op_number, ro.op_name,
                    COUNT(sn.id)                             AS total,
                    SUM(sn.status='NOT_STARTED')             AS not_started,
                    SUM(sn.status='IN_PROGRESS')             AS in_progress,
                    SUM(sn.status='COMPLETE')                AS complete,
                    SUM(sn.status='ON_HOLD')                 AS on_hold,
                    SUM(sn.status='SCRAPPED')                AS scrapped
               FROM serial_numbers sn
               JOIN routing_operations ro ON ro.id = sn.current_op_id
              WHERE sn.wo_id=?
              GROUP BY ro.id, ro.op_number, ro.op_name
              ORDER BY ro.sort_order, ro.op_number",
            [$woId]
        );

        $payload = [
            'messageType'   => 'WORKORDEROUT',
            'workOrder'     => $wo['wo_number'],
            'org'           => $wo['org_id'],
            'woStatus'      => $wo['status'],
            'holdType'      => $wo['hold_type'],
            'eventTime'     => (new DateTimeImmutable('now',new DateTimeZone('UTC')))->format('Y-m-d H:i:s'),
            'operationStatus' => $opCounts,
        ];

        $ref = 'WOO-'.$wo['wo_number'].'-'.time();
        dbInsert(
            "INSERT INTO integration_outbound
                (transaction_ref,org_id,message_type,payload,placed_at)
             VALUES (?,?,'WORKORDEROUT',?,NOW())",
            [$ref, $wo['org_id'], json_encode($payload)]
        );
    } catch (Throwable $e) {
        error_log('[ChrisMES] WORKORDEROUT write failed: '.$e->getMessage());
    }
}

function fireTimeAttendanceOut(array $wo, array $sn, float $mins, ?string $onAt, string $type): void {
    try {
        $ref = 'TAO-'.$wo['wo_number'].'-'.$sn['id'].'-'.time();
        dbInsert(
            "INSERT INTO integration_outbound
                (transaction_ref,org_id,message_type,payload,placed_at)
             VALUES (?,?,'TimeAttendanceOUT',?,NOW())",
            [$ref, $wo['org_id'], json_encode([
                'messageType'  => 'TimeAttendanceOUT',
                'workOrder'    => $wo['wo_number'],
                'opNumber'     => $sn['op_number'],
                'serialNumber' => $sn['serial_number'],
                'userId'       => $_SESSION['user_id'],
                'username'     => $_SESSION['username'],
                'eventType'    => $type,
                'clockedOn'    => $onAt,
                'clockedOff'   => (new DateTimeImmutable('now',new DateTimeZone('UTC')))->format('Y-m-d H:i:s'),
                'durationMins' => $mins,
                'org'          => $wo['org_id'],
            ])]
        );
    } catch (Throwable $e) {
        error_log('[ChrisMES] TAO integration write failed: '.$e->getMessage());
    }
}
