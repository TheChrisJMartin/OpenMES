<?php
/**
 * api/raise_nc.php — Raise a Non-Conformance
 * Version: 10.5.0
 * POST JSON: { wo_id, op_id, serial_ids[], defect_desc }
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();
header('Content-Type: application/json');

$body       = json_decode(file_get_contents('php://input'), true) ?? [];
$woId       = (int)($body['wo_id']      ?? 0);
$opId       = (int)($body['op_id']      ?? 0);
$serialIds  = array_map('intval', $body['serial_ids'] ?? []);
$defectDesc = trim($body['defect_desc'] ?? '');

if (!$woId || !$opId || !$serialIds || $defectDesc === '') {
    echo json_encode(['ok'=>false,'error'=>'Missing required fields.']); exit;
}

$scope = orgScope();
$wo = dbFetchOne(
    "SELECT * FROM work_orders WHERE id=? AND ({$scope['sql']})",
    array_merge([$woId], $scope['params'])
);
if (!$wo) { echo json_encode(['ok'=>false,'error'=>'Work order not found.']); exit; }

$pdo = getDB();
$pdo->beginTransaction();

try {
    // Get next NC number — global sequence with lock
    $seq = dbFetchOne("SELECT next_seq FROM nc_sequence WHERE id=1 FOR UPDATE");
    $ncNum   = 'NC' . str_pad($seq['next_seq'], 7, '0', STR_PAD_LEFT);
    $ncSlash = 1; // First item in this NC

    dbExecute("UPDATE nc_sequence SET next_seq=next_seq+1 WHERE id=1");

    // Create NC master record
    $ncId = dbInsert(
        "INSERT INTO non_conformances
            (nc_number, nc_sequence, wo_id, op_id, org_id, raised_by, defect_desc, status, hold_type)
         VALUES (?,?,?,?,?,?,?,'OPEN','HARD')",
        [$ncNum, $ncSlash, $woId, $opId, $wo['org_id'], $_SESSION['user_id'], $defectDesc]
    );

    // Attach serials
    foreach ($serialIds as $snId) {
        $sn = dbFetchOne("SELECT * FROM serial_numbers WHERE id=? AND wo_id=?", [$snId, $woId]);
        if (!$sn) continue;

        dbInsert(
            "INSERT INTO nc_serials (nc_id, serial_id, defect_num) VALUES (?,?,1)",
            [$ncId, $snId]
        );

        // Put serial on hold
        dbExecute(
            "UPDATE serial_numbers SET status='ON_HOLD', updated_at=NOW() WHERE id=?",
            [$snId]
        );

        // Clock off if clocked on
        $active = dbFetchOne(
            "SELECT * FROM wo_active_clocks WHERE serial_id=? AND user_id=?",
            [$snId, $_SESSION['user_id']]
        );
        if ($active) {
            $dur = round((time() - strtotime($active['clocked_on_at'])) / 60, 2);
            dbExecute("DELETE FROM wo_active_clocks WHERE serial_id=?", [$snId]);
            dbInsert(
                "INSERT INTO wo_clock_events
                    (wo_id,serial_id,op_id,user_id,event_type,clocked_on_at,clocked_off_at,duration_mins)
                 VALUES (?,?,?,?,'CLOCK_OFF',?,NOW(),?)",
                [$woId,$snId,$opId,$_SESSION['user_id'],$active['clocked_on_at'],$dur]
            );
        }
    }

    // Put WO on full hold
    dbExecute(
        "UPDATE work_orders SET status='ON_HOLD', hold_type='HARD', updated_at=NOW() WHERE id=?",
        [$woId]
    );

    dbInsert(
        "INSERT INTO wo_change_log (wo_id,op_id,user_id,change_type,note) VALUES (?,?,?,?,?)",
        [$woId, $opId, $_SESSION['user_id'], 'NC_RAISED',
         "NC {$ncNum} raised — " . substr($defectDesc, 0, 80)]
    );

    writeAuditLog('NC_RAISED','non_conformance',(string)$ncId,$wo['org_id'],null,null,
        null,null,$ncNum,
        "NC {$ncNum} raised on WO {$wo['wo_number']}: {$defectDesc}");

    $pdo->commit();
    echo json_encode(['ok'=>true,'nc_number'=>$ncNum,'nc_id'=>$ncId]);

} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[ChrisMES] raise_nc error: '.$e->getMessage());
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
