<?php
/**
 * api/get_routings.php — Returns routings for a part (JSON)
 * Version: 10.5.0
 * Returns APPROVED + SUPERSEDED revisions so older revisions can still be selected.
 * v10.5.0: When ?routing_id=N&std_mins=1, returns total standard minutes for that routing.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();
header('Content-Type: application/json');

// Mode: std_mins for a specific routing
if (isset($_GET['std_mins']) && isset($_GET['routing_id'])) {
    $routingId = (int)$_GET['routing_id'];
    $row = dbFetchOne(
        "SELECT COALESCE(SUM(actual_mins),0) AS total_std_mins
           FROM routing_operations WHERE routing_id=?",
        [$routingId]
    );
    echo json_encode(['total_std_mins' => (int)($row['total_std_mins'] ?? 0)]);
    exit;
}

$partId = (int)($_GET['part_id'] ?? 0);
if (!$partId) { echo '[]'; exit; }

$routings = dbFetchAll(
    "SELECT r.id, r.routing_number, r.revision_label, r.status, r.approved_at
       FROM routings r
      WHERE r.part_id=? AND r.status IN ('APPROVED','SUPERSEDED')
      ORDER BY r.revision DESC",
    [$partId]
);

echo json_encode($routings);
