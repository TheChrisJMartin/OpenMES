<?php
/**
 * api/broadcast_save.php
 * Version: 8.0.0
 * Description: Handles save and deactivate POST actions for broadcast messages.
 *              IT Admin only. Redirects back to admin_broadcast.php.
 */

define('MES_APP', true);
require_once '../config.php';
require_once '../db.php';
require_once '../includes/session.php';

requireRole('IT_ADMIN');
verifyCsrfToken($_POST['csrf_token'] ?? '');

$action = $_POST['action'] ?? '';
$userId = (int)$_SESSION['user']['id'];
$now    = date('Y-m-d H:i:s');

function redirectBack(string $msg, bool $error = false): void
{
    $param = $error ? 'error' : 'success';
    header('Location: ../admin_broadcast.php?' . $param . '=' . urlencode($msg));
    exit;
}

switch ($action) {

    // ------------------------------------------------------------------
    // SAVE — create a new broadcast message record, optionally activate
    // ------------------------------------------------------------------
    case 'save':
        $text    = trim($_POST['message_text'] ?? '');
        $colour  = $_POST['colour']   ?? 'yellow';
        $active  = isset($_POST['is_active']) ? 1 : 0;

        // Validate
        if ($text === '') {
            redirectBack('Message text is required.', true);
        }
        if (mb_strlen($text) > 128) {
            redirectBack('Message must be 128 characters or fewer.', true);
        }
        if (!in_array($colour, ['red', 'yellow', 'green'], true)) {
            redirectBack('Invalid colour selected.', true);
        }

        $pdo->beginTransaction();
        try {
            // If activating, deactivate any current active message first
            if ($active) {
                $pdo->prepare("UPDATE broadcast_messages SET is_active = 0 WHERE is_active = 1")
                    ->execute();
            }

            // Insert new message
            $stmt = $pdo->prepare(
                "INSERT INTO broadcast_messages
                    (message_text, colour, is_active, created_by, created_at)
                 VALUES
                    (:msg, :colour, :active, :uid, :now)"
            );
            $stmt->execute([
                ':msg'    => $text,
                ':colour' => $colour,
                ':active' => $active,
                ':uid'    => $userId,
                ':now'    => $now,
            ]);
            $newId = $pdo->lastInsertId();

            // Audit log
            auditLog($pdo, $userId, 'BROADCAST_MESSAGE', $newId,
                'Created broadcast message: ' . $text . ' | Colour: ' . $colour . ' | Active: ' . $active);

            $pdo->commit();
            redirectBack('Broadcast message saved successfully.');
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log('broadcast_save.php error: ' . $e->getMessage());
            redirectBack('An error occurred saving the message. Please try again.', true);
        }
        break;

    // ------------------------------------------------------------------
    // DEACTIVATE — turn off current active message
    // ------------------------------------------------------------------
    case 'deactivate':
        try {
            $stmt = $pdo->prepare(
                "UPDATE broadcast_messages
                    SET is_active = 0, updated_by = :uid, updated_at = :now
                  WHERE is_active = 1"
            );
            $stmt->execute([':uid' => $userId, ':now' => $now]);

            auditLog($pdo, $userId, 'BROADCAST_MESSAGE', null,
                'Deactivated broadcast message banner');

            redirectBack('Broadcast message deactivated.');
        } catch (Exception $e) {
            error_log('broadcast_save.php deactivate error: ' . $e->getMessage());
            redirectBack('An error occurred. Please try again.', true);
        }
        break;

    default:
        redirectBack('Invalid action.', true);
}
