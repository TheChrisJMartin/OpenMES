<?php
/**
 * api/clockon_serial.php
 * Version: 8.0.0
 * Description: Processes clock-on requests for one or more serial/lot numbers.
 *              Returns JSON response.
 *
 * Bug fix v8.0.0:
 *   The duplicate-session guard now correctly checks for sessions where
 *   clock_off_time IS NULL only. Previously the absence of this condition
 *   caused clocked-off (completed) sessions to be treated as still-active,
 *   blocking operators from clocking back on to serials that had been
 *   properly clocked off on a previous operation.
 *
 *   A transaction is used so that concurrent requests for the same serial
 *   are handled safely via SELECT ... FOR UPDATE.
 */

define('MES_APP', true);
require_once '../config.php';
require_once '../db.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

requireRole(['OPERATOR', 'SUPERVISOR', 'IT_ADMIN', 'MANUFACTURING_ENGINEER',
             'MANUFACTURING_ENGINEER_SUPERVISOR', 'INSPECTOR', 'TESTER', 'FINAL_TESTER']);

// ------------------------------------------------------------------
// Input validation
// ------------------------------------------------------------------
verifyCsrfToken($_POST['csrf_token'] ?? '');

$userId      = (int)$_SESSION['user']['id'];
$orgId       = (int)$_SESSION['user']['org_id'];
$workOrderId = (int)($_POST['work_order_id'] ?? 0);
$serialIds   = array_map('intval', (array)($_POST['serial_ids'] ?? []));

if ($workOrderId === 0 || empty($serialIds)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request parameters.']);
    exit;
}

// Verify work order belongs to operator's org
$stmt = $pdo->prepare(
    "SELECT id, status FROM work_orders WHERE id = :id AND org_id = :org LIMIT 1"
);
$stmt->execute([':id' => $workOrderId, ':org' => $orgId]);
$wo = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$wo) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Work order not found or access denied.']);
    exit;
}
if (in_array($wo['status'], ['ON_HOLD', 'COMPLETE', 'CANCELLED'])) {
    echo json_encode(['success' => false, 'message' => 'Work order is not available for clocking (' . $wo['status'] . ').']);
    exit;
}

$now       = date('Y-m-d H:i:s');
$clonedOn  = [];
$skipped   = [];
$errors    = [];

$pdo->beginTransaction();

try {
    foreach ($serialIds as $serialRowId) {

        // Lock the serial row so concurrent requests can't double-clock
        $stmtSerial = $pdo->prepare(
            "SELECT wos.id, wos.current_op_sequence, wos.status, rop.behaviour, rop.id AS op_id
               FROM wo_serials   wos
               JOIN routing_ops  rop ON rop.id = wos.current_op_sequence
              WHERE wos.id             = :sid
                AND wos.work_order_id  = :woid
              LIMIT 1
              FOR UPDATE"
        );
        $stmtSerial->execute([':sid' => $serialRowId, ':woid' => $workOrderId]);
        $serial = $stmtSerial->fetch(PDO::FETCH_ASSOC);

        if (!$serial) {
            $skipped[] = ['id' => $serialRowId, 'reason' => 'Serial not found on this work order.'];
            continue;
        }
        if ($serial['status'] === 'COMPLETE' || $serial['status'] === 'SCRAPPED') {
            $skipped[] = ['id' => $serialRowId, 'reason' => 'Serial is ' . $serial['status'] . '.'];
            continue;
        }
        if ($serial['behaviour'] === 'NON_CLOCKING') {
            $skipped[] = ['id' => $serialRowId, 'reason' => 'Operation is non-clocking.'];
            continue;
        }

        // ------------------------------------------------------------------
        // v8.0.0 FIX: Check for an OPEN (not yet clocked-off) session only.
        // The previous query omitted "AND clock_off_time IS NULL" which caused
        // rows from prior completed operations to block clock-on.
        // ------------------------------------------------------------------
        $stmtCheck = $pdo->prepare(
            "SELECT id, user_id
               FROM wo_clock_events
              WHERE wo_serial_id   = :sid
                AND clock_off_time IS NULL
              LIMIT 1"
        );
        $stmtCheck->execute([':sid' => $serialRowId]);
        $existingSession = $stmtCheck->fetch(PDO::FETCH_ASSOC);

        if ($existingSession) {
            if ((int)$existingSession['user_id'] === $userId) {
                // Same operator — they are already clocked on (race/double-click)
                $skipped[] = ['id' => $serialRowId, 'reason' => 'You are already clocked on to this serial.'];
            } else {
                // Another operator holds an open session
                $skipped[] = ['id' => $serialRowId, 'reason' => 'Serial is already clocked on by another operator.'];
            }
            continue;
        }

        // All clear — insert the clock-on event
        $stmtInsert = $pdo->prepare(
            "INSERT INTO wo_clock_events
                (wo_serial_id, routing_op_id, user_id, clock_on_time)
             VALUES
                (:sid, :op_id, :uid, :now)"
        );
        $stmtInsert->execute([
            ':sid'   => $serialRowId,
            ':op_id' => $serial['op_id'],
            ':uid'   => $userId,
            ':now'   => $now,
        ]);

        // Audit log
        auditLog($pdo, $userId, 'CLOCK_ON', $serialRowId,
            'Clocked on to serial ID ' . $serialRowId . ' on work order ' . $workOrderId);

        $clonedOn[] = $serialRowId;
    }

    $pdo->commit();

} catch (Exception $e) {
    $pdo->rollBack();
    error_log('clockon_serial.php error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'A server error occurred. Please try again.']);
    exit;
}

// ------------------------------------------------------------------
// Response
// ------------------------------------------------------------------
$success = !empty($clonedOn);

if ($success) {
    // Redirect to the active work screen
    $redirectUrl = '../operator_work.php?wo_id=' . $workOrderId;
    echo json_encode([
        'success'      => true,
        'clocked_on'   => $clonedOn,
        'skipped'      => $skipped,
        'redirect_url' => $redirectUrl,
    ]);
} else {
    $reasons = array_column($skipped, 'reason');
    echo json_encode([
        'success'  => false,
        'message'  => 'No serials could be clocked on to: ' . implode('; ', array_unique($reasons)),
        'skipped'  => $skipped,
    ]);
}
