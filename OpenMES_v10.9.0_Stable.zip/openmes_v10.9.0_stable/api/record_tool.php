<?php
/**
 * api/record_tool.php — Record tool use on a work order operation
 * Version: 10.9.0
 * F089: Called from operator screen when operator records tool use.
 * F087: Blocks recording of tools with expired calibration.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
verifyCsrfToken($_POST['csrf_token'] ?? '');

$woId   = (int)($_POST['wo_id']   ?? 0);
$toolId = (int)($_POST['tool_id'] ?? 0);
$opId   = (int)($_POST['op_id']   ?? 0);

if (!$woId || !$toolId || !$opId) {
    $_SESSION['flash_error'] = 'Invalid tool record request.';
    header('Location: ' . $_SERVER['HTTP_REFERER'] ?? SITE_URL . '/workorders/operator.php');
    exit;
}

// F087: Check calibration not expired
$tool = dbFetchOne(
    "SELECT asset_number, calibration_due FROM calibration_tools WHERE id=?",
    [$toolId]
);
if ($tool && $tool['calibration_due'] && $tool['calibration_due'] < date('Y-m-d')) {
    $_SESSION['flash_error'] = "Tool {$tool['asset_number']} has an expired calibration date and cannot be recorded.";
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? SITE_URL . '/workorders/operator.php'));
    exit;
}

// Get serials for this WO that are currently on this op
$serials = dbFetchAll(
    "SELECT id FROM serial_numbers WHERE wo_id=? AND current_op_id=?",
    [$woId, $opId]
);

foreach ($serials as $sn) {
    dbInsert(
        "INSERT IGNORE INTO wo_tool_records (wo_id, serial_id, tool_id, recorded_by, recorded_at)
         VALUES (?,?,?,?,NOW())",
        [$woId, $sn['id'], $toolId, $_SESSION['user_id']]
    );
}

$_SESSION['flash_success'] = "Tool {$tool['asset_number']} recorded.";
header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? SITE_URL . '/workorders/operator.php?id=' . $woId));
exit;
