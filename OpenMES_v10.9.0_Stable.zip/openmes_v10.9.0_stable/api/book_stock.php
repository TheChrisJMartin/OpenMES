<?php
/**
 * api/book_stock.php — Book serials to inventory stock
 * Version: 10.0.0
 * v10.0.0: Block BTS if quality variable results are incomplete on any serial
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();
header('Content-Type: application/json');

$body      = json_decode(file_get_contents('php://input'), true) ?? [];
$woId      = (int)($body['wo_id']      ?? 0);
$serialIds = array_map('intval', $body['serial_ids'] ?? []);
$locId     = (int)($body['location_id'] ?? 0);

if (!$woId || !$serialIds || !$locId) {
    echo json_encode(['ok'=>false,'error'=>'Missing parameters.']); exit;
}

$scope = orgScope('w');
$wo    = dbFetchOne(
    "SELECT w.* FROM work_orders w WHERE w.id=? AND ({$scope['sql']})",
    array_merge([$woId], $scope['params'])
);
if (!$wo) { echo json_encode(['ok'=>false,'error'=>'Work order not found.']); exit; }

// Verify location belongs to this org
$loc = dbFetchOne("SELECT id FROM inventory_locations WHERE id=? AND org_id=? AND active=1", [$locId,$wo['org_id']]);
if (!$loc) { echo json_encode(['ok'=>false,'error'=>'Invalid inventory location.']); exit; }

$pdo = getDB();
$pdo->beginTransaction();
try {
    $booked = 0;
    foreach ($serialIds as $snId) {
        $sn = dbFetchOne(
            "SELECT sn.*,ro.op_type FROM serial_numbers sn
             LEFT JOIN routing_operations ro ON ro.id=sn.current_op_id
             WHERE sn.id=? AND sn.wo_id=?",
            [$snId,$woId]
        );
        if (!$sn) continue;

        // Check no open NCs
        if ($sn['status']==='SCRAPPED') continue;

        // v10.0.0: Block BTS if any quality variable results are missing on this serial
        // Find all inspection/test ops in this WO's routing that have quality variables
        $requiredQvOps = dbFetchAll(
            "SELECT DISTINCT qv.op_id, ro.op_number, ro.op_name
               FROM quality_variables qv
               JOIN routing_operations ro ON ro.id = qv.op_id
              WHERE ro.routing_id = (SELECT routing_id FROM work_orders WHERE id=?)
                AND qv.active = 1",
            [$woId]
        );
        foreach ($requiredQvOps as $qvOp) {
            $resultCount = dbFetchOne(
                "SELECT COUNT(*) AS n FROM quality_results
                  WHERE serial_id=? AND op_id=?",
                [$snId, $qvOp['op_id']]
            )['n'] ?? 0;
            if ($resultCount === 0) {
                $pdo->rollBack();
                $sn2 = dbFetchOne("SELECT serial_number FROM serial_numbers WHERE id=?", [$snId]);
                echo json_encode(['ok'=>false,'error'=>
                    "Cannot book serial {$sn2['serial_number']} to stock — quality measurements are incomplete on Op "
                    . str_pad($qvOp['op_number'],3,'0',STR_PAD_LEFT) . " {$qvOp['op_name']}."
                ]);
                exit;
            }
        }

        // Book to stock
        dbInsert(
            "INSERT INTO wo_stock_bookings (wo_id,serial_id,location_id,booked_by,booked_at)
             VALUES (?,?,?,?,NOW())",
            [$woId,$snId,$locId,$_SESSION['user_id']]
        );
        dbExecute(
            "UPDATE serial_numbers SET status='COMPLETE',updated_at=NOW() WHERE id=?",
            [$snId]
        );

        // WorkOrderMoveOUT integration event
        $ref = 'WOM-'.$wo['wo_number'].'-'.$snId.'-'.time();
        dbInsert(
            "INSERT INTO integration_outbound (transaction_ref,org_id,message_type,payload,placed_at)
             VALUES (?,?,'WorkOrderMoveOUT',?,NOW())",
            [$ref,$wo['org_id'],json_encode([
                'messageType'  => 'WorkOrderMoveOUT',
                'workOrder'    => $wo['wo_number'],
                'serialNumber' => $sn['serial_number'],
                'locationId'   => $locId,
                'bookedBy'     => $_SESSION['username'],
                'bookedAt'     => date('Y-m-d H:i:s'),
            ])]
        );

        writeAuditLog('BOOK_TO_STOCK','serial_number',(string)$snId,$wo['org_id'],null,null,
            'status','IN_PROGRESS','COMPLETE',
            "Booked to stock: {$sn['serial_number']} WO {$wo['wo_number']} → location {$locId}");
        $booked++;
    }

    // Update WO status
    $remaining = dbFetchOne(
        "SELECT COUNT(*) AS n FROM serial_numbers WHERE wo_id=? AND status NOT IN ('COMPLETE','SCRAPPED')",
        [$woId]
    )['n'] ?? 0;
    if ((int)$remaining === 0) {
        dbExecute("UPDATE work_orders SET status='COMPLETE',updated_at=NOW() WHERE id=?",[$woId]);
        dbInsert("INSERT INTO wo_change_log (wo_id,user_id,change_type,note) VALUES (?,?,?,?)",
            [$woId,$_SESSION['user_id'],'WO_COMPLETE','All serials booked to stock — WO complete']);
    }

    $pdo->commit();
    echo json_encode(['ok'=>true,'booked'=>$booked]);
} catch (Throwable $e) {
    $pdo->rollBack();
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
