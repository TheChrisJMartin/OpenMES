<?php
/**
 * api/set_theme.php — ChrisMES Theme Toggle API
 * Version: 1.0.0
 *
 * POST JSON: { "theme": "dark" | "light" }
 * Updates user's theme preference in DB and session.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

header('Content-Type: application/json');

requireLogin();

$body  = json_decode(file_get_contents('php://input'), true);
$theme = $body['theme'] ?? '';

if (!in_array($theme, ['dark', 'light'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid theme value.']);
    exit;
}

dbExecute(
    "UPDATE users SET theme = ? WHERE id = ?",
    [$theme, $_SESSION['user_id']]
);

$_SESSION['theme'] = $theme;

echo json_encode(['ok' => true, 'theme' => $theme]);
