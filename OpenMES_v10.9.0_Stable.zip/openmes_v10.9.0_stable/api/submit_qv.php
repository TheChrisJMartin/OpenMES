<?php
/**
 * api/submit_qv.php — Submit quality variable results during execution
 * Version: 10.5.0
 * Description: Called from operator screen when collecting measurements at
 *              Inspection/Final Test ops. Validates against limits, flags
 *              out-of-spec, and returns whether an NC should be raised.
 *              The operator must confirm before NC is auto-raised.
 * POST JSON: { wo_id, serial_id, op_id, results: [{qv_id, value}], confirm_nc: bool }
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();
header('Content-Type: application/json');

$body     = json_decode(file_get_contents('php://input'), true) ?? [];
$woId     = (int)($body['wo_id']     ?? 0);
$serialId = (int)($body['serial_id'] ?? 0);
$opId     = (int)($body['op_id']     ?? 0);
$results  = $body['results']    ?? [];
$confirmNc= (bool)($body['confirm_nc'] ?? false);

if (!$woId || !$serialId || !$opId || empty($results)) {
    echo json_encode(['ok'=>false,'error'=>'Missing required parameters.']); exit;
}

// Verify WO is accessible
$scope = orgScope('w');
$wo = dbFetchOne(
    "SELECT w.* FROM work_orders w WHERE w.id=? AND ({$scope['sql']})",
    array_merge([$woId], $scope['params'])
);
if (!$wo) { echo json_encode(['ok'=>false,'error'=>'Work order not found.']); exit; }

// Verify the operator is clocked on to this serial
$active = dbFetchOne(
    "SELECT id FROM wo_active_clocks WHERE wo_id=? AND serial_id=? AND user_id=?",
    [$woId, $serialId, $_SESSION['user_id']]
);
if (!$active) {
    echo json_encode(['ok'=>false,'error'=>'You must be clocked on to this serial to record measurements.']); exit;
}

// Fetch all required quality variables for this op
$requiredVars = dbFetchAll(
    "SELECT qv.*, u.code AS uom_code, qv.qv_type
       FROM quality_variables qv
       LEFT JOIN uom u ON u.id = qv.uom_id
      WHERE qv.op_id=? AND qv.active=1",
    [$opId]
);

if (empty($requiredVars)) {
    echo json_encode(['ok'=>false,'error'=>'No quality variables defined for this operation.']); exit;
}

// Check all required variables have been submitted
$submittedIds = array_column($results, 'qv_id');
$requiredIds  = array_column($requiredVars, 'id');
$missing      = array_diff($requiredIds, array_map('intval', $submittedIds));
if ($missing) {
    echo json_encode(['ok'=>false,'error'=>'All measurements must be entered before submitting.']); exit;
}

$pdo = getDB();

// First pass: check for existing results (prevent double-submission)
$existing = dbFetchOne(
    "SELECT id FROM quality_results WHERE serial_id=? AND op_id=? LIMIT 1",
    [$serialId, $opId]
);
if ($existing) {
    echo json_encode(['ok'=>false,'error'=>'Measurements have already been recorded for this serial on this operation.']); exit;
}

// Second pass: validate values against limits, identify out-of-spec
$outOfSpec = [];
$validatedResults = [];

foreach ($requiredVars as $qv) {
    $submitted = array_filter($results, fn($r) => (int)$r['qv_id'] === (int)$qv['id']);
    $submitted = array_values($submitted);
    if (empty($submitted)) continue;

    $value     = (float)$submitted[0]['value'];
    $inSpec    = true;
    $qvType    = $qv['qv_type'] ?? 'NUMERIC';

    // F048: PASS_FAIL and YES_NO use 1=pass/yes, 0=fail/no
    if ($qvType === 'PASS_FAIL' || $qvType === 'YES_NO') {
        $inSpec = ((int)$value === 1);
        if (!$inSpec) {
            $label = $qvType === 'PASS_FAIL' ? 'FAIL' : 'NO';
            $reason = "{$qv['name']}: recorded as {$label}";
        }
    } else {
    $reason    = '';

    if ($qv['lower_limit'] !== null && $value < (float)$qv['lower_limit']) {
        $inSpec = false;
        $reason = "{$qv['name']}: {$value}{$qv['uom_code']} is below lower limit of {$qv['lower_limit']}{$qv['uom_code']}";
    } elseif ($qv['upper_limit'] !== null && $value > (float)$qv['upper_limit']) {
        $inSpec = false;
        $reason = "{$qv['name']}: {$value}{$qv['uom_code']} exceeds upper limit of {$qv['upper_limit']}{$qv['uom_code']}";
    }
    } // end else NUMERIC

    $validatedResults[] = [
        'qv_id'    => (int)$qv['id'],
        'value'    => $value,
        'in_spec'  => $inSpec,
        'reason'   => $reason,
        'qv_name'  => $qv['name'],
    ];

    if (!$inSpec) {
        $outOfSpec[] = $reason;
    }
}

// If out of spec and operator hasn't confirmed NC yet — return warning for confirmation
if (!empty($outOfSpec) && !$confirmNc) {
    echo json_encode([
        'ok'           => false,
        'out_of_spec'  => true,
        'reasons'      => $outOfSpec,
        'needs_confirm'=> true,
        'message'      => 'The following measurements are out of specification. A Non-Conformance will be raised automatically. Do you want to proceed?',
    ]);
    exit;
}

// All clear (or operator has confirmed) — persist results
$pdo->beginTransaction();
try {
    $ncId = null;

    // Insert all results
    foreach ($validatedResults as $vr) {
        dbInsert(
            "INSERT INTO quality_results
                (qv_id,wo_id,serial_id,op_id,result_value,is_in_spec,collected_by,collected_at)
             VALUES (?,?,?,?,?,?,?,NOW())",
            [$vr['qv_id'],$woId,$serialId,$opId,$vr['value'],$vr['in_spec']?1:0,$_SESSION['user_id']]
        );
    }

    // Auto-raise NC if out of spec and confirmed
    if (!empty($outOfSpec) && $confirmNc) {
        $defectDesc = 'Quality variable out of specification: ' . implode('; ', $outOfSpec);

        // Get next NC number
        $seq   = dbFetchOne("SELECT next_seq FROM nc_sequence WHERE id=1 FOR UPDATE");
        $ncNum = 'NC' . str_pad($seq['next_seq'], 7, '0', STR_PAD_LEFT);
        dbExecute("UPDATE nc_sequence SET next_seq=next_seq+1 WHERE id=1");

        $ncId = dbInsert(
            "INSERT INTO non_conformances
                (nc_number,nc_sequence,wo_id,op_id,org_id,raised_by,defect_desc,status,hold_type)
             VALUES (?,1,?,?,?,?,?,'OPEN','HARD')",
            [$ncNum,1,$woId,$opId,$wo['org_id'],$_SESSION['user_id'],$defectDesc]
        );

        dbInsert(
            "INSERT INTO nc_serials (nc_id,serial_id,defect_num) VALUES (?,?,1)",
            [$ncId,$serialId]
        );

        // Put serial and WO on full hold
        dbExecute("UPDATE serial_numbers SET status='ON_HOLD',updated_at=NOW() WHERE id=?", [$serialId]);

        // Clock off the operator
        $activeRow = dbFetchOne(
            "SELECT * FROM wo_active_clocks WHERE serial_id=? AND user_id=?",
            [$serialId,$_SESSION['user_id']]
        );
        if ($activeRow) {
            $dur = round((time() - strtotime($activeRow['clocked_on_at'])) / 60, 2);
            dbExecute("DELETE FROM wo_active_clocks WHERE serial_id=?", [$serialId]);
            dbInsert(
                "INSERT INTO wo_clock_events
                    (wo_id,serial_id,op_id,user_id,event_type,clocked_on_at,clocked_off_at,duration_mins)
                 VALUES (?,?,?,?,'CLOCK_OFF',?,NOW(),?)",
                [$woId,$serialId,$opId,$_SESSION['user_id'],$activeRow['clocked_on_at'],$dur]
            );
        }

        dbExecute(
            "UPDATE work_orders SET status='ON_HOLD',hold_type='HARD',updated_at=NOW() WHERE id=?",
            [$woId]
        );
        dbInsert(
            "INSERT INTO wo_change_log (wo_id,op_id,user_id,change_type,note) VALUES (?,?,?,?,?)",
            [$woId,$opId,$_SESSION['user_id'],'NC_AUTO_RAISED',
             "Auto-raised {$ncNum} — out of spec measurement"]
        );

        // Update quality_results rows to link the NC
        dbExecute(
            "UPDATE quality_results SET nc_id=? WHERE serial_id=? AND op_id=? AND is_in_spec=0",
            [$ncId,$serialId,$opId]
        );

        writeAuditLog('QV_NC_AUTO','non_conformance',(string)$ncId,$wo['org_id'],null,null,
            null,null,$ncNum,"Auto-raised NC {$ncNum} for out-of-spec measurement on WO {$wo['wo_number']}");
    }

    $pdo->commit();
    echo json_encode([
        'ok'        => true,
        'out_of_spec'=> !empty($outOfSpec),
        'nc_raised' => $ncId !== null,
        'nc_number' => $ncId ? $ncNum : null,
    ]);

} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[ChrisMES] submit_qv error: ' . $e->getMessage());
    echo json_encode(['ok'=>false,'error'=>'Database error. Please try again.']);
}
