<?php
/**
 * api/serve_pdf.php — Authenticated PDF file server
 * Version: 3.0.0
 *
 * Streams a stored PDF to the browser only for authenticated users
 * who have access to the document's org.
 * Never exposes the real filesystem path to the client.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();

$docId = (int)($_GET['id'] ?? 0);
$scope = orgScope('d');

$doc = dbFetchOne(
    "SELECT d.file_path, d.file_name, d.org_id
     FROM documents d
     WHERE d.id=? AND ({$scope['sql']})",
    array_merge([$docId], $scope['params'])
);

if (!$doc) {
    http_response_code(404);
    exit('Document not found or access denied.');
}

$fullPath = BASE_PATH . '/' . ltrim($doc['file_path'], '/');

if (!file_exists($fullPath)) {
    http_response_code(404);
    exit('PDF file not found on server. The seed documents are placeholders — upload a real PDF via the Documents screen.');
}

$fsize = filesize($fullPath);
header('Content-Type: application/pdf');
header('Content-Length: ' . $fsize);
// CD011: Sanitise filename for Content-Disposition header — strip all chars
// except alphanumerics, dots, hyphens, underscores to prevent header injection
$safeFilename = preg_replace('/[^a-zA-Z0-9._\-]/', '_', $doc['file_name']);
header('Content-Disposition: inline; filename="' . $safeFilename . '"');
header('Cache-Control: private, max-age=3600');
readfile($fullPath);
exit;
