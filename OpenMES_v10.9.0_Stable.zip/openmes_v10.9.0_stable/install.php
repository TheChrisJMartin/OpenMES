<?php
/**
 * install.php -- OpenMES First-Time Installation Wizard
 * Version: 10.9.0
 *
 * SECURITY WARNING: This file creates config.php and writes DB credentials.
 * It self-deletes after successful installation.
 * If installation is abandoned, DELETE THIS FILE MANUALLY before going live.
 *
 * This file is included in the GitHub release for fresh installs only.
 * It will refuse to run if config.php already exists with valid credentials.
 */

// Block if already installed
if (file_exists(__DIR__ . '/config.php')) {
    $cfg = file_get_contents(__DIR__ . '/config.php');
    if (strpos($cfg, 'DB_HOST') !== false && strpos($cfg, 'PLACEHOLDER') === false) {
        die('<h2 style="font-family:monospace;padding:40px;color:#c00;">
            OpenMES is already installed.<br>
            <a href="index.php">Go to OpenMES</a> &mdash;
            or delete config.php to re-run setup.
        </h2>');
    }
}

$step    = (int)($_POST['step'] ?? $_GET['step'] ?? 1);
$error   = '';
$success = '';

// ── Step helpers ──────────────────────────────────────────────────────────────
function checkRequirements(): array {
    $checks = [];
    $checks[] = ['PHP Version 8.0+', version_compare(PHP_VERSION,'8.0.0','>='), PHP_VERSION];
    $checks[] = ['PDO Extension',     extension_loaded('pdo'),         extension_loaded('pdo') ? 'OK' : 'Missing'];
    $checks[] = ['PDO MySQL Driver',  in_array('mysql',PDO::getAvailableDrivers()), in_array('mysql',PDO::getAvailableDrivers()) ? 'OK' : 'Missing'];
    $checks[] = ['ZipArchive',        class_exists('ZipArchive'),      class_exists('ZipArchive') ? 'OK' : 'Missing'];
    $checks[] = ['finfo (MIME)',      function_exists('finfo_open'),   function_exists('finfo_open') ? 'OK' : 'Missing (PDF upload validation reduced)'];
    $checks[] = ['uploads/ writable', is_writable(__DIR__ . '/uploads'), is_writable(__DIR__ . '/uploads') ? 'OK' : 'Not writable'];
    $checks[] = ['bootstrap.sql present', file_exists(__DIR__ . '/bootstrap.sql'), file_exists(__DIR__ . '/bootstrap.sql') ? 'OK' : 'Missing'];
    return $checks;
}

function allRequired(array $checks): bool {
    // finfo and uploads writable are warnings not blockers
    $optional = ['finfo (MIME)', 'uploads/ writable'];
    foreach ($checks as $c) {
        if (!$c[1] && !in_array($c[0], $optional)) return false;
    }
    return true;
}

// ── Step 2: Test DB connection ─────────────────────────────────────────────
$dbOk = false;
if ($step === 2 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost    = trim($_POST['db_host']    ?? 'localhost');
    $dbPort    = trim($_POST['db_port']    ?? '3306');
    $dbName    = trim($_POST['db_name']    ?? '');
    $dbUser    = trim($_POST['db_user']    ?? '');
    $dbPass    = $_POST['db_pass']         ?? '';
    $siteUrl   = rtrim(trim($_POST['site_url']   ?? ''), '/');
    $siteSubpath = trim($_POST['site_subpath'] ?? '');
    $siteName  = trim($_POST['site_name']  ?? 'OpenMES');
    $timezone  = trim($_POST['timezone']   ?? 'Europe/London');
    $testMode  = isset($_POST['test_mode']) ? 'true' : 'false';

    if (!$dbName || !$dbUser) {
        $error = 'Database name and username are required.';
        $step = 2;
    } else {
        try {
            $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
            $pdo = new PDO($dsn, $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $dbOk = true;
            $_SESSION['install'] = compact('dbHost','dbPort','dbName','dbUser','dbPass',
                'siteUrl','siteSubpath','siteName','timezone','testMode');
            $step = 3;
        } catch (PDOException $e) {
            $error = 'Database connection failed: ' . $e->getMessage();
            $step = 2;
        }
    }
}

// ── Step 3: Run bootstrap SQL ─────────────────────────────────────────────
$sqlLog = [];
if ($step === 3 && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirm'] ?? '') === 'CONFIRM') {
    session_start();
    $cfg = $_SESSION['install'] ?? [];
    if (empty($cfg)) { $error = 'Session expired — please start again.'; $step = 1; }
    else {
        try {
            $dsn = "mysql:host={$cfg['dbHost']};port={$cfg['dbPort']};dbname={$cfg['dbName']};charset=utf8mb4";
            $pdo = new PDO($dsn, $cfg['dbUser'], $cfg['dbPass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

            $sql = file_get_contents(__DIR__ . '/bootstrap.sql');
            $chunks = explode(';', $sql);
            $ok = 0; $skip = 0; $fail = 0;

            foreach ($chunks as $chunk) {
                $lines = explode("\n", $chunk);
                $code  = array_filter($lines, fn($l) => trim($l) !== '' && !str_starts_with(ltrim($l),'--'));
                $stmt  = trim(implode("\n", $code));
                if ($stmt === '') { $skip++; continue; }
                try {
                    $pdo->exec($stmt);
                    $ok++;
                    $sqlLog[] = ['ok', substr($stmt,0,100)];
                } catch (PDOException $e) {
                    if (str_contains($e->getMessage(),'Duplicate') || str_contains($e->getMessage(),'already exists')) {
                        $skip++;
                    } else {
                        $fail++;
                        $sqlLog[] = ['err', $e->getMessage() . ' — ' . substr($stmt,0,80)];
                    }
                }
            }

            // Hash passwords for test accounts (username as password in test mode)
            $cost = 12;
            $testUsers = $pdo->query("SELECT id, username FROM users WHERE is_test_acct=1 OR password_hash='PLACEHOLDER'")
                             ->fetchAll(PDO::FETCH_ASSOC);
            foreach ($testUsers as $u) {
                $hash = password_hash($u['username'], PASSWORD_BCRYPT, ['cost'=>$cost]);
                $pdo->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash,$u['id']]);
            }

            // Write config.php
            $subpath = $cfg['siteSubpath'] ? "'" . addslashes($cfg['siteSubpath']) . "'" : "''";
            $configContent = "<?php\n"
                . "ini_set('display_errors','0');\n"
                . "ini_set('display_startup_errors','0');\n"
                . "error_reporting(E_ALL);\n"
                . "ini_set('log_errors','1');\n\n"
                . "/**\n * config.php -- OpenMES Configuration\n * Generated by install.php " . date('Y-m-d H:i:s') . "\n */\n\n"
                . "define('SITE_URL',      '" . addslashes($cfg['siteUrl']) . "');\n"
                . "define('SITE_SUBPATH',  " . $subpath . ");\n\n"
                . "define('DB_HOST',    '" . addslashes($cfg['dbHost']) . "');\n"
                . "define('DB_PORT',    '" . addslashes($cfg['dbPort']) . "');\n"
                . "define('DB_NAME',    '" . addslashes($cfg['dbName']) . "');\n"
                . "define('DB_USER',    '" . addslashes($cfg['dbUser']) . "');\n"
                . "define('DB_PASS',    '" . addslashes($cfg['dbPass']) . "');\n"
                . "define('DB_CHARSET', 'utf8mb4');\n\n"
                . "define('TEST_MODE', " . $cfg['testMode'] . ");\n\n"
                . "define('BASE_PATH',    __DIR__);\n"
                . "define('UPLOADS_PATH', BASE_PATH . '/uploads/documents');\n"
                . "define('UPLOADS_URL',  SITE_URL  . '/uploads/documents');\n"
                . "define('BCRYPT_COST',  12);\n\n"
                . "// SITE_VERSION is stored in system_config DB table -- do not define here\n";

            file_put_contents(__DIR__ . '/config.php', $configContent);

            // Update site config in DB
            $pdo->prepare("UPDATE system_config SET config_val=? WHERE config_key='SITE_NAME'")->execute([$cfg['siteName']]);
            $pdo->prepare("UPDATE system_config SET config_val=? WHERE config_key='SITE_TIMEZONE'")->execute([$cfg['timezone']]);
            $pdo->prepare("UPDATE system_config SET config_val=? WHERE config_key='TEST_MODE'")->execute([$cfg['testMode']==='true'?'1':'0']);

            $sqlLog[] = ['ok', "config.php written successfully"];
            $sqlLog[] = ['ok', "{$ok} SQL statements executed, {$skip} skipped, {$fail} failed"];

            if ($fail === 0) {
                $step = 4; // complete
                // Self-delete
                @unlink(__FILE__);
            } else {
                $error = "{$fail} SQL statement(s) failed — see log below. config.php has been written.";
            }

        } catch (Throwable $e) {
            $error = 'Installation failed: ' . $e->getMessage();
            $step = 3;
        }
    }
}

if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>OpenMES — Install</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:#0d1117;color:#e6edf3;font-family:-apple-system,'Segoe UI',system-ui,sans-serif;
     font-size:14px;line-height:1.6;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:36px 40px;width:100%;max-width:600px}
h1{font-size:24px;font-weight:700;color:#58a6ff;margin-bottom:4px}
.brand{color:#8b949e;font-size:13px;margin-bottom:24px}
h2{font-size:16px;font-weight:600;color:#e6edf3;margin-bottom:14px}
label{display:block;font-size:12px;color:#8b949e;margin-bottom:4px;margin-top:12px}
input,select{width:100%;padding:8px 10px;background:#0d1117;border:1px solid #30363d;border-radius:5px;
             color:#e6edf3;font-size:13px;margin-bottom:2px}
input:focus,select:focus{outline:none;border-color:#58a6ff}
.btn{display:inline-block;padding:10px 24px;border-radius:6px;font-size:14px;font-weight:600;
     cursor:pointer;border:none;text-decoration:none;margin-top:16px}
.btn-primary{background:#238636;color:#fff}.btn-primary:hover{background:#2ea043}
.btn-secondary{background:#21262d;color:#e6edf3;border:1px solid #30363d}
.alert-danger{background:#3d1c1c;border:1px solid #c00;border-radius:5px;padding:10px 14px;
              margin-bottom:16px;color:#ff7b7b;font-size:13px}
.alert-success{background:#1c3d1c;border:1px solid #2ea043;border-radius:5px;padding:10px 14px;
               margin-bottom:16px;color:#3fb950;font-size:13px}
.alert-warning{background:#3d2f0a;border:1px solid #bf8f00;border-radius:5px;padding:10px 14px;
               margin-bottom:16px;color:#f0ad4e;font-size:12px}
.check-row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #21262d;font-size:12px}
.check-ok{color:#3fb950}.check-warn{color:#f0ad4e}.check-fail{color:#ff7b7b}
.steps{display:flex;gap:0;margin-bottom:24px}
.step{flex:1;text-align:center;padding:6px;font-size:11px;color:#8b949e;border-bottom:2px solid #30363d}
.step.active{color:#58a6ff;border-bottom-color:#58a6ff;font-weight:600}
.step.done{color:#3fb950;border-bottom-color:#3fb950}
.log{background:#0d1117;border:1px solid #30363d;border-radius:5px;padding:10px;
     max-height:200px;overflow-y:auto;font-family:monospace;font-size:11px;margin-top:12px}
.log-ok{color:#3fb950}.log-err{color:#ff7b7b}
hr{border:none;border-top:1px solid #30363d;margin:20px 0}
code{background:#21262d;padding:2px 6px;border-radius:3px;font-size:12px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.checkbox-row{display:flex;align-items:center;gap:8px;margin-top:12px}
.checkbox-row input{width:auto;margin:0}
</style>
</head>
<body>
<div class="card">
    <h1>OpenMES</h1>
    <div class="brand">Manufacturing Execution System — Installation Wizard v10.9.0</div>

    <div class="steps">
        <?php
        $steps = ['Requirements','Database','Install','Complete'];
        foreach ($steps as $i => $s) {
            $n = $i + 1;
            $cls = $n < $step ? 'done' : ($n === $step ? 'active' : '');
            echo "<div class='step {$cls}'>" . ($n < $step ? '✓ ' : '') . htmlspecialchars($s) . "</div>";
        }
        ?>
    </div>

    <?php if ($error): ?>
    <div class="alert-danger">⛔ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($step === 1): ?>
    <!-- STEP 1: Requirements -->
    <h2>Step 1 — System Requirements</h2>
    <?php
    $checks = checkRequirements();
    $allOk  = allRequired($checks);
    foreach ($checks as $c):
        $cls = $c[1] ? 'check-ok' : (in_array($c[0],['finfo (MIME)','uploads/ writable']) ? 'check-warn' : 'check-fail');
        $icon = $c[1] ? '✓' : (in_array($c[0],['finfo (MIME)','uploads/ writable']) ? '⚠' : '⛔');
    ?>
    <div class="check-row">
        <span><?= htmlspecialchars($c[0]) ?></span>
        <span class="<?= $cls ?>"><?= $icon ?> <?= htmlspecialchars($c[2]) ?></span>
    </div>
    <?php endforeach; ?>

    <?php if (!$allOk): ?>
    <div class="alert-danger" style="margin-top:14px;">
        One or more required components are missing. Please resolve before continuing.
    </div>
    <?php else: ?>
    <div class="alert-success" style="margin-top:14px;">✓ All required components present.</div>
    <div class="alert-warning">
        ⚠ <strong>Security Notice:</strong> This install.php file contains no authentication.
        Complete installation immediately or delete this file if you are not proceeding.
    </div>
    <form method="POST">
        <input type="hidden" name="step" value="2">
        <button type="submit" class="btn btn-primary">Continue →</button>
    </form>
    <?php endif; ?>

    <?php elseif ($step === 2): ?>
    <!-- STEP 2: Database & Site Config -->
    <h2>Step 2 — Database & Site Configuration</h2>
    <form method="POST">
        <input type="hidden" name="step" value="2">
        <h3 style="font-size:13px;color:#8b949e;margin-top:4px;margin-bottom:8px;">Database Connection</h3>
        <div class="grid2">
            <div>
                <label>Database Host</label>
                <input type="text" name="db_host" value="localhost" required>
            </div>
            <div>
                <label>Port</label>
                <input type="text" name="db_port" value="3306">
            </div>
        </div>
        <label>Database Name</label>
        <input type="text" name="db_name" placeholder="openmes" required>
        <label>Database Username</label>
        <input type="text" name="db_user" placeholder="openmes_user" required>
        <label>Database Password</label>
        <input type="password" name="db_pass" placeholder="••••••••">
        <hr>
        <h3 style="font-size:13px;color:#8b949e;margin-bottom:8px;">Site Configuration</h3>
        <label>Site URL <span style="color:#8b949e;font-weight:400;">(no trailing slash)</span></label>
        <input type="text" name="site_url" placeholder="https://yourdomain.com" required>
        <label>Site Sub-path <span style="color:#8b949e;font-weight:400;">(leave blank if at domain root)</span></label>
        <input type="text" name="site_subpath" placeholder="/openmes">
        <label>Site Name</label>
        <input type="text" name="site_name" value="OpenMES">
        <label>Timezone</label>
        <select name="timezone">
            <?php
            $tzs = ['Europe/London','Europe/Paris','Europe/Berlin','America/New_York','America/Chicago',
                    'America/Denver','America/Los_Angeles','Asia/Dubai','Asia/Singapore','Australia/Sydney'];
            foreach ($tzs as $tz) echo "<option>" . htmlspecialchars($tz) . "</option>";
            ?>
        </select>
        <div class="checkbox-row">
            <input type="checkbox" name="test_mode" id="test_mode" checked>
            <label for="test_mode" style="margin:0;cursor:pointer;">
                Enable Test Mode <span style="color:#8b949e;">(username = password for test accounts)</span>
            </label>
        </div>
        <button type="submit" class="btn btn-primary">Test Connection & Continue →</button>
    </form>

    <?php elseif ($step === 3): ?>
    <!-- STEP 3: Confirm & Install -->
    <h2>Step 3 — Install Database & Write Config</h2>
    <div class="alert-warning">
        This will run <code>bootstrap.sql</code> against your database and write <code>config.php</code>.
        This action cannot be easily undone. Make sure the database is empty or a fresh install.
    </div>
    <p style="font-size:12px;color:#8b949e;margin-top:8px;">
        The following will be created: complete database schema, demo organisations (BIKE &amp; TEACL),
        test user accounts, and your <code>config.php</code> file.
        After installation, <code>install.php</code> will self-delete.
    </p>
    <form method="POST">
        <input type="hidden" name="step" value="3">
        <label>Type <code>CONFIRM</code> to proceed</label>
        <input type="text" name="confirm" placeholder="CONFIRM" style="font-family:monospace;max-width:200px;">
        <button type="submit" class="btn btn-primary">Install OpenMES →</button>
        <a href="install.php" class="btn btn-secondary" style="margin-left:8px;">← Back</a>
    </form>

    <?php elseif ($step === 4): ?>
    <!-- STEP 4: Complete -->
    <div class="alert-success">✓ OpenMES has been installed successfully!</div>
    <h2>Installation Complete</h2>
    <p style="font-size:13px;color:#8b949e;margin-bottom:16px;">
        Your OpenMES installation is ready. <code>install.php</code> has been deleted.
    </p>

    <?php if (!empty($sqlLog)): ?>
    <div class="log">
        <?php foreach ($sqlLog as $l): ?>
        <div class="log-<?= $l[0] ?>"><?= $l[0]==='ok'?'✓':'⛔' ?> <?= htmlspecialchars($l[1]) ?></div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <hr>
    <h3 style="font-size:14px;margin-bottom:12px;">Next Steps</h3>
    <div style="font-size:12px;color:#8b949e;line-height:2;">
        1. Log in as <code>ITADMIN1</code> (password: <code>ITADMIN1</code> in Test Mode)<br>
        2. Go to <strong>Administration → System Config</strong> to disable Test Mode before go-live<br>
        3. Create your organisation and users under <strong>Administration</strong><br>
        4. Run the <strong>Test Suite</strong> (Administration → Test Suite) to verify the installation<br>
        5. Check for updates on the <strong>Dashboard</strong>
    </div>
    <a href="index.php" class="btn btn-primary" style="display:inline-block;margin-top:16px;">Go to OpenMES →</a>

    <?php if (!empty($sqlLog)): ?>
    <?php endif; ?>
    <?php endif; ?>

</div>
</body>
</html>
