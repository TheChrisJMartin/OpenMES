<?php
/**
 * includes/layout.php — ChrisMES Page Layout Shell
 * Version: 10.5.0
 *
 * Provides renderPageStart($title) and renderPageEnd().
 *
 * v10.5.3.1: Defines MES_APP so broadcast_banner.php guard passes.
 */

if (!defined('MES_APP')) define('MES_APP', true);

/**
 * Also provides renderNav() for the left-hand navigation.
 *
 * Usage:
 *   require_once __DIR__ . '/../includes/layout.php';
 *   renderPageStart('Dashboard');
 *   ... page content ...
 *   renderPageEnd();
 */

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/app_config.php';
require_once dirname(__DIR__) . '/auth.php';

// Load DB-based config (defines SITE_NAME, SITE_TIMEZONE, feature switches etc)
loadAppConfig();

// ── Theme helper ─────────────────────────────────────────────────────────────

if (!function_exists('currentTheme')) {
    function currentTheme(): string {
        return $_SESSION['theme'] ?? DEFAULT_THEME;
    }
}

// ── Navigation definition (role-gated) ───────────────────────────────────────

function navItems(): array {
    $p = currentPersona();

    $all        = ['IT_ADMIN','SUPERVISOR','OPERATOR','TESTER','INSPECTOR','FINAL_TESTER','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER'];
    $itAdmin    = ['IT_ADMIN'];
    $management = ['IT_ADMIN','SUPERVISOR','MFG_ENGINEER','MFG_ENGINEER_SUP'];
    $engineers  = ['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER'];
    $supervisor = ['IT_ADMIN','SUPERVISOR'];
    $qualityMgmt = ['IT_ADMIN','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER'];

    $p = SITE_SUBPATH; // prefix for all internal links

    return [
        [
            'label' => 'Dashboard',
            'icon'  => 'grid',
            'href'  => $p . '/dashboard.php',
            'roles' => $all,
        ],
        [
            'label'    => 'Administration',
            'icon'     => 'settings',
            'roles'    => $itAdmin,
            'children' => [
                ['label' => 'Organisations',    'href' => $p . '/admin/orgs.php'],
                ['label' => 'Departments',      'href' => $p . '/admin/departments.php'],
                ['label' => 'Resources',        'href' => $p . '/admin/resources.php'],
                ['label' => 'Users & Roles',    'href' => $p . '/admin/users.php'],
                ['label' => 'Units of Measure', 'href' => $p . '/admin/uom.php'],
                ['label' => 'Inv. Locations',   'href' => $p . '/admin/locations.php'],
                ['label' => 'Serial Registers', 'href' => $p . '/admin/serial_registers.php'],
                ['label' => 'Integration Log',  'href' => $p . '/admin/integration.php'],
                ['label' => 'System Config',    'href' => $p . '/admin/config.php'],
                ['label' => 'Broadcast Message','href' => $p . '/routings/admin_broadcast.php'],
                ['label' => 'Security Log',     'href' => $p . '/admin/security_log.php'],
                ['label' => 'Deploy',           'href' => $p . '/admin/deploy.php'],
                ['label' => 'Test Suite',       'href' => $p . '/tests/run_tests.php'],
            ],
        ],
        [
            'label'    => 'Item Master',
            'icon'     => 'package',
            'roles'    => $management,
            'children' => [
                ['label' => 'Parts', 'href' => $p . '/items/parts.php'],
            ],
        ],
        [
            'label'    => 'Documents',
            'icon'     => 'file-text',
            'roles'    => $engineers,
            'children' => [
                ['label' => 'Work Instructions', 'href' => $p . '/docs/list.php'],
                ['label' => 'Upload Document',   'href' => $p . '/docs/upload.php'],
            ],
        ],
        [
            'label'    => 'Routings',
            'icon'     => 'git-branch',
            'roles'    => $engineers,
            'children' => [
                ['label' => 'Routing List',      'href' => $p . '/routings/list.php'],
                ['label' => 'Create Routing',    'href' => $p . '/routings/create.php'],
                ['label' => 'Quality Variables', 'href' => $p . '/routings/quality_vars_list.php', 'roles' => ['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER']],
            ],
        ],
        [
            'label'    => 'Work Orders',
            'icon'     => 'clipboard',
            'roles'    => $all,
            'children' => [
                ['label' => 'Operator Screen',  'href' => $p . '/workorders/operator.php'],
                ['label' => 'Work Order List',  'href' => $p . '/workorders/list.php'],
                ['label' => 'Create Work Order','href' => $p . '/workorders/create.php', 'roles' => $supervisor],
            ],
        ],
        [
            'label'    => 'Quality',
            'icon'     => 'check-circle',
            'roles'    => ['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER','SUPERVISOR'],
            'children' => [
                ['label' => 'Non-Conformances', 'href' => $p . '/quality/nc_list.php',     'roles' => ['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER']],
                ['label' => 'Quality Analytics', 'href' => $p . '/quality/analytics.php', 'roles' => ['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER']],
                ['label' => 'Calibration',      'href' => $p . '/quality/calibration.php', 'roles' => ['IT_ADMIN','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER','SUPERVISOR','OPERATOR','TESTER','INSPECTOR','FINAL_TESTER','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER']],
                ['label' => 'Skills Library',   'href' => $p . '/quality/skills.php',      'roles' => ['IT_ADMIN','QUALITY_TRAINING_MANAGER']],
                ['label' => 'Training Matrix',  'href' => $p . '/quality/training.php',    'roles' => ['IT_ADMIN','QUALITY_TRAINING_MANAGER']],
            ],
        ],
        [
            'label' => 'Analytics',
            'icon'  => 'bar-chart-2',
            'href'  => $p . '/analytics.php',
            'roles' => $all,
        ],
        [
            'label' => 'Supervisor View',
            'icon'  => 'bar-chart-2',
            'href'  => $p . '/supervisor.php',
            'roles' => $all,
        ],
        [
            'label' => 'User Manual',
            'icon'  => 'book-open',
            'href'  => $p . '/docs/serve_report.php?file=User_Manual_v10.7.0.pdf',
            'roles' => $all,
        ],
        [
            'label' => 'Roadmap',
            'icon'  => 'map',
            'href'  => $p . '/roadmap.php',
            'roles' => $all,
        ],
        [
            'label' => 'Release Notes',
            'icon'  => 'git-branch',
            'href'  => $p . '/releases.php',
            'roles' => $all,
        ],
    ];
}

function canSeeItem(array $item): bool {
    $roles = $item['roles'] ?? [];
    if (empty($roles)) return true;
    return in_array(currentPersona(), $roles, true);
}

// ── SVG Icon helper (Feather-style inline icons) ─────────────────────────────

function icon(string $name): string {
    $icons = [
        'grid'         => '<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/>',
        'settings'     => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
        'package'      => '<line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
        'file-text'    => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>',
        'git-branch'   => '<line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
        'clipboard'    => '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/>',
        'check-circle' => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
        'bar-chart-2'  => '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
        'map'          => '<polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>',
        'chevron-down' => '<polyline points="6 9 12 15 18 9"/>',
        'log-out'      => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'sun'          => '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
        'moon'         => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
        'user'         => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    ];

    $path = $icons[$name] ?? '<circle cx="12" cy="12" r="10"/>';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

// ── Page rendering ────────────────────────────────────────────────────────────

function renderPageStart(string $pageTitle = ''): void {
    // CD004: Security headers
    if (!headers_sent()) {
        header("X-Frame-Options: DENY");
        header("X-Content-Type-Options: nosniff");
        header("Referrer-Policy: strict-origin-when-cross-origin");
        header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
        }
    }
    $theme     = currentTheme();
    $siteName  = SITE_NAME;
    $fullTitle = $pageTitle ? "{$pageTitle} — {$siteName}" : $siteName;
    $year      = date('Y');
    $version   = SITE_VERSION;
    $knownAs   = $_SESSION['known_as'] ?? '';
    $personaLabel = $_SESSION['persona_label'] ?? '';
    $orgName   = $_SESSION['org_name'] ?? 'All Orgs';
    $currentPath = $_SERVER['REQUEST_URI'] ?? '';
    // Strip subpath prefix so active detection works regardless of install location
    $subpath = SITE_SUBPATH;
    $siteUrl = SITE_URL;
    if ($subpath && str_starts_with($currentPath, $subpath)) {
        $currentPath = substr($currentPath, strlen($subpath));
    }
    if ($currentPath === '' || $currentPath === false) $currentPath = '/';

    // Build nav HTML
    $navHtml = '';
    foreach (navItems() as $item) {
        if (!canSeeItem($item)) continue;

        $hasChildren = !empty($item['children']);
        $itemPath    = str_replace(SITE_SUBPATH, '', $item['href'] ?? '');
        $isActive    = isset($item['href']) && $itemPath !== '' && str_starts_with($currentPath, $itemPath);

        if (!$hasChildren) {
            $activeClass = $isActive ? ' active' : '';
            $navHtml .= '<a href="' . htmlspecialchars($item['href']) . '" class="nav-item' . $activeClass . '">'
                     . icon($item['icon'])
                     . '<span>' . htmlspecialchars($item['label']) . '</span>'
                     . '</a>';
        } else {
            // Check if any child is active
            $groupActive = false;
            $childrenHtml = '';
            foreach ($item['children'] as $child) {
                // Per-child role check
                if (!empty($child['roles']) && !in_array(currentPersona(), $child['roles'], true)) continue;
            $childPath   = str_replace(SITE_SUBPATH, '', $child['href']);
                $childActive = str_starts_with($currentPath, $childPath);
                if ($childActive) $groupActive = true;
                $childActiveClass = $childActive ? ' active' : '';
                $childrenHtml .= '<a href="' . htmlspecialchars($child['href']) . '" class="nav-child' . $childActiveClass . '">'
                              . htmlspecialchars($child['label']) . '</a>';
            }
            if (!$childrenHtml) continue; // all children hidden

            $openClass   = $groupActive ? ' open' : '';
            $activeClass = $groupActive ? ' active' : '';
            $navHtml .= '<div class="nav-group' . $openClass . '">'
                     . '<div class="nav-group-header' . $activeClass . '" onclick="toggleGroup(this)">'
                     . icon($item['icon'])
                     . '<span>' . htmlspecialchars($item['label']) . '</span>'
                     . icon('chevron-down')
                     . '</div>'
                     . '<div class="nav-group-children">' . $childrenHtml . '</div>'
                     . '</div>';
        }
    }

    echo <<<HTML
<!DOCTYPE html>
<html lang="en" data-theme="{$theme}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$fullTitle}</title>
    <style>
        /* ══ ChrisMES Design System v1.0.0 ══════════════════════════════════ */

        /* Dark theme (default) */
        [data-theme="dark"] {
            --bg:            #0d1117;
            --bg-nav:        #010409;
            --bg-card:       #161b22;
            --bg-card-hover: #1c2230;
            --bg-input:      #0d1117;
            --border:        #30363d;
            --border-focus:  #388bfd;
            --text:          #e6edf3;
            --text-muted:    #8b949e;
            --text-dim:      #6e7681;
            --accent:        #238636;
            --accent-hover:  #2ea043;
            --accent-blue:   #388bfd;
            --accent-warn:   #d29922;
            --accent-danger: #f85149;
            --accent-info:   #58a6ff;
            --nav-width:     240px;
            --header-h:      56px;
            --radius:        6px;
            --shadow:        0 1px 3px rgba(0,0,0,.4);
        }

        /* Light theme */
        [data-theme="light"] {
            --bg:            #f6f8fa;
            --bg-nav:        #ffffff;
            --bg-card:       #ffffff;
            --bg-card-hover: #f6f8fa;
            --bg-input:      #ffffff;
            --border:        #d0d7de;
            --border-focus:  #0969da;
            --text:          #1f2328;
            --text-muted:    #57606a;
            --text-dim:      #8c959f;
            --accent:        #1a7f37;
            --accent-hover:  #2da44e;
            --accent-blue:   #0969da;
            --accent-warn:   #9a6700;
            --accent-danger: #cf222e;
            --accent-info:   #0969da;
            --nav-width:     240px;
            --header-h:      56px;
            --radius:        6px;
            --shadow:        0 1px 3px rgba(0,0,0,.12);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: -apple-system,'Segoe UI',system-ui,sans-serif;
            font-size: 14px;
            line-height: 1.5;
            display: flex;
            min-height: 100vh;
            overflow-x: hidden; /* D035: prevent body-level horizontal scroll */
        }

        /* ── Sidebar Nav ── */
        .sidebar {
            width: var(--nav-width);
            background: var(--bg-nav);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0; left: 0; bottom: 0;
            z-index: 100;
            overflow: hidden; /* D035: never let sidebar itself scroll or show a scrollbar */
        }
        .sidebar-logo {
            padding: 16px 16px 14px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            flex-shrink: 0; /* D035: logo never shrinks — stays pinned at top */
        }
        .logo-mark {
            width: 32px; height: 32px;
            background: var(--accent-blue);
            border-radius: 6px;
            display: flex; align-items: center; justify-content: center;
            font-weight: 800; font-size: 14px; color: #fff;
            flex-shrink: 0;
            letter-spacing: -.5px;
        }
        .logo-text { font-weight: 700; font-size: 15px; color: var(--text); }
        .logo-version { font-size: 9px; color: var(--text-dim); margin-top: 1px; font-family: monospace; }

        .sidebar-nav {
            flex: 1;
            min-height: 0;
            padding: 8px 0;
            /* D035: overlay renders scrollbar ON TOP of content — takes no layout space */
            overflow-y: overlay;
            overflow-x: hidden;
            /* Fallback for browsers that don't support overlay */
            scrollbar-width: none;
        }
        /* D035: WebKit — zero-width scrollbar gutter, overlay style */
        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.2);
            border-radius: 2px;
        }

        .nav-item {
            display: flex; align-items: center; gap: 10px;
            padding: 8px 14px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 13px;
            border-radius: 0;
            transition: background .1s, color .1s;
            border-left: 3px solid transparent;
        }
        .nav-item:hover { background: var(--bg-card-hover); color: var(--text); }
        .nav-item.active { color: var(--accent-blue); border-left-color: var(--accent-blue); background: rgba(56,139,253,.08); }
        .nav-item svg { flex-shrink: 0; opacity: .7; }
        .nav-item.active svg { opacity: 1; }

        /* Nav groups */
        .nav-group { }
        .nav-group-header {
            display: flex; align-items: center; gap: 10px;
            padding: 8px 14px;
            color: var(--text-muted);
            font-size: 13px;
            cursor: pointer;
            border-left: 3px solid transparent;
            transition: background .1s, color .1s;
        }
        .nav-group-header:hover { background: var(--bg-card-hover); color: var(--text); }
        .nav-group-header.active { color: var(--accent-blue); }
        .nav-group-header svg:last-child { margin-left: auto; transition: transform .2s; opacity: .5; }
        .nav-group.open .nav-group-header svg:last-child { transform: rotate(180deg); }

        .nav-group-children { display: none; padding: 0 0 4px 40px; }
        .nav-group.open .nav-group-children { display: block; }

        .nav-child {
            display: block;
            padding: 6px 10px;
            color: var(--text-dim);
            font-size: 12.5px;
            text-decoration: none;
            border-radius: var(--radius);
            transition: background .1s, color .1s;
        }
        .nav-child:hover { background: var(--bg-card-hover); color: var(--text); }
        .nav-child.active { color: var(--accent-blue); }

        /* Sidebar footer */
        .sidebar-footer {
            border-top: 1px solid var(--border);
            padding: 12px 14px;
            flex-shrink: 0; /* D035: footer stays pinned at bottom */
        }
        .sidebar-user {
            display: flex; align-items: center; gap: 9px;
            margin-bottom: 10px;
        }
        .user-avatar {
            width: 28px; height: 28px;
            background: var(--accent-blue);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 11px; font-weight: 700; color: #fff;
            flex-shrink: 0;
        }
        .user-name { font-size: 12px; font-weight: 600; color: var(--text); }
        .user-role { font-size: 10px; color: var(--text-dim); }

        .sidebar-actions { display: flex; gap: 6px; }
        .btn-sm {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 5px 10px;
            font-size: 11px;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            background: transparent;
            color: var(--text-muted);
            cursor: pointer;
            text-decoration: none;
            transition: background .1s, color .1s;
        }
        .btn-sm:hover { background: var(--bg-card-hover); color: var(--text); }

        /* ── Main Content ── */
        .main {
            margin-left: var(--nav-width);
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            min-width: 0;        /* D035: prevents flex blowout causing gap scrollbar */
            overflow-x: hidden;  /* D035: hides the spurious scrollbar between nav and content */
        }

        /* Top bar */
        .topbar {
            height: var(--header-h);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            padding: 0 24px;
            gap: 10px;
            position: sticky;
            top: 0;
            background: var(--bg);
            z-index: 50;
        }
        .topbar-title {
            font-size: 15px;
            font-weight: 600;
            flex: 1;
            color: var(--text);
        }
        .org-pill {
            font-size: 11px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 3px 10px;
            color: var(--text-muted);
            font-family: monospace;
        }

        /* Content area */
        .content {
            flex: 1;
            padding: 28px 28px 60px;
            max-width: 1400px;
            width: 100%;
        }

        /* ── Common Components ── */

        /* Cards */
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 20px;
            margin-bottom: 16px;
        }
        .card-title {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 14px;
            color: var(--text);
        }

        /* Buttons */
        .btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 7px 14px;
            font-size: 13px;
            border-radius: var(--radius);
            border: 1px solid transparent;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            transition: background .1s, border-color .1s, opacity .1s;
        }
        .btn:disabled { opacity: .5; cursor: not-allowed; }
        .btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
        .btn-primary:hover { background: var(--accent-hover); }
        .btn-secondary { background: var(--bg-card); color: var(--text); border-color: var(--border); }
        .btn-secondary:hover { background: var(--bg-card-hover); }
        .btn-danger  { background: var(--accent-danger); color: #fff; }
        .btn-warning { background: var(--accent-warn); color: #fff; }
        .btn-blue    { background: var(--accent-blue); color: #fff; }

        /* Tables */
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th {
            text-align: left;
            padding: 8px 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .05em;
            color: var(--text-dim);
            border-bottom: 1px solid var(--border);
            background: var(--bg-card);
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--border);
            color: var(--text);
            vertical-align: middle;
        }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: var(--bg-card-hover); }

        /* Forms */
        .form-group { margin-bottom: 16px; }
        label { display: block; font-size: 12px; font-weight: 600; color: var(--text-muted); margin-bottom: 5px; }
        input[type=text], input[type=password], input[type=email],
        input[type=number], select, textarea {
            width: 100%;
            padding: 8px 10px;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            color: var(--text);
            font-size: 13px;
            transition: border-color .15s;
        }
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--border-focus);
            box-shadow: 0 0 0 3px rgba(56,139,253,.12);
        }

        /* Badges */
        .badge {
            display: inline-block;
            font-size: 10px; font-weight: 700;
            letter-spacing: .04em;
            border-radius: 4px;
            padding: 2px 7px;
            text-transform: uppercase;
        }
        .badge-green  { background: rgba(35,134,54,.2); color: #3fb950; border: 1px solid rgba(35,134,54,.35); }
        .badge-blue   { background: rgba(56,139,253,.15); color: #79c0ff; border: 1px solid rgba(56,139,253,.3); }
        .badge-yellow { background: rgba(210,153,34,.15); color: #e3b341; border: 1px solid rgba(210,153,34,.3); }
        .badge-red    { background: rgba(248,81,73,.15); color: #ff7b72; border: 1px solid rgba(248,81,73,.3); }
        .badge-grey   { background: rgba(110,118,129,.15); color: #8b949e; border: 1px solid rgba(110,118,129,.3); }

        /* Alerts */
        .alert {
            padding: 12px 16px;
            border-radius: var(--radius);
            border: 1px solid;
            margin-bottom: 16px;
            font-size: 13px;
        }
        .alert-success { background: rgba(35,134,54,.12); border-color: rgba(35,134,54,.35); color: #3fb950; }
        .alert-danger  { background: rgba(248,81,73,.12); border-color: rgba(248,81,73,.35); color: #ff7b72; }
        .alert-info    { background: rgba(56,139,253,.12); border-color: rgba(56,139,253,.3); color: #79c0ff; }
        .alert-warning { background: rgba(210,153,34,.12); border-color: rgba(210,153,34,.3); color: #e3b341; }

        /* Page header */
        .page-header { margin-bottom: 22px; }
        .page-header h1 { font-size: 20px; font-weight: 700; margin-bottom: 4px; }
        .page-header p  { color: var(--text-muted); font-size: 13px; }
        .page-header-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; flex-wrap: wrap; }

        /* Utility */
        .mt-1 { margin-top: 8px; } .mt-2 { margin-top: 16px; }
        .mb-1 { margin-bottom: 8px; } .mb-2 { margin-bottom: 16px; }
        .text-muted { color: var(--text-muted); }
        .text-dim   { color: var(--text-dim); font-size: 12px; }
        .font-mono  { font-family: monospace; }
        .flex { display: flex; } .flex-1 { flex: 1; } .gap-1 { gap: 8px; } .gap-2 { gap: 16px; }
        .items-center { align-items: center; }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .main { margin-left: 0; }
        }
    </style>
</head>
<body>

<!-- ── Sidebar ── -->
<nav class="sidebar">
    <a href="{$subpath}/dashboard.php" class="sidebar-logo">
        <div class="logo-mark">CM</div>
        <div>
            <div class="logo-text">{$siteName}</div>
            <div class="logo-version">v{$version}</div>
        </div>
    </a>

    <div class="sidebar-nav">
        {$navHtml}
    </div>

    <div class="sidebar-footer">
        <div class="sidebar-user">
            <div class="user-avatar"><?php echo strtoupper(substr($knownAs, 0, 2)); ?></div>
            <div>
                <div class="user-name"><?php echo htmlspecialchars($knownAs); ?></div>
                <div class="user-role"><?php echo htmlspecialchars($personaLabel); ?></div>
            </div>
        </div>
        <div class="sidebar-actions">
            <button class="btn-sm" onclick="toggleTheme()" title="Toggle theme" id="theme-btn">
                <?php echo currentTheme() === 'dark' ? icon('sun') : icon('moon'); ?>
            </button>
            <a href="{$subpath}/logout.php" class="btn-sm">
                <?php echo icon('log-out'); ?> Logout
            </a>
        </div>
    </div>
</nav>

<!-- ── Main ── -->
<div class="main">
    <div class="topbar">
        <span class="topbar-title"><?php echo htmlspecialchars($pageTitle); ?></span>
        <span class="org-pill"><?php echo htmlspecialchars($orgName); ?></span>
    </div>
HTML;
    // F077: Maintenance mode warning banner for IT Admin
    if (defined('MAINTENANCE_MODE') && MAINTENANCE_MODE && ($_SESSION['persona_code'] ?? '') === 'IT_ADMIN') {
        echo '<div style="background:#bf8f00;color:#fff;text-align:center;padding:8px 16px;'
           . 'font-size:13px;font-weight:600;flex-shrink:0;">'
           . '&#9888; MAINTENANCE MODE IS ACTIVE &mdash; Non-admin users are seeing the maintenance page. '
           . '<a href="' . SITE_SUBPATH . '/admin/config.php" style="color:#fff;text-decoration:underline;margin-left:8px;">Disable in System Config</a>'
           . '</div>';
    }
    // Broadcast banner — rendered between topbar and content; silently skipped if table absent
    require_once dirname(__DIR__) . '/includes/broadcast_banner.php';
    echo <<<HTML
    <div class="content">
HTML;
}

function renderPageEnd(): void {
    $siteUrl = SITE_URL;
    echo <<<HTML
    </div><!-- /content -->
</div><!-- /main -->

<script>
function toggleGroup(header) {
    header.parentElement.classList.toggle('open');
    // D035: After expanding a group, ensure sidebar-nav scroll is contained
    const nav = document.querySelector('.sidebar-nav');
    if (nav) {
        nav.style.overflowY = 'auto';
        nav.style.overflowX = 'hidden';
    }
}

function toggleTheme() {
    // D035: Enforce sidebar-nav scroll containment on every page load
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('.sidebar');
        const nav     = document.querySelector('.sidebar-nav');
        const footer  = document.querySelector('.sidebar-footer');
        if (sidebar) sidebar.style.overflow = 'hidden';
        if (nav)     { nav.style.overflowY = 'auto'; nav.style.overflowX = 'hidden'; nav.style.minHeight = '0'; }
        if (footer)  footer.style.flexShrink = '0';
    });
    const html    = document.documentElement;
    const current = html.getAttribute('data-theme');
    const next    = current === 'dark' ? 'light' : 'dark';

    // Swap theme instantly — no flash, no reload
    html.setAttribute('data-theme', next);

    // Update the button icon
    const btn = document.getElementById('theme-btn');
    if (btn) {
        btn.innerHTML = next === 'dark'
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    }

    // Persist to server (fire and forget — no reload needed)
    fetch('{$siteUrl}/api/set_theme.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({theme: next})
    }).catch(() => {}); // silently ignore network errors
}
</script>

</body>
</html>
HTML;
}
