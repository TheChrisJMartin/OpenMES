<?php
/**
 * includes/app_config.php — Application Configuration Loader
 * Version: 10.5.3.1-php85
 *
 * Loads all runtime settings from the system_config DB table and
 * defines them as PHP constants. Must be included AFTER db.php.
 *
 * Includes sensible fallbacks so the app works even if a config
 * row is missing (e.g. after a partial migration).
 *
 * Usage — already called in includes/layout.php. You do not need
 * to include this manually in individual pages.
 */

// Defaults used if a key is not found in the DB
// Note: using define() not const — const at file scope in included files
// is deprecated/removed in PHP 8.5
if (!defined('APP_CONFIG_DEFAULTS_LOADED')) {
    define('APP_CONFIG_DEFAULTS_LOADED', true);
    define('APP_CONFIG_DEFAULTS', [
        'SITE_VERSION'            => '10.6.1',  // fallback if not in DB yet
        'SITE_NAME'               => 'ChrisMES',
        'SITE_TAGLINE'            => 'Manufacturing Execution System',
        'SITE_TIMEZONE'           => 'Europe/London',
        'SESSION_TIMEOUT_MINUTES' => '480',
        'DEFAULT_THEME'           => 'dark',
        'BCRYPT_COST'             => '12',
        'PARTS_LOCKED'            => '0',
        'ORGS_LOCKED'             => '0',
        'DEPARTMENTS_LOCKED'      => '0',
        'RESOURCES_LOCKED'        => '0',
        'AUTO_APPROVE_DOCS'       => '1',
        'AUTO_APPROVE_ROUTINGS'   => '1',
        'ALLOW_WO_CREATION'       => '1',
        'MAX_SERIALS_PER_WO'      => '100',
        'MAX_LOT_QTY_PER_WO'      => '1000',
    ]);
}

function loadAppConfig(): void {
    // Only load once per request
    if (defined('APP_CONFIG_LOADED')) return;
    define('APP_CONFIG_LOADED', true);

    $cfg = APP_CONFIG_DEFAULTS;

    // Load from DB — gracefully skip if table doesn't exist yet
    try {
        $rows = dbFetchAll("SELECT config_key, config_val FROM system_config");
        foreach ($rows as $row) {
            $cfg[$row['config_key']] = $row['config_val'];
        }
    } catch (Throwable) {
        // DB table not yet created — use defaults silently
    }

    // Define each as a PHP constant (boolean/int coerced correctly)
    $booleans = [
        'PARTS_LOCKED','ORGS_LOCKED','DEPARTMENTS_LOCKED','RESOURCES_LOCKED',
        'AUTO_APPROVE_DOCS','AUTO_APPROVE_ROUTINGS','ALLOW_WO_CREATION',
    ];
    $integers = [
        'SESSION_TIMEOUT_MINUTES','BCRYPT_COST',
        'MAX_SERIALS_PER_WO','MAX_LOT_QTY_PER_WO',
    ];

    foreach ($cfg as $key => $val) {
        if (defined($key)) continue; // already defined (e.g. from config.php)

        if (in_array($key, $booleans, true)) {
            define($key, (bool)(int)$val);
        } elseif (in_array($key, $integers, true)) {
            define($key, (int)$val);
        } else {
            define($key, $val);
        }
    }

    // Apply timezone immediately after loading
    if (defined('SITE_TIMEZONE')) {
        date_default_timezone_set(SITE_TIMEZONE);
    }
}
