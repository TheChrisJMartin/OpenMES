<?php
/**
 * includes/broadcast_banner.php
 * Version: 10.5.3.1
 * Fixed: use getDB() instead of raw $pdo variable
 */

if (!defined('MES_APP')) define('MES_APP', true);

$banner = null;
try {
    $banner = dbFetchOne(
        "SELECT message_text, colour FROM broadcast_messages WHERE is_active=1 LIMIT 1"
    );
} catch (Throwable) {
    $banner = null;
}

if ($banner):
    $schemes = [
        'red'    => ['bg' => '#c0392b', 'text' => '#ffffff', 'border' => '#922b21'],
        'yellow' => ['bg' => '#f1c40f', 'text' => '#1a1a1a', 'border' => '#d4ac0d'],
        'green'  => ['bg' => '#27ae60', 'text' => '#ffffff', 'border' => '#1e8449'],
    ];
    $scheme = $schemes[$banner['colour']] ?? $schemes['yellow'];
    $msg    = htmlspecialchars($banner['message_text'], ENT_QUOTES, 'UTF-8');
?>
<div style="background:<?= $scheme['bg'] ?>;
            color:<?= $scheme['text'] ?>;
            border-bottom:3px solid <?= $scheme['border'] ?>;
            padding:10px 20px;
            font-weight:600;
            font-size:0.95rem;
            display:flex;
            align-items:center;
            gap:10px;
            z-index:9999;
            position:sticky;
            top:0;">
    <span style="font-size:1.2rem;">&#128226;</span>
    <span><?= $msg ?></span>
</div>
<?php endif; ?>
