<?php
/**
 * includes/helpers.php — ChrisMES Shared Helpers
 * Version: 10.5.0
 *
 * All badge functions live here. Do NOT redeclare them in individual pages.
 * Include where needed:
 *   require_once dirname(__DIR__) . '/includes/helpers.php';
 */

// ── Timezone & Date helpers ───────────────────────────────────────────────────

/**
 * Convert a UTC datetime string from the DB to the site timezone for display.
 */
function displayDate(?string $utcDatetime, string $format = 'd M Y H:i'): string {
    if (!$utcDatetime || $utcDatetime === '0000-00-00 00:00:00') return '—';
    try {
        $dt = new DateTimeImmutable($utcDatetime, new DateTimeZone('UTC'));
        return $dt->setTimezone(new DateTimeZone(SITE_TIMEZONE))->format($format);
    } catch (Throwable) {
        return htmlspecialchars($utcDatetime);
    }
}

/**
 * Current datetime in SITE_TIMEZONE for display.
 */
function nowDisplay(string $format = 'd M Y H:i T'): string {
    return (new DateTimeImmutable('now', new DateTimeZone(SITE_TIMEZONE)))->format($format);
}

/**
 * Current datetime in UTC for storing in DB.
 */
function nowUtc(string $format = 'Y-m-d H:i:s'): string {
    return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format($format);
}

// ── Badge helpers (one place — no redeclaration in pages) ────────────────────

function routingStatusBadge(string $status): string {
    return match($status) {
        'APPROVED'   => '<span class="badge badge-green">Approved</span>',
        'DRAFT'      => '<span class="badge badge-blue">Draft</span>',
        'SUPERSEDED' => '<span class="badge badge-yellow">Superseded</span>',
        'ARCHIVED'   => '<span class="badge badge-grey">Archived</span>',
        default      => '<span class="badge badge-grey">'.htmlspecialchars($status).'</span>',
    };
}

function docStatusBadge(string $status): string {
    return match($status) {
        'APPROVED'   => '<span class="badge badge-green">Approved</span>',
        'DRAFT'      => '<span class="badge badge-blue">Draft</span>',
        'SUPERSEDED' => '<span class="badge badge-yellow">Superseded</span>',
        'ARCHIVED'   => '<span class="badge badge-grey">Archived</span>',
        default      => '<span class="badge badge-grey">'.htmlspecialchars($status).'</span>',
    };
}

function woStatusBadge(string $status, ?string $holdType = null): string {
    // v10.5.0: When a hold type is set, the hold type badge IS the status —
    // don't show "On Hold" + "SOFT HOLD" redundantly side by side.
    if ($status === 'ON_HOLD' && $holdType) {
        return match($holdType) {
            'HARD'  => '<span class="badge badge-red">&#9940; Hard Hold</span>',
            'SOFT'  => '<span class="badge badge-yellow">&#9888; Soft Hold</span>',
            default => '<span class="badge badge-red">'.htmlspecialchars($holdType).' Hold</span>',
        };
    }

    $badge = match($status) {
        'OPEN'        => '<span class="badge badge-blue">Open</span>',
        'IN_PROGRESS' => '<span class="badge badge-green">In Progress</span>',
        'COMPLETE'    => '<span class="badge badge-grey">Complete</span>',
        'ON_HOLD'     => '<span class="badge badge-yellow">On Hold</span>',
        'CANCELLED'   => '<span class="badge badge-grey">Cancelled</span>',
        default       => '<span class="badge badge-grey">'.htmlspecialchars($status).'</span>',
    };
    return $badge;
}

function serialStatusBadge(string $status): string {
    return match($status) {
        'NOT_STARTED' => '<span class="badge badge-grey">Not Started</span>',
        'IN_PROGRESS' => '<span class="badge badge-blue">In Progress</span>',
        'COMPLETE'    => '<span class="badge badge-green">Complete</span>',
        'SCRAPPED'    => '<span class="badge badge-red">Scrapped</span>',
        'ON_HOLD'     => '<span class="badge badge-yellow">On Hold</span>',
        default       => '<span class="badge badge-grey">'.htmlspecialchars($status).'</span>',
    };
}

function ncStatusBadge(string $status): string {
    return match($status) {
        'OPEN'         => '<span class="badge badge-red">Open</span>',
        'UNDER_REVIEW' => '<span class="badge badge-yellow">Under Review</span>',
        'CLOSED'       => '<span class="badge badge-green">Closed</span>',
        'SCRAPPED'     => '<span class="badge badge-grey">Scrapped</span>',
        default        => '<span class="badge badge-grey">'.htmlspecialchars($status).'</span>',
    };
}

// ── v10.5.0: Security event logging ──────────────────────────────────────────
// Guarded because auth.php also declares this function to ensure it is
// available at login time before helpers.php is included.
if (!function_exists('writeSecurityLog')) {
function writeSecurityLog(
    string  $eventType,
    string  $severity,          // HIGH | MEDIUM | LOW
    ?int    $userId,
    ?string $usernameAttempted,
    ?string $description,
    ?string $entityType = null,
    ?int    $entityId   = null
): void {
    try {
        $ip        = $_SERVER['HTTP_X_FORWARDED_FOR']
                  ?? $_SERVER['HTTP_X_REAL_IP']
                  ?? $_SERVER['REMOTE_ADDR']
                  ?? null;
        $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300);
        dbInsert(
            "INSERT INTO security_log
                (event_type,severity,user_id,username_attempted,ip_address,
                 user_agent,description,entity_type,entity_id,occurred_at)
             VALUES (?,?,?,?,?,?,?,?,?,NOW())",
            [$eventType,$severity,$userId,$usernameAttempted,
             $ip,$userAgent,$description,$entityType,$entityId]
        );
    } catch (Throwable $e) {
        error_log('[ChrisMES] security_log write failed: ' . $e->getMessage());
    }
}
} // end if (!function_exists('writeSecurityLog'))
