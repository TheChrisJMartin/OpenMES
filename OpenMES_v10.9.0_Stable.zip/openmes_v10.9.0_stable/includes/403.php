<?php
/**
 * includes/403.php — ChrisMES Access Denied
 * Version: 1.0.0
 * Included by auth.php when persona check fails.
 */
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>Access Denied — <?= htmlspecialchars(SITE_NAME) ?></title>
    <style>
        body { background:#0d1117; color:#e6edf3; font-family:system-ui,sans-serif; display:flex; align-items:center; justify-content:center; min-height:100vh; text-align:center; }
        h1   { font-size:48px; color:#f85149; margin-bottom:8px; }
        p    { color:#8b949e; }
        a    { color:#388bfd; }
    </style>
</head>
<body>
    <div>
        <h1>403</h1>
        <p>You don't have permission to access this page.</p>
        <p style="margin-top:16px;"><a href="<?= defined('SITE_SUBPATH') ? SITE_SUBPATH : '' ?>/dashboard.php">← Return to Dashboard</a></p>
    </div>
</body>
</html>
