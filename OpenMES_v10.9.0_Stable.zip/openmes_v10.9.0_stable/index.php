<?php
/**
 * index.php — ChrisMES Public Landing Page
 * Version: 1.0.0
 *
 * Public roadmap view with login button.
 * No authentication required.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

// If already logged in, go straight to dashboard
if (isLoggedIn()) {
    header('Location: ' . SITE_URL . '/dashboard.php');
    exit;
}

$roadmap = [
    ['release'=>'1.0.0','title'=>'Foundation & Authentication',             'status'=>'delivered',  'target'=>'Sprint 1',  'features'=>19],
    ['release'=>'2.0.0','title'=>'Organisation, User & Item Master Mgmt',   'status'=>'delivered',  'target'=>'Sprint 2',  'features'=>12],
    ['release'=>'3.0.0','title'=>'Document / Work Instruction Management',  'status'=>'delivered',    'target'=>'Sprint 3',  'features'=>9],
    ['release'=>'4.0.0','title'=>'Routing Editor, Doc Enhancements & Rev Control',       'status'=>'planned',    'target'=>'Sprint 4',  'features'=>8],
    ['release'=>'5.0.0','title'=>'Work Order Creation & Serial/Lot Mgmt',   'status'=>'planned',    'target'=>'Sprint 5',  'features'=>8],
    ['release'=>'6.0.0','title'=>'Operator Execution Screen & Clock On/Off','status'=>'planned',    'target'=>'Sprint 6',  'features'=>7],
    ['release'=>'7.0.0','title'=>'Non-Conformance, Disposition & Integration Viewer',   'status'=>'delivered',  'target'=>'Sprint 7',  'features'=>5],
    ['release'=>'8.0.0','title'=>'Supervisor Dashboard, Tooling & Calib.',  'status'=>'planned',    'target'=>'Sprint 8',  'features'=>5],
    ['release'=>'9.0.0','title'=>'Quality Variables & ERP Integration',     'status'=>'planned',    'target'=>'Sprint 9',  'features'=>5],
    ['release'=>'10.0.0','title'=>'Advanced Features & System Hardening',   'status'=>'planned',    'target'=>'Sprint 10', 'features'=>5],
];

$delivered = count(array_filter($roadmap, fn($r) => $r['status'] === 'delivered'));
$total     = count($roadmap);
$pct       = round(($delivered / $total) * 100);
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(SITE_NAME) ?> — Manufacturing Execution System</title>
    <style>
        :root {
            --bg:          #0d1117;
            --bg-card:     #161b22;
            --bg-card2:    #1c2230;
            --border:      #30363d;
            --accent:      #238636;
            --accent-blue: #388bfd;
            --accent-warn: #d29922;
            --text:        #e6edf3;
            --text-muted:  #8b949e;
            --text-dim:    #6e7681;
            --radius:      8px;
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            min-height: 100vh;
        }

        /* ── Top bar ── */
        .topbar {
            border-bottom: 1px solid var(--border);
            padding: 0 32px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            background: var(--bg);
            z-index: 50;
        }
        .topbar-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }
        .logo-mark {
            width: 32px; height: 32px;
            background: var(--accent-blue);
            border-radius: 6px;
            display: flex; align-items: center; justify-content: center;
            font-weight: 800; font-size: 14px; color: #fff;
            letter-spacing: -.5px;
        }
        .logo-text  { font-weight: 700; font-size: 15px; color: var(--text); }
        .logo-sub   { font-size: 11px; color: var(--text-dim); margin-top: 1px; }

        .btn-login {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: var(--accent-blue);
            color: #fff;
            border: none;
            border-radius: var(--radius);
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            transition: opacity .15s;
        }
        .btn-login:hover { opacity: .85; }

        /* ── Hero ── */
        .hero {
            text-align: center;
            padding: 64px 24px 48px;
            max-width: 680px;
            margin: 0 auto;
        }
        .hero-badge {
            display: inline-block;
            background: rgba(56,139,253,.12);
            border: 1px solid rgba(56,139,253,.3);
            color: #79c0ff;
            border-radius: 20px;
            padding: 4px 14px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .06em;
            text-transform: uppercase;
            margin-bottom: 20px;
        }
        .hero h1 {
            font-size: 36px;
            font-weight: 800;
            letter-spacing: -.03em;
            margin-bottom: 14px;
            line-height: 1.15;
        }
        .hero h1 span { color: var(--accent-blue); }
        .hero p {
            color: var(--text-muted);
            font-size: 15px;
            margin-bottom: 28px;
        }
        .hero-actions {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .btn-hero-primary {
            display: inline-flex; align-items: center; gap: 8px;
            background: var(--accent-blue);
            color: #fff;
            border-radius: var(--radius);
            padding: 11px 24px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: opacity .15s;
        }
        .btn-hero-primary:hover { opacity: .85; }
        .btn-hero-secondary {
            display: inline-flex; align-items: center; gap: 8px;
            background: var(--bg-card);
            color: var(--text);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 11px 24px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: background .15s;
        }
        .btn-hero-secondary:hover { background: var(--bg-card2); }

        /* ── Progress bar ── */
        .progress-section {
            max-width: 860px;
            margin: 0 auto 40px;
            padding: 0 24px;
        }
        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .progress-label { font-size: 12px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: .06em; }
        .progress-pct   { font-size: 13px; font-weight: 700; color: var(--accent-blue); font-family: monospace; }
        .progress-track {
            height: 6px;
            background: var(--border);
            border-radius: 3px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent-blue), #58a6ff);
            border-radius: 3px;
            transition: width .4s ease;
            width: <?= $pct ?>%;
        }
        .progress-meta {
            display: flex;
            gap: 20px;
            margin-top: 10px;
            font-size: 11px;
            color: var(--text-dim);
        }
        .progress-meta span { display: flex; align-items: center; gap: 5px; }
        .dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
        .dot-green  { background: #3fb950; }
        .dot-blue   { background: var(--accent-blue); }
        .dot-grey   { background: var(--text-dim); }

        /* ── Roadmap grid ── */
        .roadmap-section {
            max-width: 860px;
            margin: 0 auto;
            padding: 0 24px 80px;
        }
        .section-title {
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: var(--text-dim);
            margin-bottom: 16px;
        }
        .roadmap-grid {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .rm-row {
            display: flex;
            align-items: center;
            gap: 14px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 13px 16px;
            transition: border-color .15s;
        }
        .rm-row:hover { border-color: #444c56; }
        .rm-row.delivered { border-left: 3px solid #3fb950; }
        .rm-row.in-progress { border-left: 3px solid var(--accent-blue); }
        .rm-row.planned { border-left: 3px solid var(--border); padding-left: 13px; }

        .rm-ver {
            font-family: monospace;
            font-size: 11px;
            color: var(--text-dim);
            background: var(--bg);
            border: 1px solid var(--border);
            border-radius: 4px;
            padding: 2px 8px;
            white-space: nowrap;
            min-width: 58px;
            text-align: center;
        }
        .rm-title {
            flex: 1;
            font-size: 13px;
            font-weight: 500;
            color: var(--text);
        }
        .rm-target {
            font-size: 11px;
            color: var(--text-dim);
            font-family: monospace;
            white-space: nowrap;
        }
        .rm-count {
            font-size: 11px;
            color: var(--text-dim);
            white-space: nowrap;
        }
        .badge {
            font-size: 10px;
            font-weight: 700;
            letter-spacing: .04em;
            border-radius: 4px;
            padding: 2px 8px;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .badge-green  { background: rgba(46,160,67,.15); color: #3fb950; border: 1px solid rgba(46,160,67,.35); }
        .badge-blue   { background: rgba(56,139,253,.12); color: #79c0ff; border: 1px solid rgba(56,139,253,.3); }
        .badge-grey   { background: rgba(110,118,129,.12); color: #8b949e; border: 1px solid rgba(110,118,129,.25); }

        /* ── Footer ── */
        .footer {
            border-top: 1px solid var(--border);
            padding: 20px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 11px;
            color: var(--text-dim);
            font-family: monospace;
            flex-wrap: wrap;
            gap: 8px;
        }

        @media (max-width: 600px) {
            .hero h1 { font-size: 26px; }
            .rm-target, .rm-count { display: none; }
        }
    </style>
</head>
<body>

<!-- Top bar -->
<div class="topbar">
    <a href="<?= SITE_URL ?>/index.php" class="topbar-brand">
        <div class="logo-mark">CM</div>
        <div>
            <div class="logo-text"><?= htmlspecialchars(SITE_NAME) ?></div>
            <div class="logo-sub">Manufacturing Execution System</div>
        </div>
    </a>
    <a href="<?= SITE_URL ?>/login.php" class="btn-login">
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
        Sign In
    </a>
</div>

<!-- Hero -->
<div class="hero">
    <div class="hero-badge">Discrete Manufacturing</div>
    <h1><?= htmlspecialchars(SITE_NAME) ?> — <span>Release Roadmap</span></h1>
    <p>A modern Manufacturing Execution System built for multi-org discrete manufacturing.<br>
       Track work orders, routings, quality and operator execution in one place.</p>
    <div class="hero-actions">
        <a href="<?= SITE_URL ?>/login.php" class="btn-hero-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
            Sign In to ChrisMES
        </a>
        <a href="#roadmap" class="btn-hero-secondary">View Roadmap ↓</a>
    </div>
</div>

<!-- Progress -->
<div class="progress-section">
    <div class="progress-header">
        <span class="progress-label">Overall Progress</span>
        <span class="progress-pct"><?= $delivered ?> / <?= $total ?> releases — <?= $pct ?>%</span>
    </div>
    <div class="progress-track"><div class="progress-fill"></div></div>
    <div class="progress-meta">
        <span><span class="dot dot-green"></span> Delivered (<?= $delivered ?>)</span>
        <span><span class="dot dot-grey"></span> Planned (<?= $total - $delivered ?>)</span>
    </div>
</div>

<!-- Roadmap -->
<div class="roadmap-section" id="roadmap">
    <div class="section-title">Release Schedule</div>
    <div class="roadmap-grid">
        <?php foreach ($roadmap as $r):
            $cls = match($r['status']) {
                'delivered'   => 'delivered',
                'in-progress' => 'in-progress',
                default       => 'planned',
            };
            $badge = match($r['status']) {
                'delivered'   => '<span class="badge badge-green">✓ Delivered</span>',
                'in-progress' => '<span class="badge badge-blue">In Progress</span>',
                default       => '<span class="badge badge-grey">Planned</span>',
            };
        ?>
        <div class="rm-row <?= $cls ?>">
            <span class="rm-ver">v<?= htmlspecialchars($r['release']) ?></span>
            <span class="rm-title"><?= htmlspecialchars($r['title']) ?></span>
            <span class="rm-target"><?= htmlspecialchars($r['target']) ?></span>
            <span class="rm-count"><?= $r['features'] ?> items</span>
            <?= $badge ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <span><?= htmlspecialchars(SITE_NAME) ?> v<?= SITE_VERSION ?> — AI-managed release cycle</span>
    <span><?= date('d M Y H:i T') ?></span>
</div>

</body>
</html>
