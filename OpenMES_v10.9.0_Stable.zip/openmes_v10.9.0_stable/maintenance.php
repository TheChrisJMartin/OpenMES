<?php
/**
 * maintenance.php — Maintenance Mode page
 * Version: 10.9.0
 * F077: Shown to non-IT_ADMIN users when MAINTENANCE_MODE is enabled.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/app_config.php';
loadAppConfig();

// If maintenance mode is off, redirect to dashboard
if (!defined('MAINTENANCE_MODE') || !MAINTENANCE_MODE) {
    header('Location: ' . SITE_URL . '/dashboard.php');
    exit;
}

$message = defined('MAINTENANCE_MESSAGE')
    ? MAINTENANCE_MESSAGE
    : 'System is currently undergoing maintenance. Please try again shortly.';

$theme = 'dark';
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= $theme ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance — <?= defined('SITE_NAME') ? htmlspecialchars(SITE_NAME) : 'OpenMES' ?></title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root[data-theme="dark"] {
            --bg: #0d1117; --text: #e6edf3; --text-muted: #8b949e;
            --border: #30363d; --accent: #2E75B6;
        }
        body {
            background: var(--bg); color: var(--text);
            font-family: -apple-system,'Segoe UI',system-ui,sans-serif;
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }
        .card {
            text-align: center; padding: 48px 40px; max-width: 480px;
            border: 1px solid var(--border); border-radius: 12px;
        }
        .icon { font-size: 56px; margin-bottom: 20px; }
        h1 { font-size: 24px; font-weight: 700; margin-bottom: 12px; }
        p { color: var(--text-muted); line-height: 1.6; font-size: 14px; }
        .brand {
            font-size: 12px; color: var(--text-muted);
            margin-top: 32px; padding-top: 20px;
            border-top: 1px solid var(--border);
        }
        .brand strong { color: var(--accent); }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">🔧</div>
        <h1>Under Maintenance</h1>
        <p><?= htmlspecialchars($message) ?></p>
        <div class="brand">
            <strong><?= defined('SITE_NAME') ? htmlspecialchars(SITE_NAME) : 'OpenMES' ?></strong><br>
            <?= defined('SITE_VERSION') ? 'v' . htmlspecialchars(SITE_VERSION) : '' ?>
        </div>
    </div>
</body>
</html>
