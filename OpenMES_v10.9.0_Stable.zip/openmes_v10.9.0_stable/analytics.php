<?php
/**
 * analytics.php — Manufacturing Analytics Dashboard
 * Version: 10.5.0
 * Description: Supervisor-focused analytics. Shows throughput, labour efficiency,
 *              operator utilisation, NC rate, and operation bottlenecks.
 *              Org-scoped: supervisors see their org; IT Admin selects an org.
 *              Date range: This Week (default), Today, This Month, Custom.
 *              Accessible by all personas (same access as supervisor screen).
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/helpers.php';

requireLogin();

// ── Date range ────────────────────────────────────────────────────────────────
$range    = $_GET['range'] ?? 'week';
$tz       = new DateTimeZone(SITE_TIMEZONE);
$now      = new DateTimeImmutable('now', $tz);

switch ($range) {
    case 'today':
        $dateFrom = $now->setTime(0, 0, 0)->format('Y-m-d H:i:s');
        $dateTo   = $now->setTime(23, 59, 59)->format('Y-m-d H:i:s');
        $rangeLabel = 'Today — ' . $now->format('d M Y');
        break;
    case 'month':
        $dateFrom = $now->modify('first day of this month')->setTime(0,0,0)->format('Y-m-d H:i:s');
        $dateTo   = $now->modify('last day of this month')->setTime(23,59,59)->format('Y-m-d H:i:s');
        $rangeLabel = 'This Month — ' . $now->format('F Y');
        break;
    case 'custom':
        $dateFrom = ($_GET['from'] ?? $now->modify('-6 days')->format('Y-m-d')) . ' 00:00:00';
        $dateTo   = ($_GET['to']   ?? $now->format('Y-m-d'))                    . ' 23:59:59';
        $rangeLabel = 'Custom: ' . substr($dateFrom,0,10) . ' → ' . substr($dateTo,0,10);
        break;
    default: // week
        $range    = 'week';
        $dateFrom = $now->modify('monday this week')->setTime(0,0,0)->format('Y-m-d H:i:s');
        $dateTo   = $now->modify('sunday this week')->setTime(23,59,59)->format('Y-m-d H:i:s');
        $rangeLabel = 'This Week — w/c ' . $now->modify('monday this week')->format('d M Y');
}

// ── Org scope ─────────────────────────────────────────────────────────────────
// IT Admin or multi-org users pick an org; single-org users are pinned.
$isAdmin     = hasPersona('IT_ADMIN');
$allOrgs     = $isAdmin
    ? dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code")
    : [];

$selectedOrgId = null;
if ($isAdmin) {
    $selectedOrgId = (int)($_GET['org'] ?? 0);
    if ($selectedOrgId === 0 && !empty($allOrgs)) {
        $selectedOrgId = (int)$allOrgs[0]['id']; // default to first org
    }
} else {
    $selectedOrgId = currentOrgId();
}

$selectedOrg = $selectedOrgId
    ? dbFetchOne("SELECT id,code,name FROM orgs WHERE id=?", [$selectedOrgId])
    : null;

// All queries below are scoped to $selectedOrgId
$orgParam = [$selectedOrgId];

// ── Helper: convert UTC DB timestamps to local for grouping ───────────────────
// We store in UTC; convert to site TZ for date-grouping in SQL
$tzOffset = $now->format('P'); // e.g. +01:00

// ── 1. Throughput — units completed per day in range ─────────────────────────
$throughput = dbFetchAll(
    "SELECT DATE(CONVERT_TZ(ce.clocked_off_at, '+00:00', ?)) AS day,
            COUNT(DISTINCT ce.serial_id) AS units_completed
       FROM wo_clock_events ce
       JOIN work_orders w ON w.id = ce.wo_id
      WHERE w.org_id = ?
        AND ce.event_type = 'COMPLETE'
        AND ce.clocked_off_at BETWEEN ? AND ?
      GROUP BY day
      ORDER BY day",
    [$tzOffset, $selectedOrgId, $dateFrom, $dateTo]
);

$totalCompleted = array_sum(array_column($throughput, 'units_completed'));

// ── 2. Labour efficiency — actual vs standard by op type ─────────────────────
$efficiency = dbFetchAll(
    "SELECT ro.op_type,
            COUNT(*) AS ops_completed,
            ROUND(AVG(ce.duration_mins),1) AS avg_actual_mins,
            ROUND(AVG(ro.actual_mins),1) AS avg_std_mins,
            SUM(ce.is_overrun) AS overruns
       FROM wo_clock_events ce
       JOIN routing_operations ro ON ro.id = ce.op_id
       JOIN work_orders w ON w.id = ce.wo_id
      WHERE w.org_id = ?
        AND ce.event_type = 'COMPLETE'
        AND ce.duration_mins > 0
        AND ce.clocked_off_at BETWEEN ? AND ?
      GROUP BY ro.op_type
      ORDER BY ops_completed DESC",
    [$selectedOrgId, $dateFrom, $dateTo]
);

// ── 3. Operator utilisation — hours booked per operator ──────────────────────
$utilisation = dbFetchAll(
    "SELECT u.known_as, u.username,
            COUNT(DISTINCT ce.serial_id) AS serials_worked,
            ROUND(SUM(ce.duration_mins) / 60, 1) AS hours_booked,
            SUM(ce.is_overrun) AS overruns
       FROM wo_clock_events ce
       JOIN users u ON u.id = ce.user_id
       JOIN work_orders w ON w.id = ce.wo_id
      WHERE w.org_id = ?
        AND ce.event_type IN ('COMPLETE','CLOCK_OFF')
        AND ce.duration_mins > 0
        AND ce.clocked_off_at BETWEEN ? AND ?
      GROUP BY u.id, u.known_as, u.username
      ORDER BY hours_booked DESC
      LIMIT 15",
    [$selectedOrgId, $dateFrom, $dateTo]
);

$totalHours = array_sum(array_column($utilisation, 'hours_booked'));

// ── 4. NC rate — NCs raised per 100 units completed ──────────────────────────
$ncStats = dbFetchOne(
    "SELECT COUNT(*) AS total_ncs
       FROM non_conformances nc
       JOIN work_orders w ON w.id = nc.wo_id
      WHERE w.org_id = ?
        AND nc.raised_at BETWEEN ? AND ?",
    [$selectedOrgId, $dateFrom, $dateTo]
);
$totalNcs   = (int)($ncStats['total_ncs'] ?? 0);
$ncRate     = $totalCompleted > 0 ? round(($totalNcs / $totalCompleted) * 100, 1) : 0;

// NC breakdown by status
$ncByStatus = dbFetchAll(
    "SELECT nc.status, COUNT(*) AS n
       FROM non_conformances nc
       JOIN work_orders w ON w.id = nc.wo_id
      WHERE w.org_id = ?
        AND nc.raised_at BETWEEN ? AND ?
      GROUP BY nc.status",
    [$selectedOrgId, $dateFrom, $dateTo]
);
$ncOpen = 0;
foreach ($ncByStatus as $s) {
    if (in_array($s['status'], ['OPEN','UNDER_REVIEW'])) $ncOpen += $s['n'];
}

// ── 4b. NC trend by cause category (F073) ──────────────────────────────────
$ncByCause = dbFetchAll(
    "SELECT COALESCE(nc.cause_category,'UNSPECIFIED') AS cat, COUNT(*) AS cnt
       FROM non_conformances nc
      WHERE nc.org_id=? AND nc.raised_at BETWEEN ? AND ?
      GROUP BY cat ORDER BY cnt DESC",
    [$selectedOrgId, $dateFrom, $dateTo]
);

// NC trend by day
$ncByDay = dbFetchAll(
    "SELECT DATE(nc.raised_at) AS day, COUNT(*) AS cnt
       FROM non_conformances nc
      WHERE nc.org_id=? AND nc.raised_at BETWEEN ? AND ?
      GROUP BY DATE(nc.raised_at) ORDER BY day",
    [$selectedOrgId, $dateFrom, $dateTo]
);

// ── 5. Operation bottlenecks — ops with most serials waiting ─────────────────
$bottlenecks = dbFetchAll(
    "SELECT ro.op_number, ro.op_name, ro.op_type,
            d.code AS dept_code,
            COUNT(sn.id) AS serials_waiting,
            ROUND(AVG(TIMESTAMPDIFF(MINUTE, w.created_at, NOW()) / 60), 1) AS avg_age_hrs
       FROM serial_numbers sn
       JOIN routing_operations ro ON ro.id = sn.current_op_id
       JOIN work_orders w ON w.id = sn.wo_id
       LEFT JOIN departments d ON d.id = ro.department_id
      WHERE w.org_id = ?
        AND sn.status IN ('NOT_STARTED','IN_PROGRESS')
        AND w.status IN ('OPEN','IN_PROGRESS')
      GROUP BY ro.id, ro.op_number, ro.op_name, ro.op_type, d.code
      ORDER BY serials_waiting DESC
      LIMIT 8",
    [$selectedOrgId]
);

// ── 6. First-pass yield — serials complete without any NC ────────────────────
$fpyData = dbFetchOne(
    "SELECT
        COUNT(DISTINCT sn.id) AS total_complete,
        COUNT(DISTINCT ncs.serial_id) AS had_nc
       FROM serial_numbers sn
       JOIN work_orders w ON w.id = sn.wo_id
       LEFT JOIN nc_serials ncs ON ncs.serial_id = sn.id
      WHERE w.org_id = ?
        AND sn.status = 'COMPLETE'
        AND sn.updated_at BETWEEN ? AND ?",
    [$selectedOrgId, $dateFrom, $dateTo]
);
$fpyTotal   = (int)($fpyData['total_complete'] ?? 0);
$fpyHadNc   = (int)($fpyData['had_nc'] ?? 0);
$fpyPct     = $fpyTotal > 0 ? round((($fpyTotal - $fpyHadNc) / $fpyTotal) * 100, 1) : null;

// ── 7. Live: who is clocked on right now ─────────────────────────────────────
$clockedNow = dbFetchAll(
    "SELECT ac.serial_id, u.known_as, w.wo_number, ro.op_number, ro.op_name,
            ac.clocked_on_at,
            ROUND(TIMESTAMPDIFF(MINUTE, ac.clocked_on_at, NOW()),0) AS mins_on,
            ro.actual_mins AS std_mins
       FROM wo_active_clocks ac
       JOIN users u ON u.id = ac.user_id
       JOIN work_orders w ON w.id = ac.wo_id
       JOIN routing_operations ro ON ro.id = ac.op_id
      WHERE w.org_id = ?
      ORDER BY ac.clocked_on_at",
    [$selectedOrgId]
);

$ncTrendJs = json_encode([
    'cause' => $ncByCause,
    'daily' => $ncByDay,
]);
renderPageStart('Analytics');
?>

<style>
.metric-card {
    background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);
    padding:16px 18px;display:flex;flex-direction:column;gap:4px;
}
.metric-big { font-size:32px;font-weight:800;font-family:monospace;line-height:1; }
.metric-label { font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em; }
.metric-sub { font-size:12px;color:var(--text-dim); }

.bar-row { display:flex;align-items:center;gap:10px;font-size:12px;margin-bottom:6px; }
.bar-track { flex:1;height:8px;background:var(--border);border-radius:4px;overflow:hidden; }
.bar-fill { height:100%;border-radius:4px;transition:width .4s; }

.section-title {
    font-size:13px;font-weight:700;color:var(--text-muted);
    text-transform:uppercase;letter-spacing:.07em;
    margin:20px 0 10px;padding-bottom:6px;
    border-bottom:1px solid var(--border);
}
</style>

<!-- Page header + controls -->
<div class="page-header page-header-row" style="margin-bottom:16px;">
    <div>
        <h1>Analytics</h1>
        <p><?= htmlspecialchars($selectedOrg ? $selectedOrg['code'].' — '.$selectedOrg['name'] : 'All') ?>
           &mdash; <?= htmlspecialchars($rangeLabel) ?></p>
    </div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-end;">
        <!-- Org selector (IT Admin only) -->
        <?php if ($isAdmin && count($allOrgs) > 1): ?>
        <form method="GET" style="display:flex;gap:6px;align-items:flex-end;">
            <input type="hidden" name="range" value="<?= htmlspecialchars($range) ?>">
            <?php if ($range==='custom'): ?>
            <input type="hidden" name="from" value="<?= htmlspecialchars($_GET['from']??'') ?>">
            <input type="hidden" name="to"   value="<?= htmlspecialchars($_GET['to']??'')   ?>">
            <?php endif; ?>
            <select name="org" onchange="this.form.submit()" style="font-size:12px;padding:5px 8px;">
                <?php foreach ($allOrgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $o['id']==$selectedOrgId?'selected':'' ?>>
                    <?= htmlspecialchars($o['code'].' — '.$o['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php endif; ?>

        <!-- Range picker -->
        <div style="display:flex;gap:4px;">
            <?php foreach (['today'=>'Today','week'=>'This Week','month'=>'This Month','custom'=>'Custom'] as $r=>$l): ?>
            <a href="?range=<?= $r ?>&org=<?= $selectedOrgId ?>"
               class="btn <?= $range===$r?'btn-primary':'btn-secondary' ?>"
               style="padding:5px 10px;font-size:12px;"><?= $l ?></a>
            <?php endforeach; ?>
        </div>

        <?php if ($range==='custom'): ?>
        <form method="GET" style="display:flex;gap:6px;align-items:flex-end;">
            <input type="hidden" name="range" value="custom">
            <input type="hidden" name="org" value="<?= $selectedOrgId ?>">
            <input type="date" name="from" value="<?= htmlspecialchars(substr($dateFrom,0,10)) ?>"
                   style="font-size:12px;padding:4px 6px;">
            <input type="date" name="to"   value="<?= htmlspecialchars(substr($dateTo,0,10)) ?>"
                   style="font-size:12px;padding:4px 6px;">
            <button type="submit" class="btn btn-secondary" style="font-size:12px;padding:5px 10px;">Go</button>
        </form>
        <?php endif; ?>
    </div>
</div>

<!-- ── KPI Row ── -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px;">
    <div class="metric-card">
        <div class="metric-big" style="color:var(--accent-blue);"><?= number_format($totalCompleted) ?></div>
        <div class="metric-label">Units Completed</div>
        <div class="metric-sub">ops completed in range</div>
    </div>
    <div class="metric-card">
        <div class="metric-big" style="color:#3fb950;"><?= number_format($totalHours, 1) ?></div>
        <div class="metric-label">Hours Booked</div>
        <div class="metric-sub"><?= count($utilisation) ?> operator<?= count($utilisation)!==1?'s':'' ?> active</div>
    </div>
    <div class="metric-card">
        <div class="metric-big" style="color:<?= $totalNcs>0?'var(--accent-danger)':'#3fb950' ?>;"><?= $totalNcs ?></div>
        <div class="metric-label">Non-Conformances</div>
        <div class="metric-sub"><?= $ncRate ?>% NC rate &mdash; <?= $ncOpen ?> open</div>
    </div>
    <div class="metric-card">
        <div class="metric-big" style="color:<?= ($fpyPct??100) >= 95 ? '#3fb950' : (($fpyPct??100)>=80?'var(--accent-warn)':'var(--accent-danger)') ?>;">
            <?= $fpyPct !== null ? $fpyPct.'%' : '—' ?>
        </div>
        <div class="metric-label">First-Pass Yield</div>
        <div class="metric-sub"><?= $fpyTotal ?> units complete, <?= $fpyHadNc ?> had NC</div>
    </div>
    <div class="metric-card">
        <div class="metric-big" style="color:var(--accent-blue);"><?= count($clockedNow) ?></div>
        <div class="metric-label">Currently Clocked On</div>
        <div class="metric-sub">live right now</div>
    </div>
</div>

<!-- ── Throughput chart ── -->
<div class="section-title">Daily Throughput — Units Completed</div>
<?php if (empty($throughput)): ?>
<div class="card" style="color:var(--text-dim);text-align:center;padding:28px;">No completions recorded in this period.</div>
<?php else:
    $maxThroughput = max(array_column($throughput, 'units_completed'));
?>
<div class="card" style="padding:16px 20px;">
    <?php foreach ($throughput as $t):
        $pct = $maxThroughput > 0 ? round(($t['units_completed'] / $maxThroughput) * 100) : 0;
        $dayLabel = (new DateTimeImmutable($t['day']))->format('D d M');
    ?>
    <div class="bar-row">
        <div style="width:80px;text-align:right;font-size:11px;color:var(--text-muted);flex-shrink:0;"><?= $dayLabel ?></div>
        <div class="bar-track">
            <div class="bar-fill" style="width:<?= $pct ?>%;background:var(--accent-blue);"></div>
        </div>
        <div style="width:40px;font-family:monospace;font-size:12px;font-weight:700;color:var(--accent-blue);"><?= $t['units_completed'] ?></div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">

<!-- ── Labour efficiency ── -->
<div>
    <div class="section-title">Labour Efficiency by Operation Type</div>
    <?php if (empty($efficiency)): ?>
    <div class="card" style="color:var(--text-dim);text-align:center;padding:28px;">No data in this period.</div>
    <?php else: ?>
    <div class="card" style="padding:0;overflow:hidden;">
        <table>
            <thead>
                <tr>
                    <th>Op Type</th>
                    <th>Count</th>
                    <th>Avg Actual</th>
                    <th>Avg Std</th>
                    <th>Efficiency</th>
                    <th>Overruns</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($efficiency as $e):
                $std   = (float)$e['avg_std_mins'];
                $act   = (float)$e['avg_actual_mins'];
                $eff   = ($std > 0 && $act > 0) ? round(($std / $act) * 100) : null;
                $effColour = $eff === null ? 'var(--text-dim)'
                           : ($eff >= 90 ? '#3fb950' : ($eff >= 70 ? 'var(--accent-warn)' : 'var(--accent-danger)'));
            ?>
            <tr>
                <td style="font-size:12px;"><?= htmlspecialchars(str_replace('_',' ',$e['op_type'])) ?></td>
                <td style="font-family:monospace;font-size:12px;"><?= $e['ops_completed'] ?></td>
                <td style="font-family:monospace;font-size:12px;"><?= $act ?>m</td>
                <td style="font-family:monospace;font-size:12px;color:var(--text-dim);"><?= $std > 0 ? $std.'m' : '—' ?></td>
                <td style="font-family:monospace;font-size:12px;font-weight:700;color:<?= $effColour ?>;">
                    <?= $eff !== null ? $eff.'%' : '—' ?>
                </td>
                <td style="font-size:12px;color:<?= $e['overruns']>0?'var(--accent-danger)':'var(--text-dim)' ?>;">
                    <?= $e['overruns'] > 0 ? '⚠ '.$e['overruns'] : '—' ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- ── Operation bottlenecks ── -->
<div>
    <div class="section-title">Operation Bottlenecks (Live)</div>
    <?php if (empty($bottlenecks)): ?>
    <div class="card" style="color:var(--text-dim);text-align:center;padding:28px;">No active work orders.</div>
    <?php else:
        $maxWaiting = max(array_column($bottlenecks, 'serials_waiting'));
    ?>
    <div class="card" style="padding:16px 20px;">
        <?php foreach ($bottlenecks as $b):
            $pct = $maxWaiting > 0 ? round(($b['serials_waiting'] / $maxWaiting) * 100) : 0;
            $colour = $b['serials_waiting'] >= 10 ? 'var(--accent-danger)'
                    : ($b['serials_waiting'] >= 5  ? 'var(--accent-warn)'
                    : 'var(--accent-blue)');
        ?>
        <div class="bar-row" style="margin-bottom:8px;">
            <div style="width:90px;flex-shrink:0;">
                <div style="font-size:11px;font-weight:700;font-family:monospace;">Op <?= str_pad($b['op_number'],3,'0',STR_PAD_LEFT) ?></div>
                <div style="font-size:10px;color:var(--text-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:88px;" title="<?= htmlspecialchars($b['op_name']) ?>">
                    <?= htmlspecialchars(substr($b['op_name'],0,12)) ?>
                </div>
            </div>
            <div class="bar-track">
                <div class="bar-fill" style="width:<?= $pct ?>%;background:<?= $colour ?>;"></div>
            </div>
            <div style="width:55px;font-family:monospace;font-size:12px;font-weight:700;color:<?= $colour ?>;white-space:nowrap;">
                <?= $b['serials_waiting'] ?> units
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

</div><!-- /grid -->

<!-- ── Operator utilisation ── -->
<div class="section-title">Operator Utilisation</div>
<?php if (empty($utilisation)): ?>
<div class="card" style="color:var(--text-dim);text-align:center;padding:28px;">No operator activity recorded in this period.</div>
<?php else:
    $maxHours = max(array_column($utilisation, 'hours_booked'));
?>
<div class="card" style="padding:0;overflow:hidden;">
    <table>
        <thead>
            <tr>
                <th>Operator</th>
                <th>Hours Booked</th>
                <th style="min-width:200px;">Activity</th>
                <th>Units</th>
                <th>Overruns</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($utilisation as $u):
            $pct = $maxHours > 0 ? round(($u['hours_booked'] / $maxHours) * 100) : 0;
        ?>
        <tr>
            <td>
                <div style="font-weight:600;"><?= htmlspecialchars($u['known_as']) ?></div>
                <div class="text-dim" style="font-size:11px;"><?= htmlspecialchars($u['username']) ?></div>
            </td>
            <td style="font-family:monospace;font-size:14px;font-weight:700;color:var(--accent-blue);">
                <?= number_format($u['hours_booked'],1) ?>h
            </td>
            <td>
                <div class="bar-track" style="height:10px;">
                    <div class="bar-fill" style="width:<?= $pct ?>%;background:var(--accent-blue);"></div>
                </div>
            </td>
            <td style="font-family:monospace;font-size:12px;"><?= $u['serials_worked'] ?></td>
            <td style="font-size:12px;color:<?= $u['overruns']>0?'var(--accent-danger)':'var(--text-dim)' ?>;">
                <?= $u['overruns'] > 0 ? '⚠ '.$u['overruns'] : '—' ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<!-- ── Live: currently clocked on ── -->
<div class="section-title">Currently Clocked On — Live</div>
<?php if (empty($clockedNow)): ?>
<div class="card" style="color:var(--text-dim);text-align:center;padding:20px;">No operators currently clocked on.</div>
<?php else: ?>
<div class="card" style="padding:0;overflow:hidden;">
    <table>
        <thead>
            <tr><th>Operator</th><th>Work Order</th><th>Operation</th><th>Duration</th><th>Status</th><?php if(hasPersona(['IT_ADMIN','SUPERVISOR'])): ?><th></th><?php endif; ?></tr>
        </thead>
        <tbody>
        <?php foreach ($clockedNow as $c):
            $isOverrun = $c['std_mins'] > 0 && $c['mins_on'] > $c['std_mins'];
            $h = floor($c['mins_on']/60); $m = $c['mins_on'] % 60;
            $durStr = ($h > 0 ? "{$h}h " : '') . "{$m}m";
        ?>
        <tr style="<?= $isOverrun?'background:rgba(248,81,73,.05);':'' ?>">
            <td style="font-weight:600;"><?= htmlspecialchars($c['known_as']) ?></td>
            <td><code style="color:var(--accent-blue);font-size:12px;"><?= htmlspecialchars($c['wo_number']) ?></code></td>
            <td style="font-size:12px;">
                <code><?= str_pad($c['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                <?= htmlspecialchars($c['op_name']) ?>
            </td>
            <td style="font-family:monospace;font-size:12px;
                       color:<?= $isOverrun?'var(--accent-danger)':'#3fb950' ?>;">
                <?= $durStr ?>
                <?= $isOverrun ? ' ⚠ OVERRUN' : '' ?>
            </td>
            <td><span class="badge badge-green" style="font-size:10px;">● LIVE</span></td>
            <?php if(hasPersona(['IT_ADMIN','SUPERVISOR'])): ?>
            <td>
                <button onclick="showForceClockoff(<?= (int)$c['serial_id'] ?>,'<?= htmlspecialchars(addslashes($c['known_as'])) ?>','<?= htmlspecialchars(addslashes($c['wo_number'])) ?>')"
                        class="btn btn-danger" style="font-size:10px;padding:2px 8px;">Force Off</button>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div style="margin-top:16px;text-align:right;font-size:11px;color:var(--text-dim);">
    Data as of <?= $now->format('d M Y H:i T') ?> &mdash;
    <a href="?range=<?= $range ?>&org=<?= $selectedOrgId ?>" style="color:var(--accent-blue);">Refresh</a>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
(function() {
    const T = <?= $ncTrendJs ?? '{"cause":[],"daily":[]}' ?>;
    const isDark = document.documentElement.dataset.theme === 'dark';
    const textCol = isDark ? '#8b949e' : '#595959';
    Chart.defaults.color = textCol;

    const catColors = {
        'MAN':'#58a6ff','MACHINE':'#3fb950','METHOD':'#f0ad4e',
        'MATERIAL':'#a371f7','MEASUREMENT':'#ff6b6b','ENVIRONMENT':'#79c0ff','UNSPECIFIED':'#8b949e'
    };

    // Cause category chart
    const causeEl = document.getElementById('ncCauseChart');
    if (causeEl && T.cause.length) {
        new Chart(causeEl.getContext('2d'), {
            type: 'bar',
            data: {
                labels: T.cause.map(r => r.cat),
                datasets: [{
                    label: 'NC Count',
                    data: T.cause.map(r => parseInt(r.cnt)),
                    backgroundColor: T.cause.map(r => catColors[r.cat] || '#8b949e'),
                }]
            },
            options: { responsive:true, maintainAspectRatio:true, indexAxis:'y',
                plugins:{legend:{display:false}},
                scales:{x:{beginAtZero:true,ticks:{font:{size:10}}},y:{ticks:{font:{size:10}}}} }
        });
    }

    // Daily trend chart
    const dailyEl = document.getElementById('ncDailyChart');
    if (dailyEl && T.daily.length) {
        new Chart(dailyEl.getContext('2d'), {
            type: 'line',
            data: {
                labels: T.daily.map(r => r.day),
                datasets: [{
                    label: 'NCs',
                    data: T.daily.map(r => parseInt(r.cnt)),
                    borderColor: '#ff6b6b',
                    backgroundColor: 'rgba(255,107,107,0.15)',
                    pointRadius: 4, fill: true, tension: 0.2,
                }]
            },
            options: { responsive:true, maintainAspectRatio:true,
                plugins:{legend:{display:false}},
                scales:{x:{ticks:{font:{size:10},maxRotation:45}},
                        y:{beginAtZero:true,ticks:{font:{size:10},stepSize:1}}} }
        });
    }
})();
</script>
<!-- F090: Force Clock-Off Modal -->
<div id="forceModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);
     z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:10px;
                padding:24px;max-width:420px;width:90%;">
        <h3 style="margin-bottom:12px;font-size:15px;">Force Clock-Off</h3>
        <p id="forceMsg" style="font-size:13px;color:var(--text-muted);margin-bottom:14px;"></p>
        <label style="font-size:12px;color:var(--text-muted);display:block;margin-bottom:4px;">Reason (optional)</label>
        <input type="text" id="forceReason" maxlength="500" placeholder="e.g. End of shift"
               style="width:100%;padding:8px;border:1px solid var(--border);border-radius:4px;
                      background:var(--bg);color:var(--text);margin-bottom:16px;">
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <button onclick="document.getElementById('forceModal').style.display='none'"
                    class="btn btn-secondary">Cancel</button>
            <button onclick="doForceClockoff()" class="btn btn-danger">Confirm Force Off</button>
        </div>
    </div>
</div>
<script>
let forceSerialId = null;
function showForceClockoff(sid, name, wo) {
    forceSerialId = sid;
    document.getElementById('forceMsg').textContent = 'Clock off ' + name + ' from ' + wo + '?';
    document.getElementById('forceReason').value = '';
    document.getElementById('forceModal').style.display = 'flex';
}
async function doForceClockoff() {
    if (!forceSerialId) return;
    const fd = new FormData();
    fd.append('serial_id', forceSerialId);
    fd.append('reason', document.getElementById('forceReason').value);
    fd.append('csrf_token', '<?= generateCsrfToken() ?>');
    const r = await fetch('<?= SITE_SUBPATH ?>/api/force_clockoff.php', {method:'POST',body:fd});
    const d = await r.json();
    document.getElementById('forceModal').style.display = 'none';
    if (d.ok) { alert(d.message); location.reload(); }
    else { alert('Error: ' + d.error); }
}
</script>
<?php renderPageEnd(); ?>
