<?php
// CD010/CD016: Disable error display in production
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);
ini_set('log_errors', '1');

/**
 * config.php — ChrisMES Core Configuration
 * Version: 10.0.0
 */

define('SITE_URL',     'https://chris-martin.co.uk/chrismes');
define('SITE_SUBPATH', '/chrismes');

define('DB_HOST',    'chris-martin.co.uk.mysql');
define('DB_PORT',    '3306');
define('DB_NAME',    'chris_martin_co_ukmes');
define('DB_USER',    'chris_martin_co_ukmes');
define('DB_PASS',    'CCCCCmbr03627@');
define('DB_CHARSET', 'utf8mb4');

define('TEST_MODE', true);

define('BASE_PATH',    __DIR__);
define('UPLOADS_PATH', BASE_PATH . '/uploads/documents');
define('UPLOADS_URL',  SITE_URL  . '/uploads/documents');

// SITE_VERSION removed from config.php in v10.6.1
// It is now stored in the system_config DB table and loaded by app_config.php
// The deployer updates it automatically after each deployment.
