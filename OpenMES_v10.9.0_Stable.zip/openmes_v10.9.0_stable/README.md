# OpenMES — Manufacturing Execution System

[![Version](https://img.shields.io/badge/version-10.9.0-blue)](https://github.com/TheChrisJMartin/OpenMES/releases)
[![PHP](https://img.shields.io/badge/PHP-8.0%2B-purple)](https://php.net)
[![License](https://img.shields.io/badge/license-MIT-green)](#license)

OpenMES is a web-based Manufacturing Execution System (MES) designed for discrete manufacturing. It manages the complete production lifecycle from work order creation through to booking finished goods into stock, with full traceability, quality management, and ERP integration capability.

**Live Demo:** [openmes-dev.donotpassgo.co.uk](https://openmes-dev.donotpassgo.co.uk)

---

## Features

- **Multi-organisation** support with high-walled data isolation
- **Work order execution** with serialised and lot-controlled tracking
- **Document management** with revision control and approval workflow
- **Routing management** with revision control, operation types, and document links
- **Quality variable collection** at inspection and test operations
- **IMR control charts** with Western Electric rule detection (Rules 1-8)
- **Non-conformance management** with engineer disposition workflow and 6M root cause analysis
- **Calibration database** for tools and test equipment with expiry enforcement
- **Operator skills matrix** with training approval and expiry tracking
- **Force clock-off** for supervisors and IT Admin
- **Maintenance mode** for planned downtime
- **In-app deployment manager** with SQL patch execution and schema versioning
- **GitHub auto-update check** on the dashboard
- **Automated test suite** covering 119 checks across 8 categories
- **ERP integration** via outbound message queue
- **Security hardened**: CSRF protection, session hardening, login rate limiting, security headers

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| PHP | 8.0 | 8.2+ |
| MySQL / MariaDB | 10.4 | 10.6+ |
| Web Server | Apache 2.4 | Apache 2.4 with mod_rewrite |
| PHP Extensions | PDO, PDO_MySQL, ZipArchive | + finfo, mbstring |
| Disk Space | 100MB | 500MB+ (for uploads) |

**PHP Extensions required:**
- `pdo` and `pdo_mysql` — database connectivity
- `zip` (ZipArchive) — in-app deployer
- `finfo` — PDF MIME type validation (recommended)

---

## Installation

### Fresh Install

1. **Download** the latest release zip from [GitHub Releases](https://github.com/TheChrisJMartin/OpenMES/releases)

2. **Upload** all files to your web server document root or subdirectory

3. **Create a MySQL database** and user:
   ```sql
   CREATE DATABASE openmes CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'openmes_user'@'localhost' IDENTIFIED BY 'your_password';
   GRANT ALL PRIVILEGES ON openmes.* TO 'openmes_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

4. **Run `install.php`** in your browser:
   ```
   https://yourdomain.com/install.php
   ```
   The wizard will:
   - Check system requirements
   - Test your database connection
   - Run the bootstrap SQL (complete schema + demo data)
   - Write `config.php`
   - Hash test account passwords
   - Self-delete on success

5. **Log in** with `ITADMIN1` / `ITADMIN1` (in Test Mode)

6. **Run the Test Suite**: Administration → Test Suite to verify the installation

> ⚠ **Security:** `install.php` self-deletes after successful installation. If you abandon installation, delete it manually before going live.

---

### Upgrading from a Previous Version

1. Log in as IT Admin
2. Go to **Administration → Deploy**
3. Upload the release zip
4. The deployer extracts PHP files and shows any SQL patches for review
5. Type **CONFIRM** to execute SQL patches
6. The app version and schema version update automatically

> `config.php` and `.htaccess` are never overwritten by the deployer.

---

## First-Time Setup Sequence

After installation, configure in this order:

| Step | Task | Where |
|------|------|-------|
| 1 | Disable Test Mode | Administration → System Config |
| 2 | Create Organisation | Administration → Organisations |
| 3 | Create Departments | Administration → Departments |
| 4 | Create Resources | Administration → Resources |
| 5 | Create User Accounts | Administration → Users |
| 6 | Create Units of Measure | Administration → UoM |
| 7 | Create Inventory Locations | Administration → Inventory Locations |
| 8 | Create Serial Number Registers | Administration → Serial Registers |
| 9 | Create Parts (Item Master) | Items → Parts |
| 10 | Upload Work Instructions | Documents → Work Instructions |
| 11 | Create and Approve Routings | Routings → Routing List |
| 12 | Define Quality Variables | Routings → Quality Variables tab |
| 13 | Add Tools & Test Equipment | Quality → Calibration |
| 14 | Assign Skills to Operators | Quality → Training Matrix |
| 15 | Create Work Orders | Work Orders → Create |

---

## Demo Data

The installation includes two demo organisations:

### BIKE — Bike Manufacturing
- Mountain Bike (MTB-BIKE-001) and Road Bike (ROAD-BIKE-001) assemblies
- Departments: Assembly, Inspection & QC, Packaging & Despatch
- Tools: Torque Screwdriver, Tyre Pressure Gauge, Chain Wear Indicator, Wheel Truing Stand
- Skills: Torque Setting, Wheel Building, Bike Final Inspection, Brake Setup & Test

### TEACL — Tea Club
- Tea Blend (TEA-BLEND-001) and Coffee Blend (COFFEE-BLEND-001)
- Departments: Brewing, Quality Control
- Tools: Digital Thermometer, Calibrated Silver Spoon, Digital Kitchen Scale
- Skills: Tea Brewing Level 1, Temperature Measurement, Beverage Inspection, Coffee Brewing Level 1

### Test Accounts

In Test Mode, all test accounts use their username as their password:

| Username | Role | Org |
|----------|------|-----|
| ITADMIN1 | IT Admin | All |
| SUPERVISOR1 | Supervisor | BIKE |
| OPERATOR1 | Operator | BIKE |
| TESTER1 | Tester | BIKE |
| INSPECTOR1 | Inspector | BIKE |
| FINALTESTER1 | Final Tester | BIKE |
| MFGENG1 | MFG Engineer | BIKE |
| ENGINEER1 | Engineer | BIKE |
| QUALITYENG1 | Quality Engineer | BIKE |
| TRAINMGR1 | Training Manager | BIKE |
| TRAINMGR2 | Training Manager | TEACL |

> ⚠ Disable Test Mode in Administration → System Config before going live.

---

## Configuration

`config.php` is written by `install.php` and contains database credentials and site settings. It is never overwritten by the deployer.

Key settings managed via **Administration → System Config** (stored in database):

| Setting | Default | Description |
|---------|---------|-------------|
| TEST_MODE | true | Enables username-as-password. **Disable before go-live.** |
| SITE_NAME | OpenMES | Displayed in navigation and page titles |
| SITE_TIMEZONE | Europe/London | All timestamps displayed in this timezone |
| MAINTENANCE_MODE | false | Redirects non-admin users to maintenance page |
| AUTO_APPROVE_DOCS | true | Enables Auto-Approve button on documents and routings |
| ALLOW_WO_CREATION | true | Set false when ERP masters work orders |
| PARTS_LOCKED | false | Set true when ERP masters parts |
| MAX_SERIALS_PER_WO | 100 | Maximum serial numbers per work order |
| MAX_LOT_QTY_PER_WO | 1000 | Maximum lot quantity per work order |

---

## Security

OpenMES implements the following security measures:

- **CSRF protection** on all POST forms
- **Session hardening**: Secure, HttpOnly, SameSite=Strict cookies
- **Login rate limiting**: 5 failures → 2s delay; 10 failures → 15min lockout
- **HTTP security headers**: X-Frame-Options, X-Content-Type-Options, Referrer-Policy, HSTS
- **PDF MIME verification** on upload
- **Password hashing**: bcrypt cost 12
- **File access controls**: `.htaccess` blocks direct access to config, SQL files, and uploads
- **Security log** accessible to IT Admin

---

## Roadmap

| Release | Title | Status |
|---------|-------|--------|
| R1–R12 | Foundation through ISO-9001 Review | Delivered |
| R13 | Advanced Features & Tooling Enforcement (Part 1) | Delivered |
| R14 | ISA-95/ISO-9001 Gap Closure | Planned |
| R15 | Receiving Inspection | Planned |
| R16 | Authorisation Profiles | Planned |
| R17 | Repairs / MRO Execution | Planned |
| R18 | SAML / SSO Integration | Planned |
| R19–R25 | Further releases | Planned |

Full roadmap: Administration → Roadmap within the system.

---

## ERP Integration

OpenMES supports ERP integration via the `integration_outbound` table. Outbound messages are generated automatically:

| Message Type | Trigger |
|-------------|---------|
| TimeAttendanceOUT | Operator clocks off or completes an operation |
| WorkOrderOUT | Operation completion — serial quantities per operation |

Inbound message types (skeleton): WorkOrderIN, PartItemIN, DepartmentIN, ResourceIN.

---

## Contributing

OpenMES is developed by Chris Martin. Contributions, bug reports, and feature requests are welcome via [GitHub Issues](https://github.com/TheChrisJMartin/OpenMES/issues).

---

## License

MIT License — see LICENSE file for details.

---

*OpenMES v10.9.0 — May 2026*
