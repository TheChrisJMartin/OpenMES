<?php
/**
 * db.php — ChrisMES Database Connector
 * Version: 1.0.0
 *
 * Returns a shared PDO instance. Include this file wherever a DB
 * connection is required. The connection is created once per request
 * (singleton pattern via static variable).
 *
 * Usage:
 *   require_once __DIR__ . '/db.php';
 *   $pdo = getDB();
 */

require_once __DIR__ . '/config.php';

function getDB(): PDO {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+00:00'",
            // Store all timestamps as UTC in DB; convert to SITE_TIMEZONE in PHP
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Do not expose credentials in output
            error_log('[ChrisMES] DB connection failed: ' . $e->getMessage());
            http_response_code(503);
            die(json_encode([
                'error' => 'Database unavailable. Please contact your system administrator.',
            ]));
        }
    }

    return $pdo;
}

/**
 * Helper: run a query and return all rows.
 */
function dbFetchAll(string $sql, array $params = []): array {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Helper: run a query and return one row.
 */
function dbFetchOne(string $sql, array $params = []): ?array {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Helper: execute a statement and return affected rows.
 */
function dbExecute(string $sql, array $params = []): int {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return $stmt->rowCount();
}

/**
 * Helper: execute insert and return last insert ID.
 */
function dbInsert(string $sql, array $params = []): string {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return getDB()->lastInsertId();
}
