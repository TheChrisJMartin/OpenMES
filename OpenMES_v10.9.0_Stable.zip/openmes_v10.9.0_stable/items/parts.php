<?php
/**
 * items/parts.php — Item Master (Parts)
 * Version: 2.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona(['IT_ADMIN','SUPERVISOR','MFG_ENGINEER','MFG_ENGINEER_SUP']);

// Ensure parts table exists
getDB()->exec("CREATE TABLE IF NOT EXISTS parts (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    org_id          INT UNSIGNED NOT NULL,
    part_number     VARCHAR(50)  NOT NULL,
    part_revision   INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Auto-increments on each edit',
    description     VARCHAR(200) NOT NULL,
    uom_id          INT UNSIGNED NOT NULL,
    serial_controlled TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1=serialised, 0=lot',
    make_buy        ENUM('MAKE','BUY') NOT NULL DEFAULT 'MAKE',
    shelf_life_days INT UNSIGNED          DEFAULT NULL COMMENT 'NULL = not shelf-lifed',
    active          TINYINT(1)   NOT NULL DEFAULT 1,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_part_org (org_id, part_number),
    CONSTRAINT fk_part_org FOREIGN KEY (org_id) REFERENCES orgs(id),
    CONSTRAINT fk_part_uom FOREIGN KEY (uom_id) REFERENCES uom(id)
) ENGINE=InnoDB");

$locked  = PARTS_LOCKED;
$message = '';
$error   = '';
$scope   = orgScope('p');

if (!$locked && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id          = (int)($_POST['id'] ?? 0);
        $orgId       = (int)($_POST['org_id'] ?? 0);
        $partNum     = strtoupper(trim($_POST['part_number'] ?? ''));
        $desc        = trim($_POST['description'] ?? '');
        $uomId       = (int)($_POST['uom_id'] ?? 0);
        $serialCtrl  = isset($_POST['serial_controlled']) ? 1 : 0;
        $makeBuy     = in_array($_POST['make_buy']??'', ['MAKE','BUY']) ? $_POST['make_buy'] : 'MAKE';
        $shelfLife   = $_POST['shelf_life_days'] !== '' ? (int)$_POST['shelf_life_days'] : null;
        $active      = isset($_POST['active']) ? 1 : 0;

        // Org scope enforcement
        if (!hasPersona('IT_ADMIN') && currentOrgId() && $orgId !== currentOrgId()) {
            $error = 'You can only create parts in your own organisation.';
        } elseif ($orgId === 0)   $error = 'Please select an organisation.';
        elseif ($partNum === '')   $error = 'Part number is required.';
        elseif ($desc === '')      $error = 'Description is required.';
        elseif ($uomId === 0)      $error = 'Please select a unit of measure.';

        if (!$error) {
            try {
                if ($id === 0) {
                    $newId = dbInsert(
                        "INSERT INTO parts (org_id,part_number,description,uom_id,serial_controlled,make_buy,shelf_life_days,active)
                         VALUES (?,?,?,?,?,?,?,?)",
                        [$orgId,$partNum,$desc,$uomId,$serialCtrl,$makeBuy,$shelfLife,$active]
                    );
                    writeAuditLog('PART_CREATE','part',(string)$newId,$orgId,null,null,null,null,$partNum,"Created part: {$partNum}");
                    $message = "Part '{$partNum}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM parts WHERE id=?", [$id]);
                    if ($old) {
                        // Check for actual changes
                        $changed = (
                            $old['description']      !== $desc        ||
                            (int)$old['uom_id']      !== $uomId       ||
                            (int)$old['serial_controlled'] !== $serialCtrl ||
                            $old['make_buy']         !== $makeBuy     ||
                            $old['shelf_life_days']  != $shelfLife    ||
                            (int)$old['active']      !== $active
                        );

                        $newRev = $changed ? ($old['part_revision'] + 1) : $old['part_revision'];

                        dbExecute(
                            "UPDATE parts SET description=?,uom_id=?,serial_controlled=?,make_buy=?,shelf_life_days=?,active=?,part_revision=?,updated_at=NOW() WHERE id=?",
                            [$desc,$uomId,$serialCtrl,$makeBuy,$shelfLife,$active,$newRev,$id]
                        );

                        $fields = [
                            'description'       => [$old['description'],(string)$desc],
                            'uom_id'            => [(string)$old['uom_id'],(string)$uomId],
                            'serial_controlled' => [(string)$old['serial_controlled'],(string)$serialCtrl],
                            'make_buy'          => [$old['make_buy'],$makeBuy],
                            'shelf_life_days'   => [(string)$old['shelf_life_days'],(string)$shelfLife],
                            'active'            => [(string)$old['active'],(string)$active],
                        ];
                        foreach ($fields as $f=>[$ov,$nv]) {
                            if ($ov !== $nv)
                                writeAuditLog('PART_EDIT','part',(string)$id,$old['org_id'],null,null,$f,$ov,$nv);
                        }
                        if ($changed)
                            writeAuditLog('PART_REVISION','part',(string)$id,$old['org_id'],null,null,'part_revision',(string)$old['part_revision'],(string)$newRev);

                        $message = "Part '{$partNum}' updated" . ($changed ? " (Revision {$newRev})" : " (no changes)") . ".";
                    }
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Part number '{$partNum}' already exists in this org." : 'Database error: '.$e->getMessage();
            }
        }
    }
}

$orgs    = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$uoms    = dbFetchAll("SELECT id,code,name FROM uom WHERE active=1 ORDER BY code");
$search  = trim($_GET['search'] ?? '');
$filterOrg = (int)($_GET['org'] ?? 0);

$where  = $scope['sql'];
$params = $scope['params'];
if ($filterOrg && hasPersona('IT_ADMIN')) { $where .= ' AND p.org_id=?'; $params[] = $filterOrg; }
if ($search) { $where .= ' AND (p.part_number LIKE ? OR p.description LIKE ?)'; $params[] = "%{$search}%"; $params[] = "%{$search}%"; }

$parts = dbFetchAll(
    "SELECT p.*,o.code AS org_code,u.code AS uom_code
     FROM parts p
     JOIN orgs o ON o.id=p.org_id
     JOIN uom u  ON u.id=p.uom_id
     WHERE {$where}
     ORDER BY o.code,p.part_number",
    $params
);

$editing = null;
if (isset($_GET['edit'])) {
    $editing = dbFetchOne(
        "SELECT p.* FROM parts p WHERE p.id=? AND ({$scope['sql']})",
        array_merge([(int)$_GET['edit']], $scope['params'])
    );
}

renderPageStart('Item Master — Parts');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Item Master</h1>
        <p>Parts catalogue. Part numbers are permanent once created.
        <?php if ($locked): ?> <span class="badge badge-yellow">PARTS LOCKED</span><?php endif; ?></p>
    </div>
    <?php if (!$locked && !$editing): ?><a href="?new=1" class="btn btn-primary">+ New Part</a><?php endif; ?>
</div>

<?php if ($locked): ?><div class="alert alert-warning">⚠ Part editing is disabled (PARTS_LOCKED = true in config.php). Parts are mastered by integration.</div><?php endif; ?>
<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if (!$locked && ($editing || isset($_GET['new']))): ?>
<div class="card">
    <div class="card-title"><?= $editing ? 'Edit Part — ' . htmlspecialchars($editing['part_number']) : 'New Part' ?></div>
    <?php if ($editing): ?>
    <div class="alert alert-info" style="margin-bottom:14px;">
        ℹ Any change will automatically increment the part revision (currently Rev <?= (int)$editing['part_revision'] ?>).
        Part number cannot be changed.
    </div>
    <?php endif; ?>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">

        <div style="display:grid;grid-template-columns:1fr 200px 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
                <select name="org_id" required <?= $editing ? 'disabled' : '' ?>>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o):
                        if (!hasPersona('IT_ADMIN') && $o['id'] != currentOrgId()) continue;
                    ?>
                    <option value="<?= $o['id'] ?>" <?= ($editing['org_id']??0)==$o['id']?'selected':'' ?>>
                        <?= htmlspecialchars($o['code'].' — '.$o['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php if ($editing): ?>
                <input type="hidden" name="org_id" value="<?= $editing['org_id'] ?>">
                <?php endif; ?>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Part Number <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="part_number" maxlength="50"
                       value="<?= htmlspecialchars($editing['part_number'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="BK-FRAME-001" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Unit of Measure <span style="color:var(--accent-danger)">*</span></label>
                <select name="uom_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($uoms as $u): ?>
                    <option value="<?= $u['id'] ?>" <?= ($editing['uom_id']??0)==$u['id']?'selected':'' ?>>
                        <?= htmlspecialchars($u['code'].' — '.$u['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="form-group" style="margin-top:14px;">
            <label>Description <span style="color:var(--accent-danger)">*</span></label>
            <input type="text" name="description" maxlength="200"
                   value="<?= htmlspecialchars($editing['description'] ?? '') ?>"
                   placeholder="Road Bike Frame — Aluminium 6061" required>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 200px;gap:14px;margin-top:2px;">
            <div class="form-group" style="margin:0;">
                <label>Make / Buy</label>
                <select name="make_buy">
                    <option value="MAKE" <?= ($editing['make_buy']??'MAKE')==='MAKE'?'selected':'' ?>>MAKE</option>
                    <option value="BUY"  <?= ($editing['make_buy']??'')==='BUY' ?'selected':'' ?>>BUY</option>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Shelf Life (days) — blank if none</label>
                <input type="number" name="shelf_life_days" min="1"
                       value="<?= htmlspecialchars($editing['shelf_life_days'] ?? '') ?>"
                       placeholder="Leave blank">
            </div>
            <div class="form-group" style="margin:0;padding-top:20px;">
                <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                    <input type="checkbox" name="serial_controlled" value="1"
                        <?= ($editing['serial_controlled']??0)?'checked':'' ?>>
                    Serialised (else Lot)
                </label>
            </div>
        </div>

        <div class="form-group" style="margin-top:10px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active']??1)?'checked':'' ?>> Active
            </label>
        </div>

        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save<?= $editing ? ' (will increment revision)' : '' ?></button>
            <a href="<?= SITE_SUBPATH ?>/items/parts.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Search & filter -->
<div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap;align-items:center;">
    <form method="GET" style="display:flex;gap:8px;flex:1;min-width:200px;">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
               placeholder="Search part number or description…" style="flex:1;">
        <?php if (hasPersona('IT_ADMIN')): ?>
        <select name="org" style="width:auto;">
            <option value="0">All Orgs</option>
            <?php foreach ($orgs as $o): ?>
            <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
            <?php endforeach; ?>
        </select>
        <?php endif; ?>
        <button type="submit" class="btn btn-secondary">Search</button>
        <?php if ($search || $filterOrg): ?><a href="<?= SITE_SUBPATH ?>/items/parts.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Org</th><th>Part Number</th><th>Rev</th><th>Description</th><th>UoM</th><th>Type</th><th>Control</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($parts as $p): ?>
            <tr>
                <td><code style="font-size:11px;"><?= htmlspecialchars($p['org_code']) ?></code></td>
                <td><code style="font-size:12px;font-weight:600;"><?= htmlspecialchars($p['part_number']) ?></code></td>
                <td><span class="text-dim font-mono"><?= str_pad($p['part_revision'],3,'0',STR_PAD_LEFT) ?></span></td>
                <td><?= htmlspecialchars($p['description']) ?></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($p['uom_code']) ?></code></td>
                <td><?= $p['make_buy']==='MAKE' ? '<span class="badge badge-blue">MAKE</span>' : '<span class="badge badge-grey">BUY</span>' ?></td>
                <td><?= $p['serial_controlled'] ? '<span class="badge badge-green">Serial</span>' : '<span class="badge badge-grey">Lot</span>' ?></td>
                <td><?= $p['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td>
                    <?php if (!$locked): ?>
                    <a href="?edit=<?= $p['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Edit</a>
                    <?php endif; ?>
                    <a href="<?= SITE_SUBPATH ?>/items/part_audit.php?id=<?= $p['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">History</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$parts): ?>
            <tr><td colspan="9" style="text-align:center;color:var(--text-dim);padding:24px;">
                <?= $search ? 'No parts match your search.' : 'No parts defined yet.' ?>
            </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
