<?php
/**
 * items/part_audit.php — Part Change History
 * Version: 2.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona(['IT_ADMIN','SUPERVISOR','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$partId = (int)($_GET['id'] ?? 0);
$scope  = orgScope('p');

$part = dbFetchOne(
    "SELECT p.*,o.code AS org_code,o.name AS org_name,u.code AS uom_code
     FROM parts p
     JOIN orgs o ON o.id=p.org_id
     JOIN uom u  ON u.id=p.uom_id
     WHERE p.id=? AND ({$scope['sql']})",
    array_merge([$partId], $scope['params'])
);

if (!$part) {
    http_response_code(404);
    renderPageStart('Part Not Found');
    echo '<div class="alert alert-danger">Part not found or access denied.</div>';
    echo '<a href="' . SITE_SUBPATH . '/items/parts.php" class="btn btn-secondary">← Back to Parts</a>';
    renderPageEnd();
    exit;
}

$history = dbFetchAll(
    "SELECT a.*,u.known_as FROM audit_log a
     LEFT JOIN users u ON u.id=a.user_id
     WHERE a.entity_type='part' AND a.entity_id=?
     ORDER BY a.created_at DESC",
    [(string)$partId]
);

renderPageStart('Part History — ' . $part['part_number']);
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/items/parts.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Item Master</a>
    <h1 style="margin-top:6px;"><?= htmlspecialchars($part['part_number']) ?></h1>
    <p><?= htmlspecialchars($part['description']) ?> — Revision <?= str_pad($part['part_revision'],3,'0',STR_PAD_LEFT) ?></p>
</div>

<div class="card" style="margin-bottom:16px;">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;font-size:13px;">
        <div><span class="text-dim">Org:</span> <code><?= htmlspecialchars($part['org_code']) ?></code></div>
        <div><span class="text-dim">UoM:</span> <code><?= htmlspecialchars($part['uom_code']) ?></code></div>
        <div><span class="text-dim">Make/Buy:</span> <?= $part['make_buy'] ?></div>
        <div><span class="text-dim">Control:</span> <?= $part['serial_controlled'] ? 'Serialised' : 'Lot' ?></div>
        <div><span class="text-dim">Shelf life:</span> <?= $part['shelf_life_days'] ? $part['shelf_life_days'].' days' : 'None' ?></div>
        <div><span class="text-dim">Status:</span> <?= $part['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></div>
    </div>
</div>

<div class="card">
    <div class="card-title">Change History (<?= count($history) ?> events)</div>
    <?php if ($history): ?>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Date / Time</th><th>Event</th><th>Field</th><th>Old Value</th><th>New Value</th><th>User</th></tr></thead>
            <tbody>
            <?php foreach ($history as $h): ?>
            <tr>
                <td class="font-mono" style="font-size:11px;white-space:nowrap;"><?= htmlspecialchars($h['created_at']) ?></td>
                <td><span class="badge badge-grey"><?= htmlspecialchars($h['event_type']) ?></span></td>
                <td class="font-mono" style="font-size:11px;"><?= htmlspecialchars($h['field_name'] ?? '—') ?></td>
                <td style="color:var(--text-muted);max-width:200px;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($h['old_value'] ?? '—') ?></td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($h['new_value'] ?? '—') ?></td>
                <td><?= htmlspecialchars($h['known_as'] ?? $h['username'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <p class="text-muted">No history recorded yet.</p>
    <?php endif; ?>
</div>

<?php renderPageEnd(); ?>
