<?php
/**
 * admin/security_log.php — Security Event Log
 * Version: 10.5.0
 * Description: IT Admin screen showing all security events — logins (success/fail),
 *              user/role/persona changes. Filterable by severity, event type, date.
 *              Severity: HIGH (red), MEDIUM (amber), LOW (grey).
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

// ── Filters ───────────────────────────────────────────────────────────────────
$filterSeverity = $_GET['severity'] ?? '';
$filterEvent    = $_GET['event']    ?? '';
$filterFrom     = $_GET['from']     ?? date('Y-m-d', strtotime('-7 days'));
$filterTo       = $_GET['to']       ?? date('Y-m-d');

$where  = 'occurred_at BETWEEN ? AND ?';
$params = [$filterFrom . ' 00:00:00', $filterTo . ' 23:59:59'];

if ($filterSeverity && in_array($filterSeverity, ['HIGH','MEDIUM','LOW'])) {
    $where .= ' AND severity=?'; $params[] = $filterSeverity;
}
if ($filterEvent !== '') {
    $where .= ' AND event_type LIKE ?'; $params[] = '%'.$filterEvent.'%';
}

$events = dbFetchAll(
    "SELECT sl.*, u.known_as, u.username
       FROM security_log sl
       LEFT JOIN users u ON u.id = sl.user_id
      WHERE {$where}
      ORDER BY sl.occurred_at DESC
      LIMIT 500",
    $params
);

$highCount   = count(array_filter($events, fn($e) => $e['severity']==='HIGH'));
$medCount    = count(array_filter($events, fn($e) => $e['severity']==='MEDIUM'));
$failedLogins= count(array_filter($events, fn($e) => $e['event_type']==='LOGIN_FAIL'));

renderPageStart('Security Log');
?>

<div class="page-header page-header-row">
    <div>
        <h1>🔒 Security Log</h1>
        <p>Audit trail of login attempts and privileged changes.</p>
    </div>
</div>

<!-- Summary KPIs -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">
    <?php foreach ([
        [count($events), 'Events', 'var(--accent-blue)'],
        [$highCount,     'High Severity', $highCount>0?'var(--accent-danger)':'var(--text-dim)'],
        [$medCount,      'Medium',        $medCount>0?'var(--accent-warn)':'var(--text-dim)'],
        [$failedLogins,  'Failed Logins', $failedLogins>0?'var(--accent-danger)':'var(--text-dim)'],
    ] as [$n,$l,$c]): ?>
    <div class="card" style="margin:0;text-align:center;padding:12px;">
        <div style="font-size:22px;font-weight:700;color:<?= $c ?>;font-family:monospace;"><?= $n ?></div>
        <div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:2px;"><?= $l ?></div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card" style="padding:12px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">From</label>
            <input type="date" name="from" value="<?= htmlspecialchars($filterFrom) ?>">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">To</label>
            <input type="date" name="to" value="<?= htmlspecialchars($filterTo) ?>">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Severity</label>
            <select name="severity">
                <option value="">All</option>
                <option value="HIGH"   <?= $filterSeverity==='HIGH'  ?'selected':'' ?>>High</option>
                <option value="MEDIUM" <?= $filterSeverity==='MEDIUM'?'selected':'' ?>>Medium</option>
                <option value="LOW"    <?= $filterSeverity==='LOW'   ?'selected':'' ?>>Low</option>
            </select>
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Event Type</label>
            <input type="text" name="event" value="<?= htmlspecialchars($filterEvent) ?>"
                   placeholder="e.g. LOGIN_FAIL" style="width:160px;">
        </div>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="?" class="btn btn-secondary">Clear</a>
    </form>
</div>

<div class="card" style="padding:0;overflow:hidden;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Severity</th>
                    <th>Event</th>
                    <th>User</th>
                    <th>IP Address</th>
                    <th>Description</th>
                    <th>Entity</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($events)): ?>
            <tr><td colspan="7" style="text-align:center;color:var(--text-dim);padding:32px;">No events in this period.</td></tr>
            <?php else: ?>
            <?php foreach ($events as $ev): ?>
            <tr style="<?= $ev['severity']==='HIGH'?'background:rgba(248,81,73,.04);':($ev['severity']==='MEDIUM'?'background:rgba(210,153,34,.04);':'') ?>">
                <td style="font-size:11px;white-space:nowrap;font-family:monospace;">
                    <?= htmlspecialchars(substr($ev['occurred_at'],0,16)) ?>
                </td>
                <td>
                    <?php $sc = match($ev['severity']) {
                        'HIGH'   => 'badge-red',
                        'MEDIUM' => 'badge-yellow',
                        default  => 'badge-grey',
                    }; ?>
                    <span class="badge <?= $sc ?>" style="font-size:10px;"><?= $ev['severity'] ?></span>
                </td>
                <td style="font-size:11px;font-family:monospace;white-space:nowrap;">
                    <?= htmlspecialchars($ev['event_type']) ?>
                </td>
                <td style="font-size:12px;">
                    <?php if ($ev['known_as']): ?>
                    <div style="font-weight:600;"><?= htmlspecialchars($ev['known_as']) ?></div>
                    <div class="text-dim" style="font-size:10px;"><?= htmlspecialchars($ev['username']??'') ?></div>
                    <?php elseif ($ev['username_attempted']): ?>
                    <div class="text-dim" style="font-size:11px;">Attempted: <em><?= htmlspecialchars($ev['username_attempted']) ?></em></div>
                    <?php else: ?>
                    <span class="text-dim">—</span>
                    <?php endif; ?>
                </td>
                <td style="font-size:11px;font-family:monospace;color:var(--text-muted);">
                    <?= htmlspecialchars($ev['ip_address']??'—') ?>
                </td>
                <td style="font-size:12px;max-width:280px;word-break:break-word;">
                    <?= htmlspecialchars($ev['description']??'') ?>
                </td>
                <td style="font-size:11px;color:var(--text-dim);">
                    <?php if ($ev['entity_type']): ?>
                    <code style="font-size:10px;"><?= htmlspecialchars($ev['entity_type']) ?></code>
                    <?php if ($ev['entity_id']): ?>
                    <span> #<?= $ev['entity_id'] ?></span>
                    <?php endif; ?>
                    <?php else: ?>—<?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
