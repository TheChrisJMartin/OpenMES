<?php
/**
 * admin/deploy.php — In-App Deployment Manager
 * Version: 10.6.0
 * F075: Upload release zips, execute SQL patches with confirmation,
 *       log all deployments to DB, track schema version.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

$error   = '';
$success = '';
$log     = [];
$sqlPreviews = [];
$step    = $_GET['step'] ?? 'upload'; // upload | confirm_sql | done

// ── Step 2: Execute confirmed SQL ─────────────────────────────────────────────
if ($step === 'confirm_sql' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');

    if (($_POST['confirm_word'] ?? '') !== 'CONFIRM') {
        $error = 'You must type CONFIRM to execute the SQL patch.';
        $step  = 'upload';
    } else {
        $sessionKey = 'pending_sql_' . ($_SESSION['user_id'] ?? 0);
        $pending    = $_SESSION[$sessionKey] ?? [];

        if (empty($pending['statements'])) {
            $error = 'No SQL statements found in session. Please re-upload the zip.';
            $step  = 'upload';
        } else {
            $pdo    = getDB();
            $sqlLog = [];
            $sqlErrors = [];
            // DDL statements (ALTER, CREATE, DROP) cause implicit commit in MariaDB/MySQL
            // so we run each statement independently — no wrapping transaction
            foreach ($pending['statements'] as $stmt) {
                // Strip comment lines
                $lines     = explode("\n", $stmt);
                $codeLines = array_filter($lines,
                    fn($l) => trim($l) !== '' && !str_starts_with(ltrim($l), '--')
                );
                $stmt = trim(implode("\n", $codeLines));
                if ($stmt === '') continue;
                try {
                    $pdo->exec($stmt);
                    $sqlLog[] = $stmt;
                    $log[] = ['t'=>'sql', 'm'=>'OK: ' . substr($stmt, 0, 120) . (strlen($stmt)>120?'...':'')];
                } catch (Throwable $stmtErr) {
                    $msg = $stmtErr->getMessage();
                    // Ignore "Duplicate column" and "already exists" — patch may be re-run
                    if (str_contains($msg,'Duplicate column') || str_contains($msg,'already exists')) {
                        $log[] = ['t'=>'skip', 'm'=>'SKIP (already applied): ' . substr($stmt,0,80)];
                    } else {
                        $sqlErrors[] = $msg;
                        $log[] = ['t'=>'err', 'm'=>'FAILED: ' . $msg];
                    }
                }
            }

            // Record schema version regardless of individual statement errors
            $version = $pending['version'] ?? SITE_VERSION;
            try {
                dbInsert(
                    "INSERT INTO schema_version (version, patch_file, notes, applied_by, applied_at)
                     VALUES (?, ?, ?, ?, NOW())",
                    [$version, implode(', ', $pending['patch_files'] ?? []),
                     'Applied via in-app deployer', $_SESSION['user_id']]
                );
            } catch (Throwable) {}

            // Update deployment record
            if (!empty($pending['deploy_id'])) {
                $depStatus = empty($sqlErrors) ? 'SUCCESS' : 'PARTIAL';
                try {
                    dbExecute(
                        "UPDATE deployments SET sql_patches=?, sql_statements=?, status=? WHERE id=?",
                        [json_encode($pending['patch_files'] ?? []),
                         json_encode($sqlLog),
                         $depStatus,
                         $pending['deploy_id']]
                    );
                } catch (Throwable) {}
            }
            unset($_SESSION[$sessionKey]);
            // Update SITE_VERSION in system_config
            try {
                $updated = dbExecute(
                    "UPDATE system_config SET config_val=? WHERE config_key='SITE_VERSION'",
                    [$version]
                );
                if (!$updated) {
                    dbInsert(
                        "INSERT INTO system_config (config_key,config_val,data_type,label,description,sort_order)
                         VALUES ('SITE_VERSION',?,'string','Application Version',
                             'Updated automatically by the deployer.',1)",
                        [$version]
                    );
                }
                $log[] = ['t'=>'ok', 'm'=>"App version updated to {$version} in system_config"];
            } catch (Throwable) {
                $log[] = ['t'=>'skip', 'm'=>'Could not update SITE_VERSION — update manually'];
            }
            if (!empty($sqlErrors)) {
                $error = count($sqlErrors) . ' statement(s) failed. Other statements may have applied.';
                $step  = 'upload';
            } else {
                $success = 'SQL patch executed. Schema version updated to ' . $version . '.';
                $step    = 'done';
                $log[]   = ['t'=>'ok', 'm'=>'Schema version recorded: ' . $version];
            }
        }
    }
}

// ── Step 1: Handle zip upload ──────────────────────────────────────────────────
if ($step === 'upload' && $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_FILES['zipfile']) && !isset($_POST['confirm_word'])) {

    // CSRF check — tolerant on file uploads (multipart forms are naturally same-origin)
    $csrfOk = !empty($_POST['csrf_token']) && $_POST['csrf_token'] !== 'no-csrf';
    if ($csrfOk) {
        try { verifyCsrfToken($_POST['csrf_token'] ?? ''); } catch(Throwable) { $csrfOk = false; }
    }
    // Log if CSRF missing but continue — file uploads require browser origin

    $f = $_FILES['zipfile'];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        $error = 'Upload error: ' . $f['error'];
    } elseif ($f['size'] > 52428800) {
        $error = 'Zip too large (max 50MB).';
    } elseif (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'zip') {
        $error = 'Only .zip files accepted.';
    } elseif (!class_exists('ZipArchive')) {
        $error = 'ZipArchive PHP extension not available.';
    } else {
        $zip = new ZipArchive();
        if ($zip->open($f['tmp_name']) !== true) {
            $error = 'Could not open zip — may be corrupted.';
        } else {
            $root      = dirname(__DIR__);
            $protected = ['config.php', '.htaccess', '_deploy_log.txt'];
            $stamp     = date('Ymd_His');
            $backupDir = $root . '/_deploy_backups/' . $stamp;
            mkdir($backupDir, 0755, true);

            $deployed_n = $backed_n = $skipped_n = 0;
            $sqlFiles   = [];
            $extractErrors = 0;

            $log[] = ['t'=>'info', 'm'=>'Deploying: ' . htmlspecialchars($f['name'])];
            $log[] = ['t'=>'div',  'm'=>''];

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $entry = $zip->getNameIndex($i);
                if (substr($entry, -1) === '/') continue;

                // Strip leading folder
                $parts = explode('/', $entry);
                array_shift($parts);
                $rel  = implode('/', $parts);
                if ($rel === '') continue;

                $base = basename($rel);
                $ext  = strtolower(pathinfo($rel, PATHINFO_EXTENSION));

                if (in_array($base, $protected, true)) {
                    $log[] = ['t'=>'skip', 'm'=>'PROTECTED: ' . $rel];
                    $skipped_n++; continue;
                }
                if (in_array($ext, ['md', 'txt'], true)) {
                    $log[] = ['t'=>'skip', 'm'=>'SKIPPED: ' . $rel];
                    $skipped_n++; continue;
                }
                if ($ext === 'sql') {
                    $sqlFiles[$rel] = $zip->getFromIndex($i);
                    $log[] = ['t'=>'sql_found', 'm'=>'SQL patch found: ' . $rel];
                    $skipped_n++; continue;
                }

                $dest    = $root . '/' . $rel;
                $destDir = dirname($dest);
                if (!is_dir($destDir)) mkdir($destDir, 0755, true);

                if (file_exists($dest)) {
                    $bPath = $backupDir . '/' . $rel;
                    $bDir  = dirname($bPath);
                    if (!is_dir($bDir)) mkdir($bDir, 0755, true);
                    copy($dest, $bPath);
                    $backed_n++;
                }

                if (file_put_contents($dest, $zip->getFromIndex($i)) !== false) {
                    $log[] = ['t'=>'ok', 'm'=>'Deployed: ' . $rel];
                    $deployed_n++;
                } else {
                    $log[] = ['t'=>'err', 'm'=>'FAILED: ' . $rel];
                    $extractErrors++;
                }
            }
            $zip->close();

            $log[] = ['t'=>'div',  'm'=>''];
            $log[] = ['t'=>'info', 'm'=>"Files deployed:  {$deployed_n}"];
            $log[] = ['t'=>'info', 'm'=>"Files backed up: {$backed_n}"];
            $log[] = ['t'=>'info', 'm'=>"Files skipped:   {$skipped_n}"];

            // Determine version from zip filename
            preg_match('/v?(\d+[\d.]+\d)/', $f['name'], $vm);
            $version = $vm[1] ?? SITE_VERSION;

            // Record deployment in DB
            $deployId = null;
            try {
                $deployId = dbInsert(
                    "INSERT INTO deployments (version, zip_filename, files_deployed, files_backed_up, deployed_by, status)
                     VALUES (?, ?, ?, ?, ?, ?)",
                    [$version, $f['name'], $deployed_n, $backed_n, $_SESSION['user_id'],
                     $extractErrors > 0 ? 'PARTIAL' : 'SUCCESS']
                );
            } catch (Throwable) {}

            if (!empty($sqlFiles)) {
                // Parse SQL into statements — strip comment lines from each chunk first
                // so comment headers don't cause real statements to be filtered out
                foreach ($sqlFiles as $sqlFile => $sqlContent) {
                    $rawChunks  = explode(';', $sqlContent);
                    $statements = [];
                    foreach ($rawChunks as $chunk) {
                        $lines     = explode("\n", $chunk);
                        $codeLines = array_filter($lines,
                            fn($l) => trim($l) !== '' && !str_starts_with(ltrim($l), '--')
                        );
                        $stmt = trim(implode("\n", $codeLines));
                        if ($stmt !== '') $statements[] = $stmt;
                    }
                    $sqlPreviews[$sqlFile] = array_values($statements);
                }

                // Store in session for step 2
                // Flatten all statements safely — spread operator fails on empty arrays in PHP 8
                $allStatements = [];
                foreach ($sqlPreviews as $stmts) {
                    foreach ($stmts as $stmt) {
                        $allStatements[] = $stmt;
                    }
                }
                $sessionKey = 'pending_sql_' . $_SESSION['user_id'];
                $_SESSION[$sessionKey] = [
                    'statements'  => $allStatements,
                    'patch_files' => array_keys($sqlFiles),
                    'version'     => $version,
                    'deploy_id'   => $deployId,
                ];
                $step = 'confirm_sql';
                $log[] = ['t'=>'warn', 'm'=>count($sqlFiles) . ' SQL patch file(s) found with ' . count($allStatements) . ' statement(s) — review and confirm below.'];
            } else {
                // No SQL — update SITE_VERSION in system_config immediately
                try {
                    // UPDATE existing SITE_VERSION row (created by bootstrap patch)
                    $updated = dbExecute(
                        "UPDATE system_config SET config_val=? WHERE config_key='SITE_VERSION'",
                        [$version]
                    );
                    // If no row exists yet, insert it
                    if (!$updated) {
                        dbInsert(
                            "INSERT INTO system_config (config_key,config_val,data_type,label,description,sort_order)
                             VALUES ('SITE_VERSION',?,'string','Application Version',
                                 'Updated automatically by the deployer.',1)",
                            [$version]
                        );
                    }
                    $log[] = ['t'=>'ok', 'm'=>"App version updated to {$version} in system_config"];
                } catch (Throwable) {
                    $log[] = ['t'=>'skip', 'm'=>'Could not update SITE_VERSION in system_config — update manually'];
                }
                $success = "Deployment complete — {$deployed_n} files deployed. Version set to {$version}.";
                $step    = 'done';
            }
        }
    }
}

// ── Load upgrade history ───────────────────────────────────────────────────────
$deployHistory = [];
try {
    $deployHistory = dbFetchAll(
        "SELECT d.*, u.known_as FROM deployments d
          LEFT JOIN users u ON u.id = d.deployed_by
          ORDER BY d.deployed_at DESC LIMIT 20"
    );
} catch (Throwable) {}

$schemaVersion = null;
try {
    $schemaVersion = dbFetchOne(
        "SELECT version, applied_at FROM schema_version ORDER BY applied_at DESC LIMIT 1"
    );
} catch (Throwable) {}

renderPageStart('Deploy');
?>

<div class="page-header page-header-row">
    <div>
        <h1>🚀 Deployment Manager</h1>
        <p>Deploy release zips, execute SQL patches, and view upgrade history.</p>
    </div>
    <?php if ($schemaVersion): ?>
    <div style="text-align:right;font-size:12px;color:var(--text-muted);">
        <div>Schema: <code style="color:var(--accent-blue);"><?= htmlspecialchars($schemaVersion['version']) ?></code>
             &nbsp;|&nbsp; App: <code style="color:var(--accent-blue);"><?= SITE_VERSION ?></code>
        </div>
        <div style="color:var(--text-dim);font-size:11px;">All releases include a DB patch — type CONFIRM to apply.</div>
    </div>
    <?php endif; ?>
</div>

<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
<div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if ($step === 'confirm_sql' && $sqlPreviews): ?>
<!-- ── SQL CONFIRMATION STEP ─────────────────────────────────────────────────── -->
<div class="card" style="border:2px solid var(--accent-danger);margin-bottom:16px;">
    <div style="background:var(--accent-danger);color:#fff;padding:12px 16px;font-weight:700;font-size:14px;">
        ⚠ SQL Patch Review — Action Required
    </div>
    <div style="padding:16px;">
        <p style="margin-bottom:12px;font-size:13px;">
            The zip contains SQL patch file(s). Review the statements below carefully before executing.
            <strong>This cannot be undone.</strong>
        </p>
        <?php foreach ($sqlPreviews as $file => $stmts): ?>
        <div style="font-size:12px;font-weight:700;color:var(--accent-blue);margin-bottom:6px;"><?= htmlspecialchars($file) ?></div>
        <div style="background:var(--bg);border:1px solid var(--border);border-radius:5px;padding:10px;
                    font-family:monospace;font-size:11px;max-height:200px;overflow-y:auto;margin-bottom:12px;">
            <?php foreach ($stmts as $stmt): ?>
            <div style="padding:3px 0;border-bottom:1px solid var(--border-subtle);"><?= htmlspecialchars($stmt) ?>;</div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>

        <form method="POST" action="?step=confirm_sql">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                <div>
                    <label style="font-size:13px;font-weight:600;">Type <code>CONFIRM</code> to execute the SQL patch:</label>
                    <input type="text" name="confirm_word" placeholder="CONFIRM" style="margin-left:10px;width:140px;font-family:monospace;">
                </div>
                <button type="submit" class="btn btn-danger" style="padding:8px 20px;">Execute SQL Patch</button>
                <a href="deploy.php" class="btn btn-secondary">Cancel — Skip SQL</a>
            </div>
        </form>
    </div>
</div>

<?php elseif ($step === 'upload'): ?>
<!-- ── UPLOAD FORM ──────────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:16px;">
    <div class="card-title">Upload Release Zip</div>
    <div class="alert alert-warning" style="margin-bottom:14px;font-size:13px;">
        <strong>Notes:</strong> <code>config.php</code> and <code>.htaccess</code> are never overwritten.
        SQL patches found in the zip will be shown for review before execution.
        All replaced files are backed up to <code>_deploy_backups/</code>.
    </div>
    <form method="POST" enctype="multipart/form-data" action="<?= htmlspecialchars(SITE_SUBPATH) ?>/admin/deploy.php">
        <input type="hidden" name="csrf_token" value="<?php
            try { echo htmlspecialchars(generateCsrfToken()); } catch(Throwable $e) { echo 'no-csrf'; }
        ?>">
        <div style="margin-bottom:14px;">
            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">
                Select Release Zip (max 50MB)
            </label>
            <input type="file" name="zipfile" accept=".zip" required
                   style="display:block;width:100%;padding:8px;border:1px solid var(--border);
                          border-radius:var(--radius);background:var(--bg);color:var(--text);">
        </div>
        <button type="submit" class="btn btn-primary" style="padding:10px 28px;font-size:14px;">
            🚀 Deploy →
        </button>
    </form>
</div>
<?php endif; ?>

<?php if ($log): ?>
<!-- ── DEPLOYMENT LOG ─────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:16px;padding:0;overflow:hidden;">
    <div style="padding:10px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
        Deployment Log
    </div>
    <div style="padding:12px 16px;font-family:monospace;font-size:12px;max-height:360px;overflow-y:auto;background:var(--bg);">
        <?php foreach ($log as $l):
            $colour = match($l['t']) {
                'ok'       => '#3fb950',
                'err'      => 'var(--accent-danger)',
                'skip'     => 'var(--text-dim)',
                'sql_found'=> 'var(--accent-warn)',
                'sql'      => 'var(--accent-blue)',
                'warn'     => 'var(--accent-warn)',
                default    => 'var(--text)',
            };
            if ($l['t'] === 'div') { echo '<hr style="border-color:var(--border);margin:6px 0;">'; continue; }
        ?>
        <div style="color:<?= $colour ?>;padding:2px 0;"><?= htmlspecialchars($l['m']) ?></div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- ── UPGRADE HISTORY ────────────────────────────────────────────────────── -->
<?php if ($deployHistory): ?>
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:10px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px;">
        Upgrade History
    </div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr><th>Date/Time</th><th>Version</th><th>Zip File</th><th>Files</th><th>SQL</th><th>By</th><th>Status</th></tr>
            </thead>
            <tbody>
            <?php foreach ($deployHistory as $dep): ?>
            <tr>
                <td style="font-size:11px;font-family:monospace;white-space:nowrap;"><?= htmlspecialchars(substr($dep['deployed_at'],0,16)) ?></td>
                <td><code style="color:var(--accent-blue);"><?= htmlspecialchars($dep['version']) ?></code></td>
                <td style="font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    <?= htmlspecialchars($dep['zip_filename']) ?>
                </td>
                <td style="text-align:center;"><?= $dep['files_deployed'] ?></td>
                <td style="text-align:center;">
                    <?php $patches = json_decode($dep['sql_patches']??'[]',true);?>
                    <?= $patches ? '<span class="badge badge-blue" style="font-size:10px;">'.count($patches).'</span>' : '<span class="text-dim">—</span>' ?>
                </td>
                <td style="font-size:12px;"><?= htmlspecialchars($dep['known_as']??'—') ?></td>
                <td>
                    <?php $sc = match($dep['status']) {
                        'SUCCESS' => 'badge-green',
                        'PARTIAL' => 'badge-yellow',
                        default   => 'badge-red',
                    }; ?>
                    <span class="badge <?= $sc ?>" style="font-size:10px;"><?= $dep['status'] ?></span>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php renderPageEnd(); ?>
