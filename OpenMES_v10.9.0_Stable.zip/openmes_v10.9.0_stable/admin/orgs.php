<?php
/**
 * admin/orgs.php — Organisation Management
 * Version: 10.5.0
 * Added: Copy org (with parts, depts, resources, routings)
 * S-95: Org maps to Enterprise/Site level in ISA-95 hierarchy
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

$locked  = ORGS_LOCKED;
$message = '';
$error   = '';

// ── Handle POST ───────────────────────────────────────────────────────────────
if (!$locked && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── Save (create/edit) ────────────────────────────────────────────────────
    if ($action === 'save') {
        $id      = (int)($_POST['id'] ?? 0);
        $code    = strtoupper(trim($_POST['code'] ?? ''));
        $name    = trim($_POST['name'] ?? '');
        $orgType = in_array($_POST['org_type']??'', ['OE','MRO']) ? $_POST['org_type'] : 'OE';
        $active  = isset($_POST['active']) ? 1 : 0;

        if (strlen($code) < 2 || strlen($code) > 5)    $error = 'Org code must be 2–5 characters.';
        elseif (!preg_match('/^[A-Z0-9]+$/', $code))    $error = 'Org code must be uppercase letters and numbers only.';
        elseif ($name === '')                            $error = 'Org name is required.';
        else {
            try {
                if ($id === 0) {
                    $newId = dbInsert("INSERT INTO orgs (code,name,org_type,active) VALUES (?,?,?,?)", [$code,$name,$orgType,$active]);
                    writeAuditLog('ORG_CREATE','org',(string)$newId,null,null,null,null,null,$code,"Created org: {$code} type={$orgType}");
                    $message = "Organisation '{$code}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM orgs WHERE id=?", [$id]);
                    if ($old) {
                        dbExecute("UPDATE orgs SET name=?,org_type=?,active=?,updated_at=NOW() WHERE id=?",[$name,$orgType,$active,$id]);
                        if ($old['name']!==$name)
                            writeAuditLog('ORG_EDIT','org',(string)$id,null,null,null,'name',$old['name'],$name);
                        if (($old['org_type']??'OE')!==$orgType)
                            writeAuditLog('ORG_EDIT','org',(string)$id,null,null,null,'org_type',$old['org_type']??'OE',$orgType);
                        if ((int)$old['active']!==$active)
                            writeAuditLog('ORG_EDIT','org',(string)$id,null,null,null,'active',(string)$old['active'],(string)$active);
                        $message = "Organisation '{$code}' updated.";
                    }
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Code '{$code}' already exists." : 'Database error: '.$e->getMessage();
            }
        }
    }

    // ── Copy org ──────────────────────────────────────────────────────────────
    if ($action === 'copy') {
        $sourceId   = (int)($_POST['source_id'] ?? 0);
        $newCode    = strtoupper(trim($_POST['new_code'] ?? ''));
        $newName    = trim($_POST['new_name'] ?? '');
        $copyParts  = isset($_POST['copy_parts']);
        $copyDepts  = isset($_POST['copy_depts']);  // depts always copied with resources
        $copyRoutings = isset($_POST['copy_routings']);

        $source = dbFetchOne("SELECT * FROM orgs WHERE id=? AND is_admin=0", [$sourceId]);
        if (!$source) { $error = 'Source organisation not found.'; }
        elseif (strlen($newCode)<2||strlen($newCode)>5) { $error = 'New code must be 2–5 characters.'; }
        elseif (!preg_match('/^[A-Z0-9]+$/',$newCode)) { $error = 'New code must be uppercase letters/numbers only.'; }
        elseif ($newName==='') { $error = 'New org name is required.'; }
        else {
            $pdo = getDB();
            $pdo->beginTransaction();
            try {
                // 1. Create new org
                $newOrgId = dbInsert("INSERT INTO orgs (code,name,org_type,active) VALUES (?,?,?,1)",[$newCode,$newName,$source['org_type']??'OE']);
                writeAuditLog('ORG_COPY','org',(string)$newOrgId,null,null,null,null,(string)$sourceId,
                    $newCode,"Copied from org {$source['code']} ({$sourceId})");

                // 2. Copy departments
                $deptMap = []; // old dept id => new dept id
                $depts   = dbFetchAll("SELECT * FROM departments WHERE org_id=? ORDER BY id",[$sourceId]);
                foreach ($depts as $d) {
                    $newDeptId = dbInsert(
                        "INSERT INTO departments (org_id,code,name,active) VALUES (?,?,?,?)",
                        [$newOrgId,$d['code'],$d['name'],$d['active']]
                    );
                    $deptMap[$d['id']] = $newDeptId;
                }

                // 3. Copy resources (workstations)
                $resMap = [];
                $resources = dbFetchAll("SELECT * FROM resources WHERE org_id=? ORDER BY id",[$sourceId]);
                foreach ($resources as $r) {
                    $newDeptId = $deptMap[$r['department_id']] ?? null;
                    if (!$newDeptId) continue;
                    $newResId = dbInsert(
                        "INSERT INTO resources (org_id,department_id,code,name,active) VALUES (?,?,?,?,?)",
                        [$newOrgId,$newDeptId,$r['code'],$r['name'],$r['active']]
                    );
                    $resMap[$r['id']] = $newResId;
                }

                // 4. Copy parts (if selected)
                $partMap = [];
                if ($copyParts) {
                    $parts = dbFetchAll("SELECT * FROM parts WHERE org_id=? ORDER BY id",[$sourceId]);
                    foreach ($parts as $p) {
                        $newPartId = dbInsert(
                            "INSERT INTO parts (org_id,part_number,part_revision,description,uom_id,serial_controlled,make_buy,shelf_life_days,active)
                             VALUES (?,?,?,?,?,?,?,?,?)",
                            [$newOrgId,$p['part_number'],$p['part_revision'],$p['description'],
                             $p['uom_id'],$p['serial_controlled'],$p['make_buy'],$p['shelf_life_days'],$p['active']]
                        );
                        $partMap[$p['id']] = $newPartId;
                        writeAuditLog('PART_CREATE','part',(string)$newPartId,$newOrgId,null,null,null,null,
                            $p['part_number'],"Copied from org {$source['code']}");
                    }
                }

                // 5. Copy routings and their operations (if selected and parts copied)
                if ($copyRoutings && $copyParts) {
                    $routings = dbFetchAll(
                        "SELECT * FROM routings WHERE org_id=? ORDER BY routing_group_id,revision",
                        [$sourceId]
                    );
                    $routingGroupMap = [];
                    foreach ($routings as $rt) {
                        $newPartId = $partMap[$rt['part_id']] ?? null;
                        if (!$newPartId) continue;

                        // New group UUID per source group
                        if (!isset($routingGroupMap[$rt['routing_group_id']])) {
                            $routingGroupMap[$rt['routing_group_id']] = sprintf(
                                '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                mt_rand(0,0xffff),mt_rand(0,0xffff),mt_rand(0,0xffff),
                                mt_rand(0,0x0fff)|0x4000,mt_rand(0,0x3fff)|0x8000,
                                mt_rand(0,0xffff),mt_rand(0,0xffff),mt_rand(0,0xffff)
                            );
                        }
                        $newGroupId = $routingGroupMap[$rt['routing_group_id']];
                        $newRoutingNumber = $newCode . '-' . dbFetchOne(
                            "SELECT part_number FROM parts WHERE id=?",[$newPartId]
                        )['part_number'];

                        $newRtId = dbInsert(
                            "INSERT INTO routings
                                (org_id,part_id,routing_group_id,routing_number,revision,revision_label,
                                 status,uploaded_by,approved_by,approved_at,auto_approved,last_edited_by,last_edited_at)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
                            [$newOrgId,$newPartId,$newGroupId,$newRoutingNumber,
                             $rt['revision'],$rt['revision_label'],$rt['status'],
                             $_SESSION['user_id'],
                             $rt['approved_by']?$_SESSION['user_id']:null,
                             $rt['approved_at'],
                             $rt['auto_approved'],
                             $_SESSION['user_id']]
                        );

                        // Copy operations — remap dept/resource; documents linked to APPROVED docs kept
                        $ops = dbFetchAll(
                            "SELECT * FROM routing_operations WHERE routing_id=? ORDER BY sort_order",
                            [$rt['id']]
                        );
                        foreach ($ops as $op) {
                            $newDeptId2 = ($op['department_id'] && isset($deptMap[$op['department_id']]))
                                ? $deptMap[$op['department_id']] : null;
                            $newResId2  = ($op['resource_id'] && isset($resMap[$op['resource_id']]))
                                ? $resMap[$op['resource_id']] : null;
                            // Keep document if still APPROVED (cross-org docs not copied — set null)
                            $docId = null;
                            dbInsert(
                                "INSERT INTO routing_operations
                                    (routing_id,op_number,behaviour,op_name,op_type,
                                     department_id,resource_id,document_id,
                                     setup_mins,actual_mins,sort_order)
                                 VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                                [$newRtId,$op['op_number'],$op['behaviour'],$op['op_name'],$op['op_type'],
                                 $newDeptId2,$newResId2,$docId,
                                 $op['setup_mins'],$op['actual_mins'],$op['sort_order']]
                            );
                        }

                        writeAuditLog('ROUTING_CREATE','routing',(string)$newRtId,$newOrgId,null,null,null,null,
                            $newRoutingNumber,"Copied from org {$source['code']}");
                    }
                }

                $pdo->commit();
                $counts = [];
                $counts[] = count($deptMap) . ' departments';
                $counts[] = count($resMap)  . ' resources';
                if ($copyParts)    $counts[] = count($partMap)  . ' parts';
                if ($copyRoutings && $copyParts) $counts[] = 'routings';
                $message = "Organisation '{$newCode}' created as a copy of '{$source['code']}'. Copied: " . implode(', ', $counts) . '.';

            } catch (Throwable $e) {
                $pdo->rollBack();
                $error = 'Copy failed: ' . $e->getMessage();
            }
        }
    }
}

// ── Fetch data ────────────────────────────────────────────────────────────────
$orgs = dbFetchAll("SELECT * FROM orgs ORDER BY is_admin DESC, code ASC");
$editing   = isset($_GET['edit']) ? dbFetchOne("SELECT * FROM orgs WHERE id=?", [(int)$_GET['edit']]) : null;
$showCopy  = isset($_GET['copy']);
$copySource = $showCopy && isset($_GET['src'])
    ? dbFetchOne("SELECT * FROM orgs WHERE id=? AND is_admin=0", [(int)$_GET['src']])
    : null;

renderPageStart('Organisations');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Organisations</h1>
        <p>ISA-95 Level: Enterprise / Site. Org code is permanent once created.</p>
    </div>
    <?php if (!$locked && !$editing && !$showCopy): ?>
    <a href="?new=1" class="btn btn-primary">+ New Organisation</a>
    <?php endif; ?>
</div>

<?php if ($locked): ?><div class="alert alert-warning">⚠ Organisation editing is disabled (ORGS_LOCKED).</div><?php endif; ?>
<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Create / Edit form -->
<?php if (!$locked && ($editing || isset($_GET['new']))): ?>
<div class="card" style="max-width:540px;">
    <div class="card-title"><?= $editing ? 'Edit Organisation' : 'New Organisation' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">
        <div style="display:grid;grid-template-columns:120px 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="code" maxlength="5"
                       value="<?= htmlspecialchars($editing['code'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="BIKE" required>
                <div class="text-dim" style="margin-top:3px;">Max 5 chars</div>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="name" maxlength="120"
                       value="<?= htmlspecialchars($editing['name'] ?? '') ?>"
                       placeholder="Bike Manufacturing Co." required>
            </div>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label>Organisation Type <span style="color:var(--accent-danger)">*</span></label>
            <?php if ($editing && isset($editing['id']) && $editing['id']): ?>
                <!-- D004: Org type cannot be changed after creation -->
                <input type="hidden" name="org_type" value="<?= htmlspecialchars($editing['org_type']??'OE') ?>">
                <div style="padding:8px 10px;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);
                            font-size:13px;color:var(--text-muted);display:flex;align-items:center;gap:8px;">
                    <span><?= ($editing['org_type']??'OE') === 'MRO' ? 'MRO — Maintenance, Repair & Overhaul' : 'OE — Original Equipment Manufacturing' ?></span>
                    <span class="badge badge-grey" style="font-size:10px;">🔒 Cannot change after creation</span>
                </div>
            <?php else: ?>
                <select name="org_type">
                    <option value="OE"  <?= ($editing['org_type']??'OE')==='OE' ?'selected':'' ?>>OE — Original Equipment Manufacturing</option>
                    <option value="MRO" <?= ($editing['org_type']??'OE')==='MRO'?'selected':'' ?>>MRO — Maintenance, Repair &amp; Overhaul</option>
                </select>
                <div class="text-dim" style="font-size:11px;margin-top:3px;">OE for standard production; MRO for repair/service work (R14)</div>
            <?php endif; ?>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active']??1)?'checked':'' ?>>
                Active
            </label>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= SITE_SUBPATH ?>/admin/orgs.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Copy org form -->
<?php if (!$locked && $showCopy): ?>
<div class="card" style="max-width:620px;">
    <div class="card-title">Copy Organisation — <?= $copySource ? htmlspecialchars($copySource['code'].' — '.$copySource['name']) : 'Select source' ?></div>

    <?php if (!$copySource): ?>
    <div class="form-group">
        <label>Select Organisation to Copy</label>
        <select onchange="window.location='?copy=1&src='+this.value" style="width:auto;">
            <option value="">— Select —</option>
            <?php foreach ($orgs as $o): if ($o['is_admin']) continue; ?>
            <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['code'].' — '.$o['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php else: ?>
    <div class="alert alert-info" style="margin-bottom:16px;font-size:13px;">
        This will create a new organisation and copy the selected elements.
        Departments and workstations are always copied.
        Documents are <strong>not</strong> copied — work instructions must be re-uploaded for the new org.
    </div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="copy">
        <input type="hidden" name="source_id" value="<?= $copySource['id'] ?>">
        <div style="display:grid;grid-template-columns:120px 1fr;gap:14px;margin-bottom:14px;">
            <div class="form-group" style="margin:0;">
                <label>New Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="new_code" maxlength="5" placeholder="BIKE2" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>New Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="new_name" maxlength="120" placeholder="Bike Manufacturing Co. — Site 2" required>
            </div>
        </div>
        <div style="display:flex;gap:20px;margin-bottom:16px;flex-wrap:wrap;">
            <label style="display:flex;align-items:center;gap:7px;font-size:13px;">
                <input type="checkbox" name="copy_depts" value="1" checked disabled>
                Departments &amp; Workstations <span class="text-dim">(always)</span>
            </label>
            <label style="display:flex;align-items:center;gap:7px;font-size:13px;">
                <input type="checkbox" name="copy_parts" value="1" checked>
                Parts (Item Master)
            </label>
            <label style="display:flex;align-items:center;gap:7px;font-size:13px;" id="copy_routings_wrap">
                <input type="checkbox" name="copy_routings" value="1" checked>
                Routings (requires Parts)
            </label>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary"
                    onclick="return confirm('Copy organisation <?= htmlspecialchars($copySource['code']) ?> to new org? This cannot be undone.')">
                Copy Organisation
            </button>
            <a href="<?= SITE_SUBPATH ?>/admin/orgs.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Org list -->
<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Code</th><th>Name</th><th>Type</th><th>Status</th><th>Depts</th><th>Parts</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($orgs as $org):
                $deptCount = dbFetchOne("SELECT COUNT(*) AS n FROM departments WHERE org_id=?",[$org['id']])['n'] ?? 0;
                try { $partCount = dbFetchOne("SELECT COUNT(*) AS n FROM parts WHERE org_id=?",[$org['id']])['n'] ?? 0; }
                catch (Throwable) { $partCount = 0; }
            ?>
            <tr>
                <td><code style="font-size:12px;"><?= htmlspecialchars($org['code']) ?></code></td>
                <td><?= htmlspecialchars($org['name']) ?></td>
                <td><?= $org['is_admin']
                    ? '<span class="badge badge-blue">Admin</span>'
                    : '<span class="badge badge-grey">Business</span>' ?>
                    <?php if (!$org['is_admin']): ?>
                    <span class="badge <?= ($org['org_type']??'OE')==='MRO'?'badge-yellow':'badge-blue' ?>"
                          style="font-size:9px;margin-left:2px;">
                        <?= htmlspecialchars($org['org_type']??'OE') ?>
                    </span>
                    <?php endif; ?>
                </td>
                <td><?= $org['active']
                    ? '<span class="badge badge-green">Active</span>'
                    : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td class="text-muted"><?= $deptCount ?></td>
                <td class="text-muted"><?= $partCount ?></td>
                <td style="white-space:nowrap;">
                    <?php if (!$locked && !$org['is_admin']): ?>
                    <a href="?edit=<?= $org['id'] ?>" class="btn btn-secondary" style="padding:4px 9px;font-size:12px;">Edit</a>
                    <a href="?copy=1&src=<?= $org['id'] ?>" class="btn btn-secondary" style="padding:4px 9px;font-size:12px;">Copy</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
