<?php
/**
 * admin/integration.php — Integration Message Log Viewer
 * Version: 7.0.0
 * Outbound and inbound ERP integration message viewer for IT Admin
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

$direction   = $_GET['dir']    ?? 'outbound';
$filterType  = $_GET['type']   ?? '';
$filterOrg   = (int)($_GET['org'] ?? 0);
$filterFrom  = $_GET['from']   ?? '';
$filterTo    = $_GET['to']     ?? '';
$filterPaused= isset($_GET['paused']);
$filterError = isset($_GET['error']);
$page        = max(1, (int)($_GET['page'] ?? 1));
$perPage     = 50;
$message     = '';
$error       = '';

$table = $direction === 'inbound' ? 'integration_inbound' : 'integration_outbound';

// Handle pause/retry POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $msgId  = (int)($_POST['msg_id'] ?? 0);

    if ($action === 'pause' && $msgId) {
        dbExecute("UPDATE {$table} SET paused=1 WHERE id=?", [$msgId]);
        $message = 'Message paused.';
    } elseif ($action === 'resume' && $msgId) {
        dbExecute("UPDATE {$table} SET paused=0 WHERE id=?", [$msgId]);
        $message = 'Message resumed.';
    } elseif ($action === 'clear_error' && $msgId) {
        dbExecute("UPDATE {$table} SET error_code=NULL, error_detail=NULL WHERE id=?", [$msgId]);
        $message = 'Error cleared — message will be retried.';
    } elseif ($action === 'pause_all') {
        dbExecute("UPDATE {$table} SET paused=1 WHERE processed_at IS NULL AND paused=0");
        $message = 'All pending messages paused.';
    } elseif ($action === 'resume_all') {
        dbExecute("UPDATE {$table} SET paused=0 WHERE paused=1");
        $message = 'All paused messages resumed.';
    }
}

// Build query
$where  = '1=1';
$params = [];

if ($filterType) { $where .= ' AND message_type=?'; $params[] = $filterType; }
if ($filterOrg)  { $where .= ' AND org_id=?'; $params[] = $filterOrg; }
if ($filterFrom) { $where .= ' AND placed_at >= ?'; $params[] = $filterFrom . ' 00:00:00'; }
if ($filterTo)   { $where .= ' AND placed_at <= ?'; $params[] = $filterTo   . ' 23:59:59'; }
if ($filterPaused) { $where .= ' AND paused=1'; }
if ($filterError)  { $where .= ' AND error_code IS NOT NULL'; }

$total = dbFetchOne("SELECT COUNT(*) AS n FROM {$table} WHERE {$where}", $params)['n'] ?? 0;
$pages = max(1, ceil($total / $perPage));
$offset= ($page - 1) * $perPage;

$messages = dbFetchAll(
    "SELECT t.*, o.code AS org_code
     FROM {$table} t
     LEFT JOIN orgs o ON o.id=t.org_id
     WHERE {$where}
     ORDER BY t.placed_at DESC
     LIMIT {$perPage} OFFSET {$offset}",
    $params
);

// Stats
$stats = dbFetchAll(
    "SELECT message_type,
            COUNT(*) AS total,
            SUM(processed_at IS NOT NULL) AS processed,
            SUM(paused=1) AS paused,
            SUM(error_code IS NOT NULL) AS errors
     FROM {$table}
     GROUP BY message_type ORDER BY total DESC"
);

$orgs = dbFetchAll("SELECT id,code FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");

// Message types per direction
$outboundTypes = ['TimeAttendanceOUT','WorkOrderMoveOUT','RoutingOUT'];
$inboundTypes  = ['WorkOrderIN','PartItemIN','DepartmentIN','ResourceIN','WorkOrderMoveIN'];
$msgTypes = $direction === 'inbound' ? $inboundTypes : $outboundTypes;

// Viewing a single message payload
$viewId  = (int)($_GET['view'] ?? 0);
$viewMsg = $viewId ? dbFetchOne("SELECT * FROM {$table} WHERE id=?", [$viewId]) : null;

renderPageStart('Integration Log');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Integration Message Log</h1>
        <p>ERP integration outbound and inbound message viewer. IT Admin only.</p>
    </div>
    <div style="display:flex;gap:6px;">
        <a href="?dir=outbound" class="btn <?= $direction==='outbound'?'btn-primary':'btn-secondary' ?>">Outbound</a>
        <a href="?dir=inbound"  class="btn <?= $direction==='inbound' ?'btn-primary':'btn-secondary' ?>">Inbound</a>
    </div>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Payload viewer modal -->
<?php if ($viewMsg): ?>
<div class="card" style="border-color:var(--accent-blue);margin-bottom:14px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <div>
            <span class="badge badge-blue"><?= htmlspecialchars($viewMsg['message_type']) ?></span>
            <code style="font-size:11px;margin-left:8px;"><?= htmlspecialchars($viewMsg['transaction_ref']) ?></code>
        </div>
        <a href="?dir=<?= $direction ?>" class="btn btn-secondary" style="padding:3px 10px;font-size:12px;">✕ Close</a>
    </div>
    <pre style="background:var(--bg);border:1px solid var(--border);border-radius:5px;padding:12px;
                font-size:12px;overflow-x:auto;white-space:pre-wrap;max-height:400px;overflow-y:auto;"><?php
        $raw = $viewMsg['payload'];
        $decoded = json_decode($raw, true);
        echo htmlspecialchars($decoded ? json_encode($decoded, JSON_PRETTY_PRINT) : $raw);
    ?></pre>
    <?php if ($viewMsg['error_detail']): ?>
    <div class="alert alert-danger" style="margin-top:10px;font-size:12px;">
        <strong>Error <?= htmlspecialchars($viewMsg['error_code']) ?>:</strong>
        <?= htmlspecialchars($viewMsg['error_detail']) ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Stats row -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:14px;">
    <?php foreach ($stats as $s): ?>
    <div class="card" style="margin:0;padding:12px;">
        <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;margin-bottom:6px;">
            <?= htmlspecialchars($s['message_type']) ?>
        </div>
        <div style="display:flex;gap:10px;font-size:12px;">
            <span><strong><?= $s['total'] ?></strong> total</span>
            <span style="color:#3fb950;"><?= $s['processed'] ?> done</span>
            <?php if ($s['errors']): ?><span style="color:var(--accent-danger);">⚠ <?= $s['errors'] ?> errors</span><?php endif; ?>
            <?php if ($s['paused']): ?><span style="color:var(--accent-warn);">⏸ <?= $s['paused'] ?> paused</span><?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    <?php if (!$stats): ?>
    <div class="card" style="margin:0;padding:12px;color:var(--text-dim);font-size:13px;">No messages yet.</div>
    <?php endif; ?>
</div>

<!-- Bulk actions -->
<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;align-items:center;">
    <form method="POST" style="display:flex;gap:6px;">
        <input type="hidden" name="action" value="pause_all">
        <button type="submit" class="btn btn-secondary" style="font-size:12px;padding:5px 12px;"
                onclick="return confirm('Pause all pending messages?')">⏸ Pause All Pending</button>
    </form>
    <form method="POST" style="display:flex;gap:6px;">
        <input type="hidden" name="action" value="resume_all">
        <button type="submit" class="btn btn-secondary" style="font-size:12px;padding:5px 12px;"
                onclick="return confirm('Resume all paused messages?')">▶ Resume All Paused</button>
    </form>
</div>

<!-- Filters -->
<div class="card" style="padding:14px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <input type="hidden" name="dir" value="<?= htmlspecialchars($direction) ?>">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Message Type</label>
            <select name="type" style="width:180px;">
                <option value="">All Types</option>
                <?php foreach ($msgTypes as $t): ?>
                <option value="<?= $t ?>" <?= $filterType===$t?'selected':'' ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">Org</label>
            <select name="org" style="width:100px;">
                <option value="0">All</option>
                <?php foreach ($orgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">From</label>
            <input type="date" name="from" value="<?= htmlspecialchars($filterFrom) ?>" style="width:140px;">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:3px;">To</label>
            <input type="date" name="to" value="<?= htmlspecialchars($filterTo) ?>" style="width:140px;">
        </div>
        <div style="padding-top:18px;">
            <label style="font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer;">
                <input type="checkbox" name="error" <?= $filterError?'checked':'' ?>> Errors only
            </label>
        </div>
        <div style="padding-top:18px;">
            <label style="font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer;">
                <input type="checkbox" name="paused" <?= $filterPaused?'checked':'' ?>> Paused only
            </label>
        </div>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="?dir=<?= htmlspecialchars($direction) ?>" class="btn btn-secondary">Clear</a>
    </form>
</div>

<!-- Message table -->
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;">
        <span style="font-weight:600;font-size:14px;"><?= ucfirst($direction) ?> Messages</span>
        <span class="text-dim" style="font-size:12px;"><?= number_format($total) ?> total — page <?= $page ?> of <?= $pages ?></span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th style="width:50px;">ID</th>
                    <th>Transaction Ref</th>
                    <th>Org</th>
                    <th>Type</th>
                    <th>Placed At</th>
                    <th>Processed At</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($messages as $msg):
                $isPending    = $msg['processed_at'] === null;
                $isPaused     = (bool)$msg['paused'];
                $hasError     = $msg['error_code'] !== null;
                $isProcessed  = !$isPending && !$hasError;
            ?>
            <tr style="<?= $hasError?'background:rgba(248,81,73,.05);':($isPaused?'opacity:.65;':'') ?>">
                <td class="text-dim font-mono" style="font-size:11px;"><?= $msg['id'] ?></td>
                <td style="font-size:11px;font-family:monospace;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    <a href="?dir=<?= $direction ?>&view=<?= $msg['id'] ?>#payload"
                       style="color:var(--accent-blue);">
                        <?= htmlspecialchars($msg['transaction_ref']) ?>
                    </a>
                </td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($msg['org_code']??'—') ?></code></td>
                <td><span class="badge badge-grey" style="font-size:10px;"><?= htmlspecialchars($msg['message_type']) ?></span></td>
                <td style="font-size:11px;white-space:nowrap;"><?= displayDate($msg['placed_at'],'d M H:i') ?></td>
                <td style="font-size:11px;white-space:nowrap;"><?= $msg['processed_at'] ? displayDate($msg['processed_at'],'d M H:i') : '<span class="text-dim">Pending</span>' ?></td>
                <td>
                    <?php if ($hasError): ?>
                    <span class="badge badge-red" title="<?= htmlspecialchars($msg['error_detail']??'') ?>">
                        Error: <?= htmlspecialchars($msg['error_code']) ?>
                    </span>
                    <?php elseif ($isPaused): ?>
                    <span class="badge badge-yellow">Paused</span>
                    <?php elseif ($isProcessed): ?>
                    <span class="badge badge-green">Processed</span>
                    <?php else: ?>
                    <span class="badge badge-blue">Pending</span>
                    <?php endif; ?>
                </td>
                <td style="white-space:nowrap;">
                    <a href="?dir=<?= $direction ?>&view=<?= $msg['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">View</a>
                    <?php if ($isPending && !$isPaused && !$hasError): ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action"  value="pause">
                        <input type="hidden" name="msg_id"  value="<?= $msg['id'] ?>">
                        <button class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">⏸</button>
                    </form>
                    <?php elseif ($isPaused): ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action"  value="resume">
                        <input type="hidden" name="msg_id"  value="<?= $msg['id'] ?>">
                        <button class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">▶</button>
                    </form>
                    <?php endif; ?>
                    <?php if ($hasError): ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action"  value="clear_error">
                        <input type="hidden" name="msg_id"  value="<?= $msg['id'] ?>">
                        <button class="btn btn-warning" style="padding:3px 8px;font-size:11px;">Retry</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$messages): ?>
            <tr><td colspan="8" style="text-align:center;color:var(--text-dim);padding:32px;">
                No messages found matching your filters.
            </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($pages > 1): ?>
    <div style="padding:12px 16px;border-top:1px solid var(--border);display:flex;gap:6px;flex-wrap:wrap;">
        <?php for ($p = 1; $p <= min($pages, 20); $p++): ?>
        <a href="?dir=<?= $direction ?>&page=<?= $p ?>&type=<?= urlencode($filterType) ?>&org=<?= $filterOrg ?>"
           class="btn <?= $p===$page?'btn-primary':'btn-secondary' ?>"
           style="padding:4px 10px;font-size:12px;"><?= $p ?></a>
        <?php endfor; ?>
        <?php if ($pages > 20): ?>
        <span class="text-dim" style="font-size:12px;padding:5px;">… <?= $pages ?> pages total</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php renderPageEnd(); ?>
