<?php
/**
 * admin/config.php — System Configuration Management
 * Version: 10.5.0
 * IT Admin only — edit all application settings stored in the DB.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

$message = '';
$error   = '';

// ── Handle POST ───────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $pdo = getDB();
    $pdo->beginTransaction();
    try {
        $configs = dbFetchAll("SELECT id, config_key, config_val, data_type FROM system_config ORDER BY sort_order");
        $changed = [];

        foreach ($configs as $cfg) {
            $key      = $cfg['config_key'];
            $oldVal   = $cfg['config_val'];
            $newVal   = null;

            if ($cfg['data_type'] === 'boolean') {
                $newVal = isset($_POST[$key]) ? '1' : '0';
            } elseif ($cfg['data_type'] === 'timezone') {
                $posted = trim($_POST[$key] ?? '');
                // Validate timezone
                if (!in_array($posted, DateTimeZone::listIdentifiers(), true)) {
                    throw new RuntimeException("Invalid timezone: {$posted}");
                }
                $newVal = $posted;
            } elseif ($cfg['data_type'] === 'integer') {
                $newVal = (string)(int)($_POST[$key] ?? $oldVal);
            } elseif ($cfg['data_type'] === 'theme') {
                $newVal = in_array($_POST[$key] ?? '', ['dark','light']) ? $_POST[$key] : 'dark';
            } else {
                $newVal = trim($_POST[$key] ?? $oldVal);
            }

            if ($newVal !== $oldVal) {
                dbExecute(
                    "UPDATE system_config SET config_val=?, updated_by=?, updated_at=NOW() WHERE config_key=?",
                    [$newVal, $_SESSION['user_id'], $key]
                );
                $changed[] = $key;
                writeAuditLog('CONFIG_CHANGE', 'system_config', $key, null,
                    null, null, $key, $oldVal, $newVal,
                    "Config '{$key}' changed from '{$oldVal}' to '{$newVal}'");
            }
        }

        $pdo->commit();
        $message = count($changed)
            ? 'Configuration saved. Changed: ' . implode(', ', $changed) . '. Changes take effect immediately.'
            : 'No changes made.';

    } catch (Throwable $e) {
        $pdo->rollBack();
        $error = 'Error saving configuration: ' . $e->getMessage();
    }
}

// ── Load current config ───────────────────────────────────────────────────────
$configs = dbFetchAll(
    "SELECT sc.*, u.known_as AS updated_by_name
     FROM system_config sc
     LEFT JOIN users u ON u.id = sc.updated_by
     ORDER BY sc.sort_order"
);

// Group by section prefix
$sections = [
    'Site Identity'    => ['SITE_NAME','SITE_TAGLINE','SITE_TIMEZONE','DEFAULT_THEME'],
    'Session & Security' => ['SESSION_TIMEOUT_MINUTES','BCRYPT_COST'],
    'Feature Switches — Data' => ['PARTS_LOCKED','ORGS_LOCKED','DEPARTMENTS_LOCKED','RESOURCES_LOCKED'],
    'Feature Switches — Approvals' => ['AUTO_APPROVE_DOCS','AUTO_APPROVE_ROUTINGS'],
    'Feature Switches — Work Orders' => ['ALLOW_WO_CREATION','MAX_SERIALS_PER_WO','MAX_LOT_QTY_PER_WO'],
];

$cfgMap = array_column($configs, null, 'config_key');

// Common timezones for the dropdown
$commonTimezones = [
    'Europe/London','Europe/Paris','Europe/Berlin','Europe/Madrid','Europe/Rome',
    'America/New_York','America/Chicago','America/Denver','America/Los_Angeles',
    'Asia/Dubai','Asia/Singapore','Asia/Tokyo','Australia/Sydney','UTC',
];

renderPageStart('System Configuration');
?>

<div class="page-header page-header-row">
    <div>
        <h1>System Configuration</h1>
        <p>Application settings stored in the database. Changes take effect immediately without redeploying files.</p>
    </div>
</div>

<div class="alert alert-info" style="margin-bottom:16px;">
    <strong>Note:</strong> Database connection, URL settings, and Test Mode remain in <code>config.php</code>
    on the server and cannot be changed here for security reasons.
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">


<?php foreach ($sections as $sectionLabel => $keys): ?>
<div class="card" style="margin-bottom:16px;">
    <div class="card-title"><?= htmlspecialchars($sectionLabel) ?></div>

    <?php foreach ($keys as $key):
        $cfg = $cfgMap[$key] ?? null;
        if (!$cfg) continue;
    ?>
    <div style="display:grid;grid-template-columns:280px 1fr 180px;gap:12px;align-items:start;
                padding:12px 0;border-bottom:1px solid var(--border);">

        <!-- Label + description -->
        <div>
            <div style="font-size:13px;font-weight:600;color:var(--text);">
                <?= htmlspecialchars($cfg['label']) ?>
            </div>
            <?php if ($cfg['description']): ?>
            <div class="text-dim" style="font-size:11px;margin-top:3px;line-height:1.4;">
                <?= htmlspecialchars($cfg['description']) ?>
            </div>
            <?php endif; ?>
            <div class="text-dim" style="font-family:monospace;font-size:10px;margin-top:4px;opacity:.6;">
                <?= htmlspecialchars($key) ?>
            </div>
        </div>

        <!-- Input -->
        <div>
            <?php if ($cfg['data_type'] === 'boolean'): ?>
            <label style="display:flex;align-items:center;gap:10px;cursor:pointer;">
                <div style="position:relative;width:44px;height:24px;flex-shrink:0;">
                    <input type="checkbox" name="<?= $key ?>" value="1"
                           <?= $cfg['config_val'] === '1' ? 'checked' : '' ?>
                           id="cfg_<?= $key ?>"
                           style="opacity:0;width:0;height:0;position:absolute;"
                           onchange="this.closest('label').querySelector('.toggle-track').style.background=this.checked?'var(--accent)':'var(--border)'">
                    <div class="toggle-track"
                         style="position:absolute;inset:0;border-radius:12px;cursor:pointer;transition:background .2s;
                                background:<?= $cfg['config_val']==='1' ? 'var(--accent)' : 'var(--border)' ?>;">
                        <div style="position:absolute;top:3px;left:3px;width:18px;height:18px;
                                    background:#fff;border-radius:50%;transition:transform .2s;
                                    transform:translateX(<?= $cfg['config_val']==='1' ? '20px' : '0' ?>);"
                             id="knob_<?= $key ?>"></div>
                    </div>
                </div>
                <span style="font-size:13px;color:var(--text-muted);" id="lbl_<?= $key ?>">
                    <?= $cfg['config_val']==='1' ? 'Enabled' : 'Disabled' ?>
                </span>
            </label>
            <script>
            document.getElementById('cfg_<?= $key ?>').addEventListener('change', function() {
                document.getElementById('knob_<?= $key ?>').style.transform = this.checked ? 'translateX(20px)' : 'translateX(0)';
                document.getElementById('lbl_<?= $key ?>').textContent = this.checked ? 'Enabled' : 'Disabled';
            });
            </script>

            <?php elseif ($cfg['data_type'] === 'timezone'): ?>
            <select name="<?= $key ?>" style="width:100%;max-width:300px;">
                <?php foreach ($commonTimezones as $tz): ?>
                <option value="<?= $tz ?>" <?= $cfg['config_val']===$tz?'selected':'' ?>><?= $tz ?></option>
                <?php endforeach; ?>
                <?php if (!in_array($cfg['config_val'], $commonTimezones, true)): ?>
                <option value="<?= htmlspecialchars($cfg['config_val']) ?>" selected>
                    <?= htmlspecialchars($cfg['config_val']) ?>
                </option>
                <?php endif; ?>
            </select>
            <div class="text-dim" style="font-size:11px;margin-top:4px;">
                Current server time in this zone: <code><?= (new DateTimeImmutable('now', new DateTimeZone($cfg['config_val'])))->format('d M Y H:i T') ?></code>
            </div>

            <?php elseif ($cfg['data_type'] === 'theme'): ?>
            <select name="<?= $key ?>" style="width:120px;">
                <option value="dark"  <?= $cfg['config_val']==='dark' ?'selected':'' ?>>Dark</option>
                <option value="light" <?= $cfg['config_val']==='light'?'selected':'' ?>>Light</option>
            </select>

            <?php elseif ($cfg['data_type'] === 'integer'): ?>
            <input type="number" name="<?= $key ?>"
                   value="<?= htmlspecialchars($cfg['config_val']) ?>"
                   min="1" style="width:120px;">

            <?php else: ?>
            <input type="text" name="<?= $key ?>"
                   value="<?= htmlspecialchars($cfg['config_val']) ?>"
                   style="width:100%;max-width:400px;">
            <?php endif; ?>
        </div>

        <!-- Last updated -->
        <div style="font-size:11px;color:var(--text-dim);text-align:right;padding-top:2px;">
            <?php if ($cfg['updated_at'] && $cfg['updated_by_name']): ?>
            Updated<br>
            <?= htmlspecialchars(displayDate($cfg['updated_at'],'d M Y H:i')) ?><br>
            by <?= htmlspecialchars($cfg['updated_by_name']) ?>
            <?php else: ?>
            Default
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>

</div>
<?php endforeach; ?>

<!-- File-only settings (read-only display) -->
<div class="card" style="margin-bottom:16px;border-color:var(--border);">
    <div class="card-title">Settings Managed in config.php (read-only)</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;font-size:13px;">
        <div><span class="text-dim">Site URL:</span> <code><?= htmlspecialchars(SITE_URL) ?></code></div>
        <div><span class="text-dim">Subpath:</span> <code><?= htmlspecialchars(SITE_SUBPATH) ?></code></div>
        <div><span class="text-dim">Code Version:</span> <code><?= htmlspecialchars(SITE_VERSION) ?></code></div>
        <div><span class="text-dim">Test Mode:</span>
            <?= TEST_MODE
                ? '<span class="badge badge-yellow">ENABLED</span>'
                : '<span class="badge badge-green">DISABLED</span>' ?>
        </div>
        <div><span class="text-dim">DB Host:</span> <code><?= htmlspecialchars(DB_HOST) ?></code></div>
        <div><span class="text-dim">DB Name:</span> <code><?= htmlspecialchars(DB_NAME) ?></code></div>
    </div>
    <div class="text-dim" style="margin-top:10px;font-size:11px;">
        Edit <code>/chrismes/config.php</code> on the server to change these values.
    </div>
</div>

<div style="display:flex;gap:10px;align-items:center;">
    <button type="submit" class="btn btn-primary">Save Configuration</button>
    <span class="text-dim" style="font-size:12px;">Changes apply immediately — no server restart required.</span>
</div>

</form>

<?php renderPageEnd(); ?>
