<?php
/**
 * admin/locations.php — Inventory Locations Management
 * Version: 2.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona('IT_ADMIN');

// Ensure table exists (created in this release)
getDB()->exec("CREATE TABLE IF NOT EXISTS inventory_locations (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    org_id     INT UNSIGNED NOT NULL,
    code       VARCHAR(30)  NOT NULL,
    name       VARCHAR(120) NOT NULL,
    active     TINYINT(1)   NOT NULL DEFAULT 1,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_loc_org_code (org_id, code),
    CONSTRAINT fk_loc_org FOREIGN KEY (org_id) REFERENCES orgs(id)
) ENGINE=InnoDB");

$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id     = (int)($_POST['id'] ?? 0);
        $orgId  = (int)($_POST['org_id'] ?? 0);
        $code   = strtoupper(trim($_POST['code'] ?? ''));
        $name   = trim($_POST['name'] ?? '');
        $active = isset($_POST['active']) ? 1 : 0;

        if ($orgId === 0)  $error = 'Please select an organisation.';
        elseif ($code === '') $error = 'Location code is required.';
        elseif ($name === '') $error = 'Location name is required.';
        else {
            try {
                if ($id === 0) {
                    $newId = dbInsert("INSERT INTO inventory_locations (org_id,code,name,active) VALUES (?,?,?,?)", [$orgId,$code,$name,$active]);
                    writeAuditLog('LOC_CREATE','inventory_location',(string)$newId,$orgId,null,null,null,null,$code,"Created location: {$code}");
                    $message = "Location '{$code}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM inventory_locations WHERE id=?", [$id]);
                    dbExecute("UPDATE inventory_locations SET name=?,active=?,updated_at=NOW() WHERE id=?",[$name,$active,$id]);
                    if ($old && $old['name']!==$name)
                        writeAuditLog('LOC_EDIT','inventory_location',(string)$id,$orgId,null,null,'name',$old['name'],$name);
                    $message = "Location '{$code}' updated.";
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Code '{$code}' already exists for this org." : 'Database error.';
            }
        }
    }
}

$orgs      = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$filterOrg = (int)($_GET['org'] ?? 0);
$locs      = $filterOrg
    ? dbFetchAll("SELECT l.*,o.code AS org_code FROM inventory_locations l JOIN orgs o ON o.id=l.org_id WHERE l.org_id=? ORDER BY l.code",[$filterOrg])
    : dbFetchAll("SELECT l.*,o.code AS org_code FROM inventory_locations l JOIN orgs o ON o.id=l.org_id ORDER BY o.code,l.code");

$editing = isset($_GET['edit']) ? dbFetchOne("SELECT * FROM inventory_locations WHERE id=?",[(int)$_GET['edit']]) : null;

renderPageStart('Inventory Locations');
?>

<div class="page-header page-header-row">
    <div><h1>Inventory Locations</h1><p>Stock locations used when booking work orders to stock.</p></div>
    <?php if (!$editing): ?><a href="?new=1" class="btn btn-primary">+ New Location</a><?php endif; ?>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($editing || isset($_GET['new'])): ?>
<div class="card">
    <div class="card-title"><?= $editing ? 'Edit Location' : 'New Location' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">
        <div style="display:grid;grid-template-columns:1fr 150px 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
                <select name="org_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o): ?>
                    <option value="<?= $o['id'] ?>" <?= ($editing['org_id']??0)==$o['id']?'selected':'' ?>>
                        <?= htmlspecialchars($o['code'].' — '.$o['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="code" maxlength="30"
                       value="<?= htmlspecialchars($editing['code'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="WH-A1" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="name" maxlength="120"
                       value="<?= htmlspecialchars($editing['name'] ?? '') ?>"
                       placeholder="Warehouse Rack A1" required>
            </div>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active']??1)?'checked':'' ?>> Active
            </label>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= SITE_SUBPATH ?>/admin/locations.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
    <label style="font-size:12px;color:var(--text-muted);margin:0;">Filter by org:</label>
    <select onchange="window.location='<?= SITE_SUBPATH ?>/admin/locations.php?org='+this.value" style="width:auto;">
        <option value="0">All</option>
        <?php foreach ($orgs as $o): ?>
        <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Org</th><th>Code</th><th>Name</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($locs as $l): ?>
            <tr>
                <td><code style="font-size:11px;"><?= htmlspecialchars($l['org_code']) ?></code></td>
                <td><code style="font-size:12px;"><?= htmlspecialchars($l['code']) ?></code></td>
                <td><?= htmlspecialchars($l['name']) ?></td>
                <td><?= $l['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td><a href="?edit=<?= $l['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Edit</a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$locs): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--text-dim);padding:24px;">No locations defined yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
