<?php
/**
 * admin/uom.php — Units of Measure Management
 * Version: 2.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona('IT_ADMIN');

$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id     = (int)($_POST['id'] ?? 0);
        $code   = strtoupper(trim($_POST['code'] ?? ''));
        $name   = trim($_POST['name'] ?? '');
        $active = isset($_POST['active']) ? 1 : 0;

        // Block editing system UoMs
        if ($id > 0) {
            $existing = dbFetchOne("SELECT is_system FROM uom WHERE id=?", [$id]);
            if ($existing && $existing['is_system']) {
                $error = 'System UoMs cannot be modified.';
            }
        }

        if (!$error) {
            if ($code === '')   $error = 'Code is required.';
            elseif (strlen($code) > 10) $error = 'Code max 10 characters.';
            elseif ($name === '') $error = 'Name is required.';
        }

        if (!$error) {
            try {
                if ($id === 0) {
                    $newId = dbInsert("INSERT INTO uom (code,name,is_system,active) VALUES (?,?,0,?)", [$code,$name,$active]);
                    writeAuditLog('UOM_CREATE','uom',(string)$newId,null,null,null,null,null,$code,"Created UoM: {$code}");
                    $message = "Unit of Measure '{$code}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM uom WHERE id=?", [$id]);
                    dbExecute("UPDATE uom SET name=?,active=? WHERE id=? AND is_system=0", [$name,$active,$id]);
                    if ($old['name'] !== $name)
                        writeAuditLog('UOM_EDIT','uom',(string)$id,null,null,null,'name',$old['name'],$name);
                    $message = "Unit '{$code}' updated.";
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Code '{$code}' already exists." : 'Database error.';
            }
        }
    }
}

$uoms    = dbFetchAll("SELECT * FROM uom ORDER BY is_system DESC, code ASC");
$editing = isset($_GET['edit']) ? dbFetchOne("SELECT * FROM uom WHERE id=? AND is_system=0", [(int)$_GET['edit']]) : null;

renderPageStart('Units of Measure');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Units of Measure</h1>
        <p>System UoMs are locked. Custom UoMs can be added and edited.</p>
    </div>
    <?php if (!$editing): ?>
    <a href="?new=1" class="btn btn-primary">+ New UoM</a>
    <?php endif; ?>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($editing || isset($_GET['new'])): ?>
<div class="card">
    <div class="card-title"><?= $editing ? 'Edit UoM' : 'New Unit of Measure' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">
        <div style="display:grid;grid-template-columns:120px 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="code" maxlength="10"
                       value="<?= htmlspecialchars($editing['code'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="PCS" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="name" maxlength="80"
                       value="<?= htmlspecialchars($editing['name'] ?? '') ?>"
                       placeholder="Pieces" required>
            </div>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active']??1) ? 'checked':'' ?>> Active
            </label>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= SITE_SUBPATH ?>/admin/uom.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Code</th><th>Name</th><th>Type</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($uoms as $u): ?>
            <tr>
                <td><code style="font-size:12px;"><?= htmlspecialchars($u['code']) ?></code></td>
                <td><?= htmlspecialchars($u['name']) ?></td>
                <td><?= $u['is_system'] ? '<span class="badge badge-blue">System</span>' : '<span class="badge badge-grey">Custom</span>' ?></td>
                <td><?= $u['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td>
                    <?php if (!$u['is_system']): ?>
                    <a href="?edit=<?= $u['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Edit</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
