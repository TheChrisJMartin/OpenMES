<?php
/**
 * admin/resources.php — Resource Management
 * Version: 2.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona('IT_ADMIN');

$locked  = RESOURCES_LOCKED;
$message = '';
$error   = '';

if (!$locked && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id     = (int)($_POST['id'] ?? 0);
        $deptId = (int)($_POST['department_id'] ?? 0);
        $code   = strtoupper(trim($_POST['code'] ?? ''));
        $name   = trim($_POST['name'] ?? '');
        $active = isset($_POST['active']) ? 1 : 0;

        if ($deptId === 0)   $error = 'Please select a department.';
        elseif ($code === '') $error = 'Resource code is required.';
        elseif ($name === '') $error = 'Resource name is required.';
        else {
            // Get org from dept
            $dept = dbFetchOne("SELECT org_id FROM departments WHERE id=?", [$deptId]);
            $orgId = $dept['org_id'] ?? null;
            try {
                if ($id === 0) {
                    $newId = dbInsert(
                        "INSERT INTO resources (org_id,department_id,code,name,active) VALUES (?,?,?,?,?)",
                        [$orgId,$deptId,$code,$name,$active]
                    );
                    writeAuditLog('RESOURCE_CREATE','resource',(string)$newId,$orgId,null,null,null,null,$code,"Created resource: {$code}");
                    $message = "Resource '{$code}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM resources WHERE id=?", [$id]);
                    if ($old) {
                        dbExecute("UPDATE resources SET department_id=?,org_id=?,name=?,active=?,updated_at=NOW() WHERE id=?",[$deptId,$orgId,$name,$active,$id]);
                        foreach (['name'=>$name,'active'=>(string)$active] as $f=>$v)
                            if ((string)$old[$f]!==$v)
                                writeAuditLog('RESOURCE_EDIT','resource',(string)$id,$orgId,null,null,$f,$old[$f],$v);
                        $message = "Resource '{$code}' updated.";
                    }
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Code '{$code}' already exists in this department." : 'Database error.';
            }
        }
    }
}

// For dropdowns
$orgs  = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$depts = dbFetchAll("SELECT d.id,d.code,d.name,o.code AS org_code,d.org_id FROM departments d JOIN orgs o ON o.id=d.org_id WHERE d.active=1 ORDER BY o.code,d.code");

$filterOrg  = (int)($_GET['org'] ?? 0);
$filterDept = (int)($_GET['dept'] ?? 0);

$where  = '1=1';
$params = [];
if ($filterOrg)  { $where .= ' AND r.org_id=?';        $params[] = $filterOrg; }
if ($filterDept) { $where .= ' AND r.department_id=?';  $params[] = $filterDept; }

$resources = dbFetchAll(
    "SELECT r.*,d.code AS dept_code,d.name AS dept_name,o.code AS org_code
     FROM resources r
     JOIN departments d ON d.id=r.department_id
     JOIN orgs o ON o.id=r.org_id
     WHERE {$where} ORDER BY o.code,d.code,r.code",
    $params
);

$editing = isset($_GET['edit']) ? dbFetchOne("SELECT * FROM resources WHERE id=?", [(int)$_GET['edit']]) : null;

renderPageStart('Resources');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Resources</h1>
        <p>Workstations and machines within departments.</p>
    </div>
    <?php if (!$locked && !$editing): ?>
    <a href="?new=1" class="btn btn-primary">+ New Resource</a>
    <?php endif; ?>
</div>

<?php if ($locked): ?><div class="alert alert-warning">⚠ Resource editing is disabled (RESOURCES_LOCKED).</div><?php endif; ?>
<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if (!$locked && ($editing || isset($_GET['new']))): ?>
<div class="card">
    <div class="card-title"><?= $editing ? 'Edit Resource' : 'New Resource' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">
        <div style="display:grid;grid-template-columns:1fr 160px 1fr;gap:16px;">
            <div class="form-group" style="margin:0;">
                <label>Department <span style="color:var(--accent-danger)">*</span></label>
                <select name="department_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($depts as $d): ?>
                    <option value="<?= $d['id'] ?>" <?= ($editing['department_id'] ?? 0)==$d['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d['org_code'] . ' › ' . $d['code'] . ' — ' . $d['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="code" maxlength="30"
                       value="<?= htmlspecialchars($editing['code'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="ASSY01" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="name" maxlength="120"
                       value="<?= htmlspecialchars($editing['name'] ?? '') ?>"
                       placeholder="Assembly Bench 1" required>
            </div>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active'] ?? 1) ? 'checked' : '' ?>>
                Active
            </label>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= SITE_SUBPATH ?>/admin/resources.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Filter -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap;">
    <label style="font-size:12px;color:var(--text-muted);margin:0;">Org:</label>
    <select onchange="window.location='<?= SITE_SUBPATH ?>/admin/resources.php?org='+this.value" style="width:auto;">
        <option value="0">All</option>
        <?php foreach ($orgs as $o): ?>
        <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Org</th><th>Department</th><th>Code</th><th>Name</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($resources as $r): ?>
            <tr>
                <td><code style="font-size:11px;"><?= htmlspecialchars($r['org_code']) ?></code></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($r['dept_code']) ?></code></td>
                <td><code style="font-size:12px;"><?= htmlspecialchars($r['code']) ?></code></td>
                <td><?= htmlspecialchars($r['name']) ?></td>
                <td><?= $r['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td><?php if (!$locked): ?><a href="?edit=<?= $r['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Edit</a><?php endif; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
