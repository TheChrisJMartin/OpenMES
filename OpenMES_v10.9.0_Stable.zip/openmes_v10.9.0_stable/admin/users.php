<?php
/**
 * admin/users.php — User Management
 * Version: 10.5.3
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona('IT_ADMIN');

$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id          = (int)($_POST['id'] ?? 0);
        $username    = strtoupper(trim($_POST['username'] ?? ''));
        $firstname   = trim($_POST['firstname'] ?? '');
        $surname     = trim($_POST['surname'] ?? '');
        $known_as    = trim($_POST['known_as'] ?? '');
        $persona_id  = (int)($_POST['persona_id'] ?? 0);
        $org_id      = ($_POST['org_id'] === '' || $_POST['org_id'] === '0') ? null : (int)$_POST['org_id'];
        $active      = isset($_POST['active'])      ? 1 : 0;
        $is_direct   = isset($_POST['is_direct'])   ? 1 : 0;
        $is_test     = isset($_POST['is_test_acct'])? 1 : 0;
        $theme       = in_array($_POST['theme']??'', ['dark','light']) ? $_POST['theme'] : 'dark';
        $new_password= trim($_POST['new_password'] ?? '');

        if ($username === '')  $error = 'Username is required.';
        elseif ($firstname === '') $error = 'First name is required.';
        elseif ($surname === '')   $error = 'Surname is required.';
        elseif ($known_as === '')  $error = 'Known as is required.';
        elseif ($persona_id === 0) $error = 'Please select a persona.';
        elseif ($id === 0 && $new_password === '') $error = 'Password is required for new users.';
        else {
            // CD015: Require acting IT Admin to re-enter their own password when granting IT_ADMIN persona
            $newPersonaCode = dbFetchOne("SELECT code FROM personas WHERE id=?", [$persona_id])['code'] ?? '';
            $oldPersonaCode = $id > 0 ? (dbFetchOne("SELECT p.code FROM users u JOIN personas p ON p.id=u.persona_id WHERE u.id=?", [$id])['code'] ?? '') : '';
            $isElevatingToAdmin = ($newPersonaCode === 'IT_ADMIN' && $oldPersonaCode !== 'IT_ADMIN');
            if ($isElevatingToAdmin) {
                $confirmPw   = $_POST['confirm_admin_password'] ?? '';
                $actingUser  = dbFetchOne("SELECT password_hash FROM users WHERE id=?", [$_SESSION['user_id']]);
                if (!$actingUser || !password_verify($confirmPw, $actingUser['password_hash'])) {
                    $error = 'Re-enter your own password to grant IT Admin access to this user.';
                }
            }
        }
        if (!$error) {
            try {
                if ($id === 0) {
                    $hash = password_hash($new_password, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST]);
                    $newId = dbInsert(
                        "INSERT INTO users (username,password_hash,firstname,surname,known_as,persona_id,org_id,active,is_direct,is_test_acct,theme)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        [$username,$hash,$firstname,$surname,$known_as,$persona_id,$org_id,$active,$is_direct,$is_test,$theme]
                    );
                    writeAuditLog('USER_CREATE','user',(string)$newId,$org_id,null,null,null,null,$username,"Created user: {$username}");
                    $message = "User '{$username}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM users WHERE id=?", [$id]);
                    if ($old) {
                        $hash = $new_password !== ''
                            ? password_hash($new_password, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST])
                            : $old['password_hash'];

                        dbExecute(
                            "UPDATE users SET firstname=?,surname=?,known_as=?,persona_id=?,org_id=?,active=?,is_direct=?,is_test_acct=?,theme=?,password_hash=?,updated_at=NOW() WHERE id=?",
                            [$firstname,$surname,$known_as,$persona_id,$org_id,$active,$is_direct,$is_test,$theme,$hash,$id]
                        );

                        $fields = ['firstname'=>$firstname,'surname'=>$surname,'known_as'=>$known_as,
                                   'persona_id'=>(string)$persona_id,'active'=>(string)$active,
                                   'is_direct'=>(string)$is_direct,'is_test_acct'=>(string)$is_test,'theme'=>$theme];
                        foreach ($fields as $f=>$v)
                            if ((string)$old[$f] !== $v)
                                writeAuditLog('USER_EDIT','user',(string)$id,$org_id,null,null,$f,$old[$f],$v);
                        if ($new_password !== '')
                            writeAuditLog('USER_PASSWORD_CHANGE','user',(string)$id,$org_id,null,null,'password','[hidden]','[changed]');

                        // D003: Security log for persona/role changes and account activation changes
                        if ((string)$old['persona_id'] !== (string)$persona_id) {
                            $oldPersona = dbFetchOne("SELECT code FROM personas WHERE id=?", [(int)$old['persona_id']]);
                            $newPersona = dbFetchOne("SELECT code FROM personas WHERE id=?", [$persona_id]);
                            writeSecurityLog('ROLE_CHANGE', 'HIGH', $_SESSION['user_id'], null,
                                "Persona changed for user '{$username}' (ID {$id}): " .
                                ($oldPersona['code'] ?? '?') . ' → ' . ($newPersona['code'] ?? '?'),
                                'user', $id);
                        }
                        if ((string)$old['active'] !== (string)$active) {
                            writeSecurityLog('USER_CHANGE', 'HIGH', $_SESSION['user_id'], null,
                                "Account active flag changed for user '{$username}' (ID {$id}): " .
                                ($old['active'] ? 'Active' : 'Inactive') . ' → ' . ($active ? 'Active' : 'Inactive'),
                                'user', $id);
                        }

                        $message = "User '{$username}' updated.";
                    }
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Username '{$username}' already exists." : 'Database error: '.$e->getMessage();
            }
        } // end if (!$error)
    }
}

$personas = dbFetchAll("SELECT * FROM personas ORDER BY label");
$orgs     = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");

$filterPersona = (int)($_GET['persona'] ?? 0);
$where  = '1=1';
$params = [];
if ($filterPersona) { $where .= ' AND u.persona_id=?'; $params[] = $filterPersona; }

$users = dbFetchAll(
    "SELECT u.*,p.label AS persona_label,p.code AS persona_code,o.code AS org_code
     FROM users u
     JOIN personas p ON p.id=u.persona_id
     LEFT JOIN orgs o ON o.id=u.org_id
     WHERE {$where}
     ORDER BY o.code,u.username",
    $params
);

$editing = isset($_GET['edit']) ? dbFetchOne(
    "SELECT u.*,p.code AS persona_code FROM users u JOIN personas p ON p.id=u.persona_id WHERE u.id=?",
    [(int)$_GET['edit']]
) : null;

renderPageStart('Users & Roles');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Users &amp; Roles</h1>
        <p>Manage user accounts and persona assignments.</p>
    </div>
    <?php if (!$editing): ?>
    <a href="?new=1" class="btn btn-primary">+ New User</a>
    <?php endif; ?>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($editing || isset($_GET['new'])): ?>
<div class="card">
    <div class="card-title"><?= $editing ? 'Edit User — ' . htmlspecialchars($editing['username']) : 'New User' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Username <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="username"
                       value="<?= htmlspecialchars($editing['username'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="OPERATOR1" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>First Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="firstname" value="<?= htmlspecialchars($editing['firstname'] ?? '') ?>" placeholder="James" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Surname <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="surname" value="<?= htmlspecialchars($editing['surname'] ?? '') ?>" placeholder="Turner" required>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:14px;">
            <div class="form-group" style="margin:0;">
                <label>Known As <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="known_as" value="<?= htmlspecialchars($editing['known_as'] ?? '') ?>" placeholder="Jimmy" required>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Persona <span style="color:var(--accent-danger)">*</span></label>
                <select name="persona_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($personas as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= ($editing['persona_id']??0)==$p['id']?'selected':'' ?>>
                        <?= htmlspecialchars($p['label']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Organisation</label>
                <select name="org_id">
                    <option value="">— None (IT Admin) —</option>
                    <?php foreach ($orgs as $o): ?>
                    <option value="<?= $o['id'] ?>" <?= ($editing['org_id']??'') == $o['id'] ? 'selected':'' ?>>
                        <?= htmlspecialchars($o['code'] . ' — ' . $o['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px;">
            <div class="form-group" style="margin:0;">
                <label><?= $editing ? 'New Password (leave blank to keep current)' : 'Password *' ?></label>
                <input type="password" name="new_password" autocomplete="new-password"
                       <?= !$editing ? 'required' : '' ?>>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Theme</label>
                <select name="theme">
                    <option value="dark"  <?= ($editing['theme']??'dark')==='dark'?'selected':'' ?>>Dark</option>
                    <option value="light" <?= ($editing['theme']??'')==='light'?'selected':'' ?>>Light</option>
                </select>
            </div>
        </div>

        <div style="display:flex;gap:20px;margin-top:16px;flex-wrap:wrap;">
            <label style="display:flex;align-items:center;gap:7px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active']??1) ? 'checked':'' ?>> Active
            </label>
            <label style="display:flex;align-items:center;gap:7px;font-size:13px;">
                <input type="checkbox" name="is_direct" value="1" <?= ($editing['is_direct']??1) ? 'checked':'' ?>> Direct Labour
            </label>
            <label style="display:flex;align-items:center;gap:7px;font-size:13px;">
                <input type="checkbox" name="is_test_acct" value="1" <?= ($editing['is_test_acct']??0) ? 'checked':'' ?>> Test Account
            </label>
        </div>

        <div style="display:flex;gap:8px;margin-top:16px;">
            <button type="submit" class="btn btn-primary">Save</button>
            <!-- CD015: Hidden confirm-password field shown by JS when IT_ADMIN selected -->
            <div id="admin-confirm-wrap" style="display:none;margin-top:12px;">
                <div class="alert alert-warning" style="margin-bottom:8px;font-size:13px;">
                    ⚠ You are granting <strong>IT Admin</strong> access. Re-enter your own password to confirm.
                </div>
                <input type="password" name="confirm_admin_password" id="confirm_admin_password"
                       placeholder="Your password" style="max-width:280px;">
            </div>
            <script>
            (function() {
                var pSel = document.querySelector('select[name="persona_id"]');
                var wrap = document.getElementById('admin-confirm-wrap');
                if (!pSel || !wrap) return;
                function checkPersona() {
                    var opt = pSel.options[pSel.selectedIndex];
                    var code = opt ? opt.textContent.trim() : '';
                    wrap.style.display = code.includes('IT Admin') ? 'block' : 'none';
                }
                pSel.addEventListener('change', checkPersona);
                checkPersona();
            })();
            </script>
            <a href="<?= SITE_SUBPATH ?>/admin/users.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Filter -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap;">
    <label style="font-size:12px;color:var(--text-muted);margin:0;">Filter:</label>
    <select onchange="window.location='<?= SITE_SUBPATH ?>/admin/users.php?persona='+this.value" style="width:auto;">
        <option value="0">All Personas</option>
        <?php foreach ($personas as $p): ?>
        <option value="<?= $p['id'] ?>" <?= $filterPersona===$p['id']?'selected':'' ?>><?= htmlspecialchars($p['label']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Username</th><th>Name</th><th>Persona</th><th>Org</th><th>Flags</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><code style="font-size:12px;"><?= htmlspecialchars($u['username']) ?></code></td>
                <td>
                    <?= htmlspecialchars($u['firstname'] . ' ' . $u['surname']) ?>
                    <div class="text-dim"><?= htmlspecialchars($u['known_as']) ?></div>
                </td>
                <td><span class="badge badge-blue"><?= htmlspecialchars($u['persona_label']) ?></span></td>
                <td><code style="font-size:11px;"><?= $u['org_code'] ? htmlspecialchars($u['org_code']) : '—' ?></code></td>
                <td style="font-size:11px;color:var(--text-dim);">
                    <?= $u['is_direct']   ? '<span title="Direct Labour" style="color:var(--accent-blue)">DIR</span> ' : '' ?>
                    <?= $u['is_test_acct']? '<span title="Test Account" style="color:var(--accent-warn)">TEST</span>' : '' ?>
                </td>
                <td><?= $u['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td><a href="?edit=<?= $u['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Edit</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
