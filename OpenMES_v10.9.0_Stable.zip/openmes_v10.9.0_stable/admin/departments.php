<?php
/**
 * admin/departments.php — Department Management
 * Version: 2.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona('IT_ADMIN');

$locked  = DEPARTMENTS_LOCKED;
$message = '';
$error   = '';

if (!$locked && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id     = (int)($_POST['id'] ?? 0);
        $orgId  = (int)($_POST['org_id'] ?? 0);
        $code   = strtoupper(trim($_POST['code'] ?? ''));
        $name   = trim($_POST['name'] ?? '');
        $active = isset($_POST['active']) ? 1 : 0;

        if ($orgId === 0)                                    $error = 'Please select an organisation.';
        elseif (strlen($code) < 2 || strlen($code) > 10)    $error = 'Department code must be 2–10 characters.';
        elseif (!preg_match('/^[A-Z0-9_-]+$/', $code))      $error = 'Code must be uppercase letters, numbers, hyphens or underscores.';
        elseif ($name === '')                                $error = 'Department name is required.';
        else {
            try {
                if ($id === 0) {
                    $newId = dbInsert(
                        "INSERT INTO departments (org_id, code, name, active) VALUES (?,?,?,?)",
                        [$orgId, $code, $name, $active]
                    );
                    writeAuditLog('DEPT_CREATE', 'department', (string)$newId, $orgId, null, null, null, null, $code, "Created dept: {$code}");
                    $message = "Department '{$code}' created.";
                } else {
                    $old = dbFetchOne("SELECT * FROM departments WHERE id=?", [$id]);
                    if ($old) {
                        dbExecute("UPDATE departments SET org_id=?,name=?,active=?,updated_at=NOW() WHERE id=?", [$orgId,$name,$active,$id]);
                        foreach (['name'=>$name,'active'=>(string)$active] as $field=>$val)
                            if ((string)$old[$field] !== $val)
                                writeAuditLog('DEPT_EDIT','department',(string)$id,$orgId,null,null,$field,$old[$field],$val);
                        $message = "Department '{$code}' updated.";
                    }
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Code '{$code}' already exists in this org." : 'Database error: ' . $e->getMessage();
            }
        }
    }
}

$orgs  = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$filterOrg = (int)($_GET['org'] ?? 0);

$depts = $filterOrg
    ? dbFetchAll("SELECT d.*,o.code AS org_code,o.name AS org_name FROM departments d JOIN orgs o ON o.id=d.org_id WHERE d.org_id=? ORDER BY d.code", [$filterOrg])
    : dbFetchAll("SELECT d.*,o.code AS org_code,o.name AS org_name FROM departments d JOIN orgs o ON o.id=d.org_id ORDER BY o.code,d.code");

$editing = isset($_GET['edit']) ? dbFetchOne("SELECT * FROM departments WHERE id=?", [(int)$_GET['edit']]) : null;

renderPageStart('Departments');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Departments</h1>
        <p>Manage departments within each organisation.</p>
    </div>
    <?php if (!$locked && !$editing): ?>
    <a href="?new=1" class="btn btn-primary">+ New Department</a>
    <?php endif; ?>
</div>

<?php if ($locked): ?><div class="alert alert-warning">⚠ Department editing is disabled (DEPARTMENTS_LOCKED).</div><?php endif; ?>
<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if (!$locked && ($editing || isset($_GET['new']))): ?>
<div class="card">
    <div class="card-title"><?= $editing ? 'Edit Department' : 'New Department' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">
        <div style="display:grid;grid-template-columns:1fr 140px 1fr;gap:16px;">
            <div class="form-group" style="margin:0;">
                <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
                <select name="org_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o): ?>
                    <option value="<?= $o['id'] ?>" <?= ($editing['org_id'] ?? 0) == $o['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($o['code'] . ' — ' . $o['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="code" maxlength="10"
                       value="<?= htmlspecialchars($editing['code'] ?? '') ?>"
                       <?= $editing ? 'readonly style="opacity:.5"' : '' ?>
                       placeholder="BKASSY" required>
                <div class="text-dim" style="margin-top:3px;">Max 10 chars</div>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Name <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="name" maxlength="120"
                       value="<?= htmlspecialchars($editing['name'] ?? '') ?>"
                       placeholder="Bicycle Assembly" required>
            </div>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active'] ?? 1) ? 'checked' : '' ?>>
                Active
            </label>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= SITE_SUBPATH ?>/admin/departments.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Filter -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
    <label style="font-size:12px;color:var(--text-muted);margin:0;">Filter by org:</label>
    <select onchange="window.location='<?= SITE_SUBPATH ?>/admin/departments.php?org='+this.value" style="width:auto;">
        <option value="0">All Organisations</option>
        <?php foreach ($orgs as $o): ?>
        <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($o['code'] . ' — ' . $o['name']) ?>
        </option>
        <?php endforeach; ?>
    </select>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Org</th><th>Code</th><th>Name</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($depts as $d): ?>
            <tr>
                <td><code style="font-size:11px;"><?= htmlspecialchars($d['org_code']) ?></code></td>
                <td><code style="font-size:12px;"><?= htmlspecialchars($d['code']) ?></code></td>
                <td><?= htmlspecialchars($d['name']) ?></td>
                <td><?= $d['active'] ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-grey">Inactive</span>' ?></td>
                <td><?php if (!$locked): ?><a href="?edit=<?= $d['id'] ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Edit</a><?php endif; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php renderPageEnd(); ?>
