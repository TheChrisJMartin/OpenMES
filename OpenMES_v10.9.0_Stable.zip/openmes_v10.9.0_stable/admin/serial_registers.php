<?php
/**
 * admin/serial_registers.php — Serial Number Register Management
 * Version: 5.0.0
 * Maintainable by: QUALITY_ENGINEER, IT_ADMIN
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','QUALITY_ENGINEER']);

$scope   = orgScope('sr');
$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id        = (int)($_POST['id'] ?? 0);
        $orgId     = (int)($_POST['org_id'] ?? 0);
        $code      = strtoupper(trim($_POST['register_code'] ?? ''));
        $prefix    = trim($_POST['prefix'] ?? '');
        $suffix    = trim($_POST['suffix'] ?? '');
        $padLen    = max(1, min(10, (int)($_POST['pad_length'] ?? 5)));
        $startSeq  = max(0, (int)($_POST['start_seq'] ?? 0));
        $endSeq    = (int)($_POST['end_seq'] ?? 99999);
        $active    = isset($_POST['active']) ? 1 : 0;

        // Build pattern preview
        $pattern = $prefix . str_repeat('#', $padLen) . $suffix;

        if ($orgId===0)   $error = 'Please select an organisation.';
        elseif ($code==='') $error = 'Register code is required.';
        elseif ($endSeq <= $startSeq) $error = 'End sequence must be greater than start sequence.';
        else {
            try {
                if ($id === 0) {
                    $newId = dbInsert(
                        "INSERT INTO serial_registers
                            (org_id,register_code,pattern,prefix,suffix,pad_length,
                             current_seq,start_seq,end_seq,active)
                         VALUES (?,?,?,?,?,?,?,?,?,?)",
                        [$orgId,$code,$pattern,$prefix,$suffix,$padLen,$startSeq,$startSeq,$endSeq,$active]
                    );
                    writeAuditLog('REGISTER_CREATE','serial_register',(string)$newId,$orgId,null,null,
                        null,null,$code,"Created register {$code}: pattern {$pattern}");
                    $message = "Register '{$code}' created. Pattern: {$pattern}";
                } else {
                    $old = dbFetchOne("SELECT * FROM serial_registers WHERE id=?",[$id]);
                    if ($old) {
                        if ($startSeq < $old['current_seq'])
                            $error = 'Start sequence cannot be less than the current sequence (' . $old['current_seq'] . ').';
                        if (!$error) {
                            dbExecute(
                                "UPDATE serial_registers SET pattern=?,prefix=?,suffix=?,pad_length=?,
                                 end_seq=?,active=?,updated_at=NOW() WHERE id=?",
                                [$pattern,$prefix,$suffix,$padLen,$endSeq,$active,$id]
                            );
                            writeAuditLog('REGISTER_EDIT','serial_register',(string)$id,$orgId);
                            $message = "Register '{$code}' updated.";
                        }
                    }
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate') ? "Code '{$code}' already exists." : 'DB error: '.$e->getMessage();
            }
        }
    }
}

$orgs = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$filterOrg = (int)($_GET['org'] ?? 0);
$whereOrg  = $filterOrg ? 'AND sr.org_id=?' : '';
$params    = $filterOrg ? [$filterOrg] : [];

$registers = dbFetchAll(
    "SELECT sr.*, o.code AS org_code,
            (sr.end_seq - sr.current_seq) AS remaining
     FROM serial_registers sr
     JOIN orgs o ON o.id=sr.org_id
     WHERE ({$scope['sql']}) {$whereOrg}
     ORDER BY o.code, sr.register_code",
    array_merge($scope['params'], $params)
);

$editing = isset($_GET['edit'])
    ? dbFetchOne("SELECT * FROM serial_registers WHERE id=?",[(int)$_GET['edit']])
    : null;

renderPageStart('Serial Number Registers');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Serial Number Registers</h1>
        <p>Define alphanumeric serial number patterns per organisation. Managed by Quality Engineer.</p>
    </div>
    <?php if (!$editing): ?>
    <a href="?new=1" class="btn btn-primary">+ New Register</a>
    <?php endif; ?>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($editing || isset($_GET['new'])): ?>
<div class="card" style="max-width:700px;">
    <div class="card-title"><?= $editing ? 'Edit Register — ' . htmlspecialchars($editing['register_code']) : 'New Serial Register' ?></div>
    <form method="POST" onchange="updatePreview()">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing['id'] ?? 0 ?>">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
                <select name="org_id" required <?= $editing?'disabled':'' ?>>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o):
                        if (!hasPersona('IT_ADMIN') && $o['id']!=currentOrgId()) continue;
                    ?>
                    <option value="<?= $o['id'] ?>" <?= ($editing['org_id']??0)==$o['id']?'selected':'' ?>>
                        <?= htmlspecialchars($o['code'].' — '.$o['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php if ($editing): ?>
                <input type="hidden" name="org_id" value="<?= $editing['org_id'] ?>">
                <?php endif; ?>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Register Code <span style="color:var(--accent-danger)">*</span></label>
                <input type="text" name="register_code" maxlength="20"
                       value="<?= htmlspecialchars($editing['register_code']??'') ?>"
                       <?= $editing?'readonly style="opacity:.5"':'' ?>
                       placeholder="BIKE-A" required>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 80px 1fr 1fr;gap:12px;margin-top:14px;">
            <div class="form-group" style="margin:0;">
                <label>Prefix</label>
                <input type="text" name="prefix" id="prefix" maxlength="10"
                       value="<?= htmlspecialchars($editing['prefix']??'') ?>"
                       placeholder="A" oninput="updatePreview()">
            </div>
            <div class="form-group" style="margin:0;">
                <label>Pad Length <span style="color:var(--accent-danger)">*</span></label>
                <input type="number" name="pad_length" id="pad_length" min="1" max="10"
                       value="<?= $editing['pad_length']??5 ?>" oninput="updatePreview()">
                <div class="text-dim">Numeric digits</div>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Suffix</label>
                <input type="text" name="suffix" id="suffix" maxlength="10"
                       value="<?= htmlspecialchars($editing['suffix']??'') ?>"
                       placeholder="" oninput="updatePreview()">
            </div>
            <div class="form-group" style="margin:0;">
                <label>Start Sequence</label>
                <input type="number" name="start_seq" min="0"
                       value="<?= $editing['start_seq']??0 ?>">
            </div>
            <div class="form-group" style="margin:0;">
                <label>End Sequence</label>
                <input type="number" name="end_seq" min="1"
                       value="<?= $editing['end_seq']??99999 ?>">
            </div>
        </div>

        <!-- Preview -->
        <div style="margin-top:14px;padding:12px;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);">
            <div class="text-dim" style="font-size:11px;margin-bottom:6px;">PATTERN PREVIEW</div>
            <div style="display:flex;gap:16px;font-family:monospace;font-size:14px;">
                <span>First: <strong id="prev_first">—</strong></span>
                <span>Example: <strong id="prev_mid">—</strong></span>
                <span>Last: <strong id="prev_last">—</strong></span>
            </div>
        </div>

        <div class="form-group" style="margin-top:14px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                <input type="checkbox" name="active" value="1" <?= ($editing['active']??1)?'checked':'' ?>> Active
            </label>
        </div>

        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">Save Register</button>
            <a href="<?= SITE_SUBPATH ?>/admin/serial_registers.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Filter -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
    <label style="font-size:12px;color:var(--text-muted);margin:0;">Org:</label>
    <select onchange="window.location='<?= SITE_SUBPATH ?>/admin/serial_registers.php?org='+this.value" style="width:auto;">
        <option value="0">All</option>
        <?php foreach ($orgs as $o): ?>
        <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Org</th><th>Code</th><th>Pattern</th><th>Current Seq</th><th>Remaining</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($registers as $reg):
                $pct = $reg['end_seq'] > $reg['start_seq']
                    ? round((($reg['current_seq']-$reg['start_seq'])/($reg['end_seq']-$reg['start_seq']))*100)
                    : 0;
                $lowStock = $reg['remaining'] < 100;
            ?>
            <tr>
                <td><code style="font-size:11px;"><?= htmlspecialchars($reg['org_code']) ?></code></td>
                <td><code style="font-size:12px;"><?= htmlspecialchars($reg['register_code']) ?></code></td>
                <td><code style="font-size:12px;"><?= htmlspecialchars($reg['pattern']) ?></code></td>
                <td class="font-mono"><?= number_format($reg['current_seq']) ?> / <?= number_format($reg['end_seq']) ?></td>
                <td>
                    <span style="color:<?= $lowStock?'var(--accent-danger)':'inherit' ?>;">
                        <?= number_format($reg['remaining']) ?>
                        <?= $lowStock ? ' ⚠' : '' ?>
                    </span>
                </td>
                <td><?= $reg['active']?'<span class="badge badge-green">Active</span>':'<span class="badge badge-grey">Inactive</span>' ?></td>
                <td><a href="?edit=<?= $reg['id'] ?>" class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">Edit</a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$registers): ?>
            <tr><td colspan="7" style="text-align:center;color:var(--text-dim);padding:24px;">No registers defined.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function pad(n, len) { return String(n).padStart(len,'0'); }
function updatePreview() {
    const prefix  = document.getElementById('prefix')?.value  ?? '';
    const padLen  = parseInt(document.getElementById('pad_length')?.value ?? 5);
    const suffix  = document.getElementById('suffix')?.value  ?? '';
    const form    = document.querySelector('form');
    const start   = parseInt(form.querySelector('[name=start_seq]')?.value ?? 0);
    const end     = parseInt(form.querySelector('[name=end_seq]')?.value   ?? 99999);
    const mid     = Math.floor((start+end)/2);
    document.getElementById('prev_first').textContent = prefix + pad(start+1,padLen) + suffix;
    document.getElementById('prev_mid').textContent   = prefix + pad(mid,padLen)     + suffix;
    document.getElementById('prev_last').textContent  = prefix + pad(end,padLen)     + suffix;
}
updatePreview();
</script>

<?php renderPageEnd(); ?>
