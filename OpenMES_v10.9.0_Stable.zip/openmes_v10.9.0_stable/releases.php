<?php
/**
 * releases.php — ChrisMES Release Notes
 * Version: 10.5.3
 * F001: Release notes accessible from nav — all releases listed with
 *       features (Fxxx) and defects (Dxxx) tracked per release.
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/layout.php';

requireLogin();

// ── Release data ──────────────────────────────────────────────────────────────
// Format: [ 'version', 'date', 'type', 'summary', [ ['ID', 'TYPE', 'desc'], ... ] ]
// TYPE: FEATURE | DEFECT | CHANGE
$releases = [
    [
        'version' => '10.8.5',
        'date'    => '2026-05-22',
        'type'    => 'Hotfix',
        'summary' => 'D035 nav scrollbar definitive fix using overflow-y:overlay. .htaccess files for web root and uploads directory. D031 6M cause category UI fix. Quality Analytics cross-revision query. Test suite improvements.',
        'items'   => [
            ['D035',  'DEFECT',  'Nav scrollbar: switched to overflow-y:overlay — scrollbar now floats on top of content taking zero layout space, closing the 1px gap between sidebar and main content confirmed via live browser inspection (sidebar clientWidth was 239px vs 240px margin-left on main).'],
            ['D031',  'DEFECT',  '6M cause category dropdown was missing from NC disposition form — UI injection failed on original build due to label mismatch. Now correctly shows Man/Machine/Method/Material/Measurement/Environment selector.'],
            ['F083',  'DEFECT',  'Quality Analytics: results query now matches by quality variable code across all routing revisions — previously only matched the exact qv_id so measurements taken on an earlier routing revision were not shown.'],
            ['SEC01', 'DEFECT',  'Web root .htaccess deployed — blocks config.php direct access, SQL/MD files, deploy backups. Security headers via mod_headers.'],
            ['SEC02', 'DEFECT',  'uploads/documents/.htaccess deployed — blocks PHP execution and direct PDF access in uploads directory.'],
            ['D036',  'DEFECT',  'Non-Conformances nav label corrected to Non-Conformance (hyphenated) — was showing without hyphen on older layout.php.'],
            ['F084',  'FEATURE', 'Automated Test Suite at Administration > Test Suite (IT Admin only). 119 tests across 8 categories: PHP Syntax, Database Tables, Schema, Configuration, File System, Security, Business Data, PHP Environment. PHP syntax detection uses token_get_all() parse error capture. config(2).php test removed as not relevant on clean installs.'],
            ['F075b', 'FEATURE', 'Deploy feature: SQL patch parser improved — strips comment lines per chunk before filtering, preventing comment headers from swallowing real statements. Statement count shown in log. array_merge spread operator replaced with safe foreach loop.'],
            ['F076b', 'FEATURE', 'GitHub update check documented in releases. Checks TheChrisJMartin/OpenMES releases API. Result cached 1 hour in update_check_cache table. Update button shown on dashboard when newer version available.'],
        ],
    ],
    [
        'version' => '10.8.0',
        'date'    => '2026-05-22',
        'type'    => 'Feature + Defect Release',
        'summary' => 'OpenMES v10.8.0. D030 QV change control on approved routings. D031 6M cause category UI. D035 nav scrollbar fix. F054 work instructions open in new tab. F043 Planner Code. F061 WITHDRAWN docs. F062 FAI flag. F068 BTS release record. F072 Corrective Action. F073 NC Trend Analysis.',
        'items'   => [
            ['D030', 'DEFECT',  'QV changes blocked on APPROVED routings (ISA-95 GAP-009, ISO-9001 Clause 8.5.6). Banner shown with instructions to create a new routing revision. QV_BYPASS config switch available for dev environments.'],
            ['D031', 'DEFECT',  '6M cause category selector added to NC disposition screen (Man, Machine, Method, Material, Measurement, Environment).'],
            ['D035', 'DEFECT',  'Nav scrollbar: thin scrollbar via scrollbar-width:thin (Firefox) and ::-webkit-scrollbar (Chrome/Edge). 4px scrollbar contained within sidebar boundary.'],
            ['F054', 'FEATURE', 'Work instruction PDFs now open in a new browser tab via serve_pdf.php. Inline PDF panel removed from operator screen. Button shows when clocked on to an operation with a document attached.'],
            ['F043', 'FEATURE', 'Planner Code field added to Parts create/edit screen (DB column existed since v10.5.3).'],
            ['F061', 'FEATURE', 'WITHDRAWN document status added. Document owner and review date fields on upload screen. WITHDRAWN documents cannot be added to new routings.'],
            ['F062', 'FEATURE', 'First Article Inspection (FAI) flag on work order creation. Marks first serial on a new routing revision for mandatory inspection (ISO-9001 Clause 8.1).'],
            ['F068', 'FEATURE', 'Formal release record added to Book to Stock action — records approver identity, date/time, and confirmation note in wo_stock_bookings.'],
            ['F072', 'FEATURE', 'Corrective action record on NC disposition: systemic fix description, CA owner, due date, and effectiveness review date (ISO-9001 Clause 10.2). Stored in nc_corrective_actions table.'],
            ['F073', 'FEATURE', 'NC trend analysis panels in Analytics: by cause category (horizontal bar, 6M colour coded) and daily NC count trend line. Filtered to selected org and date range.'],
        ],
    ],
    [
        'version' => '10.6.0',
        'date'    => '2026-05-22',
        'type'    => 'Security Hardening + Feature Release',
        'summary' => '16 cyber defects resolved. In-app deployer with SQL execution and schema versioning (F075). GitHub auto-update check (F076). SITE_VERSION moved to DB (F078/F079). Nav scrollbar fix (D035). R25 Licensing Model added to roadmap.',
        'items'   => [
            ['CD001', 'DEFECT',  '.htaccess deny rule added to protect config.php from direct browser access'],
            ['CD002', 'DEFECT',  'setup_passwords.php blocked via .htaccess and removed from deployment'],
            ['CD003', 'DEFECT',  'CSRF tokens added to all POST forms across 17 files'],
            ['CD004', 'DEFECT',  'HTTP security headers added: X-Frame-Options, X-Content-Type-Options, Referrer-Policy, HSTS'],
            ['CD005', 'DEFECT',  'Login rate limiting: 5 failures = 2s delay, 10 failures = 15min lockout per username and IP'],
            ['CD006', 'DEFECT',  'htmlspecialchars() applied to remaining unescaped DB-sourced outputs'],
            ['CD007', 'DEFECT',  'PDF upload MIME type verified using finfo_file() — extension check alone no longer sufficient'],
            ['CD008', 'DEFECT',  '.htaccess added to uploads/documents/ blocking PHP execution and direct file access'],
            ['CD009', 'DEFECT',  'Session cookie hardened: Secure, HttpOnly, SameSite=Strict'],
            ['CD010', 'DEFECT',  'display_errors=0 added to config.php'],
            ['CD011', 'DEFECT',  'Content-Disposition filename in serve_pdf.php sanitised with preg_replace'],
            ['CD012', 'DEFECT',  'Loose == comparisons replaced with strict === in nc_disposition.php and book_stock.php'],
            ['CD013', 'DEFECT',  'Accepted risk — sequential IDs in URLs. UUID migration deferred indefinitely'],
            ['CD014', 'DEFECT',  'config (2).php blocked via .htaccess'],
            ['CD015', 'DEFECT',  'Password confirmation required when granting IT_ADMIN persona'],
            ['CD016', 'DEFECT',  'display_errors and error_reporting configured explicitly in config.php'],
            ['D035',  'DEFECT',  'Left nav scrollbar gap fixed — overflow-x:hidden on body and .main; min-width:0 on .main'],
            ['F075',  'FEATURE', 'In-app deployment manager at Administration > Deploy. Upload zip, review SQL patches, type CONFIRM to execute. All deployments logged. Schema version tracked in schema_version table'],
            ['F076',  'FEATURE', 'GitHub auto-update check on dashboard (IT Admin only). Checks TheChrisJMartin/OpenMES releases. Result cached 1 hour. GITHUB_RELEASE_URL configurable in system config'],
            ['F078',  'FEATURE', 'SITE_VERSION moved from config.php to system_config DB table'],
            ['F079',  'FEATURE', 'Deployer writes SITE_VERSION to system_config after every successful deployment'],
            ['F080',  'FEATURE', 'R25 Licensing Model added to roadmap (requirements TBD)'],
        ],
    ],
    [
        'version' => '10.5.5',
        'date'    => '2026-05-19',
        'type'    => 'Roadmap Update',
        'summary' => 'ISO-9001:2015 gap analysis complete (ChrisMES-ISO9001-GAP-001). Findings identified and loaded into roadmap as planned features for future sprints. R11 and R12 marked In Progress (research done, not yet built). R13 expanded with quality system improvement features.',
        'items'   => [
            ['F055', 'FEATURE', 'Identified from ISO-001/002: QMS context and stakeholder requirement fields (planned R13)'],
            ['F056', 'FEATURE', 'Identified from ISO-003: QMS process gate enforcement and process map (planned R13)'],
            ['F057', 'FEATURE', 'Identified from ISO-006: Risk classification on NCs — likelihood, severity, risk score (planned)'],
            ['F058', 'FEATURE', 'Identified from ISO-007: Quality objective targets with RAG status in Analytics (planned R13)'],
            ['F059', 'FEATURE', 'Identified from ISO-009/Clause 7.1.5: Calibration certificate attachment and history log (planned R13)'],
            ['F060', 'FEATURE', 'Identified from ISO-011: Quality policy text and operator acknowledgement (planned)'],
            ['F061', 'FEATURE', 'Identified from ISO-013/Clause 7.5: WITHDRAWN document status; review date and owner fields (planned R13)'],
            ['F062', 'FEATURE', 'Identified from ISO-014/Clause 8.1: First Article Inspection (FAI) flag on work orders (planned R13)'],
            ['F063', 'FEATURE', 'Identified from ISO-015: Customer order reference field on work orders (planned)'],
            ['F064', 'FEATURE', 'Identified from ISO-017/Clause 8.4: Supplier register and quality ratings (planned R14)'],
            ['F065', 'FEATURE', 'Identified from ISO-018: Environment as a quality variable type (planned)'],
            ['F066', 'FEATURE', 'Identified from ISO-020: Customer-supplied flag on serial numbers and tools (planned)'],
            ['F067', 'FEATURE', 'Identified from ISO-021: Shelf-life expiry enforcement at WO creation and Book to Stock (planned)'],
            ['F068', 'FEATURE', 'Identified from ISO-023/Clause 8.6: Formal release record with approver on Book to Stock (planned R13)'],
            ['F069', 'FEATURE', 'Identified from ISO-025/Clause 9.1: Period-over-period trend comparison in Analytics (planned R13)'],
            ['F070', 'FEATURE', 'Identified from ISO-026/Clause 9.2: Audit data export feature (planned R13)'],
            ['F071', 'FEATURE', 'Identified from ISO-027: Management review record (planned)'],
            ['F072', 'FEATURE', 'Identified from ISO-029/Clause 10.2: Corrective action record on NC disposition (planned R13)'],
            ['F073', 'FEATURE', 'Identified from ISO-029/Clause 10.2: NC trend analysis in Analytics (planned R13)'],
            ['F074', 'FEATURE', 'Roadmap: R11 ISA-95 and R12 ISO-9001 marked In Progress (research complete, implementation not yet started). R13 expanded with F044/F059/F061/F062/F064/F068/F069/F070/F072/F073 identified from both reviews.'],
        ],
    ],
    [
        'version' => '10.5.4',
        'date'    => '2026-05-19',
        'type'    => 'Feature + Bug Fix + Roadmap Update',
        'summary' => 'ISA-95 gap analysis complete (ChrisMES-ISA95-GAP-001). 20 findings identified and loaded into roadmap as planned features for future sprints. PDF viewer fix. Roadmap renumbered R11=ISA-95 through R23.',
        'items'   => [
            ['D033', 'DEFECT',  'Work instruction PDFs not scrollable — full A4 page content not visible. Fixed: canvas now renders at fit-width scale inside a scrollable container with max-height 80vh. Fit, zoom in, and zoom out buttons provided.'],
            ['D034', 'DEFECT',  'NC modal and Hard Hold alerts in operator screen still referenced "Full Hold" instead of "Hard Hold" — corrected throughout operator.php'],
            ['F036', 'FEATURE', 'Identified from ISA-95 GAP-001: Site-level hierarchy mapping — formal 4-to-5 level mapping (planned for future sprint)'],
            ['F037', 'FEATURE', 'Identified from ISA-95 GAP-002: Persona-to-ISA-95 role mapping document (planned)'],
            ['F038', 'FEATURE', 'Identified from ISA-95 GAP-003: Level 3/4 boundary document (planned)'],
            ['F039', 'FEATURE', 'Identified from ISA-95 GAP-004: Qualification levels on Skills Library (planned)'],
            ['F040', 'FEATURE', 'Identified from ISA-95 GAP-005: Personnel Class concept — prerequisite for Supervisor Planner (planned)'],
            ['F041', 'FEATURE', 'Identified from ISA-95 GAP-006: Equipment capability attributes on Resources (planned)'],
            ['F042', 'FEATURE', 'Identified from ISA-95 GAP-007: Material lot genealogy — deferred to R14 Receiving Inspection'],
            ['F043', 'FEATURE', 'Identified from ISA-95 GAP-008: Planner Code UI on Parts screen — DB column added v10.5.3, UI planned for R13'],
            ['F044', 'FEATURE', 'Identified from ISA-95 GAP-009 and ISO-9001 Clause 8.5.6: D030 fix — QV changes on approved routing must trigger new revision (planned R13, highest priority)'],
            ['F045', 'FEATURE', 'Identified from ISA-95 GAP-012: WorkOrderIN processing from ERP (planned R13)'],
            ['F046', 'FEATURE', 'Identified from ISA-95 GAP-013: Supervisor dispatching (planned R22 Supervisor Planner)'],
            ['F047', 'FEATURE', 'Identified from ISA-95 GAP-015: Indirect labour suppression and non-productive bookings (planned R23)'],
            ['F048', 'FEATURE', 'Identified from ISA-95 GAP-016: PASS/FAIL/CONDITIONAL quality result codes + WorkOrderOUT inclusion (planned R13)'],
            ['F049', 'FEATURE', 'Identified from ISA-95 GAP-017: Planned vs actual hours in WorkOrderOUT (planned R13)'],
            ['F050', 'FEATURE', 'Identified from ISA-95 GAP-018: OEE calculation in Analytics + KPI export (planned R13)'],
            ['F051', 'FEATURE', 'Identified from ISA-95 GAP-019: Maintenance Management — future sprint requirement TBD'],
            ['F052', 'FEATURE', 'Identified from ISA-95 GAP-020: WIP location tracking at workstation level (planned R13)'],
            ['F053', 'FEATURE', 'Roadmap renumbered: R11=ISA-95 Review (in progress), R12=ISO-9001 Review (in progress), R13=Advanced Features (was R11), R22=Supervisor Planner, R23=Non-Productive Bookings'],
        ],
    ],
    [
        'version' => '10.5.3',
        'date'    => '2026-05-19',
        'type'    => 'Feature + Bug Fix',
        'summary' => 'Routing integrity, security logging improvements, scrap WORKORDEROUT, 6M NC categories, planner code, default op 999.',
        'items'   => [
            ['D001', 'DEFECT',  'Archive routing blocked if active work orders exist on that routing revision'],
            ['D002', 'DEFECT',  'Routing delete policy clarified — DRAFT routings with no work orders can have all operations deleted (they were never used). Only APPROVED/SUPERSEDED routings are permanently protected from modification'],
            ['D003', 'DEFECT',  'Persona/role change on a user now raises a HIGH severity security log entry'],
            ['D004', 'DEFECT',  'Organisation type (OE/MRO) is now read-only after creation — displayed as locked field'],
            ['D005', 'DEFECT',  'Scrap via NC disposition now fires WORKORDEROUT integration message; if all serials scrapped/complete the WO auto-completes'],
            ['F001', 'FEATURE', 'Release Notes page added to navigation (Administration → Release Notes) — all releases listed with feature/defect IDs'],
            ['F002', 'FEATURE', 'Planner Code field added to Item Master (parts table)'],
            ['F003', 'FEATURE', 'New routings automatically get a default op 999 (Book to Stock, Non-Clocking) on creation'],
            ['F004', 'FEATURE', '6M cause categories added to Non-Conformances (Man, Machine, Method, Material, Measurement, Environment)'],
            ['D028', 'DEFECT',  'Quality Variables nav link missing from layout.php — never carried forward from v10.1.0 into subsequent layout versions'],
            ['D029', 'DEFECT',  'Quality Variables tab missing from routing editor edit.php — tab injection from v10.0.0 not carried into v10.5.3 copy'],
            ['F028', 'FEATURE', 'ISA-95 compliance review sprint planned — review system hierarchy, data model and integration interfaces against ISA-95; results will generate further feature requirements'],
            ['F029', 'FEATURE', 'ISO-9001 compliance review sprint planned — review quality management processes against ISO-9001:2015; results will generate further feature requirements'],
        ],
    ],
    [
        'version' => '10.5.2',
        'date'    => '2026-05-19',
        'type'    => 'Hot Fix',
        'summary' => 'Login error and config toggle fixes.',
        'items'   => [
            ['D006', 'DEFECT', 'Fatal error on login — writeSecurityLog() undefined because helpers.php not yet loaded at auth time'],
            ['D007', 'DEFECT', 'Config screen boolean toggles not responding — double-toggle caused by redundant onclick on track div'],
        ],
    ],
    [
        'version' => '10.5.1',
        'date'    => '2026-05-19',
        'type'    => 'Roadmap Update',
        'summary' => 'SAML / SSO Integration sprint added as R15.',
        'items'   => [
            ['F005', 'FEATURE', 'R15.0.0 — SAML / SSO Integration added to roadmap (Azure AD, Okta, Google Workspace, ADFS; JIT provisioning, role mapping, SLO)'],
        ],
    ],
    [
        'version' => '10.5.0',
        'date'    => '2026-05-19',
        'type'    => 'Feature + Bug Fix',
        'summary' => 'Hold type redesign (HARD/SOFT), WO view improvements, security log, supervisor enhancements, WORKORDEROUT, OE/MRO org type, R14 roadmap.',
        'items'   => [
            ['D008', 'DEFECT',  'Analytics fatal error — nc.created_at column does not exist; corrected to nc.raised_at'],
            ['D009', 'DEFECT',  'Execute button shown on completed work orders in supervisor view'],
            ['D010', 'DEFECT',  'api/get_routings.php missing opening <?php tag — served as plain text'],
            ['D011', 'DEFECT',  'Work order create — parts not populating after org selection (orgScope alias missing)'],
            ['D012', 'DEFECT',  'Work order create — control type dropdown present; should auto-derive from part'],
            ['D013', 'DEFECT',  'onRoutingChange() missing closing brace broke all JS on work order create page'],
            ['D014', 'DEFECT',  'Hold type FULL rejected by DB after ENUM change to HARD/SOFT — raise_nc.php, submit_qv.php, nc_disposition.php still wrote FULL'],
            ['D015', 'DEFECT',  'ON HOLD + SOFT HOLD shown as two separate badges — redundant; now shows single contextual badge'],
            ['F006', 'FEATURE', 'Hard Hold (red, blocks clock-on) and Soft Hold (amber, blocks completion only) replace legacy FULL hold type'],
            ['F007', 'FEATURE', 'WO view: no Operator Screen button on COMPLETE/CANCELLED WOs; Analytics & Audit link shown instead'],
            ['F008', 'FEATURE', 'WO view: last operator shown per serial number in WO Detail tab'],
            ['F009', 'FEATURE', 'WO view: Standard Time label and efficiency % in Time Bookings tab'],
            ['F010', 'FEATURE', 'WO view: Planned Setup / Planned Actual labels in Routing tab'],
            ['F011', 'FEATURE', 'WO view: Quality Records enriched with spec position indicator and tools/TE used'],
            ['F012', 'FEATURE', 'WO view: Op completions written to Change Log with op number'],
            ['F013', 'FEATURE', 'Security Log — login events and role changes recorded with IP, user agent, severity'],
            ['F014', 'FEATURE', 'WORKORDEROUT integration message fired on every operation completion'],
            ['F015', 'FEATURE', 'Supervisor view — std-time progress %, planned start/finish, priority, overdue highlighting'],
            ['F016', 'FEATURE', 'Work order creation — priority, planned start/finish, control type auto-set from part'],
            ['F017', 'FEATURE', 'Org type OE/MRO on creation; R14 Repairs/MRO sprint added to roadmap'],
        ],
    ],
    [
        'version' => '10.1.0',
        'date'    => '2026-05-19',
        'type'    => 'Patch',
        'summary' => 'Quality Variables nav link and operator screen measurement panel wired in.',
        'items'   => [
            ['D016', 'DEFECT',  'No navigation link to Quality Variables — required navigating through routing list'],
            ['D017', 'DEFECT',  'Quality variable collection panel not wired into operator screen — api/submit_qv.php existed but was never called'],
            ['D018', 'DEFECT',  'operator.php parse error — unclosed brace in QV data loading block'],
        ],
    ],
    [
        'version' => '10.0.0',
        'date'    => '2026-05-19',
        'type'    => 'Feature Release — Sprint 10',
        'summary' => 'Quality Variables, out-of-spec NC trigger, Analytics dashboard.',
        'items'   => [
            ['F018', 'FEATURE', 'Quality variables defined per routing on Inspection/Test operations'],
            ['F019', 'FEATURE', 'Quality measurement collection during operator execution; out-of-spec auto-raises NC'],
            ['F020', 'FEATURE', 'Complete and Book to Stock blocked until all quality measurements recorded'],
            ['F021', 'FEATURE', 'Analytics dashboard — throughput, labour efficiency, bottlenecks, operator utilisation, first-pass yield'],
        ],
    ],
    [
        'version' => '9.0.0',
        'date'    => '2026-05-19',
        'type'    => 'Feature Release — Sprint 9',
        'summary' => 'Calibration database, operator skills, Quality Training Manager persona.',
        'items'   => [
            ['F022', 'FEATURE', 'Calibration database — T-prefix tools, TE-prefix test equipment, expiry enforcement'],
            ['F023', 'FEATURE', 'Skills library and training matrix — Quality Training Manager persona'],
            ['F024', 'FEATURE', 'Skill gate enforcement on routing operations — CLOCK_ON, COMPLETION, BOTH'],
            ['F025', 'FEATURE', '30-day skill expiry dashboard warning for Quality Training Managers'],
        ],
    ],
    [
        'version' => '8.3.0',
        'date'    => '2026-05-19',
        'type'    => 'Roadmap Update',
        'summary' => 'Roadmap restructured — R9 through R13 defined.',
        'items'   => [
            ['F026', 'FEATURE', 'Roadmap restructured: R9 Tooling/Skills, R10 QV/ERP, R11 Advanced, R12 Receiving Inspection, R13 Auth Profiles'],
        ],
    ],
    [
        'version' => '8.2.0',
        'date'    => '2026-05-19',
        'type'    => 'Hot Fix',
        'summary' => 'Clock-on false positive across work orders.',
        'items'   => [
            ['D019', 'DEFECT', 'Clock-on cross-WO false positive — wo_active_clocks conflict check lacked wo_id filter; TEACL0000003 blocked by TEACL0000001 op 40'],
        ],
    ],
    [
        'version' => '8.1.0',
        'date'    => '2026-05-19',
        'type'    => 'Feature + Bug Fix',
        'summary' => 'Broadcast messages, clock-on fix, correct file locations.',
        'items'   => [
            ['D020', 'DEFECT',  'Clock-on false positive — wo_active_clocks check had no user_id or op_id filter'],
            ['D021', 'DEFECT',  'Broadcast admin file in wrong directory (routings/ instead of admin/)'],
            ['D022', 'DEFECT',  'Broadcast banner never displayed — MES_APP guard incompatible with layout.php include pattern'],
            ['D023', 'DEFECT',  'broadcast_save.php called non-existent verifyCsrfToken() and auditLog() functions'],
            ['F027', 'FEATURE', 'System-wide broadcast banner — IT Admin sets 128-char message with Red/Yellow/Green colour'],
        ],
    ],
];

renderPageStart('Release Notes');
?>

<div class="page-header">
    <h1>Release Notes</h1>
    <p>Change history — features (F) and defects (D) tracked per release.</p>
</div>

<?php foreach ($releases as $rel):
    $featureCount = count(array_filter($rel['items'], fn($i) => $i[1] === 'FEATURE'));
    $defectCount  = count(array_filter($rel['items'], fn($i) => $i[1] === 'DEFECT'));
?>
<div class="card" style="margin-bottom:16px;padding:0;overflow:hidden;">
    <!-- Release header -->
    <div style="padding:12px 16px;background:var(--bg);border-bottom:1px solid var(--border);
                display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <code style="font-size:15px;font-weight:800;color:var(--accent-blue);">v<?= htmlspecialchars($rel['version']) ?></code>
        <span style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($rel['date']) ?></span>
        <span class="badge badge-grey" style="font-size:11px;"><?= htmlspecialchars($rel['type']) ?></span>
        <?php if ($featureCount > 0): ?>
        <span class="badge badge-green" style="font-size:10px;"><?= $featureCount ?> feature<?= $featureCount!==1?'s':'' ?></span>
        <?php endif; ?>
        <?php if ($defectCount > 0): ?>
        <span class="badge badge-red" style="font-size:10px;"><?= $defectCount ?> fix<?= $defectCount!==1?'es':'' ?></span>
        <?php endif; ?>
        <span style="margin-left:auto;font-size:12px;color:var(--text-muted);font-style:italic;">
            <?= htmlspecialchars($rel['summary']) ?>
        </span>
    </div>
    <!-- Items -->
    <div style="padding:12px 16px;">
        <?php foreach ($rel['items'] as $item):
            $isDefect = $item[1] === 'DEFECT';
            $badgeClass = $isDefect ? 'badge-red' : 'badge-green';
            $icon       = $isDefect ? '🐛' : '✨';
        ?>
        <div style="display:flex;gap:10px;align-items:flex-start;padding:5px 0;
                    border-bottom:1px solid var(--border-subtle, rgba(128,128,128,.1));">
            <code style="font-size:11px;font-weight:700;color:var(--accent-blue);
                         white-space:nowrap;padding-top:1px;"><?= htmlspecialchars($item[0]) ?></code>
            <span class="badge <?= $badgeClass ?>" style="font-size:9px;flex-shrink:0;margin-top:2px;">
                <?= $icon ?> <?= $item[1] ?>
            </span>
            <span style="font-size:13px;color:var(--text);"><?= htmlspecialchars($item[2]) ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>

<?php renderPageEnd(); ?>
