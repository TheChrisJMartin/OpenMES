<?php
/**
 * routings/quality_vars.php — Quality Variables for a Routing
 * Version: 10.0.0
 * Description: Define quality variables against inspection/test operations
 *              on a routing. Linked from the routing editor as a second tab.
 *              MFG_ENGINEER, MFG_ENGINEER_SUP, IT_ADMIN, QUALITY_ENGINEER can edit.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER']);

$routingId = (int)($_GET['id'] ?? 0);
$scope     = orgScope('r');
$message   = '';
$error     = '';

$routing = dbFetchOne(
    "SELECT r.*, p.part_number, p.description AS part_desc, o.code AS org_code
       FROM routings r
       JOIN parts p ON p.id = r.part_id
       JOIN orgs   o ON o.id = r.org_id
      WHERE r.id=? AND ({$scope['sql']})",
    array_merge([$routingId], $scope['params'])
);

if (!$routing) {
    renderPageStart('Not Found');
    echo '<div class="alert alert-danger">Routing not found.</div>';
    echo '<a href="'.SITE_SUBPATH.'/routings/list.php" class="btn btn-secondary">← Routings</a>';
    renderPageEnd(); exit;
}

$canEdit = hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','QUALITY_ENGINEER'])
           && $routing['status'] === 'DRAFT';

// Check if a DRAFT revision exists for this routing (different ID, same part+org)
$draftRevision = null;
if ($routing['status'] === 'APPROVED') {
    $draftRevision = dbFetchOne(
        "SELECT id FROM routings WHERE part_id=? AND org_id=? AND status='DRAFT' ORDER BY id DESC LIMIT 1",
        [$routing['part_id'], $routing['org_id']]
    );
};

// Only INSPECTION / FINAL_TEST / FINAL_INSPECTION ops are valid targets
$eligibleOps = dbFetchAll(
    "SELECT id, op_number, op_name, op_type
       FROM routing_operations
      WHERE routing_id=?
        AND op_type IN ('INSPECTION','FINAL_TEST','FINAL_INSPECTION')
      ORDER BY sort_order, op_number",
    [$routingId]
);

$uoms = dbFetchAll("SELECT id, code, name FROM uom ORDER BY code");

// ── POST ──────────────────────────────────────────────────────────────────────
if ($canEdit && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id     = (int)($_POST['qv_id'] ?? 0);

    if ($action === 'delete' && $id) {
        dbExecute("UPDATE quality_variables SET active=0, updated_at=NOW() WHERE id=? AND routing_id=?",
            [$id, $routingId]);
        writeAuditLog('QV_DELETE','quality_variables',(string)$id,$routing['org_id'],null,null,
            null,null,null,"Deactivated quality variable ID {$id} on routing {$routing['routing_number']}");
        $message = 'Quality variable removed.';
    } else {
        $opId   = (int)($_POST['op_id']      ?? 0);
        $code   = strtoupper(trim($_POST['code']   ?? ''));
        $name   = trim($_POST['name']          ?? '');
        $qvType = in_array($_POST['qv_type'] ?? '', ['NUMERIC','PASS_FAIL','YES_NO'])
                  ? $_POST['qv_type'] : 'NUMERIC'; // F048
        // F048b: Auto-assign system UoM for binary variable types
        if ($qvType === 'PASS_FAIL') {
            $pfUom = dbFetchOne("SELECT id FROM uom WHERE code='P/F' AND is_system=1 LIMIT 1");
            $uomId = $pfUom ? (int)$pfUom['id'] : null;
        } elseif ($qvType === 'YES_NO') {
            $ynUom = dbFetchOne("SELECT id FROM uom WHERE code='Y/N' AND is_system=1 LIMIT 1");
            $uomId = $ynUom ? (int)$ynUom['id'] : null;
        } else {
            $uomId = ((int)($_POST['uom_id'] ?? 0)) ?: null;
        }
        $lower  = trim($_POST['lower_limit']   ?? '') !== '' ? (float)$_POST['lower_limit']  : null;
        $upper  = trim($_POST['upper_limit']   ?? '') !== '' ? (float)$_POST['upper_limit']  : null;
        $target = trim($_POST['target_value']  ?? '') !== '' ? (float)$_POST['target_value'] : null;
        $active = isset($_POST['active']) ? 1 : 0;

        // Validate op belongs to this routing and is eligible
        $validOp = array_filter($eligibleOps, fn($o) => $o['id'] === $opId);

        if (!$opId || !$validOp) {
            $error = 'Please select an Inspection or Test operation.';
        } elseif ($code === '') {
            $error = 'Code is required.';
        } elseif ($name === '') {
            $error = 'Name is required.';
        } elseif ($lower !== null && $upper !== null && $lower >= $upper) {
            $error = 'Lower limit must be less than upper limit.';
        } else {
            try {
                if ($id === 0) {
                    $newId = dbInsert(
                        "INSERT INTO quality_variables
                            (routing_id,op_id,org_id,code,name,uom_id,qv_type,
                             lower_limit,upper_limit,target_value,active,created_by)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        [$routingId,$opId,$routing['org_id'],$code,$name,$uomId,$qvType,
                         $lower,$upper,$target,$active,$_SESSION['user_id']]
                    );
                    writeAuditLog('QV_CREATE','quality_variables',(string)$newId,$routing['org_id'],null,null,
                        null,null,$code,"Created QV: {$code} on routing {$routing['routing_number']}");
                    $message = "Quality variable '{$code}' added.";
                } else {
                    dbExecute(
                        "UPDATE quality_variables
                            SET op_id=?,code=?,name=?,uom_id=?,qv_type=?,
                                lower_limit=?,upper_limit=?,target_value=?,active=?,updated_at=NOW()
                          WHERE id=? AND routing_id=?",
                        [$opId,$code,$name,$uomId,$lower,$upper,$target,$active,$id,$routingId]
                    );
                    writeAuditLog('QV_EDIT','quality_variables',(string)$id,$routing['org_id'],null,null,
                        null,null,null,"Updated QV: {$code} on routing {$routing['routing_number']}");
                    $message = "Quality variable '{$code}' updated.";
                }
            } catch (PDOException $e) {
                $error = str_contains($e->getMessage(),'Duplicate')
                    ? "Code '{$code}' already exists on this routing."
                    : 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// ── Fetch variables ───────────────────────────────────────────────────────────
$variables = dbFetchAll(
    "SELECT qv.*, ro.op_number, ro.op_name, ro.op_type, u.code AS uom_code
       FROM quality_variables qv
       JOIN routing_operations ro ON ro.id = qv.op_id
       LEFT JOIN uom u ON u.id = qv.uom_id
      WHERE qv.routing_id=? AND qv.active=1
      ORDER BY ro.sort_order, ro.op_number, qv.code",
    [$routingId]
);

$editVar = null;
if (isset($_GET['edit_qv'])) {
    $editVar = dbFetchOne(
        "SELECT * FROM quality_variables WHERE id=? AND routing_id=?",
        [(int)$_GET['edit_qv'], $routingId]
    );
}

renderPageStart('Quality Variables — ' . $routing['routing_number']);
?>

<!-- Tab nav -->
<div style="display:flex;gap:0;margin-bottom:16px;border-bottom:2px solid var(--border);">
    <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $routingId ?>"
       style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--text-muted);
              text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;">
        Operations
    </a>
    <a href="<?= SITE_SUBPATH ?>/routings/op_tools.php?id=<?= $routingId ?>"
       style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--text-muted);
              text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;">
        Required Tools
    </a>
    <span style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--accent-blue);
                 border-bottom:2px solid var(--accent-blue);margin-bottom:-2px;">
        Quality Variables
    </span>
</div>

<div class="page-header page-header-row" style="margin-bottom:12px;">
    <div>
        <a href="<?= SITE_SUBPATH ?>/routings/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Routings</a>
        <h1 style="margin-top:4px;"><?= htmlspecialchars($routing['routing_number']) ?> — Quality Variables</h1>
        <p><?= htmlspecialchars($routing['part_desc']) ?> &mdash; Rev <code><?= htmlspecialchars($routing['revision_label']) ?></code></p>
    </div>
    <?= routingStatusBadge($routing['status']) ?>
</div>

<?php if (!$eligibleOps): ?>
<div class="alert alert-warning">
    ⚠ No Inspection or Test operations exist on this routing. Add an operation with type
    <strong>Inspection</strong>, <strong>Final Test</strong>, or <strong>Final Inspection</strong>
    before defining quality variables.
</div>
<?php endif; ?>

<?php if ($routing['status'] === 'APPROVED'): ?>
<div class="alert alert-danger" style="margin-bottom:14px;">
    ⚠ <strong>You are viewing the APPROVED revision (Rev <?= htmlspecialchars($routing['revision_label']) ?>).</strong>
    Quality variables cannot be modified on an approved routing.
    <?php if ($draftRevision): ?>
    <a href="<?= SITE_SUBPATH ?>/routings/quality_vars.php?id=<?= (int)$draftRevision['id'] ?>"
       class="btn btn-primary" style="font-size:12px;padding:4px 14px;margin-left:10px;">
        Switch to DRAFT revision →
    </a>
    <?php else: ?>
    Go to the routing list and open the DRAFT revision, or create a new revision.
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr <?= ($canEdit && $eligibleOps) ? '320px' : '' ?>;gap:16px;align-items:start;">

<!-- Variables table -->
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;">
        <span style="font-weight:600;font-size:14px;">Defined Variables</span>
        <span class="text-dim" style="font-size:12px;"><?= count($variables) ?> defined</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Name</th>
                    <th>Operation</th>
                    <th>Lower</th>
                    <th>Target</th>
                    <th>Upper</th>
                    <th>UoM</th>
                    <?php if ($canEdit): ?><th></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($variables)): ?>
                <tr><td colspan="<?= $canEdit ? 8 : 7 ?>" style="text-align:center;color:var(--text-dim);padding:24px;">
                    No quality variables defined.<?= $canEdit ? ' Add one using the form →' : '' ?>
                </td></tr>
            <?php else: ?>
            <?php foreach ($variables as $v): ?>
            <tr>
                <td><code style="color:var(--accent-blue);font-weight:700;"><?= htmlspecialchars($v['code']) ?></code></td>
                <td><?= htmlspecialchars($v['name']) ?></td>
                <td>
                    <code style="font-size:11px;"><?= str_pad($v['op_number'],3,'0',STR_PAD_LEFT) ?></code>
                    <span class="text-dim" style="font-size:11px;">— <?= htmlspecialchars($v['op_name']) ?></span>
                </td>
                <td style="font-family:monospace;font-size:12px;"><?= $v['lower_limit'] !== null ? $v['lower_limit'] : '—' ?></td>
                <td style="font-family:monospace;font-size:12px;color:var(--accent-blue);"><?= $v['target_value'] !== null ? $v['target_value'] : '—' ?></td>
                <td style="font-family:monospace;font-size:12px;"><?= $v['upper_limit'] !== null ? $v['upper_limit'] : '—' ?></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($v['uom_code'] ?? '—') ?></code></td>
                <?php if ($canEdit): ?>
                <td style="white-space:nowrap;">
                    <a href="?id=<?= $routingId ?>&edit_qv=<?= $v['id'] ?>#qv-form"
                       class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">Edit</a>
                    <form method="POST" style="display:inline;"
                          onsubmit="return confirm('Remove quality variable <?= htmlspecialchars(addslashes($v['code'])) ?>?')">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="qv_id"  value="<?= $v['id'] ?>">
                        <button class="btn btn-danger" style="padding:3px 7px;font-size:11px;">✕</button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($canEdit && $eligibleOps): ?>
<!-- Add/Edit form -->
<div class="card" id="qv-form">
    <div class="card-title"><?= $editVar ? 'Edit Variable' : 'Add Quality Variable' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="qv_id" value="<?= $editVar['id'] ?? 0 ?>">

        <div class="form-group">
            <label>Operation <span style="color:var(--accent-danger)">*</span></label>
            <select name="op_id" required>
                <option value="">— Select —</option>
                <?php foreach ($eligibleOps as $op): ?>
                <option value="<?= $op['id'] ?>"
                    <?= ($editVar['op_id'] ?? 0) == $op['id'] ? 'selected' : '' ?>>
                    <?= str_pad($op['op_number'],3,'0',STR_PAD_LEFT) ?> — <?= htmlspecialchars($op['op_name']) ?>
                    (<?= htmlspecialchars(str_replace('_',' ',$op['op_type'])) ?>)
                </option>
                <?php endforeach; ?>
            </select>
            <div class="text-dim" style="font-size:11px;margin-top:3px;">Only Inspection / Final Test / Final Inspection ops shown</div>
        </div>

        <div class="form-group">
            <label>Code <span style="color:var(--accent-danger)">*</span></label>
            <input type="text" name="code" maxlength="30"
                   value="<?= htmlspecialchars($editVar['code'] ?? '') ?>"
                   placeholder="e.g. BREW-TEMP"
                   style="text-transform:uppercase;" oninput="this.value=this.value.toUpperCase()" required>
        </div>

        <div class="form-group">
            <label>Name <span style="color:var(--accent-danger)">*</span></label>
            <input type="text" name="name" maxlength="120"
                   value="<?= htmlspecialchars($editVar['name'] ?? '') ?>"
                   placeholder="e.g. Brew Temperature" required>
        </div>

        <div class="form-group">
            <label>Variable Type</label>
                <select name="qv_type" class="form-control" id="qv_type_sel"
                        onchange="updateQvTypeFields()" style="margin-bottom:12px;">
                    <option value="NUMERIC"   <?= ($editing['qv_type']??'NUMERIC')==='NUMERIC'  ?'selected':'' ?>>Numeric (with limits)</option>
                    <option value="PASS_FAIL" <?= ($editing['qv_type']??'')==='PASS_FAIL'?'selected':'' ?>>Pass / Fail</option>
                    <option value="YES_NO"    <?= ($editing['qv_type']??'')==='YES_NO'  ?'selected':'' ?>>Yes / No</option>
                </select>
                <label class="qv-numeric-field">Unit of Measure</label>
            <div class="qv-numeric-field"><select name="uom_id">
                <option value="">— None —</option>
                <?php foreach ($uoms as $u): ?>
                <option value="<?= $u['id'] ?>"
                    <?= ($editVar['uom_id'] ?? null) == $u['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($u['code'] . ' — ' . $u['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
            <div class="form-group" style="margin:0;">
                <div class="qv-binary-info" style="display:none;padding:8px 12px;background:var(--bg);
              border:1px solid var(--border);border-radius:5px;margin-bottom:10px;font-size:12px;color:var(--text-muted);">
    <span id="qv-binary-uom-note"></span>
</div>
<div class="qv-numeric-field"><label>Lower Limit</label>
                <input type="number" name="lower_limit" step="any"
                       value="<?= $editVar['lower_limit'] ?? '' ?>" placeholder="90">
            </div>
            <div class="form-group" style="margin:0;">
                <label>Target</label>
                <input type="number" name="target_value" step="any"
                       value="<?= $editVar['target_value'] ?? '' ?>" placeholder="95">
            </div>
            <div class="form-group" style="margin:0;">
                <label>Upper Limit</label>
                <input type="number" name="upper_limit" step="any"
                       value="<?= $editVar['upper_limit'] ?? '' ?>" placeholder="100">
            </div>
        </div>
        <div class="text-dim" style="font-size:11px;margin-bottom:12px;">Leave limits blank to collect values without spec checking</div>

        <div class="form-group">
            <label style="display:flex;align-items:center;gap:8px;font-weight:400;cursor:pointer;">
                <input type="checkbox" name="active" value="1" <?= ($editVar['active'] ?? 1) ? 'checked' : '' ?>>
                Active
            </label>
        </div>

        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary"><?= $editVar ? 'Update' : 'Add Variable' ?></button>
            <?php if ($editVar): ?>
            <a href="?id=<?= $routingId ?>" class="btn btn-secondary">Cancel</a>
            <?php endif; ?>
        </div>
    </form>
</div>
<?php endif; ?>

</div>

<script>
function updateQvTypeFields() {
    const type = document.getElementById('qv_type_sel')?.value;
    const numericFields = document.querySelectorAll('.qv-numeric-field');
    const binaryInfo = document.querySelector('.qv-binary-info');
    const noteEl = document.getElementById('qv-binary-uom-note');
    numericFields.forEach(el => {
        el.style.display = (type === 'NUMERIC') ? '' : 'none';
    });
    if (binaryInfo) {
        if (type === 'PASS_FAIL') {
            binaryInfo.style.display = 'block';
            if (noteEl) noteEl.textContent = 'Unit of Measure will be set to P/F (Pass / Fail) automatically.';
        } else if (type === 'YES_NO') {
            binaryInfo.style.display = 'block';
            if (noteEl) noteEl.textContent = 'Unit of Measure will be set to Y/N (Yes / No) automatically.';
        } else {
            binaryInfo.style.display = 'none';
        }
    }
}
document.addEventListener('DOMContentLoaded', updateQvTypeFields);
</script>
<?php renderPageEnd(); ?>
