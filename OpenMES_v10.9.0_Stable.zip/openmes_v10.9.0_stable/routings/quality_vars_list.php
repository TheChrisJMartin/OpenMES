<?php
/**
 * routings/quality_vars_list.php — Quality Variables Overview
 * Version: 10.1.0
 * Description: Lists all approved routings, showing how many quality variables
 *              each has defined, with a direct link to manage them.
 *              This is the landing page from the nav link Routings → Quality Variables.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','QUALITY_ENGINEER','QUALITY_TRAINING_MANAGER']);

$scope = orgScope('r');

$routings = dbFetchAll(
    "SELECT r.id, r.routing_number, r.status, r.revision_label,
            p.part_number, p.description AS part_desc,
            o.code AS org_code,
            (SELECT COUNT(*) FROM quality_variables qv
              JOIN routing_operations ro ON ro.id = qv.op_id
             WHERE ro.routing_id = r.id AND qv.active = 1) AS qv_count,
            (SELECT COUNT(*) FROM routing_operations ro
              WHERE ro.routing_id = r.id
                AND ro.op_type IN ('INSPECTION','FINAL_TEST','FINAL_INSPECTION')) AS eligible_ops
       FROM routings r
       JOIN parts p ON p.id = r.part_id
       JOIN orgs   o ON o.id = r.org_id
      WHERE ({$scope['sql']})
        AND r.status IN ('APPROVED','DRAFT')
      ORDER BY o.code, r.routing_number",
    $scope['params']
);

renderPageStart('Quality Variables');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Quality Variables</h1>
        <p>Define measurable quality checks on Inspection and Test operations across your routings.</p>
    </div>
</div>

<div class="card" style="padding:0;overflow:hidden;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <?php if (hasPersona('IT_ADMIN')): ?><th>Org</th><?php endif; ?>
                    <th>Routing</th>
                    <th>Part</th>
                    <th>Rev</th>
                    <th>Status</th>
                    <th style="text-align:center;">Eligible Ops</th>
                    <th style="text-align:center;">Variables Defined</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($routings)): ?>
                <tr><td colspan="8" style="text-align:center;color:var(--text-dim);padding:32px;">
                    No routings found.
                </td></tr>
            <?php else: ?>
            <?php foreach ($routings as $r): ?>
            <tr>
                <?php if (hasPersona('IT_ADMIN')): ?>
                <td><code style="font-size:11px;"><?= htmlspecialchars($r['org_code']) ?></code></td>
                <?php endif; ?>
                <td>
                    <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $r['id'] ?>"
                       style="color:var(--accent-blue);font-weight:600;text-decoration:none;font-family:monospace;">
                        <?= htmlspecialchars($r['routing_number']) ?>
                    </a>
                </td>
                <td>
                    <div style="font-size:12px;font-weight:500;"><?= htmlspecialchars($r['part_number']) ?></div>
                    <div class="text-dim" style="font-size:11px;"><?= htmlspecialchars(substr($r['part_desc'],0,35)) ?></div>
                </td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($r['revision_label']) ?></code></td>
                <td><?= routingStatusBadge($r['status']) ?></td>
                <td style="text-align:center;">
                    <?php if ($r['eligible_ops'] > 0): ?>
                        <span class="badge badge-blue"><?= $r['eligible_ops'] ?></span>
                    <?php else: ?>
                        <span class="text-dim" style="font-size:11px;">None</span>
                    <?php endif; ?>
                </td>
                <td style="text-align:center;">
                    <?php if ($r['qv_count'] > 0): ?>
                        <span class="badge badge-green"><?= $r['qv_count'] ?> defined</span>
                    <?php elseif ($r['eligible_ops'] > 0): ?>
                        <span class="badge badge-yellow">None yet</span>
                    <?php else: ?>
                        <span class="text-dim" style="font-size:11px;">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($r['eligible_ops'] > 0): ?>
                    <a href="<?= SITE_SUBPATH ?>/routings/quality_vars.php?id=<?= $r['id'] ?>"
                       class="btn btn-primary" style="padding:4px 12px;font-size:12px;">
                        <?= $r['qv_count'] > 0 ? 'Edit Variables' : 'Add Variables' ?>
                    </a>
                    <?php else: ?>
                    <span class="text-dim" style="font-size:11px;">No inspection ops</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card" style="margin-top:12px;padding:14px 16px;background:rgba(56,139,253,.05);border-color:rgba(56,139,253,.2);">
    <div style="font-size:12px;color:var(--text-muted);">
        <strong style="color:var(--accent-blue);">ℹ How quality variables work:</strong>
        Quality variables are defined on <strong>Inspection</strong>, <strong>Final Test</strong>, or
        <strong>Final Inspection</strong> operations. When an operator is clocked on to one of these
        operations, they must enter all required measurements before they can complete the operation.
        Results outside defined limits automatically raise a Non-Conformance and put the work order on hold.
    </div>
</div>

<?php renderPageEnd(); ?>
