<?php
/**
 * routings/create.php — Create new routing or new revision of existing
 * Version: 10.5.3
 * Fixed: document_id preserved on clone; last_edited_at/by tracked
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$scope   = orgScope();
$message = '';
$error   = '';

$existingGroupId = trim($_GET['group'] ?? '');
$fromRoutingId   = (int)($_GET['from'] ?? 0);
$existingRouting = null;
$nextRevision    = 1;

if ($existingGroupId && $fromRoutingId) {
    $existingRouting = dbFetchOne(
        "SELECT r.*, p.part_number, o.code AS org_code
         FROM routings r JOIN parts p ON p.id=r.part_id JOIN orgs o ON o.id=r.org_id
         WHERE r.id=?", [$fromRoutingId]
    );
    if ($existingRouting) {
        $maxRev = dbFetchOne(
            "SELECT MAX(revision) AS m FROM routings WHERE routing_group_id=?",
            [$existingGroupId]
        )['m'] ?? 0;
        $nextRevision = $maxRev + 1;
    }
}

$orgs  = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$parts = dbFetchAll(
    "SELECT p.id,p.part_number,p.description,o.code AS org_code
     FROM parts p JOIN orgs o ON o.id=p.org_id
     WHERE ({$scope['sql']}) AND p.active=1 ORDER BY o.code,p.part_number",
    $scope['params']
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $orgId      = (int)($_POST['org_id'] ?? 0);
    $partId     = (int)($_POST['part_id'] ?? 0);
    $isNewGroup = empty($_POST['routing_group_id']);
    $groupId    = $isNewGroup
        ? sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0,0xffff),mt_rand(0,0xffff),mt_rand(0,0xffff),
            mt_rand(0,0x0fff)|0x4000,mt_rand(0,0x3fff)|0x8000,
            mt_rand(0,0xffff),mt_rand(0,0xffff),mt_rand(0,0xffff))
        : trim($_POST['routing_group_id']);

    if ($orgId===0)   $error = 'Please select an organisation.';
    elseif ($partId===0) $error = 'Please select a part number.';
    else {
        if (!$isNewGroup) {
            $draftExists = dbFetchOne(
                "SELECT id FROM routings WHERE routing_group_id=? AND status='DRAFT'",
                [$groupId]
            );
            if ($draftExists) $error = 'A DRAFT revision already exists. Approve it first.';
        }
    }

    if (!$error) {
        $part = dbFetchOne(
            "SELECT p.part_number, o.code AS org_code FROM parts p JOIN orgs o ON o.id=p.org_id WHERE p.id=?",
            [$partId]
        );
        $routingNumber = $part['org_code'] . '-' . $part['part_number'];

        if (!$isNewGroup) {
            $maxRev = dbFetchOne(
                "SELECT MAX(revision) AS m FROM routings WHERE routing_group_id=?", [$groupId]
            )['m'] ?? 0;
            $revision = $maxRev + 1;
        } else {
            $existing = dbFetchOne(
                "SELECT id FROM routings WHERE org_id=? AND part_id=?", [$orgId,$partId]
            );
            if ($existing) { $error = 'A routing already exists for this part. Use "New Rev" from the routing list.'; }
            $revision = 1;
        }

        if (!$error) {
            $revLabel = str_pad($revision, 6, '0', STR_PAD_LEFT);
            $newId = dbInsert(
                "INSERT INTO routings
                    (org_id,part_id,routing_group_id,routing_number,revision,revision_label,
                     status,uploaded_by,last_edited_by,last_edited_at)
                 VALUES (?,?,?,?,?,?,'DRAFT',?,?,NOW())",
                [$orgId,$partId,$groupId,$routingNumber,$revision,$revLabel,
                 $_SESSION['user_id'],$_SESSION['user_id']]
            );

            // Clone operations from previous revision
            // FIX: document_id IS preserved — only unset if the doc is now archived
            if (!$isNewGroup && $fromRoutingId) {
                $ops = dbFetchAll(
                    "SELECT ro.* FROM routing_operations ro WHERE ro.routing_id=? ORDER BY ro.sort_order",
                    [$fromRoutingId]
                );
                foreach ($ops as $op) {
                    // Keep document link only if doc is still APPROVED (not archived/superseded)
                    $docId = null;
                    if ($op['document_id']) {
                        $docStatus = dbFetchOne(
                            "SELECT status FROM documents WHERE id=?", [$op['document_id']]
                        );
                        if ($docStatus && $docStatus['status'] === 'APPROVED') {
                            $docId = $op['document_id'];
                        }
                        // Superseded/Archived docs are dropped — routing must use current approved rev
                    }
                    dbInsert(
                        "INSERT INTO routing_operations
                            (routing_id,op_number,behaviour,op_name,op_type,
                             department_id,resource_id,document_id,
                             setup_mins,actual_mins,sort_order)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        [$newId,$op['op_number'],$op['behaviour'],$op['op_name'],$op['op_type'],
                         $op['department_id'],$op['resource_id'],$docId,
                         $op['setup_mins'],$op['actual_mins'],$op['sort_order']]
                    );
                }
            }

            // Clone quality variables from previous revision, mapping to new op IDs
            if (!$isNewGroup && $fromRoutingId) {
                $oldQvs = dbFetchAll(
                    "SELECT qv.* FROM quality_variables qv
                      WHERE qv.routing_id=? AND qv.active=1",
                    [$fromRoutingId]
                );
                foreach ($oldQvs as $qv) {
                    // Find the matching new op by op_number
                    $newOp = dbFetchOne(
                        "SELECT id FROM routing_operations
                          WHERE routing_id=? AND op_number=?",
                        [$newId, $qv['op_number'] ?? '']
                    );
                    // If matching op found, clone the QV to new routing and op
                    if ($newOp) {
                        dbInsert(
                            "INSERT INTO quality_variables
                                (routing_id,op_id,org_id,code,name,uom_id,qv_type,
                                 lower_limit,upper_limit,target_value,active,created_by)
                             VALUES (?,?,?,?,?,?,?,?,?,?,1,?)",
                            [$newId,$newOp['id'],$orgId,
                             $qv['code'],$qv['name'],$qv['uom_id'],$qv['qv_type'] ?? 'NUMERIC',
                             $qv['lower_limit'],$qv['upper_limit'],$qv['target_value'],
                             $_SESSION['user_id']]
                        );
                    }
                }
            }

            writeAuditLog('ROUTING_CREATE','routing',(string)$newId,$orgId,null,null,null,null,
                $routingNumber,"Created routing {$routingNumber} Rev {$revLabel}");

            // F003: Add a default op 999 (Book to Stock, Non-Clocking) to new routings only
            // (not when cloning from an existing revision — ops are copied from the source)
            if ($isNewGroup) {
                dbInsert(
                    "INSERT INTO routing_operations
                        (routing_id,op_number,behaviour,op_name,op_type,sort_order)
                     VALUES (?,999,'NON-CLOCKING','Book to Stock','BOOK_TO_STOCK',999)",
                    [$newId]
                );
            }

            header('Location: ' . SITE_URL . '/routings/edit.php?id=' . $newId . '&created=1');
            exit;
        }
    }
}

renderPageStart('Create Routing');
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/routings/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Routings</a>
    <h1 style="margin-top:6px;">
        <?= $existingRouting ? 'New Revision — ' . htmlspecialchars($existingRouting['routing_number']) : 'Create Routing' ?>
    </h1>
    <?php if ($existingRouting): ?>
    <p>Current revision: <strong><?= htmlspecialchars($existingRouting['revision_label']) ?></strong>
       — New revision will be: <strong><?= str_pad($nextRevision,6,'0',STR_PAD_LEFT) ?></strong></p>
    <?php endif; ?>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card" style="max-width:640px;">
    <?php if ($existingRouting): ?>
    <div class="alert alert-info" style="margin-bottom:16px;">
        Creating new revision of <strong><?= htmlspecialchars($existingRouting['routing_number']) ?></strong>.
        Operations will be copied. Documents linked to <strong>APPROVED</strong> work instructions
        are preserved. Documents that have been superseded or archived will be cleared and
        must be re-attached.
    </div>
    <?php endif; ?>

    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="routing_group_id" value="<?= htmlspecialchars($existingRouting['routing_group_id'] ?? '') ?>">

        <?php if (!$existingRouting): ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
            <div class="form-group" style="margin:0;">
                <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
                <select name="org_id" id="org_select" required onchange="filterParts(this.value)">
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o):
                        if (!hasPersona('IT_ADMIN') && $o['id'] != currentOrgId()) continue;
                    ?>
                    <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['code'].' — '.$o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Part Number <span style="color:var(--accent-danger)">*</span></label>
                <select name="part_id" id="part_select" required>
                    <option value="">— Select org first —</option>
                    <?php foreach ($parts as $p): ?>
                    <option value="<?= $p['id'] ?>" data-orgcode="<?= htmlspecialchars($p['org_code']) ?>">
                        <?= htmlspecialchars($p['org_code'].' › '.$p['part_number'].' — '.$p['description']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <?php else: ?>
        <input type="hidden" name="org_id"  value="<?= $existingRouting['org_id'] ?>">
        <input type="hidden" name="part_id" value="<?= $existingRouting['part_id'] ?>">
        <div style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">
            <strong>Org:</strong> <code><?= htmlspecialchars($existingRouting['org_code']) ?></code>
            &nbsp;&nbsp;
            <strong>Part:</strong> <code><?= htmlspecialchars($existingRouting['part_number']) ?></code>
        </div>
        <?php endif; ?>

        <div style="margin-top:16px;">
            <button type="submit" class="btn btn-primary">
                <?= $existingRouting ? 'Create New Revision & Open Editor' : 'Create Routing & Open Editor' ?>
            </button>
            <a href="<?= SITE_SUBPATH ?>/routings/list.php" class="btn btn-secondary" style="margin-left:8px;">Cancel</a>
        </div>
    </form>
</div>

<script>
const parts = <?= json_encode(array_map(fn($p) => [
    'id'      => $p['id'],
    'orgcode' => $p['org_code'],
    'label'   => $p['org_code'].' › '.$p['part_number'].' — '.$p['description']
], $parts)) ?>;

function filterParts(orgId) {
    const orgEl   = document.getElementById('org_select');
    const orgCode = orgEl.options[orgEl.selectedIndex]?.text?.split(' — ')[0]?.trim() ?? '';
    const sel     = document.getElementById('part_select');
    sel.innerHTML = '<option value="">— Select part —</option>';
    parts.filter(p => !orgCode || p.orgcode === orgCode).forEach(p => {
        const o = document.createElement('option');
        o.value = p.id; o.textContent = p.label;
        sel.appendChild(o);
    });
}
</script>

<?php renderPageEnd(); ?>
