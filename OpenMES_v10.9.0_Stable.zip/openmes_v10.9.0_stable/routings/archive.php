<?php
/**
 * routings/archive.php — Archive an approved routing revision
 * Version: 10.5.3
 * D001: Cannot archive a routing that has active (non-complete) work orders.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER_SUP']);

$routingId = (int)($_GET['id'] ?? 0);
$scope     = orgScope('r');

$routing = dbFetchOne(
    "SELECT r.* FROM routings r
     WHERE r.id=? AND r.status='APPROVED' AND ({$scope['sql']})",
    array_merge([$routingId], $scope['params'])
);

if (!$routing) {
    header('Location: ' . SITE_URL . '/routings/list.php');
    exit;
}

// D001: Block if any active (non-complete, non-cancelled) WOs use this routing
$activeWOs = dbFetchOne(
    "SELECT COUNT(*) AS n FROM work_orders
      WHERE routing_id=? AND status NOT IN ('COMPLETE','CANCELLED')",
    [$routingId]
);
if ((int)($activeWOs['n'] ?? 0) > 0) {
    header('Location: ' . SITE_URL . '/routings/list.php?err=archive_active_wo');
    exit;
}

dbExecute(
    "UPDATE routings SET status='ARCHIVED', archived_by=?, archived_at=NOW(), updated_at=NOW() WHERE id=?",
    [$_SESSION['user_id'], $routingId]
);

writeAuditLog(
    'ROUTING_ARCHIVED', 'routing', (string)$routingId, $routing['org_id'],
    null, null, 'status', 'APPROVED', 'ARCHIVED',
    'Archived: ' . $routing['routing_number'] . ' Rev ' . $routing['revision_label']
);

header('Location: ' . SITE_URL . '/routings/list.php?archived=1');
exit;
