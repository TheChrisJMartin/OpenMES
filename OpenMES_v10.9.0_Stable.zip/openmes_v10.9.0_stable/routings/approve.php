<?php
/**
 * routings/approve.php — Routing Approval
 * Version: 6.1.0
 * Fix: When approving, older APPROVED revisions in same group become SUPERSEDED
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$routingId = (int)($_GET['id'] ?? 0);
$scope     = orgScope('r');
$error     = '';

$routing = dbFetchOne(
    "SELECT r.*, p.part_number, p.description AS part_desc, o.code AS org_code,
            uu.id AS creator_id, uu.known_as AS creator_name,
            (SELECT COUNT(*) FROM routing_operations ro WHERE ro.routing_id=r.id) AS op_count
     FROM routings r
     JOIN parts p ON p.id=r.part_id JOIN orgs o ON o.id=r.org_id
     LEFT JOIN users uu ON uu.id=r.uploaded_by
     WHERE r.id=? AND r.status='DRAFT' AND ({$scope['sql']})",
    array_merge([$routingId], $scope['params'])
);

if (!$routing) {
    header('Location: ' . SITE_URL . '/routings/list.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'approve' || $action === 'auto_approve') {
        $isAuto = ($action === 'auto_approve');

        if (!$isAuto && $_SESSION['user_id'] == $routing['creator_id'])
            $error = 'You cannot approve a routing you created.';
        if ($isAuto && !hasPersona('IT_ADMIN'))
            $error = 'Only IT Admin can use auto-approve.';
        if ($isAuto && !AUTO_APPROVE_ROUTINGS)
            $error = 'Auto-approve is disabled in config.php.';
        if (!$error && $routing['op_count'] == 0)
            $error = 'Cannot approve a routing with no operations.';

        if (!$error) {
            $pdo = getDB();
            $pdo->beginTransaction();
            try {
                // Supersede any existing APPROVED revisions in this group
                dbExecute(
                    "UPDATE routings SET status='SUPERSEDED', updated_at=NOW()
                     WHERE routing_group_id=? AND status='APPROVED' AND id!=?",
                    [$routing['routing_group_id'], $routingId]
                );

                // Approve this revision
                dbExecute(
                    "UPDATE routings SET status='APPROVED', approved_by=?, approved_at=NOW(),
                     auto_approved=?, updated_at=NOW() WHERE id=?",
                    [$_SESSION['user_id'], $isAuto ? 1 : 0, $routingId]
                );

                writeAuditLog(
                    $isAuto ? 'ROUTING_AUTO_APPROVED' : 'ROUTING_APPROVED',
                    'routing', (string)$routingId, $routing['org_id'],
                    null, null, 'status', 'DRAFT', 'APPROVED',
                    ($isAuto?'Auto-approved':'Approved').': '.$routing['routing_number'].' Rev '.$routing['revision_label']
                );

                $pdo->commit();
                header('Location: '.SITE_URL.'/routings/edit.php?id='.$routingId.'&approved=1');
                exit;
            } catch (Throwable $e) {
                $pdo->rollBack();
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

renderPageStart('Approve Routing');
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/routings/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Routings</a>
    <h1 style="margin-top:6px;">Approve — <?= htmlspecialchars($routing['routing_number']) ?></h1>
    <p><?= htmlspecialchars($routing['part_desc']) ?> — Rev <code><?= htmlspecialchars($routing['revision_label']) ?></code></p>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:900px;">
    <div class="card">
        <div class="card-title">Routing Details</div>
        <table style="font-size:13px;">
            <tr><td class="text-dim" style="padding:5px 14px 5px 0;white-space:nowrap;">Routing</td><td><code><?= htmlspecialchars($routing['routing_number']) ?></code></td></tr>
            <tr><td class="text-dim" style="padding:5px 14px 5px 0;">Revision</td><td><code><?= htmlspecialchars($routing['revision_label']) ?></code></td></tr>
            <tr><td class="text-dim" style="padding:5px 14px 5px 0;">Part</td><td><?= htmlspecialchars($routing['part_number']) ?></td></tr>
            <tr><td class="text-dim" style="padding:5px 14px 5px 0;">Org</td><td><code><?= htmlspecialchars($routing['org_code']) ?></code></td></tr>
            <tr><td class="text-dim" style="padding:5px 14px 5px 0;">Created by</td><td><?= htmlspecialchars($routing['creator_name']??'—') ?></td></tr>
            <tr><td class="text-dim" style="padding:5px 14px 5px 0;">Operations</td><td><?= (int)$routing['op_count'] ?></td></tr>
        </table>
        <div class="alert alert-info" style="margin-top:12px;font-size:12px;">
            ℹ Approving this revision will mark any currently APPROVED revision of this
            routing as <strong>SUPERSEDED</strong>. Superseded revisions remain visible
            and can still be used to create work orders.
        </div>
        <div style="margin-top:10px;">
            <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $routingId ?>"
               class="btn btn-secondary" style="font-size:12px;">Review Operations ↗</a>
        </div>
    </div>

    <div class="card">
        <div class="card-title">Approval Actions</div>
        <?php if ($_SESSION['user_id'] == $routing['creator_id']): ?>
        <div class="alert alert-warning">⚠ You created this routing. A different user must approve it.</div>
        <?php endif; ?>
        <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">
            Review all operations before approving. Once approved this revision cannot be edited.
        </p>
        <form method="POST" style="display:flex;flex-direction:column;gap:10px;">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <?php if ($_SESSION['user_id'] != $routing['creator_id']): ?>
            <button type="submit" name="action" value="approve" class="btn btn-primary">✓ Approve Routing</button>
            <?php endif; ?>
            <?php if (hasPersona('IT_ADMIN') && AUTO_APPROVE_ROUTINGS): ?>
            <button type="submit" name="action" value="auto_approve" class="btn btn-warning"
                    onclick="return confirm('Auto-approve bypasses the two-user rule. Continue?')">
                ⚡ Auto-Approve (IT Admin)
            </button>
            <?php elseif (hasPersona('IT_ADMIN')): ?>
            <div class="text-dim" style="font-size:12px;">Auto-approve disabled in config.php.</div>
            <?php endif; ?>
            <a href="<?= SITE_SUBPATH ?>/routings/list.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php renderPageEnd(); ?>
