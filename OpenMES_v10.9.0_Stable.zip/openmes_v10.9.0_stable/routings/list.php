<?php
/**
 * routings/list.php — Routing List
 * Version: 10.5.3
 * Fix: SUPERSEDED revisions shown with yellow badge; can still create WO from them
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','SUPERVISOR','ENGINEER','QUALITY_ENGINEER']);

// ── Delete DRAFT routing ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_routing') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);
    $delId = (int)($_POST['routing_id'] ?? 0);
    $r = dbFetchOne("SELECT * FROM routings WHERE id=?", [$delId]);
    if ($r && $r['status'] === 'DRAFT') {
        $woCount = (int)(dbFetchOne(
            "SELECT COUNT(*) AS n FROM work_orders WHERE routing_id=?", [$delId])['n'] ?? 0);
        if ($woCount === 0) {
            dbExecute("DELETE FROM quality_results WHERE qv_id IN
                (SELECT id FROM quality_variables WHERE routing_id=?)", [$delId]);
            dbExecute("DELETE FROM quality_variables WHERE routing_id=?", [$delId]);
            dbExecute("DELETE FROM routing_operations WHERE routing_id=?", [$delId]);
            dbExecute("DELETE FROM routings WHERE id=? AND status='DRAFT'", [$delId]);
            writeAuditLog('ROUTING_DELETE','routing',(string)$delId,$r['org_id'],
                null,null,null,null,$r['routing_number'],
                "Deleted DRAFT routing {$r['routing_number']} Rev {$r['revision_label']}");
        }
    }
    header('Location: ' . SITE_SUBPATH . '/routings/list.php');
    exit;
}

$scope        = orgScope('r');
$filterStatus = $_GET['status'] ?? '';
$filterOrgId  = (int)($_GET['org'] ?? 0);
$search       = trim($_GET['search'] ?? '');

$where  = '(' . $scope['sql'] . ')';
$params = $scope['params'];

if ($filterStatus && in_array($filterStatus,['DRAFT','APPROVED','SUPERSEDED','ARCHIVED'])) {
    $where .= ' AND r.status=?'; $params[] = $filterStatus;
}
if ($filterOrgId && hasPersona('IT_ADMIN')) {
    $where .= ' AND r.org_id=?'; $params[] = $filterOrgId;
}
if ($search) {
    $where .= ' AND (r.routing_number LIKE ? OR p.part_number LIKE ? OR p.description LIKE ?)';
    $params[] = "%{$search}%"; $params[] = "%{$search}%"; $params[] = "%{$search}%";
}

$routings = dbFetchAll(
    "SELECT r.*, o.code AS org_code, p.part_number, p.description AS part_desc,
            uu.known_as AS creator_name, ua.known_as AS approver_name,
            (SELECT COUNT(*) FROM routing_operations ro WHERE ro.routing_id=r.id) AS op_count
     FROM routings r
     JOIN orgs o ON o.id=r.org_id JOIN parts p ON p.id=r.part_id
     LEFT JOIN users uu ON uu.id=r.uploaded_by
     LEFT JOIN users ua ON ua.id=r.approved_by
     WHERE {$where}
     ORDER BY o.code, r.routing_number, r.revision DESC",
    $params
);

// Group by routing_group_id
$grouped = [];
foreach ($routings as $r) {
    $grouped[$r['routing_group_id']][] = $r;
}

$orgs = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");


renderPageStart('Routings');
?>

<?php if (($_GET['archived'] ?? '') === '1'): ?>
<div class="alert alert-success">Routing archived successfully.</div>
<?php elseif (($_GET['err'] ?? '') === 'archive_active_wo'): ?>
<div class="alert alert-danger">⚠ Cannot archive this routing — it is currently assigned to one or more active work orders. Complete or cancel those work orders first.</div>
<?php endif; ?>

<div class="page-header page-header-row">
    <div>
        <h1>Routings</h1>
        <p>Manufacturing routings — all revisions shown. Superseded revisions can still be used to create work orders.</p>
    </div>
    <?php if (hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
    <a href="<?= SITE_SUBPATH ?>/routings/create.php" class="btn btn-primary">+ Create Routing</a>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card" style="padding:14px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Routing name or part…" style="width:220px;">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Status</label>
            <select name="status" style="width:140px;">
                <option value="">All Statuses</option>
                <option value="DRAFT"      <?= $filterStatus==='DRAFT'     ?'selected':'' ?>>Draft</option>
                <option value="APPROVED"   <?= $filterStatus==='APPROVED'  ?'selected':'' ?>>Approved</option>
                <option value="SUPERSEDED" <?= $filterStatus==='SUPERSEDED'?'selected':'' ?>>Superseded</option>
                <option value="ARCHIVED"   <?= $filterStatus==='ARCHIVED'  ?'selected':'' ?>>Archived</option>
            </select>
        </div>
        <?php if (hasPersona('IT_ADMIN')): ?>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Org</label>
            <select name="org" style="width:110px;">
                <option value="0">All</option>
                <?php foreach ($orgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $filterOrgId===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="<?= SITE_SUBPATH ?>/routings/list.php" class="btn btn-secondary">Clear</a>
    </form>
</div>

<?php if (!$grouped): ?>
<div class="card" style="text-align:center;padding:40px;color:var(--text-dim);">
    No routings found.
    <?php if (hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
    <a href="<?= SITE_SUBPATH ?>/routings/create.php" style="color:var(--accent-blue);">Create one</a>.
    <?php endif; ?>
</div>
<?php endif; ?>

<?php foreach ($grouped as $groupId => $revisions):
    $latest = $revisions[0]; // Already DESC by revision
?>
<div class="card" style="margin-bottom:12px;padding:0;overflow:hidden;">

    <!-- Group header -->
    <div style="padding:11px 16px;background:var(--bg-card2);border-bottom:1px solid var(--border);
                display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <code style="font-size:12px;font-weight:700;color:var(--text);"><?= htmlspecialchars($latest['routing_number']) ?></code>
        <span style="font-size:13px;color:var(--text-muted);flex:1;"><?= htmlspecialchars($latest['part_desc']) ?></span>
        <code style="font-size:11px;color:var(--text-dim);"><?= htmlspecialchars($latest['part_number']) ?></code>
        <code style="font-size:11px;color:var(--text-dim);"><?= htmlspecialchars($latest['org_code']) ?></code>
        <span style="font-size:11px;color:var(--text-dim);"><?= count($revisions) ?> revision<?= count($revisions)!==1?'s':'' ?></span>
    </div>

    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr>
                    <th style="width:80px;">Rev</th>
                    <th style="width:140px;">Status</th>
                    <th style="width:55px;">Ops</th>
                    <th>Created By</th>
                    <th>Approved By</th>
                    <th>Approved At</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($revisions as $rev):
                $isSuperseded = $rev['status'] === 'SUPERSEDED';
                $isArchived   = $rev['status'] === 'ARCHIVED';
                $rowStyle     = $isArchived ? 'opacity:.5;' : ($isSuperseded ? 'color:var(--text-muted);' : '');
            ?>
            <tr style="<?= $rowStyle ?>">
                <td><code class="font-mono" style="font-size:12px;"><?= htmlspecialchars($rev['revision_label']) ?></code></td>
                <td><?= routingStatusBadge($rev['status']) ?></td>
                <td class="text-muted"><?= (int)$rev['op_count'] ?></td>
                <td style="font-size:12px;"><?= htmlspecialchars($rev['creator_name']??'—') ?></td>
                <td style="font-size:12px;"><?= htmlspecialchars($rev['approver_name']??'—') ?><?= $rev['auto_approved']?' ⚡':'' ?></td>
                <td style="font-size:12px;white-space:nowrap;"><?= $rev['approved_at'] ? displayDate($rev['approved_at']) : '—' ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $rev['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">
                        <?= $rev['status']==='DRAFT' ? 'Edit' : 'View' ?>
                    </a>

                    <?php if ($rev['status']==='DRAFT' && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/routings/approve.php?id=<?= $rev['id'] ?>"
                       class="btn btn-primary" style="padding:3px 9px;font-size:11px;">Approve</a>
                    <form method="POST" style="display:inline"
                          onsubmit="return confirm('Delete this DRAFT revision? Cannot be undone.')">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="action" value="delete_routing">
                        <input type="hidden" name="routing_id" value="<?= $rev['id'] ?>">
                        <button type="submit" class="btn btn-danger"
                                style="padding:3px 9px;font-size:11px;line-height:1.5;vertical-align:middle;">Delete</button>
                    </form>
                    <?php endif; ?>

                    <?php if (in_array($rev['status'],['APPROVED','SUPERSEDED']) && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/routings/create.php?group=<?= urlencode($groupId) ?>&from=<?= $rev['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">New Rev</a>
                    <?php endif; ?>

                    <?php if ($rev['status']==='APPROVED' && hasPersona(['IT_ADMIN','MFG_ENGINEER_SUP'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/routings/archive.php?id=<?= $rev['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;"
                       onclick="return confirm('Archive this routing revision?')">Archive</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endforeach; ?>

<?php renderPageEnd(); ?>
