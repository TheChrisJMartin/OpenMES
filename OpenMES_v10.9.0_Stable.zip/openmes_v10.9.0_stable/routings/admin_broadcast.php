<?php
/**
 * routings/admin_broadcast.php — Broadcast Message Manager
 * Version: 10.9.0
 * D046: Rewritten from v8.0.0 to use current auth/layout structure.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona('IT_ADMIN');

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $msg    = trim($_POST['message'] ?? '');
        $colour = in_array($_POST['colour'] ?? '', ['red','yellow','green']) ? $_POST['colour'] : 'yellow';
        $enable = isset($_POST['enable']) ? 1 : 0;

        if ($msg === '') {
            $error = 'Please enter a message.';
        } else {
            // Deactivate all existing
            dbExecute("UPDATE broadcast_messages SET is_active=0 WHERE 1");
            // Insert new
            dbInsert(
                "INSERT INTO broadcast_messages (message, colour, is_active, created_by, created_at)
                 VALUES (?, ?, ?, ?, NOW())",
                [$msg, $colour, $enable, $_SESSION['user_id']]
            );
            $success = 'Broadcast message saved.';
        }
    } elseif ($action === 'deactivate') {
        dbExecute("UPDATE broadcast_messages SET is_active=0 WHERE 1");
        $success = 'Broadcast message deactivated.';
    }
}

// Load current active message
$current = null;
try {
    $current = dbFetchOne("SELECT * FROM broadcast_messages WHERE is_active=1 LIMIT 1");
} catch (Throwable) {}

// Load history
$history = [];
try {
    $history = dbFetchAll(
        "SELECT bm.*, u.known_as
           FROM broadcast_messages bm
           LEFT JOIN users u ON u.id=bm.created_by
          ORDER BY bm.created_at DESC LIMIT 10"
    );
} catch (Throwable) {}

renderPageStart('Broadcast Message');
?>

<div class="page-header">
    <h1>Broadcast Message</h1>
    <p style="color:var(--text-muted);">Post a system-wide banner visible to all logged-in users.</p>
</div>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Current active message -->
<?php if ($current): ?>
<div class="card" style="margin-bottom:14px;border:2px solid var(--accent-warn);">
    <div class="card-title">Current Active Message</div>
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span class="badge badge-<?= htmlspecialchars($current['colour'] ?? 'yellow') ?>"
              style="font-size:12px;padding:4px 12px;">
            <?= strtoupper($current['colour'] ?? 'YELLOW') ?>
        </span>
        <span style="font-size:14px;flex:1;"><?= htmlspecialchars($current['message']) ?></span>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="action" value="deactivate">
            <button type="submit" class="btn btn-danger" style="font-size:12px;">Deactivate</button>
        </form>
    </div>
</div>
<?php else: ?>
<div class="alert alert-warning" style="margin-bottom:14px;">No active broadcast message.</div>
<?php endif; ?>

<!-- Set new message -->
<div class="card" style="margin-bottom:14px;">
    <div class="card-title">Set New Broadcast Message</div>
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="action" value="save">
        <div class="form-group">
            <label>Message <span style="font-size:11px;color:var(--text-muted);">(max 128 characters)</span></label>
            <input type="text" name="message" maxlength="128" required
                   value="<?= htmlspecialchars($current['message'] ?? '') ?>"
                   placeholder="e.g. System maintenance tonight at 22:00 UTC">
        </div>
        <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:14px;">
            <div>
                <label style="font-size:12px;color:var(--text-muted);display:block;margin-bottom:4px;">Colour</label>
                <select name="colour" class="form-control" style="width:auto;">
                    <option value="red"    <?= ($current['colour']??'')   ==='red'    ?'selected':'' ?>>🔴 Red (Urgent)</option>
                    <option value="yellow" <?= ($current['colour']??'yellow')==='yellow'?'selected':'' ?>>🟡 Yellow (Warning)</option>
                    <option value="green"  <?= ($current['colour']??'')   ==='green'  ?'selected':'' ?>>🟢 Green (Information)</option>
                </select>
            </div>
            <div style="display:flex;align-items:center;gap:8px;margin-top:18px;">
                <input type="checkbox" name="enable" id="enable" value="1" checked>
                <label for="enable" style="margin:0;cursor:pointer;">Enable banner immediately</label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Save Message</button>
    </form>
</div>

<!-- History -->
<?php if ($history): ?>
<div class="card" style="padding:0;overflow:hidden;">
    <div class="card-title" style="padding:12px 16px;border-bottom:1px solid var(--border);">Recent Messages (Last 10)</div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead><tr><th>Date</th><th>Message</th><th>Colour</th><th>By</th><th>Active</th></tr></thead>
            <tbody>
            <?php foreach ($history as $h): ?>
            <tr>
                <td style="font-size:11px;font-family:monospace;white-space:nowrap;">
                    <?= htmlspecialchars(substr($h['created_at'],0,16)) ?>
                </td>
                <td style="font-size:12px;"><?= htmlspecialchars($h['message']) ?></td>
                <td><span class="badge badge-<?= htmlspecialchars($h['colour']??'grey') ?>" style="font-size:10px;">
                    <?= strtoupper($h['colour']??'') ?>
                </span></td>
                <td style="font-size:12px;"><?= htmlspecialchars($h['known_as']??'—') ?></td>
                <td><?= $h['is_active'] ? '<span class="badge badge-green" style="font-size:10px;">ACTIVE</span>' : '<span class="text-dim" style="font-size:11px;">—</span>' ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php renderPageEnd(); ?>
