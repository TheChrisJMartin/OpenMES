<?php
/**
 * routings/edit.php — Routing Operation Editor
 * Version: 10.5.3
 * Fixed: last_edited_by/at tracking; timezone-correct timestamps
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','SUPERVISOR','ENGINEER','QUALITY_ENGINEER']);

$routingId = (int)($_GET['id'] ?? 0);
$scope     = orgScope('r');
$message   = '';
$error     = '';

$routing = dbFetchOne(
    "SELECT r.*, p.part_number, p.description AS part_desc,
            o.code AS org_code, o.name AS org_name,
            uu.known_as AS creator_name,
            ua.known_as AS approver_name,
            ue.known_as AS editor_name
     FROM routings r
     JOIN parts p ON p.id=r.part_id
     JOIN orgs o  ON o.id=r.org_id
     LEFT JOIN users uu ON uu.id=r.uploaded_by
     LEFT JOIN users ua ON ua.id=r.approved_by
     LEFT JOIN users ue ON ue.id=r.last_edited_by
     WHERE r.id=? AND ({$scope['sql']})",
    array_merge([$routingId], $scope['params'])
);

if (!$routing) {
    renderPageStart('Not Found');
    echo '<div class="alert alert-danger">Routing not found.</div>';
    echo '<a href="' . SITE_SUBPATH . '/routings/list.php" class="btn btn-secondary">← Routings</a>';
    renderPageEnd(); exit;
}

$isDraft = ($routing['status'] === 'DRAFT');
$canEdit = $isDraft && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$depts = dbFetchAll(
    "SELECT id,code,name FROM departments WHERE org_id=? AND active=1 ORDER BY code",
    [$routing['org_id']]
);
$resources = dbFetchAll(
    "SELECT id,code,name,department_id FROM resources WHERE org_id=? AND active=1 ORDER BY code",
    [$routing['org_id']]
);
// Only currently APPROVED docs (not archived/superseded)
$availDocs = dbFetchAll(
    "SELECT d.id, d.doc_number, d.description, d.revision_label
     FROM documents d
     WHERE d.org_id=? AND d.status='APPROVED'
     ORDER BY d.doc_number",
    [$routing['org_id']]
);

if ($canEdit && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_op') {
        $opId      = (int)($_POST['op_id'] ?? 0);
        $opNum     = (int)($_POST['op_number'] ?? 0);
        $behaviour = in_array($_POST['behaviour']??'',['CLOCKING','NON-CLOCKING'])
                     ? $_POST['behaviour'] : 'CLOCKING';
        $opName    = trim($_POST['op_name'] ?? '');
        $opType    = in_array($_POST['op_type']??'',['STANDARD','INSPECTION','FINAL_TEST','FINAL_INSPECTION','BOOK_TO_STOCK','MATERIAL_KITTING'])
                     ? $_POST['op_type'] : 'STANDARD';
        $deptId    = ((int)($_POST['department_id']??0) > 0) ? (int)$_POST['department_id'] : null;
        $resId     = ((int)($_POST['resource_id']??0)   > 0) ? (int)$_POST['resource_id']   : null;
        $docId     = ((int)($_POST['document_id']??0)   > 0) ? (int)$_POST['document_id']   : null;
        $setupMins = max(0,(int)($_POST['setup_mins']  ?? 0));
        $actMins   = max(0,(int)($_POST['actual_mins'] ?? 0));

        if ($opNum <= 0)    $error = 'Operation number must be greater than 0.';
        elseif ($opName==='') $error = 'Operation name is required.';
        else {
            try {
                if ($opId === 0) {
                    $dup = dbFetchOne(
                        "SELECT id FROM routing_operations WHERE routing_id=? AND op_number=?",
                        [$routingId,$opNum]
                    );
                    if ($dup) { $error = "Operation number {$opNum} already exists on this routing."; }
                    else {
                        $maxSort = dbFetchOne(
                            "SELECT MAX(sort_order) AS m FROM routing_operations WHERE routing_id=?",
                            [$routingId]
                        )['m'] ?? 0;
                        dbInsert(
                            "INSERT INTO routing_operations
                                (routing_id,op_number,behaviour,op_name,op_type,
                                 department_id,resource_id,document_id,
                                 setup_mins,actual_mins,sort_order)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            [$routingId,$opNum,$behaviour,$opName,$opType,
                             $deptId,$resId,$docId,$setupMins,$actMins,$maxSort+10]
                        );
                        $message = "Operation {$opNum} added.";
                    }
                } else {
                    dbExecute(
                        "UPDATE routing_operations
                         SET behaviour=?,op_name=?,op_type=?,department_id=?,resource_id=?,
                             document_id=?,setup_mins=?,actual_mins=?,updated_at=NOW()
                         WHERE id=? AND routing_id=?",
                        [$behaviour,$opName,$opType,$deptId,$resId,$docId,
                         $setupMins,$actMins,$opId,$routingId]
                    );
                    $message = "Operation {$opNum} updated.";
                }

                if (!$error) {
                    // Update last_edited timestamp on routing
                    dbExecute(
                        "UPDATE routings SET last_edited_by=?, last_edited_at=NOW(), updated_at=NOW() WHERE id=?",
                        [$_SESSION['user_id'], $routingId]
                    );
                    writeAuditLog('ROUTING_OP_EDIT','routing',(string)$routingId,$routing['org_id'],
                        null,null,'op_number',null,(string)$opNum,
                        ($opId===0?"Added":"Edited")." op {$opNum}: {$opName}");
                    // Re-fetch routing to show updated timestamps
                    $routing = dbFetchOne(
                        "SELECT r.*, p.part_number, p.description AS part_desc,
                                o.code AS org_code, o.name AS org_name,
                                uu.known_as AS creator_name, ua.known_as AS approver_name,
                                ue.known_as AS editor_name
                         FROM routings r
                         JOIN parts p ON p.id=r.part_id JOIN orgs o ON o.id=r.org_id
                         LEFT JOIN users uu ON uu.id=r.uploaded_by
                         LEFT JOIN users ua ON ua.id=r.approved_by
                         LEFT JOIN users ue ON ue.id=r.last_edited_by
                         WHERE r.id=?", [$routingId]
                    );
                }
            } catch (PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }

    if ($action === 'delete_op') {
        $opId = (int)($_POST['op_id'] ?? 0);
        $op   = dbFetchOne("SELECT * FROM routing_operations WHERE id=? AND routing_id=?",[$opId,$routingId]);
        if ($op) {
            // DRAFT routings can have any/all operations deleted — they have never been used.
            // Only APPROVED and above are protected from modification (they are read-only in the editor).
            dbExecute("DELETE FROM routing_operations WHERE id=?",[$opId]);
            dbExecute(
                "UPDATE routings SET last_edited_by=?, last_edited_at=NOW(), updated_at=NOW() WHERE id=?",
                [$_SESSION['user_id'], $routingId]
            );
            writeAuditLog('ROUTING_OP_DELETE','routing',(string)$routingId,$routing['org_id'],
                null,null,'op_number',(string)$op['op_number'],null,"Deleted op {$op['op_number']}");
            $message = "Operation {$op['op_number']} deleted.";
        }
    }
}

// ── Delete DRAFT routing ──────────────────────────────────────────────────────
if (($_POST['action'] ?? '') === 'delete_routing' && $routing['status'] === 'DRAFT') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    if (!hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])) {
        http_response_code(403); die('Forbidden');
    }
    // Check no work orders reference this routing
    $woCount = (int)(dbFetchOne(
        "SELECT COUNT(*) AS n FROM work_orders WHERE routing_id=?", [$routingId])['n'] ?? 0);
    if ($woCount > 0) {
        $error = "Cannot delete — {$woCount} work order(s) reference this routing revision.";
    } else {
        // Delete quality_results linked to this routing's QVs first (FK constraint)
        dbExecute(
            "DELETE FROM quality_results
              WHERE qv_id IN (SELECT id FROM quality_variables WHERE routing_id=?)",
            [$routingId]
        );
        dbExecute("DELETE FROM quality_variables WHERE routing_id=?", [$routingId]);
        dbExecute("DELETE FROM routing_operations WHERE routing_id=?", [$routingId]);
        dbExecute("DELETE FROM routings WHERE id=? AND status='DRAFT'", [$routingId]);
        writeAuditLog('ROUTING_DELETE','routing',(string)$routingId,$routing['org_id'],
            null,null,null,null,$routing['routing_number'],
            "Deleted DRAFT routing {$routing['routing_number']} Rev {$routing['revision_label']}");
        header('Location: ' . SITE_SUBPATH . '/routings/list.php');
        exit;
    }
}

$operations = dbFetchAll(
    "SELECT ro.*, d.code AS dept_code, res.code AS res_code,
            doc.doc_number, doc.revision_label AS doc_rev
     FROM routing_operations ro
     LEFT JOIN departments d  ON d.id=ro.department_id
     LEFT JOIN resources res  ON res.id=ro.resource_id
     LEFT JOIN documents doc  ON doc.id=ro.document_id
     WHERE ro.routing_id=? ORDER BY ro.sort_order, ro.op_number",
    [$routingId]
);

$editOpId = (int)($_GET['edit_op'] ?? 0);
$editOp   = $editOpId
    ? dbFetchOne("SELECT * FROM routing_operations WHERE id=? AND routing_id=?",[$editOpId,$routingId])
    : null;

$opTypes = [
    'STANDARD'         => 'Standard',
    'INSPECTION'       => 'Inspection',
    'FINAL_TEST'       => 'Final Test',
    'FINAL_INSPECTION' => 'Final Inspection',
    'BOOK_TO_STOCK'    => 'Book to Stock',
    'MATERIAL_KITTING' => 'Material Kitting',
];

$approved = isset($_GET['approved']);
renderPageStart('Routing — ' . $routing['routing_number']);
?>

<?php if ($approved): ?><div class="alert alert-success">✓ Routing approved successfully.</div><?php endif; ?>
<?php if (isset($_GET['created'])): ?><div class="alert alert-success">✓ Routing created. Add operations below.</div><?php endif; ?>
<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Tab nav — D029 fix -->
<div style="display:flex;gap:0;margin-bottom:16px;border-bottom:2px solid var(--border);">
    <span style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--accent-blue);
                 border-bottom:2px solid var(--accent-blue);margin-bottom:-2px;">
        Operations
    </span>
    <a href="<?= SITE_SUBPATH ?>/routings/op_tools.php?id=<?= $routingId ?>"
       style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--text-muted);
              text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;">
        Required Tools
    </a>
    <a href="<?= SITE_SUBPATH ?>/routings/quality_vars.php?id=<?= $routingId ?>"
       style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--text-muted);
              text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;">
        Quality Variables
    </a>
</div>

<div class="page-header page-header-row">
    <div>
        <a href="<?= SITE_SUBPATH ?>/routings/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Routings</a>
        <h1 style="margin-top:4px;"><?= htmlspecialchars($routing['routing_number']) ?></h1>
        <p><?= htmlspecialchars($routing['part_desc']) ?> &mdash; Rev <code><?= htmlspecialchars($routing['revision_label']) ?></code></p>
    </div>
    <div style="display:flex;gap:8px;align-items:flex-start;flex-wrap:wrap;">
        <?= routingStatusBadge($routing['status']) ?>
        <?php if ($routing['status']==='DRAFT' && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
        <a href="<?= SITE_SUBPATH ?>/routings/approve.php?id=<?= $routingId ?>" class="btn btn-primary">Approve Routing</a>
        <form method="POST" style="display:inline"
              onsubmit="return confirm('Permanently delete this DRAFT routing revision? This cannot be undone.')">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="action" value="delete_routing">
            <button type="submit" class="btn btn-danger">Delete DRAFT</button>
        </form>
        <?php endif; ?>
    </div>
</div>

<!-- Info bar -->
<div class="card" style="padding:12px 16px;margin-bottom:14px;">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;font-size:12px;">
        <div><span class="text-dim">Org:</span> <code><?= htmlspecialchars($routing['org_code']) ?></code></div>
        <div><span class="text-dim">Part:</span> <code><?= htmlspecialchars($routing['part_number']) ?></code></div>
        <div><span class="text-dim">Revision:</span> <code><?= htmlspecialchars($routing['revision_label']) ?></code></div>
        <div><span class="text-dim">Created by:</span> <?= htmlspecialchars($routing['creator_name'] ?? '—') ?></div>
        <?php if ($routing['approved_by']): ?>
        <div><span class="text-dim">Approved by:</span> <?= htmlspecialchars($routing['approver_name'] ?? '—') ?><?= $routing['auto_approved']?' ⚡':'' ?></div>
        <div><span class="text-dim">Approved at:</span> <?= displayDate($routing['approved_at']) ?> <?= $routing['approved_at'] ? '<span class="text-dim">(' . SITE_TIMEZONE . ')</span>' : '' ?></div>
        <?php endif; ?>
        <?php if ($routing['last_edited_at']): ?>
        <div><span class="text-dim">Last edited by:</span> <?= htmlspecialchars($routing['editor_name'] ?? '—') ?></div>
        <div><span class="text-dim">Last edited at:</span> <?= displayDate($routing['last_edited_at']) ?> <span class="text-dim">(<?= SITE_TIMEZONE ?>)</span></div>
        <?php endif; ?>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr <?= $canEdit?'340px':'' ?>;gap:16px;align-items:start;">

<!-- Operations -->
<div class="card" style="padding:0;overflow:hidden;">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;">
        <span style="font-weight:600;font-size:14px;">Operations</span>
        <span class="text-dim" style="font-size:12px;"><?= count($operations) ?> steps</span>
        <?php if ($canEdit): ?>
        <a href="#add-op" class="btn btn-primary" style="margin-left:auto;padding:4px 12px;font-size:12px;">+ Add Operation</a>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr>
                    <th style="width:55px;">Op</th>
                    <th style="width:115px;">Behaviour</th>
                    <th>Name</th>
                    <th style="width:120px;">Type</th>
                    <th>Dept</th>
                    <th>Resource</th>
                    <th>Document</th>
                    <th style="width:65px;">Setup</th>
                    <th style="width:65px;">Actual</th>
                    <?php if ($canEdit): ?><th style="width:90px;"></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if (!$operations): ?>
            <tr><td colspan="<?= $canEdit?10:9 ?>" style="text-align:center;color:var(--text-dim);padding:24px;">
                No operations yet.<?= $canEdit ? ' Add one using the form →' : '' ?>
            </td></tr>
            <?php endif; ?>
            <?php foreach ($operations as $op):
                $isNC = $op['behaviour'] === 'NON-CLOCKING';
            ?>
            <tr style="<?= $isNC ? 'color:var(--text-dim);' : '' ?>">
                <td><code style="font-size:13px;font-weight:700;"><?= str_pad($op['op_number'],3,'0',STR_PAD_LEFT) ?></code></td>
                <td><?= $isNC
                    ? '<span class="badge badge-grey" style="font-size:10px;">NON-CLOCK</span>'
                    : '<span class="badge badge-blue" style="font-size:10px;">CLOCKING</span>' ?></td>
                <td><?= htmlspecialchars($op['op_name']) ?></td>
                <td><span style="font-size:11px;"><?= htmlspecialchars(str_replace('_',' ',$op['op_type'])) ?></span></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($op['dept_code'] ?? '—') ?></code></td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($op['res_code']  ?? '—') ?></code></td>
                <td style="font-size:11px;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    <?= $op['doc_number']
                        ? '<span title="' . htmlspecialchars($op['doc_number']) . '">' .
                          htmlspecialchars($op['doc_number']) .
                          ' <span class="text-dim">(' . htmlspecialchars($op['doc_rev']) . ')</span></span>'
                        : '<span class="text-dim">—</span>' ?>
                </td>
                <td class="text-dim" style="font-size:12px;"><?= $op['setup_mins']  ?>m</td>
                <td class="text-dim" style="font-size:12px;"><?= $op['actual_mins'] ?>m</td>
                <?php if ($canEdit): ?>
                <td style="white-space:nowrap;">
                    <a href="?id=<?= $routingId ?>&edit_op=<?= $op['id'] ?>#add-op"
                       class="btn btn-secondary" style="padding:3px 7px;font-size:11px;">Edit</a>
                    <form method="POST" style="display:inline"
                          onsubmit="return confirm('Delete op <?= (int)$op['op_number'] ?>?')">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="action" value="delete_op">
                        <input type="hidden" name="op_id"  value="<?= $op['id'] ?>">
                        <button type="submit" class="btn btn-danger" style="padding:3px 7px;font-size:11px;">✕</button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($canEdit): ?>
<!-- Add / Edit op form -->
<div class="card" id="add-op">
    <div class="card-title"><?= $editOp ? 'Edit Op ' . str_pad($editOp['op_number'],3,'0',STR_PAD_LEFT) : 'Add Operation' ?></div>
    <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="action" value="save_op">
        <input type="hidden" name="op_id"  value="<?= $editOp['id'] ?? 0 ?>">

        <div class="form-group">
            <label>Op Number <span style="color:var(--accent-danger)">*</span></label>
            <input type="number" name="op_number" min="1" max="9999"
                   value="<?= $editOp['op_number'] ?? '' ?>"
                   <?= $editOp ? 'readonly style="opacity:.5;width:80px;"' : 'style="width:80px;"' ?>
                   placeholder="10" required>
        </div>

        <div class="form-group">
            <label>Behaviour</label>
            <select name="behaviour">
                <option value="CLOCKING"     <?= ($editOp['behaviour']??'CLOCKING')==='CLOCKING'?'selected':'' ?>>Clocking</option>
                <option value="NON-CLOCKING" <?= ($editOp['behaviour']??'')==='NON-CLOCKING'?'selected':'' ?>>Non-Clocking</option>
            </select>
        </div>

        <div class="form-group">
            <label>Operation Name <span style="color:var(--accent-danger)">*</span></label>
            <input type="text" name="op_name" maxlength="100"
                   value="<?= htmlspecialchars($editOp['op_name'] ?? '') ?>"
                   placeholder="Frame Fabrication" required>
        </div>

        <div class="form-group">
            <label>Operation Type</label>
            <select name="op_type">
                <?php foreach ($opTypes as $val=>$lbl): ?>
                <option value="<?= $val ?>" <?= ($editOp['op_type']??'STANDARD')===$val?'selected':'' ?>><?= $lbl ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Department</label>
            <select name="department_id" id="dept_sel" onchange="filterResources(this.value)">
                <option value="">— None —</option>
                <?php foreach ($depts as $d): ?>
                <option value="<?= $d['id'] ?>" <?= ($editOp['department_id']??0)==$d['id']?'selected':'' ?>>
                    <?= htmlspecialchars($d['code'].' — '.$d['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Resource</label>
            <select name="resource_id" id="res_sel">
                <option value="">— None —</option>
                <?php foreach ($resources as $res): ?>
                <option value="<?= $res['id'] ?>"
                        data-dept="<?= $res['department_id'] ?>"
                        <?= ($editOp['resource_id']??0)==$res['id']?'selected':'' ?>>
                    <?= htmlspecialchars($res['code'].' — '.$res['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Work Instruction <span class="text-dim">(Approved only)</span></label>
            <select name="document_id">
                <option value="">— None —</option>
                <?php foreach ($availDocs as $doc): ?>
                <option value="<?= $doc['id'] ?>" <?= ($editOp['document_id']??0)==$doc['id']?'selected':'' ?>>
                    <?= htmlspecialchars($doc['doc_number'].' (Rev '.$doc['revision_label'].')') ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
            <div class="form-group" style="margin:0;">
                <label>Setup (mins)</label>
                <input type="number" name="setup_mins"  min="0" value="<?= $editOp['setup_mins']  ?? 0 ?>">
            </div>
            <div class="form-group" style="margin:0;">
                <label>Actual (mins)</label>
                <input type="number" name="actual_mins" min="0" value="<?= $editOp['actual_mins'] ?? 0 ?>">
            </div>
        </div>

        <div style="display:flex;gap:8px;margin-top:14px;">
            <button type="submit" class="btn btn-primary">
                <?= $editOp ? 'Update Operation' : 'Add Operation' ?>
            </button>
            <?php if ($editOp): ?>
            <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $routingId ?>" class="btn btn-secondary">Cancel</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<script>
// Filter resources by selected department
function filterResources(deptId) {
    const sel = document.getElementById('res_sel');
    const cur = sel.value;
    Array.from(sel.options).forEach(o => {
        if (!o.value) return;
        o.style.display = (!deptId || o.dataset.dept === deptId) ? '' : 'none';
    });
    if (sel.options[sel.selectedIndex]?.style.display === 'none') sel.value = '';
}
// Apply on load if editing
filterResources(document.getElementById('dept_sel')?.value ?? '');
</script>
<?php endif; ?>

</div>

<?php renderPageEnd(); ?>
