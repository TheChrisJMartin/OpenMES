<?php
/**
 * routings/op_tools.php - Required Tools per Operation
 * Version: 10.9.0
 * F085: Define which tools/TE are required to complete each operation.
 * F087: Tools with expired calibration are shown as blocked.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$routingId = (int)($_GET['id'] ?? 0);
if (!$routingId) { header('Location: ' . SITE_SUBPATH . '/routings/list.php'); exit; }

$scope = orgScope();
$routing = dbFetchOne(
    "SELECT r.*, p.part_number, p.description AS part_desc, o.code AS org_code
       FROM routings r
       JOIN parts p ON p.id = r.part_id
       JOIN orgs o  ON o.id = r.org_id
      WHERE r.id=? AND ({$scope['sql']})",
    array_merge([$routingId], $scope['params'])
);
if (!$routing) { header('Location: ' . SITE_SUBPATH . '/routings/list.php'); exit; }

$canEdit = $routing['status'] === 'DRAFT' &&
           hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$message = $error = '';

// ── POST: add or remove required tool ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action  = $_POST['action'] ?? '';
    $opId    = (int)($_POST['op_id']   ?? 0);
    $toolId  = (int)($_POST['tool_id'] ?? 0);
    $notes   = trim($_POST['notes']    ?? '');

    if ($action === 'add' && $opId && $toolId && $canEdit) {
        try {
            dbInsert(
                "INSERT IGNORE INTO op_required_tools (op_id, tool_id, notes, created_by)
                 VALUES (?, ?, ?, ?)",
                [$opId, $toolId, $notes ?: null, $_SESSION['user_id']]
            );
            $message = 'Tool requirement added.';
        } catch (Throwable $e) {
            $error = 'Could not add tool: ' . $e->getMessage();
        }
    } elseif ($action === 'remove' && $opId && $toolId && $canEdit) {
        dbExecute("DELETE FROM op_required_tools WHERE op_id=? AND tool_id=?", [$opId, $toolId]);
        $message = 'Tool requirement removed.';
    }
}

// ── Load operations ────────────────────────────────────────────────────────────
$ops = dbFetchAll(
    "SELECT id, op_number, op_name, op_type, behaviour
       FROM routing_operations WHERE routing_id=? ORDER BY sort_order",
    [$routingId]
);

// ── Load required tools per op ────────────────────────────────────────────────
$reqTools = [];
foreach ($ops as $op) {
    $reqTools[$op['id']] = dbFetchAll(
        "SELECT ort.id AS req_id, ort.op_id, ort.tool_id, ort.notes,
                ct.asset_number, ct.description AS tool_desc, ct.asset_type,
                ct.calibration_due,
                CASE
                    WHEN ct.calibration_due IS NULL THEN 'NO_CAL'
                    WHEN ct.calibration_due < CURDATE() THEN 'EXPIRED'
                    WHEN ct.calibration_due < DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'DUE_SOON'
                    ELSE 'IN_DATE'
                END AS cal_status
           FROM op_required_tools ort
           JOIN calibration_tools ct ON ct.id = ort.tool_id
          WHERE ort.op_id=?
          ORDER BY ct.asset_number",
        [$op['id']]
    );
}

// ── Load available tools for add dropdown ────────────────────────────────────
$allTools = dbFetchAll(
    "SELECT ct.id, ct.asset_number, ct.description, ct.asset_type,
            ct.calibration_due,
            CASE
                WHEN ct.calibration_due IS NULL THEN 'NO_CAL'
                WHEN ct.calibration_due < CURDATE() THEN 'EXPIRED'
                WHEN ct.calibration_due < DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'DUE_SOON'
                ELSE 'IN_DATE'
            END AS cal_status
       FROM calibration_tools ct
      WHERE ct.org_id=?
      ORDER BY ct.asset_number",
    [$routing['org_id']]
);

renderPageStart('Required Tools — ' . $routing['org_code'] . '-' . $routing['part_number']);
?>

<div class="page-header page-header-row">
    <div>
        <h1>Required Tools</h1>
        <p style="color:var(--text-muted);">
            <?= htmlspecialchars($routing['org_code'] . '-' . $routing['part_number']) ?>
            &mdash; <?= htmlspecialchars($routing['part_desc']) ?>
            &mdash; Rev <?= htmlspecialchars($routing['revision']) ?>
            <span class="badge badge-<?= $routing['status'] === 'APPROVED' ? 'green' : 'yellow' ?>" style="font-size:10px;margin-left:6px;">
                <?= $routing['status'] ?>
            </span>
        </p>
    </div>
    <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $routingId ?>" class="btn btn-secondary">
        ← Back to Routing
    </a>
</div>

<!-- Tabs -->
<div style="display:flex;gap:0;border-bottom:2px solid var(--border);margin-bottom:18px;">
    <a href="<?= SITE_SUBPATH ?>/routings/edit.php?id=<?= $routingId ?>"
       style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--text-muted);text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;">
        Operations
    </a>
    <span style="padding:8px 18px;font-size:13px;font-weight:700;color:var(--text);
                 border-bottom:2px solid var(--accent-blue);margin-bottom:-2px;">
        Required Tools
    </span>
    <a href="<?= SITE_SUBPATH ?>/routings/quality_vars.php?id=<?= $routingId ?>"
       style="padding:8px 18px;font-size:13px;font-weight:600;color:var(--text-muted);text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;">
        Quality Variables
    </a>
</div>

<?php if (!$canEdit): ?>
<div class="alert alert-warning" style="margin-bottom:14px;">
    This routing is <strong><?= $routing['status'] ?></strong> — tool requirements are read-only.
    Create a new DRAFT revision to make changes.
</div>
<?php endif; ?>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php foreach ($ops as $op):
    $tools = $reqTools[$op['id']] ?? [];
    $opKey = 'op_' . $op['id'];
?>
<div class="card" style="margin-bottom:14px;padding:0;overflow:hidden;">
    <div style="padding:10px 16px;border-bottom:1px solid var(--border);background:var(--bg);
                display:flex;align-items:center;justify-content:space-between;">
        <div style="font-weight:600;font-size:13px;">
            <code style="color:var(--accent-blue);"><?= htmlspecialchars($op['op_number']) ?></code>
            &nbsp;<?= htmlspecialchars($op['op_name']) ?>
            <span class="text-dim" style="font-size:11px;margin-left:6px;"><?= $op['op_type'] ?></span>
        </div>
        <?php if ($canEdit): ?>
        <button onclick="document.getElementById('add-<?= $opKey ?>').style.display='block';this.style.display='none'"
                class="btn btn-secondary" style="font-size:11px;padding:4px 10px;">
            + Add Tool
        </button>
        <?php endif; ?>
    </div>

    <?php if ($canEdit): ?>
    <!-- Add tool form (hidden by default) -->
    <div id="add-<?= $opKey ?>" style="display:none;padding:12px 16px;background:var(--bg-card);border-bottom:1px solid var(--border);">
        <form method="POST" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="action"  value="add">
            <input type="hidden" name="op_id"   value="<?= $op['id'] ?>">
            <div style="flex:2;min-width:200px;">
                <label style="font-size:11px;color:var(--text-muted);display:block;margin-bottom:3px;">Tool / Test Equipment</label>
                <select name="tool_id" class="form-control" required>
                    <option value="">— Select tool —</option>
                    <?php foreach ($allTools as $t):
                        $calBadge = match($t['cal_status']) {
                            'EXPIRED'  => ' [EXPIRED]',
                            'DUE_SOON' => ' [Due Soon]',
                            default    => ''
                        };
                    ?>
                    <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['asset_number'] . ' — ' . $t['description'] . $calBadge) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="flex:1;min-width:150px;">
                <label style="font-size:11px;color:var(--text-muted);display:block;margin-bottom:3px;">Notes (optional)</label>
                <input type="text" name="notes" maxlength="200" placeholder="e.g. torque setting 25Nm">
            </div>
            <button type="submit" class="btn btn-primary" style="font-size:12px;padding:7px 16px;">Add</button>
            <button type="button" onclick="document.getElementById('add-<?= $opKey ?>').style.display='none'"
                    class="btn btn-secondary" style="font-size:12px;padding:7px 12px;">Cancel</button>
        </form>
    </div>
    <?php endif; ?>

    <?php if (empty($tools)): ?>
    <div style="padding:14px 16px;font-size:12px;color:var(--text-muted);">No tools required for this operation.</div>
    <?php else: ?>
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr><th>Asset #</th><th>Type</th><th>Description</th><th>Calibration</th><th>Notes</th><?= $canEdit ? '<th></th>' : '' ?></tr>
            </thead>
            <tbody>
            <?php foreach ($tools as $t):
                $calColour = match($t['cal_status']) {
                    'EXPIRED'  => 'var(--accent-danger)',
                    'DUE_SOON' => 'var(--accent-warn)',
                    'IN_DATE'  => '#3fb950',
                    default    => 'var(--text-dim)',
                };
                $calLabel = match($t['cal_status']) {
                    'EXPIRED'  => 'EXPIRED',
                    'DUE_SOON' => 'Due ' . ($t['calibration_due'] ?? ''),
                    'IN_DATE'  => 'In Date',
                    default    => 'No Cal Required',
                };
            ?>
            <tr>
                <td><code style="font-size:12px;"><?= htmlspecialchars($t['asset_number']) ?></code></td>
                <td><span class="badge badge-<?= $t['asset_type'] === 'TE' ? 'blue' : 'grey' ?>" style="font-size:10px;"><?= $t['asset_type'] ?></span></td>
                <td style="font-size:12px;"><?= htmlspecialchars($t['tool_desc']) ?></td>
                <td style="font-size:11px;color:<?= $calColour ?>;font-weight:<?= $t['cal_status']==='EXPIRED'?'700':'400' ?>;">
                    <?= htmlspecialchars($calLabel) ?>
                </td>
                <td style="font-size:11px;color:var(--text-muted);"><?= htmlspecialchars($t['notes'] ?? '—') ?></td>
                <?php if ($canEdit): ?>
                <td>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('Remove this tool requirement?')">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="action"  value="remove">
                        <input type="hidden" name="op_id"   value="<?= $op['id'] ?>">
                        <input type="hidden" name="tool_id" value="<?= $t['tool_id'] ?>">
                        <button type="submit" class="btn btn-danger" style="padding:3px 8px;font-size:11px;">Remove</button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<?php renderPageEnd(); ?>
