<?php
/**
 * supervisor.php — Supervisor View
 * Version: 10.5.0
 * Shows work order list with live status — accessible by all personas
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/helpers.php';

requireLogin();

$scope        = orgScope('w');
$filterStatus = $_GET['status'] ?? '';
$filterOrg    = (int)($_GET['org'] ?? 0);
$search       = trim($_GET['search'] ?? '');

$where  = '(' . $scope['sql'] . ')';
$params = $scope['params'];

if ($filterStatus && in_array($filterStatus,['OPEN','IN_PROGRESS','ON_HOLD','COMPLETE','CANCELLED'])) {
    $where .= ' AND w.status=?'; $params[] = $filterStatus;
}
if ($filterOrg && hasPersona('IT_ADMIN')) {
    $where .= ' AND w.org_id=?'; $params[] = $filterOrg;
}
if ($search !== '') {
    $where .= ' AND (w.wo_number LIKE ? OR p.part_number LIKE ? OR p.description LIKE ?)';
    $params[] = "%{$search}%"; $params[] = "%{$search}%"; $params[] = "%{$search}%";
}

$workOrders = dbFetchAll(
    "SELECT w.*,
            o.code AS org_code,
            p.part_number, p.description AS part_desc,
            r.revision_label AS routing_rev,
            u.known_as AS creator_name,
            (SELECT COUNT(*) FROM serial_numbers sn WHERE sn.wo_id=w.id) AS serial_total,
            (SELECT COUNT(*) FROM serial_numbers sn WHERE sn.wo_id=w.id AND sn.status='COMPLETE') AS serial_done,
            (SELECT COUNT(*) FROM serial_numbers sn WHERE sn.wo_id=w.id AND sn.status='IN_PROGRESS') AS serial_wip,
            (SELECT COUNT(*) FROM serial_numbers sn WHERE sn.wo_id=w.id AND sn.status='ON_HOLD') AS serial_hold,
            (SELECT COUNT(*) FROM non_conformances nc WHERE nc.wo_id=w.id AND nc.status IN ('OPEN','UNDER_REVIEW')) AS open_ncs,
            (SELECT COALESCE(SUM(ce.duration_mins),0) FROM wo_clock_events ce WHERE ce.wo_id=w.id AND ce.event_type IN ('COMPLETE','CLOCK_OFF')) AS booked_mins,
            (SELECT COALESCE(SUM(ro.actual_mins),0) FROM routing_operations ro WHERE ro.routing_id=w.routing_id) AS total_std_mins,
            (SELECT COALESCE(SUM(ro.actual_mins),0)
               FROM routing_operations ro
              WHERE ro.routing_id = w.routing_id
                AND EXISTS (
                    SELECT 1 FROM wo_clock_events ce
                     WHERE ce.wo_id = w.id
                       AND ce.op_id = ro.id
                       AND ce.event_type = 'COMPLETE'
                )) AS done_std_mins,
            w.planned_start, w.planned_finish, w.priority
     FROM work_orders w
     JOIN orgs o     ON o.id = w.org_id
     JOIN parts p    ON p.id = w.part_id
     JOIN routings r ON r.id = w.routing_id
     LEFT JOIN users u ON u.id = w.created_by
     WHERE {$where}
     ORDER BY
         FIELD(w.status,'ON_HOLD','IN_PROGRESS','OPEN','COMPLETE','CANCELLED'),
         w.created_at DESC",
    $params
);

// Quick stats across visible WOs
$statsTotal    = count($workOrders);
$statsOpen     = count(array_filter($workOrders, fn($w)=>$w['status']==='OPEN'));
$statsWip      = count(array_filter($workOrders, fn($w)=>$w['status']==='IN_PROGRESS'));
$statsHold     = count(array_filter($workOrders, fn($w)=>$w['status']==='ON_HOLD'));
$statsComplete = count(array_filter($workOrders, fn($w)=>$w['status']==='COMPLETE'));
$statsNCs      = array_sum(array_column($workOrders, 'open_ncs'));

$orgs = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");


renderPageStart('Supervisor View');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Supervisor View</h1>
        <p>Live work order status across your organisation<?= hasPersona('IT_ADMIN') ? 's' : '' ?>.</p>
    </div>
</div>

<!-- Summary stats -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:16px;">
    <?php foreach ([
        [$statsTotal,    'Total WOs',    'var(--accent-blue)'],
        [$statsOpen,     'Open',         'var(--accent-blue)'],
        [$statsWip,      'In Progress',  '#3fb950'],
        [$statsHold,     'On Hold',      'var(--accent-warn)'],
        [$statsComplete, 'Complete',     'var(--text-dim)'],
        [$statsNCs,      'Open NCs',     $statsNCs>0?'var(--accent-danger)':'var(--text-dim)'],
    ] as [$n,$l,$c]): ?>
    <div class="card" style="margin:0;text-align:center;padding:12px;">
        <div style="font-size:22px;font-weight:700;color:<?= $c ?>;font-family:monospace;"><?= $n ?></div>
        <div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-top:2px;"><?= $l ?></div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card" style="padding:14px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                   placeholder="WO number or part…" style="width:200px;">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Status</label>
            <select name="status" style="width:140px;">
                <option value="">All</option>
                <option value="OPEN"        <?= $filterStatus==='OPEN'       ?'selected':'' ?>>Open</option>
                <option value="IN_PROGRESS" <?= $filterStatus==='IN_PROGRESS'?'selected':'' ?>>In Progress</option>
                <option value="ON_HOLD"     <?= $filterStatus==='ON_HOLD'    ?'selected':'' ?>>On Hold</option>
                <option value="COMPLETE"    <?= $filterStatus==='COMPLETE'   ?'selected':'' ?>>Complete</option>
            </select>
        </div>
        <?php if (hasPersona('IT_ADMIN')): ?>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Org</label>
            <select name="org" style="width:110px;">
                <option value="0">All</option>
                <?php foreach ($orgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $filterOrg===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="<?= SITE_SUBPATH ?>/supervisor.php" class="btn btn-secondary">Clear</a>
        <span style="margin-left:auto;font-size:11px;color:var(--text-dim);align-self:center;">
            Auto-refresh:
            <select onchange="setRefresh(this.value)" style="width:auto;font-size:11px;padding:3px 6px;">
                <option value="0">Off</option>
                <option value="30">30s</option>
                <option value="60">1 min</option>
                <option value="300">5 min</option>
            </select>
        </span>
    </form>
</div>

<!-- WO Table -->
<div class="card" style="padding:0;overflow:hidden;">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>WO Number</th>
                    <th>Org</th>
                    <th>Part</th>
                    <th>Pri</th>
                    <th>Progress</th>
                    <th>WIP</th>
                    <th>Hold</th>
                    <th>NCs</th>
                    <th>Booked</th>
                    <th>Planned Start</th>
                    <th>Planned Finish</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($workOrders as $wo):
                // Progress: prefer standard-time based, fallback to serial count
                $stdTotal = (float)($wo['total_std_mins'] ?? 0);
                $stdDone  = (float)($wo['done_std_mins']  ?? 0);
                $progress = $stdTotal > 0
                    ? round(($stdDone / $stdTotal) * 100)
                    : ($wo['serial_total'] > 0 ? round(($wo['serial_done'] / $wo['serial_total']) * 100) : 0);
                $bkMins = (float)$wo['booked_mins'];
                $bkH = floor($bkMins/60); $bkM = round(fmod($bkMins,60));
                $priColour = ($wo['priority']??50) <= 20 ? 'var(--accent-danger)'
                           : (($wo['priority']??50) <= 40 ? 'var(--accent-warn)' : 'var(--text-dim)');
            ?>
            <tr style="<?= $wo['open_ncs']>0?'background:rgba(248,81,73,.04);':'' ?>">
                <td>
                    <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $wo['id'] ?>"
                       style="color:var(--accent-blue);text-decoration:none;font-weight:700;font-family:monospace;font-size:12px;">
                        <?= htmlspecialchars($wo['wo_number']) ?>
                    </a>
                    <div class="text-dim" style="font-size:10px;"><?= htmlspecialchars(substr($wo['part_desc'],0,22)) ?></div>
                </td>
                <td><code style="font-size:11px;"><?= htmlspecialchars($wo['org_code']) ?></code></td>
                <td style="font-size:12px;font-weight:600;"><?= htmlspecialchars($wo['part_number']) ?></td>
                <td style="text-align:center;">
                    <span style="font-weight:700;font-size:12px;color:<?= $priColour ?>;">
                        <?= $wo['priority']??50 ?>
                    </span>
                </td>
                <td style="min-width:120px;">
                    <div style="display:flex;align-items:center;gap:5px;">
                        <div style="flex:1;height:7px;background:var(--border);border-radius:3px;overflow:hidden;">
                            <div style="height:100%;width:<?= $progress ?>%;background:<?= $progress>=100?'#3fb950':'var(--accent-blue)' ?>;border-radius:3px;transition:width .3s;"></div>
                        </div>
                        <span class="text-dim" style="font-size:10px;white-space:nowrap;font-family:monospace;"><?= $progress ?>%</span>
                    </div>
                    <?php if ($stdTotal > 0): ?>
                    <div class="text-dim" style="font-size:9px;margin-top:2px;"><?= round($stdDone) ?>m / <?= round($stdTotal) ?>m std</div>
                    <?php else: ?>
                    <div class="text-dim" style="font-size:9px;margin-top:2px;"><?= $wo['serial_done'] ?>/<?= $wo['serial_total'] ?> units</div>
                    <?php endif; ?>
                </td>
                <td style="text-align:center;">
                    <?= $wo['serial_wip'] > 0 ? '<span class="badge badge-blue" style="font-size:10px;">'.(int)$wo['serial_wip'].'</span>' : '<span class="text-dim">—</span>' ?>
                </td>
                <td style="text-align:center;">
                    <?= $wo['serial_hold'] > 0 ? '<span class="badge badge-yellow" style="font-size:10px;">'.(int)$wo['serial_hold'].'</span>' : '<span class="text-dim">—</span>' ?>
                </td>
                <td style="text-align:center;">
                    <?= $wo['open_ncs'] > 0 ? '<span class="badge badge-red" style="font-size:10px;">⚠ '.(int)$wo['open_ncs'].'</span>' : '<span class="text-dim">—</span>' ?>
                </td>
                <td style="font-size:11px;font-family:monospace;white-space:nowrap;">
                    <?= $bkH>0 ? "{$bkH}h " : '' ?><?= $bkM ?>m
                </td>
                <td style="font-size:11px;white-space:nowrap;color:var(--text-muted);">
                    <?= $wo['planned_start'] ? displayDate($wo['planned_start'],'d M H:i') : '—' ?>
                </td>
                <td style="font-size:11px;white-space:nowrap;<?= ($wo['planned_finish'] && $wo['planned_finish'] < date('Y-m-d H:i:s') && $wo['status']!=='COMPLETE') ? 'color:var(--accent-danger);font-weight:700;' : 'color:var(--text-muted);' ?>">
                    <?= $wo['planned_finish'] ? displayDate($wo['planned_finish'],'d M H:i') : '—' ?>
                    <?php if ($wo['planned_finish'] && $wo['planned_finish'] < date('Y-m-d H:i:s') && $wo['status']!=='COMPLETE'): ?>
                    <span class="badge badge-red" style="font-size:9px;display:block;">OVERDUE</span>
                    <?php endif; ?>
                </td>
                <td><?= woStatusBadge($wo['status'],$wo['hold_type']) ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= SITE_SUBPATH ?>/workorders/view.php?id=<?= $wo['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">View</a>
                    <?php if (!in_array($wo['status'],['COMPLETE','CANCELLED'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/workorders/operator.php?id=<?= $wo['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 8px;font-size:11px;">Execute</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$workOrders): ?>
            <tr><td colspan="13" style="text-align:center;color:var(--text-dim);padding:32px;">
                No work orders found.
            </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
let refreshTimer = null;
function setRefresh(secs) {
    if (refreshTimer) clearInterval(refreshTimer);
    if (parseInt(secs) > 0) {
        refreshTimer = setInterval(() => window.location.reload(), parseInt(secs) * 1000);
    }
}
</script>

<?php renderPageEnd(); ?>
