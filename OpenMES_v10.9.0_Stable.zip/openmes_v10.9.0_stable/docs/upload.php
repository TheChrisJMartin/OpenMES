<?php
/**
 * docs/upload.php — Upload / New Revision of a Document
 * Version: 3.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$message = '';
$error   = '';

// Are we creating a new revision of an existing document group?
$existingGroupId = trim($_GET['group'] ?? '');
$existingDoc     = null;
$nextRevision    = 1;

if ($existingGroupId) {
    $existingDoc = dbFetchOne(
        "SELECT d.*, p.part_number FROM documents d
         LEFT JOIN parts p ON p.id = d.part_id
         WHERE d.doc_group_id = ? ORDER BY d.revision DESC LIMIT 1",
        [$existingGroupId]
    );
    if ($existingDoc) {
        $nextRevision = $existingDoc['revision'] + 1;
    }
}

$scope  = orgScope();
$orgs   = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$parts  = dbFetchAll(
    "SELECT p.id,p.part_number,p.description,o.code AS org_code
     FROM parts p JOIN orgs o ON o.id=p.org_id
     WHERE ({$scope['sql']}) AND p.active=1 ORDER BY o.code,p.part_number",
    $scope['params']
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CD003: Verify CSRF token
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $orgId       = (int)($_POST['org_id'] ?? 0);
    $partId      = ($_POST['part_id'] !== '' && $_POST['part_id'] !== '0') ? (int)$_POST['part_id'] : null;
    $description = trim($_POST['description'] ?? '');
    $isNewGroup  = empty($_POST['doc_group_id']);
    $groupId     = $isNewGroup ? sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff),
        mt_rand(0,0x0fff)|0x4000, mt_rand(0,0x3fff)|0x8000,
        mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff)
    ) : trim($_POST['doc_group_id']);

    // Validate
    if ($orgId === 0)      $error = 'Please select an organisation.';
    elseif ($description === '') $error = 'Description is required.';
    elseif (empty($_FILES['pdf_file']['name'])) $error = 'Please select a PDF file to upload.';
    elseif ($_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) $error = 'Upload error. Please try again.';
    elseif (strtolower(pathinfo($_FILES['pdf_file']['name'], PATHINFO_EXTENSION)) !== 'pdf') $error = 'Only PDF files are accepted.';
    elseif (!function_exists('finfo_open') ||
            ($finfo = finfo_open(FILEINFO_MIME_TYPE)) === false ||
            ($mime = finfo_file($finfo, $_FILES['pdf_file']['tmp_name'])) === false ||
            !in_array($mime, ['application/pdf', 'application/x-pdf'], true))
        $error = 'File does not appear to be a valid PDF. Please check the file and try again.'; // CD007

    if (!$error) {
        // Determine doc number
        if ($isNewGroup) {
            if ($partId) {
                $part = dbFetchOne("SELECT p.part_number, o.code AS org_code FROM parts p JOIN orgs o ON o.id=p.org_id WHERE p.id=?", [$partId]);
                $docNumber = ($part['org_code'] ?? '') . '-' . ($part['part_number'] ?? $partId);
            } else {
                $shortId = strtoupper(substr(str_replace('-', '', $groupId), 0, 8));
                $docNumber = 'GENERIC-DOC-' . $shortId;
            }
        } else {
            $docNumber = $existingDoc['doc_number'];
        }

        // Get next revision number
        if (!$isNewGroup) {
            $maxRev = dbFetchOne(
                "SELECT MAX(revision) AS maxrev FROM documents WHERE doc_group_id=?",
                [$groupId]
            )['maxrev'] ?? 0;
            $revision = $maxRev + 1;
        } else {
            $revision = 1;
        }
        $revLabel = str_pad($revision, 6, '0', STR_PAD_LEFT);

        // Save file
        $uploadDir = UPLOADS_PATH . '/' . $orgId . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $safeFilename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $_FILES['pdf_file']['name']);
        $storedName   = date('YmdHis') . '_' . $safeFilename;
        $destPath     = $uploadDir . $storedName;
        $relPath      = 'uploads/documents/' . $orgId . '/' . $storedName;

        if (!move_uploaded_file($_FILES['pdf_file']['tmp_name'], $destPath)) {
            $error = 'Failed to save the uploaded file. Check the uploads directory is writable.';
        }
    }

    if (!$error) {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            // Supersede all previous APPROVED revisions in this group
            if (!$isNewGroup) {
                dbExecute(
                    "UPDATE documents SET status='SUPERSEDED', updated_at=NOW()
                     WHERE doc_group_id=? AND status='APPROVED'",
                    [$groupId]
                );
            }

            // Insert new revision as DRAFT
            $newId = dbInsert(
                "INSERT INTO documents
                    (org_id, doc_group_id, doc_number, description, part_id,
                     revision, revision_label, status, file_name, file_path,
                     file_size, uploaded_by, uploaded_at)
                 VALUES (?,?,?,?,?,?,?,'DRAFT',?,?,?,?,NOW())",
                [
                    $orgId, $groupId, $docNumber, $description, $partId,
                    $revision, $revLabel,
                    $safeFilename, $relPath,
                    $_FILES['pdf_file']['size'],
                    $_SESSION['user_id']
                ]
            );

            writeAuditLog(
                'DOC_UPLOAD', 'document', (string)$newId, $orgId,
                null, null, 'revision', null, $revLabel,
                "Uploaded {$docNumber} Rev {$revLabel} — {$description}"
            );

            $pdo->commit();
            $message = "Document '{$docNumber}' Rev {$revLabel} uploaded as DRAFT. It must be approved before use.";
            $existingGroupId = '';
            $existingDoc     = null;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

renderPageStart('Upload Document');
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/docs/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Documents</a>
    <h1 style="margin-top:6px;">
        <?= $existingDoc ? 'New Revision — ' . htmlspecialchars($existingDoc['doc_number']) : 'Upload Document' ?>
    </h1>
    <?php if ($existingDoc): ?>
    <p>Current revision: <strong><?= htmlspecialchars($existingDoc['revision_label']) ?></strong>
       &mdash; New revision will be: <strong><?= str_pad($nextRevision,6,'0',STR_PAD_LEFT) ?></strong></p>
    <?php endif; ?>
</div>

<?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card">
    <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <input type="hidden" name="doc_group_id" value="<?= htmlspecialchars($existingDoc['doc_group_id'] ?? '') ?>">

        <?php if (!$existingDoc): ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
            <div class="form-group" style="margin:0;">
                <label>Organisation <span style="color:var(--accent-danger)">*</span></label>
                <select name="org_id" required>
                    <option value="">— Select —</option>
                    <?php foreach ($orgs as $o):
                        if (!hasPersona('IT_ADMIN') && $o['id'] != currentOrgId()) continue;
                    ?>
                    <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['code'] . ' — ' . $o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label>Link to Part Number <span style="color:var(--text-dim)">(optional — leave blank for generic)</span></label>
                <select name="part_id">
                    <option value="">— Generic Document —</option>
                    <?php foreach ($parts as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['org_code'] . ' › ' . $p['part_number'] . ' — ' . $p['description']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <?php else: ?>
        <input type="hidden" name="org_id" value="<?= $existingDoc['org_id'] ?>">
        <input type="hidden" name="part_id" value="<?= $existingDoc['part_id'] ?? '' ?>">
        <div class="alert alert-info" style="margin-bottom:14px;">
            Uploading new revision of <strong><?= htmlspecialchars($existingDoc['doc_number']) ?></strong>.
            The current approved revision will be marked as Superseded.
            New revision will be DRAFT until approved.
        </div>
        <?php endif; ?>

        <div class="form-group">
            <label>Description <span style="color:var(--accent-danger)">*</span></label>
            <input type="text" name="description" maxlength="200"
                   value="<?= htmlspecialchars($existingDoc['description'] ?? '') ?>"
                   placeholder="e.g. Road Bike Frame Assembly & Torque Settings" required>
        </div>

        <div class="form-group">
            <label>PDF File <span style="color:var(--accent-danger)">*</span></label>
            <input type="file" name="pdf_file" accept=".pdf,application/pdf" required
                   style="padding:6px;background:var(--bg-input);border:1px solid var(--border);border-radius:var(--radius);width:100%;color:var(--text);">
            <div class="text-dim" style="margin-top:4px;">PDF files only. Max file size governed by your server PHP upload limits.</div>
        </div>

        <div style="display:flex;gap:8px;">
            <button type="submit" class="btn btn-primary">
                <?= $existingDoc ? 'Upload New Revision' : 'Upload Document' ?>
            </button>
            <a href="<?= SITE_SUBPATH ?>/docs/list.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php renderPageEnd(); ?>
