<?php
/**
 * docs/archive.php — Archive a superseded document revision
 * Version: 4.0.0
 * Only MFG_ENGINEER_SUP and IT_ADMIN may archive.
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER_SUP']);

$docId = (int)($_GET['id'] ?? 0);
$scope = orgScope('d');

$doc = dbFetchOne(
    "SELECT d.* FROM documents d
     WHERE d.id=? AND d.status='SUPERSEDED' AND ({$scope['sql']})",
    array_merge([$docId], $scope['params'])
);

if (!$doc) {
    header('Location: ' . SITE_URL . '/docs/list.php');
    exit;
}

dbExecute(
    "UPDATE documents SET status='ARCHIVED', archived_by=?, archived_at=NOW(), updated_at=NOW() WHERE id=?",
    [$_SESSION['user_id'], $docId]
);

writeAuditLog(
    'DOC_ARCHIVED', 'document', (string)$docId, $doc['org_id'],
    null, null, 'status', 'SUPERSEDED', 'ARCHIVED',
    'Archived: ' . $doc['doc_number'] . ' Rev ' . $doc['revision_label']
);

header('Location: ' . SITE_URL . '/docs/list.php?archived=1');
exit;
