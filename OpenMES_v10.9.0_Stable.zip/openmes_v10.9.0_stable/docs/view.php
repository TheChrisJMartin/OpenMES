<?php
/**
 * docs/view.php — Document Viewer with inline PDF.js rendering
 * Version: 3.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();

$docId  = (int)($_GET['id'] ?? 0);
$scope  = orgScope('d');

$doc = dbFetchOne(
    "SELECT d.*, o.code AS org_code, o.name AS org_name,
            p.part_number, p.description AS part_desc,
            uu.known_as AS uploader_name,
            ua.known_as AS approver_name
     FROM documents d
     JOIN orgs o ON o.id=d.org_id
     LEFT JOIN parts p  ON p.id=d.part_id
     LEFT JOIN users uu ON uu.id=d.uploaded_by
     LEFT JOIN users ua ON ua.id=d.approved_by
     WHERE d.id=? AND ({$scope['sql']})",
    array_merge([$docId], $scope['params'])
);

if (!$doc) {
    renderPageStart('Document Not Found');
    echo '<div class="alert alert-danger">Document not found or you do not have access.</div>';
    echo '<a href="' . SITE_SUBPATH . '/docs/list.php" class="btn btn-secondary">← Back to Documents</a>';
    renderPageEnd();
    exit;
}

// All revisions for this document group
$allRevisions = dbFetchAll(
    "SELECT d.id, d.revision, d.revision_label, d.status, d.uploaded_at, u.known_as AS uploader_name
     FROM documents d
     LEFT JOIN users u ON u.id=d.uploaded_by
     WHERE d.doc_group_id=? ORDER BY d.revision DESC",
    [$doc['doc_group_id']]
);

// PDF URL — serve via api/serve_pdf.php for access control
$pdfUrl = SITE_URL . '/api/serve_pdf.php?id=' . $docId;
$approved = isset($_GET['approved']);

renderPageStart('View — ' . $doc['doc_number']);
?>

<?php if ($approved): ?>
<div class="alert alert-success">✓ Document approved successfully.</div>
<?php endif; ?>

<div class="page-header page-header-row">
    <div>
        <a href="<?= SITE_SUBPATH ?>/docs/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Documents</a>
        <h1 style="margin-top:6px;"><?= htmlspecialchars($doc['doc_number']) ?></h1>
        <p><?= htmlspecialchars($doc['description']) ?></p>
    </div>
    <div style="display:flex;gap:8px;align-items:flex-start;flex-wrap:wrap;">
        <?php echo match($doc['status']) {
            'APPROVED'   => '<span class="badge badge-green" style="font-size:12px;padding:5px 12px;">✓ Approved</span>',
            'DRAFT'      => '<span class="badge badge-yellow" style="font-size:12px;padding:5px 12px;">Draft</span>',
            'SUPERSEDED' => '<span class="badge badge-grey" style="font-size:12px;padding:5px 12px;">Superseded</span>',
            default      => ''
        }; ?>
        <?php if ($doc['status'] === 'DRAFT' && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
        <a href="<?= SITE_SUBPATH ?>/docs/approve.php?id=<?= $docId ?>" class="btn btn-primary">Approve</a>
        <?php endif; ?>
        <?php if (hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
        <a href="<?= SITE_SUBPATH ?>/docs/upload.php?group=<?= urlencode($doc['doc_group_id']) ?>" class="btn btn-secondary">Upload New Revision</a>
        <?php endif; ?>
    </div>
</div>

<div style="display:grid;grid-template-columns:280px 1fr;gap:16px;align-items:start;">

    <!-- Sidebar: doc info + revision history -->
    <div>
        <div class="card">
            <div class="card-title">Document Info</div>
            <div style="font-size:12px;display:flex;flex-direction:column;gap:8px;">
                <div><span class="text-dim">Org:</span> <code><?= htmlspecialchars($doc['org_code']) ?></code></div>
                <div><span class="text-dim">Part:</span> <?= $doc['part_number'] ? '<code>' . htmlspecialchars($doc['part_number']) . '</code>' : '<span class="text-dim">Generic</span>' ?></div>
                <div><span class="text-dim">Revision:</span> <code><?= htmlspecialchars($doc['revision_label']) ?></code></div>
                <div><span class="text-dim">File:</span> <?= htmlspecialchars($doc['file_name']) ?></div>
                <div><span class="text-dim">Size:</span> <?= number_format($doc['file_size'] / 1024, 1) ?> KB</div>
                <div><span class="text-dim">Uploaded by:</span> <?= htmlspecialchars($doc['uploader_name'] ?? '—') ?></div>
                <div><span class="text-dim">Uploaded at:</span> <?= htmlspecialchars($doc['uploaded_at']) ?></div>
                <?php if ($doc['approved_by']): ?>
                <div><span class="text-dim">Approved by:</span> <?= htmlspecialchars($doc['approver_name'] ?? '—') ?> <?= $doc['auto_approved'] ? '⚡' : '' ?></div>
                <div><span class="text-dim">Approved at:</span> <?= htmlspecialchars($doc['approved_at']) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card" style="margin-top:0;">
            <div class="card-title">Revision History</div>
            <?php foreach ($allRevisions as $rev): ?>
            <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                <code style="min-width:52px;"><?= htmlspecialchars($rev['revision_label']) ?></code>
                <?php echo match($rev['status']) {
                    'APPROVED'   => '<span class="badge badge-green">Approved</span>',
                    'DRAFT'      => '<span class="badge badge-yellow">Draft</span>',
                    'SUPERSEDED' => '<span class="badge badge-grey">Superseded</span>',
                    default      => ''
                }; ?>
                <?php if ($rev['id'] != $docId): ?>
                <a href="<?= SITE_SUBPATH ?>/docs/view.php?id=<?= $rev['id'] ?>"
                   style="color:var(--accent-blue);margin-left:auto;">View</a>
                <?php else: ?>
                <span style="color:var(--text-dim);margin-left:auto;">Current</span>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- PDF Viewer -->
    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;">
            <span style="font-size:13px;font-weight:600;">PDF Preview</span>
            <a href="<?= htmlspecialchars($pdfUrl) ?>" target="_blank"
               class="btn btn-secondary" style="margin-left:auto;padding:4px 12px;font-size:12px;">
                Open in new tab ↗
            </a>
        </div>

        <!-- PDF.js viewer -->
        <div id="pdf-container" style="width:100%;height:800px;background:#1a1a1a;position:relative;">
            <div id="pdf-loading" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);color:#888;font-size:13px;">
                Loading PDF…
            </div>
            <canvas id="pdf-canvas" style="display:none;width:100%;"></canvas>

            <!-- Page controls -->
            <div id="pdf-controls" style="display:none;position:absolute;bottom:0;left:0;right:0;
                 background:rgba(0,0,0,.75);padding:10px 16px;display:flex;align-items:center;gap:12px;">
                <button onclick="changePage(-1)" class="btn btn-secondary" style="padding:4px 12px;">‹ Prev</button>
                <span style="font-size:12px;color:#ccc;">
                    Page <span id="page-num">1</span> of <span id="page-count">?</span>
                </span>
                <button onclick="changePage(1)" class="btn btn-secondary" style="padding:4px 12px;">Next ›</button>
                <button onclick="zoomIn()" class="btn btn-secondary" style="padding:4px 10px;margin-left:12px;">＋</button>
                <button onclick="zoomOut()" class="btn btn-secondary" style="padding:4px 10px;">－</button>
                <span id="zoom-level" style="font-size:11px;color:#aaa;">100%</span>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
        <script>
        (function() {
            const pdfUrl   = <?= json_encode($pdfUrl) ?>;
            const canvas   = document.getElementById('pdf-canvas');
            const ctx      = canvas.getContext('2d');
            const loading  = document.getElementById('pdf-loading');
            const controls = document.getElementById('pdf-controls');
            const numEl    = document.getElementById('page-num');
            const cntEl    = document.getElementById('page-count');
            const zoomEl   = document.getElementById('zoom-level');

            let pdfDoc  = null;
            let pageNum = 1;
            let scale   = 1.4;

            pdfjsLib.GlobalWorkerOptions.workerSrc =
                'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

            pdfjsLib.getDocument(pdfUrl).promise.then(function(pdf) {
                pdfDoc = pdf;
                cntEl.textContent = pdf.numPages;
                loading.style.display = 'none';
                canvas.style.display  = 'block';
                controls.style.display = 'flex';
                renderPage(pageNum);
            }).catch(function(err) {
                loading.textContent = 'Could not load PDF: ' + err.message;
            });

            function renderPage(num) {
                pdfDoc.getPage(num).then(function(page) {
                    const viewport = page.getViewport({scale: scale});
                    canvas.height  = viewport.height;
                    canvas.width   = viewport.width;
                    canvas.style.width  = '100%';
                    canvas.style.height = 'auto';
                    page.render({canvasContext: ctx, viewport: viewport});
                    numEl.textContent  = num;
                    zoomEl.textContent = Math.round(scale * 100) + '%';
                });
            }

            window.changePage = function(delta) {
                const next = pageNum + delta;
                if (next < 1 || next > pdfDoc.numPages) return;
                pageNum = next;
                renderPage(pageNum);
            };

            window.zoomIn  = function() { scale = Math.min(scale + 0.2, 3.0); renderPage(pageNum); };
            window.zoomOut = function() { scale = Math.max(scale - 0.2, 0.4); renderPage(pageNum); };
        })();
        </script>
    </div>
</div>

<?php renderPageEnd(); ?>
