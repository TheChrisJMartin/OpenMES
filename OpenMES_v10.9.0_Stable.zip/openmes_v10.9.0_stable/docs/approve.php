<?php
/**
 * docs/approve.php — Document Approval Screen
 * Version: 3.0.0
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP']);

$docId   = (int)($_GET['id'] ?? 0);
$scope   = orgScope('d');
$message = '';
$error   = '';

$doc = dbFetchOne(
    "SELECT d.*, o.code AS org_code, p.part_number,
            uu.id AS uploader_id, uu.known_as AS uploader_name
     FROM documents d
     JOIN orgs o ON o.id=d.org_id
     LEFT JOIN parts p ON p.id=d.part_id
     LEFT JOIN users uu ON uu.id=d.uploaded_by
     WHERE d.id=? AND ({$scope['sql']})",
    array_merge([$docId], $scope['params'])
);

if (!$doc) {
    renderPageStart('Document Not Found');
    echo '<div class="alert alert-danger">Document not found or access denied.</div>';
    echo '<a href="' . SITE_SUBPATH . '/docs/list.php" class="btn btn-secondary">← Back</a>';
    renderPageEnd();
    exit;
}

if ($doc['status'] !== 'DRAFT') {
    header('Location: ' . SITE_URL . '/docs/view.php?id=' . $docId);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'approve' || $action === 'auto_approve') {
        $isAuto = ($action === 'auto_approve');

        // Standard approval: must be a different user from uploader
        if (!$isAuto && $_SESSION['user_id'] == $doc['uploader_id']) {
            $error = 'You cannot approve a document you uploaded. A different user must approve it.';
        }

        // Auto-approve: IT Admin only AND config must allow it
        if ($isAuto && !hasPersona('IT_ADMIN')) {
            $error = 'Only IT Admin can use auto-approve.';
        }
        if ($isAuto && !AUTO_APPROVE_DOCS) {
            $error = 'Auto-approve is disabled in config.php (AUTO_APPROVE_DOCS = false).';
        }

        if (!$error) {
            $pdo = getDB();
            $pdo->beginTransaction();
            try {
                dbExecute(
                    "UPDATE documents SET status='APPROVED', approved_by=?, approved_at=NOW(), auto_approved=?, updated_at=NOW() WHERE id=?",
                    [$_SESSION['user_id'], $isAuto ? 1 : 0, $docId]
                );
                writeAuditLog(
                    $isAuto ? 'DOC_AUTO_APPROVED' : 'DOC_APPROVED',
                    'document', (string)$docId, $doc['org_id'],
                    null, null, 'status', 'DRAFT', 'APPROVED',
                    ($isAuto ? 'Auto-approved' : 'Approved') . ': ' . $doc['doc_number'] . ' Rev ' . $doc['revision_label']
                );
                $pdo->commit();
                header('Location: ' . SITE_URL . '/docs/view.php?id=' . $docId . '&approved=1');
                exit;
            } catch (Throwable $e) {
                $pdo->rollBack();
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

renderPageStart('Approve Document');
?>

<div class="page-header">
    <a href="<?= SITE_SUBPATH ?>/docs/list.php" style="font-size:12px;color:var(--text-muted);text-decoration:none;">← Documents</a>
    <h1 style="margin-top:6px;">Approve — <?= htmlspecialchars($doc['doc_number']) ?></h1>
    <p><?= htmlspecialchars($doc['description']) ?></p>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">

    <!-- Doc details -->
    <div class="card">
        <div class="card-title">Document Details</div>
        <table style="font-size:13px;">
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;white-space:nowrap;">Doc Number</td>  <td><code><?= htmlspecialchars($doc['doc_number']) ?></code></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Revision</td>     <td><code><?= htmlspecialchars($doc['revision_label']) ?></code></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Description</td>  <td><?= htmlspecialchars($doc['description']) ?></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Organisation</td> <td><code><?= htmlspecialchars($doc['org_code']) ?></code></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Part</td>         <td><?= $doc['part_number'] ? htmlspecialchars($doc['part_number']) : '<span class="text-dim">Generic</span>' ?></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Uploaded by</td>  <td><?= htmlspecialchars($doc['uploader_name']) ?></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Uploaded at</td>  <td><?= htmlspecialchars($doc['uploaded_at']) ?></td></tr>
            <tr><td class="text-dim" style="padding:5px 12px 5px 0;">Status</td>       <td><span class="badge badge-yellow">DRAFT</span></td></tr>
        </table>

        <!-- PDF Preview -->
        <div style="margin-top:16px;">
            <a href="<?= SITE_SUBPATH ?>/docs/view.php?id=<?= $docId ?>" target="_blank"
               class="btn btn-secondary">Preview PDF ↗</a>
        </div>
    </div>

    <!-- Approval actions -->
    <div class="card">
        <div class="card-title">Approval Actions</div>

        <?php if ($_SESSION['user_id'] == $doc['uploader_id']): ?>
        <div class="alert alert-warning">
            ⚠ You uploaded this document. A <strong>different user</strong> must approve it through standard approval.
        </div>
        <?php endif; ?>

        <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">
            Review the PDF document before approving. Once approved, the document becomes available
            to attach to routing operations.
        </p>

        <form method="POST" style="display:flex;flex-direction:column;gap:10px;">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

            <?php if ($_SESSION['user_id'] != $doc['uploader_id']): ?>
            <button type="submit" name="action" value="approve" class="btn btn-primary">
                ✓ Approve Document
            </button>
            <?php endif; ?>

            <?php if (hasPersona('IT_ADMIN') && AUTO_APPROVE_DOCS): ?>
            <button type="submit" name="action" value="auto_approve" class="btn btn-warning"
                    onclick="return confirm('Auto-approve bypasses the two-user rule. Continue?')">
                ⚡ Auto-Approve (IT Admin)
            </button>
            <?php elseif (hasPersona('IT_ADMIN') && !AUTO_APPROVE_DOCS): ?>
            <div class="text-dim" style="font-size:12px;">Auto-approve is disabled in config.php.</div>
            <?php endif; ?>

            <a href="<?= SITE_SUBPATH ?>/docs/list.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php renderPageEnd(); ?>
