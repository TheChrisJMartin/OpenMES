<?php
/**
 * docs/list.php — Document / Work Instruction List
 * Version: 4.0.0
 * Changes: Show all revisions; superseded=yellow; ARCHIVED status + action
 */

require_once dirname(__DIR__) . '/auth.php';
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/includes/layout.php';

requireLogin();
requirePersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP','ENGINEER','QUALITY_ENGINEER','SUPERVISOR']);

$scope        = orgScope('d');
$filterStatus = $_GET['status'] ?? '';
$filterPartId = (int)($_GET['part'] ?? 0);
$filterOrgId  = (int)($_GET['org']  ?? 0);
$search       = trim($_GET['search'] ?? '');

$where  = '(' . $scope['sql'] . ')';
$params = $scope['params'];

if ($filterStatus && in_array($filterStatus, ['DRAFT','APPROVED','SUPERSEDED','ARCHIVED'])) {
    $where .= ' AND d.status = ?';
    $params[] = $filterStatus;
}
if ($filterPartId) {
    $where .= ' AND d.part_id = ?';
    $params[] = $filterPartId;
}
if ($filterOrgId && hasPersona('IT_ADMIN')) {
    $where .= ' AND d.org_id = ?';
    $params[] = $filterOrgId;
}
if ($search) {
    $where .= ' AND (d.doc_number LIKE ? OR d.description LIKE ?)';
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

// ALL revisions — grouped visually by doc_group_id
$docs = dbFetchAll(
    "SELECT d.*,
            o.code AS org_code,
            p.part_number,
            uu.known_as AS uploader_name,
            ua.known_as AS approver_name,
            ar.known_as AS archiver_name
     FROM documents d
     JOIN orgs o    ON o.id = d.org_id
     LEFT JOIN parts p   ON p.id = d.part_id
     LEFT JOIN users uu  ON uu.id = d.uploaded_by
     LEFT JOIN users ua  ON ua.id = d.approved_by
     LEFT JOIN users ar  ON ar.id = d.archived_by
     WHERE {$where}
     ORDER BY o.code, d.doc_number, d.revision DESC",
    $params
);

// Dropdowns
$orgs  = dbFetchAll("SELECT id,code,name FROM orgs WHERE active=1 AND is_admin=0 ORDER BY code");
$parts = dbFetchAll(
    "SELECT p.id, p.part_number FROM parts p WHERE ({$scope['sql']}) AND p.active=1 ORDER BY p.part_number",
    $scope['params']
);

// Status badge helper — guarded as also defined in includes/helpers.php
if (!function_exists('docStatusBadge')) {
function docStatusBadge(string $status): string {
    return match($status) {
        'APPROVED'   => '<span class="badge badge-green">Approved</span>',
        'DRAFT'      => '<span class="badge badge-blue">Draft</span>',
        'SUPERSEDED' => '<span class="badge badge-yellow">Superseded</span>',
        'ARCHIVED'   => '<span class="badge badge-grey">Archived</span>',
        default      => '<span class="badge badge-grey">' . htmlspecialchars($status) . '</span>',
    };
}
}

// Group docs by doc_group_id so we can draw separators
$grouped = [];
foreach ($docs as $d) {
    $grouped[$d['doc_group_id']][] = $d;
}

renderPageStart('Documents & Work Instructions');
?>

<div class="page-header page-header-row">
    <div>
        <h1>Documents &amp; Work Instructions</h1>
        <p>All revisions shown. Superseded revisions are yellow; archived cannot be attached to routings.</p>
    </div>
    <?php if (hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
    <a href="<?= SITE_SUBPATH ?>/docs/upload.php" class="btn btn-primary">+ Upload Document</a>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card" style="padding:14px 16px;margin-bottom:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Doc number or description…" style="width:220px;">
        </div>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Status</label>
            <select name="status" style="width:140px;">
                <option value="">All Statuses</option>
                <option value="DRAFT"      <?= $filterStatus==='DRAFT'      ?'selected':'' ?>>Draft</option>
                <option value="APPROVED"   <?= $filterStatus==='APPROVED'   ?'selected':'' ?>>Approved</option>
                <option value="SUPERSEDED" <?= $filterStatus==='SUPERSEDED' ?'selected':'' ?>>Superseded</option>
                <option value="ARCHIVED"   <?= $filterStatus==='ARCHIVED'   ?'selected':'' ?>>Archived</option>
            </select>
        </div>
        <?php if (hasPersona('IT_ADMIN')): ?>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Org</label>
            <select name="org" style="width:110px;">
                <option value="0">All Orgs</option>
                <?php foreach ($orgs as $o): ?>
                <option value="<?= $o['id'] ?>" <?= $filterOrgId===$o['id']?'selected':'' ?>><?= htmlspecialchars($o['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div>
            <label style="display:block;font-size:11px;color:var(--text-muted);margin-bottom:4px;">Part</label>
            <select name="part" style="width:200px;">
                <option value="0">All Parts</option>
                <?php foreach ($parts as $p): ?>
                <option value="<?= $p['id'] ?>" <?= $filterPartId===$p['id']?'selected':'' ?>><?= htmlspecialchars($p['part_number']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-secondary">Filter</button>
        <a href="<?= SITE_SUBPATH ?>/docs/list.php" class="btn btn-secondary">Clear</a>
    </form>
</div>

<?php if (!$grouped): ?>
<div class="card" style="text-align:center;padding:40px;color:var(--text-dim);">
    No documents found. <a href="<?= SITE_SUBPATH ?>/docs/upload.php" style="color:var(--accent-blue);">Upload one</a>.
</div>
<?php endif; ?>

<?php foreach ($grouped as $groupId => $revisions):
    $latest = $revisions[0]; // Already sorted DESC so first = latest revision
?>
<div class="card" style="margin-bottom:12px;padding:0;overflow:hidden;">

    <!-- Group header -->
    <div style="padding:11px 16px;background:var(--bg-card2);border-bottom:1px solid var(--border);
                display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <code style="font-size:12px;font-weight:700;color:var(--text);"><?= htmlspecialchars($latest['doc_number']) ?></code>
        <span style="font-size:13px;color:var(--text-muted);flex:1;"><?= htmlspecialchars($latest['description']) ?></span>
        <?php if ($latest['part_number']): ?>
        <code style="font-size:11px;color:var(--text-dim);"><?= htmlspecialchars($latest['part_number']) ?></code>
        <?php else: ?>
        <span style="font-size:11px;color:var(--text-dim);">Generic</span>
        <?php endif; ?>
        <code style="font-size:11px;color:var(--text-dim);"><?= htmlspecialchars($latest['org_code']) ?></code>
        <span style="font-size:11px;color:var(--text-dim);"><?= count($revisions) ?> revision<?= count($revisions)!==1?'s':'' ?></span>
    </div>

    <!-- All revisions table -->
    <div class="table-wrap">
        <table style="margin:0;">
            <thead>
                <tr>
                    <th style="width:80px;">Rev</th>
                    <th style="width:130px;">Status</th>
                    <th>Uploaded By</th>
                    <th>Uploaded At</th>
                    <th>Approved By</th>
                    <th>Approved At</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($revisions as $rev):
                $rowStyle = match($rev['status']) {
                    'ARCHIVED'   => 'opacity:.55;',
                    'SUPERSEDED' => '',
                    default      => '',
                };
            ?>
            <tr style="<?= $rowStyle ?>">
                <td><code class="font-mono" style="font-size:12px;"><?= htmlspecialchars($rev['revision_label']) ?></code></td>
                <td><?= docStatusBadge($rev['status']) ?></td>
                <td style="font-size:12px;"><?= htmlspecialchars($rev['uploader_name'] ?? '—') ?></td>
                <td style="font-size:12px;white-space:nowrap;"><?= htmlspecialchars(substr($rev['uploaded_at'],0,16)) ?></td>
                <td style="font-size:12px;">
                    <?= htmlspecialchars($rev['approver_name'] ?? '—') ?>
                    <?= $rev['auto_approved'] ? '<span title="Auto-approved">⚡</span>' : '' ?>
                </td>
                <td style="font-size:12px;white-space:nowrap;"><?= $rev['approved_at'] ? htmlspecialchars(substr($rev['approved_at'],0,16)) : '—' ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= SITE_SUBPATH ?>/docs/view.php?id=<?= $rev['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">View</a>

                    <?php if ($rev['status'] === 'DRAFT' && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/docs/approve.php?id=<?= $rev['id'] ?>"
                       class="btn btn-primary" style="padding:3px 9px;font-size:11px;">Approve</a>
                    <?php endif; ?>

                    <?php if ($rev['status'] === 'SUPERSEDED' && hasPersona(['IT_ADMIN','MFG_ENGINEER_SUP'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/docs/archive.php?id=<?= $rev['id'] ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;"
                       onclick="return confirm('Archive this revision? Archived docs cannot be attached to routings.')">
                        Archive
                    </a>
                    <?php endif; ?>

                    <?php if ($rev['status'] === 'APPROVED' && hasPersona(['IT_ADMIN','MFG_ENGINEER','MFG_ENGINEER_SUP'])): ?>
                    <a href="<?= SITE_SUBPATH ?>/docs/upload.php?group=<?= urlencode($groupId) ?>"
                       class="btn btn-secondary" style="padding:3px 9px;font-size:11px;">New Rev</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endforeach; ?>

<?php renderPageEnd(); ?>
